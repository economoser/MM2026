function [effwage_m, effwage_f, distrib_m, distrib_f, p_m, p_f, u_m, u_f, Vout_m, Vout_f, Tout_m, Tout_f, adjf_m, adjf_f, pi_m_out, pi_f_out] = fun_solve_equalpay( ...
        params, delta_m, delta_f, lambda_u_m, lambda_u_f, lambda_e_m, ...
        lambda_e_f, lambda_god_m, lambda_god_f, meas_m, meas_f, phi, ...
        costIN_m, costIN_f, c_v_in_m, c_v_in_f, ppi_in_m, ppi_in_f, pi_m, ...
        pi_f, only_m, only_f, eta_v, eta_amenities)

    %==========================================================================
    % DESCRIPTION: This helper function solves the equal pay policy by solving the wage/amenities posting problem
    %              firm-by-firm, and finds the offer distribution that is
    %              consistent with firms' choices
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - parameters, labor market objects, measures of men and
    %                women, outside options, vacancy costs, composite productivities,
    %                amenities, single-gender dummies, elasticities
    %
    % OUTPUTS:     - the utility postings (effwage_x), the offer distributions
    %                (distrib_x), composite productivity (p_x), the
    %                unemployment rates (u_x), the aggregate vacancies (V_x), T
    %                (Tout_x), the adjustment factors for lambda_u (adjf_x),
    %                endogenous amenities (pi_x_out) for each gender x=m,f
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % Specify how to aggregate vacancies, dummy for one-gender firms in data
    method_ladder = 2; % 2 = sum over firms. 1 = weigh by the distribution
    onegender = (only_m | only_f);

    % Codes used by initial guesses
    % grid_width_wpi_m = 1.5; % maximum utility spread allowed in solution grid
    % grid_width_wpi_f = 1.2;

    %Bandwitdh of kernel CDF estimation
    cdfbw = 0.01;

    %Instead of using FOC, this function aims to directly maximize profits
    phi_m = phi(1);
    phi_f = phi(2);
    alpha = params(4);
    toll = 10^(-6);
    % opts_fzero = optimset('Display','iter');
    opts_neldermead = optimset('Display','iter','TolX',toll,'TolFun',toll);
    % algo_solution = 'fixed_point'; % this option allows iterative solution, useful at the beginning but not for refinement
    algo_solution='fsolve';

    % Back out amenity cost shifters and options for fsolve
    if eta_amenities > 0
        pi_cost_m=1./(pi_m.^(eta_amenities-1));
        pi_cost_f=1./(pi_f.^(eta_amenities-1));
        opts_fsolve=optimoptions(@fsolve, 'Display','iter','FiniteDifferenceStepSize',10^(-3),'StepTolerance',sqrt(1e-5),...
            'FunctionTolerance',toll,'OptimalityTolerance',toll,'UseParallel',true,'FiniteDifferenceType','forward','MaxFunctionEvaluations',2000);
    elseif eta_amenities == 0
        opts_fsolve=optimoptions(@fsolve, 'Display','iter','FiniteDifferenceStepSize',10^(-3),'StepTolerance',sqrt(1e-5),...
            'FunctionTolerance',toll,'OptimalityTolerance',toll,'UseParallel',true,'FiniteDifferenceType','forward','MaxFunctionEvaluations',2000);
    end
    opts_fsolve2=optimoptions(@fsolve, 'Display','iter','FiniteDifferenceStepSize',10^(-6),...
        'FunctionTolerance',toll,'OptimalityTolerance',toll,'UseParallel',false);
    opts_fmincon=optimoptions(@fmincon, 'Display','iter','FiniteDifferenceStepSize',10^(-3),...
        'FunctionTolerance',toll,'OptimalityTolerance',toll);

    %options for solution algorithm
    maxiter_iterative_solution=0; %set this to 200 the first time to allow convergence to a better guess
    continue_with_fsolve=1;
    immediate_solution=1; %if the current point is at the solution, stop immediately
    toll_immediate=3e-3;
    mode_approx_F='spline';
    mode_approx_outside_F='nearest';
    use_sigmoid_code=false;
    graph_convergence=false; %set to true to visually check convergence

    %set up file for guess
    if (eta_amenities > 0)
        loadfile_guess=sprintf('%s/guesses/guess_F_policy_equalpay.mat',DIR_INPUT);
    elseif (eta_amenities == 0)
        loadfile_guess=sprintf('%s/guesses/guess_F_policy_equalpay_exo.mat',DIR_INPUT);
    end

    %Number of firms for aggregates
    N=numel(ppi_in_m);
    N_m=numel(ppi_in_m);
    N_f=numel(ppi_in_f);

    [ppi_in_m_sorted,idx_ppi_m]=sort(ppi_in_m);
    [ppi_in_f_sorted,idx_ppi_f]=sort(ppi_in_f);

    d_allrungs_m=ones(numel(ppi_in_m),1).*(1/N_m);
    d_allrungs_f=ones(numel(ppi_in_f),1).*(1/N_f);

    change_ppi_in_m=ppi_in_m_sorted(2:end)-ppi_in_m_sorted(1:end-1);
    change_ppi_in_m(N_m)=change_ppi_in_m(N_m-1);
    change_ppi_in_f=ppi_in_f_sorted(2:end)-ppi_in_f_sorted(1:end-1);
    change_ppi_in_f(N_f)=change_ppi_in_f(N_f-1);
    if method_ladder == 2
        change_ppi_in_m=change_ppi_in_m.*0 + 1;
        change_ppi_in_f=change_ppi_in_f.*0 + 1;
    end

    p_in_m=ppi_in_m-pi_m;
    p_in_f=ppi_in_f-pi_f;

    gridpoints_F=63; %63;   %Default is 63 grid points, less is too imprecise

    %sqrt-spaced grids
    if eta_amenities == 0
        grid_wpi_m=(linspace(0,sqrt(max(ppi_in_m-phi_m)),gridpoints_F+1)').^2+phi_m;
        grid_wpi_f=(linspace(0,sqrt(max(ppi_in_f-phi_f)),gridpoints_F+1)').^2+phi_f;
    else
        grid_wpi_m=(linspace(0,sqrt(max(ppi_in_m-phi_m+0.1)),gridpoints_F+1)').^2+phi_m; %larger grid for values outside
        grid_wpi_f=(linspace(0,sqrt(max(ppi_in_f-phi_f+0.1)),gridpoints_F+1)').^2+phi_f; %larger grid for values outside
    end

    %useful precalculations for later
    pi_m_both=pi_m(not(onegender));
    pi_f_both=pi_f(not(onegender));

    p_in_m_both=p_in_m(not(onegender));
    p_in_f_both=p_in_f(not(onegender));
    pi_cost_m_both=pi_cost_m(not(onegender));
    pi_cost_f_both=pi_cost_f(not(onegender));
    N_m_both=numel(p_in_m_both);
    N_f_both=numel(p_in_f_both);

    %Constraints for fmincon (usually not used)
    Acon=eye(gridpoints_F*2);
    for k=1:gridpoints_F-1
        Acon(k,k+1)=-1;
    end
    for k=gridpoints_F+1:gridpoints_F*2-1
        Acon(k,k+1)=-1;
    end
    Acon(gridpoints_F,gridpoints_F)=0;
    Acon(gridpoints_F*2,gridpoints_F*2)=0;
    bcon=zeros(gridpoints_F*2,1);

    % Precalculations for optimization problem
    if eta_amenities > 0
        p_in_m_nocost=p_in_m+(pi_cost_m./eta_amenities).*(pi_m.^eta_amenities);
        p_in_f_nocost=p_in_f+(pi_cost_f./eta_amenities).*(pi_f.^eta_amenities);
        p_in_m_both_nocost=p_in_m_both+(pi_cost_m_both./eta_amenities).*(pi_m_both.^eta_amenities);
        p_in_f_both_nocost=p_in_f_both+(pi_cost_f_both./eta_amenities).*(pi_f_both.^eta_amenities);
    else
        p_in_m_nocost=p_in_m;
        p_in_f_nocost=p_in_f;
        p_in_m_both_nocost=p_in_m_both;
        p_in_f_both_nocost=p_in_f_both;
    end


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % BEGINNING OF INLINE FUNCTIONS
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function [res_fun_F,out_F_m,out_F_f,w_m_now,w_f_now,v_m_now,v_f_now,maxesout,pi_m_now,pi_f_now,...
            profits_both,profits_onlymen,profits_onlywomen] = solve_f_with_fsolve(allF,cnow_m2,cnow_f2,~,~,...
            TT_in_m2,TT_in_f2,adjf_in_m2,adjf_in_f2,w_m_old2,w_f_old2,v_m_old2,v_f_old2,...
            old_profits_both,old_profits_onlym,old_profits_onlyf,adjfac2,use_sigmoid) % Inline function that solves the maximization problem of firms under the equal-pay policy

        %==========================================================================
        % DESCRIPTION: This inline function solves the problem firm-by-firm, maximizing profits for both amenities and wages
		%              under the constraint that wages must be identical for both genders, but amenities can be set freely
        %
        % AUTHORS:     Iacopo Morchio (University of Bristol)
		%              Christian Moser (Columbia University)
        %
        % DATE:        November 4, 2025
        %==========================================================================

        %extract f_m and f_f
        if use_sigmoid      %from deep learning: use continuous function
            guess_h_m2=[0; 1./(1+exp(-allF(1:gridpoints_F)))];
            guess_h_f2=[0; 1./(1+exp(-allF(gridpoints_F+1:gridpoints_F*2)))];
        else
            guess_h_m2=[0; allF(1:gridpoints_F)];
            guess_h_f2=[0; allF(gridpoints_F+1:gridpoints_F*2)];
        end

        % Define interpolators for offer CDF
        h_intermed_m=griddedInterpolant(grid_wpi_m,guess_h_m2,mode_approx_F,mode_approx_outside_F);
        h_intermed_f=griddedInterpolant(grid_wpi_f,guess_h_f2,mode_approx_F,mode_approx_outside_F);

        % Define interpolators for firm size calculations
        size_intermed_m=griddedInterpolant(grid_wpi_m,(1./(delta_m + adjf_in_m2.*lambda_god_m + adjf_in_m2.*lambda_e_m.*(1-min(max(guess_h_m2,0),1))).^2),mode_approx_F,mode_approx_outside_F);
        size_intermed_f=griddedInterpolant(grid_wpi_f,(1./(delta_f + adjf_in_f2.*lambda_god_f + adjf_in_f2.*lambda_e_f.*(1-min(max(guess_h_f2,0),1))).^2),mode_approx_F,mode_approx_outside_F);

        h_fun_m=@(x) min(max(h_intermed_m(x),0),1);
        h_fun_f=@(x) min(max(h_intermed_f(x),0),1);

        max_wpi_m=min(grid_wpi_m(h_fun_m(grid_wpi_m)==1));
        max_wpi_f=min(grid_wpi_f(h_fun_f(grid_wpi_f)==1));
        if isempty(max_wpi_m), max_wpi_m=max(grid_wpi_m); end
        if isempty(max_wpi_f), max_wpi_f=max(grid_wpi_f); end

        precalc_m=(1./(cnow_m2.*c_v_in_m));
        precalc_f=(1./(cnow_f2.*c_v_in_f));
        precalc_m_both=precalc_m(not(onegender));
        precalc_f_both=precalc_f(not(onegender));

        lowerlimitboth=max(phi_m*ones(N_m_both,1)-pi_m_both+1e-13,phi_f*ones(N_f_both,1)-pi_f_both+1e-13);
        upperlimitboth=min(min(max(max(grid_wpi_m)-pi_m_both,max(grid_wpi_f)-pi_f_both),p_in_m_both),p_in_f_both)-1e-13;
        upperlimitboth(upperlimitboth<lowerlimitboth)=lowerlimitboth(upperlimitboth<lowerlimitboth);

        if eta_amenities == 0
            % version with exogenous amenities
            % the function interpolates size directly rather than F
            [w_both_out]=fun_golden_multi_correct(@(ww) -((p_in_m_both-ww).*TT_in_m2.*size_intermed_m(ww+pi_m_both).* ... %per-worker profits and size
                ((max((p_in_m_both-ww),0).*precalc_m_both.*(   ((  ((TT_in_m2).*size_intermed_m(ww+pi_m_both)) )))).^(1./(eta_v-1)))) - ... %vacancy creation margin
                ((p_in_f_both-ww).*TT_in_f2.*size_intermed_f(ww+pi_f_both).* ... %per-worker profits and size
                ((max((p_in_f_both-ww),0).*precalc_f_both.*(   ((  ((TT_in_f2).*size_intermed_f(ww+pi_f_both)) )))).^(1./(eta_v-1)))), ...
                lowerlimitboth,upperlimitboth,toll);
            pi_m_endog_both=pi_m;
            pi_f_endog_both=pi_f;
        else
            % version with endogenous amenities: features a second inner
            % maximization problem in which firms optimally choose amenities
            % the problem does not change for single-gender firms (they still
            % satisfy marginal cost of amenities = 1)
            % This function interpolates size directly rather than F
            [w_both_out]=fun_golden_multi_correct(@(ww) max_problem_both_pi_w_DERIVATIVES_v2(p_in_m_both_nocost-ww,p_in_f_both_nocost-ww,ww,...
                pi_cost_m_both,pi_cost_f_both,precalc_m_both,precalc_f_both,lambda_e_m,lambda_e_f,...
                delta_m,delta_f,lambda_god_m,lambda_god_f,eta_amenities,adjf_in_m2,adjf_in_f2,...
                size_intermed_m,size_intermed_f,TT_in_m2,TT_in_f2,phi_m,phi_f,max_wpi_m,max_wpi_f,eta_v),...
                toll*ones(N_m_both,1),max(p_in_m_both_nocost-toll,p_in_f_both_nocost-toll),toll);
            [~,pi_m_endog_both2,pi_f_endog_both2] = max_problem_both_pi_w_DERIVATIVES_v2(p_in_m_both_nocost-w_both_out,p_in_f_both_nocost-w_both_out,w_both_out,...
                pi_cost_m_both,pi_cost_f_both,precalc_m_both,precalc_f_both,lambda_e_m,lambda_e_f,...
                delta_m,delta_f,lambda_god_m,lambda_god_f,eta_amenities,adjf_in_m2,adjf_in_f2,...
                size_intermed_m,size_intermed_f,TT_in_m2,TT_in_f2,phi_m,phi_f,max_wpi_m,max_wpi_f,eta_v);

            pi_m_endog_both=pi_m;
            pi_f_endog_both=pi_f;
            pi_m_endog_both(not(onegender))=pi_m_endog_both2;
            pi_f_endog_both(not(onegender))=pi_f_endog_both2;

        end
        w_both=p_in_m.*0;
        w_both(not(onegender))=w_both_out;

        % Exclude firms that prefer to hire both genders
        % Requires computing profits for dual-gendered firms first, then compare
        if eta_amenities > 0
            v_m_both=((TT_in_m2./(cnow_m2.*c_v_in_m)).*max((p_in_m_nocost - w_both - (pi_cost_m./eta_amenities).*(pi_m_endog_both.^eta_amenities)),0).*(1./(delta_m + adjf_in_m2.*(lambda_god_m + lambda_e_m.*(1-h_fun_m(w_both+pi_m_endog_both)))).^2)).^(1./(eta_v-1));
            v_f_both=((TT_in_f2./(cnow_f2.*c_v_in_f)).*max((p_in_f_nocost - w_both - (pi_cost_f./eta_amenities).*(pi_f_endog_both.^eta_amenities)),0).*(1./(delta_f + adjf_in_f2.*(lambda_god_f + lambda_e_f.*(1-h_fun_f(w_both+pi_f_endog_both)))).^2)).^(1./(eta_v-1));
        elseif eta_amenities==0
            v_m_both=((TT_in_m2./(cnow_m2.*c_v_in_m)).*(p_in_m_nocost - w_both).*(1./(delta_m + adjf_in_m2.*(lambda_god_m + lambda_e_m.*(1-h_fun_m(w_both+pi_m_endog_both)))).^2)).^(1./(eta_v-1));
            v_f_both=((TT_in_f2./(cnow_f2.*c_v_in_f)).*(p_in_f_nocost - w_both).*(1./(delta_f + adjf_in_f2.*(lambda_god_f + lambda_e_f.*(1-h_fun_f(w_both+pi_f_endog_both)))).^2)).^(1./(eta_v-1));
        end

        % if the above returns negative vacancies, these firms need to be shut down
        v_m_both(p_in_m-w_both<0)=0;
        v_f_both(p_in_f-w_both<0)=0;
        v_m_both(w_both==0)=0;
        v_f_both(w_both==0)=0;
        v_m_both(v_m_both<0)=0;
        v_f_both(v_f_both<0)=0;

        % Firms that are offering below outside option cannot hire
        v_m_both(w_both+pi_m_endog_both<phi_m)=0;
        v_f_both(w_both+pi_f_endog_both<phi_f)=0;

        % Computes profits under dual-gender hiring
        if eta_amenities > 0
            profits_both=(p_in_m_nocost - w_both - (pi_cost_m./eta_amenities).*(pi_m_endog_both.^eta_amenities)).*(v_m_both.*TT_in_m2).*(1./(delta_m + adjf_in_m2.*(lambda_god_m + lambda_e_m.*(1-h_fun_m(w_both+pi_m_endog_both)))).^2) + ...
                (p_in_f_nocost - w_both - (pi_cost_f./eta_amenities).*(pi_f_endog_both.^eta_amenities)).*(v_f_both.*TT_in_f2).*(1./(delta_f + adjf_in_f2.*(lambda_god_f + lambda_e_f.*(1-h_fun_f(w_both+pi_f_endog_both)))).^2) ...
                -(cnow_m2.*c_v_in_m./2).*(v_m_both.^eta_v) - (cnow_f2.*c_v_in_f./2).*(v_f_both.^eta_v);
        elseif eta_amenities == 0
            profits_both=(p_in_m - w_both).*(v_m_both.*TT_in_m2).*(1./(delta_m + adjf_in_m2.*(lambda_god_m + lambda_e_m.*(1-h_fun_m(w_both+pi_m_endog_both)))).^eta_v) + ...
                (p_in_f - w_both).*(v_f_both.*TT_in_f2).*(1./(delta_f + adjf_in_f2.*(lambda_god_f + lambda_e_f.*(1-h_fun_f(w_both+pi_f_endog_both)))).^eta_v) ...
                -(cnow_m2.*c_v_in_m./eta_v).*(v_m_both.^eta_v) - (cnow_f2.*c_v_in_f./2).*(v_f_both.^eta+v);
        end

        % construct best-case scenario profits for single-gender hiring
        % That is: wage = outside option minus optimal amenities (phi_g-pi_g)
        % This is to remove cases in which single-gender hiring is not more
        % profitable than dual-gender hiring even if utility is set at the
        % outside option
        bestcase_profits_onlym=((p_in_m-phi_m+pi_m).*(p_in_m-phi_m+pi_m).*precalc_m.*(((TT_in_m2)./((delta_m + adjf_in_m2.*lambda_god_m).^2)).^2));
        bestcase_profits_onlyf=((p_in_f-phi_f+pi_f).*(p_in_f-phi_f+pi_f).*precalc_f.*(((TT_in_f2)./((delta_f + adjf_in_f2.*lambda_god_f).^2)).^2));
        bestboth_m=(profits_both>bestcase_profits_onlym);
        bestboth_f=(profits_both>bestcase_profits_onlyf);

        selec_only_m=(not(only_f) & not(bestboth_m));
        selec_only_f=(not(only_m) & not(bestboth_f));
        p_in_m_onlym=p_in_m(selec_only_m);
        p_in_f_onlyf=p_in_f(selec_only_f);
        N_m_onlym=numel(p_in_m_onlym);
        N_f_onlyf=numel(p_in_f_onlyf);
        pi_m_onlym=pi_m(selec_only_m);
        pi_f_onlyf=pi_f(selec_only_f);
        minw_m_onlym=max(phi_m*ones(N_m_onlym,1)-pi_m_onlym,0)+toll;
        minw_f_onlyf=max(phi_f*ones(N_f_onlyf,1)-pi_f_onlyf,0)+toll;

        % Profit maximization for single-gender firms
        % The idea: if a firm decides to become single-gender to avoid the policy, it can only hire one gender,
        % and therefore will choose the profit-maximizing one
        [w_onlymen_out]=fun_golden_multi_correct(@(ww) -(((p_in_m_onlym-ww)./((delta_m + adjf_in_m2.*(lambda_god_m + lambda_e_m.*(1-min(max(h_intermed_m(ww+pi_m_onlym),0),1)))).^2))),...
            minw_m_onlym,p_in_m_onlym,toll);
        [w_onlywomen_out]=fun_golden_multi_correct(@(ww) -(((p_in_f_onlyf-ww)./((delta_f + adjf_in_f2.*(lambda_god_f + lambda_e_f.*(1-min(max(h_intermed_f(ww+pi_f_onlyf),0),1)))).^2))),...
            minw_f_onlyf,p_in_f_onlyf,toll);

        w_onlymen=p_in_m.*0;
        w_onlywomen=p_in_f.*0;
        w_onlymen(selec_only_m)=w_onlymen_out;
        w_onlywomen(selec_only_f)=w_onlywomen_out;

        v_m_onlymen=((TT_in_m2./(cnow_m2.*c_v_in_m)).*(p_in_m - w_onlymen).*(1./(delta_m + adjf_in_m2.*(lambda_god_m + lambda_e_m.*(1-h_fun_m(w_onlymen+pi_m)))).^2)).^(1./(eta_v-1));
        v_f_onlymen=zeros(N,1);
        v_m_onlywomen=zeros(N,1);
        v_f_onlywomen=((TT_in_f2./(cnow_f2.*c_v_in_f)).*(p_in_f - w_onlywomen).*(1./(delta_f + adjf_in_f2.*(lambda_god_f + lambda_e_f.*(1-h_fun_f(w_onlywomen+pi_f)))).^2)).^(1./(eta_v-1));

        % shut down firms with negative vacancies (if they occur)
        v_m_onlymen(p_in_m-w_onlymen<0)=0;
        v_f_onlywomen(p_in_f-w_onlywomen<0)=0;
        v_m_onlymen(w_onlymen==0)=0;
        v_f_onlywomen(w_onlywomen==0)=0;

        % now compute profits under different scenarios
        profits_onlymen=(p_in_m-w_onlymen).*(v_m_onlymen.*TT_in_m2).*(1./(delta_m + adjf_in_m2.*(lambda_god_m + lambda_e_m.*(1-h_fun_m(w_onlymen+pi_m)))).^2) ...
            - (cnow_m2.*c_v_in_m./eta_v).*(v_m_onlymen.^eta_v);
        profits_onlywomen=(p_in_f-w_onlywomen).*(v_f_onlywomen.*TT_in_f2).*(1./(delta_f + adjf_in_f2.*(lambda_god_f + lambda_e_f.*(1-h_fun_f(w_onlywomen+pi_f)))).^2) ...
            - (cnow_f2.*c_v_in_f./eta_v).*(v_f_onlywomen.^eta_v);

        %Smooth profits to improve convergence (experimental)
        profits_both=adjfac2.*old_profits_both + (1-adjfac2).*profits_both;
        profits_onlymen=adjfac2.*old_profits_onlym + (1-adjfac2).*profits_onlymen;
        profits_onlywomen=adjfac2.*old_profits_onlyf + (1-adjfac2).*profits_onlywomen;

        [~,whattodo]=max([profits_both profits_onlymen profits_onlywomen zeros(N,1)+eps],[],2);
        whattodo(only_m)=2;
        whattodo(only_f)=3;

        %whattodo==1 --> hire both, ==2 --> hire only men, ==3 --> hire only women
        w_m_now=(whattodo==1).*w_both + (whattodo==2).*w_onlymen;
        w_f_now=(whattodo==1).*w_both + (whattodo==3).*w_onlywomen;
        pi_m_now=(whattodo==1).*pi_m_endog_both + (whattodo==2).*pi_m + (whattodo==3).*pi_m + (whattodo==4).*pi_m;
        pi_f_now=(whattodo==1).*pi_f_endog_both + (whattodo==2).*pi_f + (whattodo==3).*pi_f + (whattodo==4).*pi_f;
        v_m_now=((whattodo==1).*v_m_both + (whattodo==2).*v_m_onlymen + (whattodo==3).*v_m_onlywomen);
        v_f_now=((whattodo==1).*v_f_both + (whattodo==2).*v_f_onlymen + (whattodo==3).*v_f_onlywomen);

        %Smoothing factor, used only for iterative solution
        if adjfac2 > 0
            whichtoadjust_m=(w_m_now>0 & ((v_m_old2>0 & v_m_now>0)));
            whichtoadjust_f=(w_f_now>0 & ((v_f_old2>0 & v_f_now>0)));
            w_m_now(whichtoadjust_m)=adjfac2*w_m_old2(whichtoadjust_m) + (1-adjfac2)*w_m_now(whichtoadjust_m);
            w_f_now(whichtoadjust_f)=adjfac2*w_f_old2(whichtoadjust_f) + (1-adjfac2)*w_f_now(whichtoadjust_f);

            w_m_now(v_m_now>0 & (whattodo==1 | whattodo==2))=max(w_m_now(v_m_now>0 & (whattodo==1 | whattodo==2)),phi_m-pi_m_now(v_m_now>0 & (whattodo==1 | whattodo==2))+1e-12);
            w_f_now(v_f_now>0 & (whattodo==1 | whattodo==3))=max(w_f_now(v_f_now>0 & (whattodo==1 | whattodo==3)),phi_f-pi_f_now(v_f_now>0 & (whattodo==1 | whattodo==3))+1e-12);

            v_m_now(w_m_now>0 & v_m_old2>0 & v_m_now>0)=adjfac2*v_m_old2(w_m_now>0 & v_m_old2>0 & v_m_now>0) + (1-adjfac2)*v_m_now(w_m_now>0 & v_m_old2>0 & v_m_now>0);
            v_f_now(w_f_now>0 & v_f_old2>0 & v_f_now>0)=adjfac2*v_f_old2(w_f_now>0 & v_f_old2>0 & v_f_now>0) + (1-adjfac2)*v_f_now(w_f_now>0 & v_f_old2>0 & v_f_now>0);
            %additional adjustment to smooth vacancies over guess iterations
            v_m_now(w_m_now+pi_m_now>phi_m & v_m_now>0)=adjfac2*v_m_old2(w_m_now+pi_m_now>phi_m & v_m_now>0) + (1-adjfac2)*v_m_now(w_m_now+pi_m_now>phi_m & v_m_now>0);
            v_f_now(w_f_now+pi_f_now>phi_f & v_f_now>0)=adjfac2*v_f_old2(w_f_now+pi_f_now>phi_f & v_f_now>0) + (1-adjfac2)*v_f_now(w_f_now+pi_f_now>phi_f & v_f_now>0);

        end

        %Use kernel density to obtain F estimates
        maxesout=[max(w_m_now(v_m_now>0)+pi_m_now(v_m_now>0)); max(w_f_now(v_f_now>0)+pi_f_now(v_f_now>0))];
        excess=0.00000001;
        out_F_m=zeros(gridpoints_F+1,1);
        out_F_f=zeros(gridpoints_F+1,1);

        selecpoints_notone_F_m_grid=(grid_wpi_m>0); %(grid_wpi_m<maxesout(1));
        selecpoints_notone_F_f_grid=(grid_wpi_f>0); %(grid_wpi_f<maxesout(2));
        selecobs_F_m=(v_m_now>0);
        selecobs_F_f=(v_f_now>0);

        [out_F_m(selecpoints_notone_F_m_grid)]=ksdensity(w_m_now(selecobs_F_m)+pi_m_now(selecobs_F_m),grid_wpi_m(selecpoints_notone_F_m_grid),...
            'Support',[min(grid_wpi_m)-excess max(grid_wpi_m)+excess],...
            'Weights',v_m_now(selecobs_F_m),'BoundaryCorrection','reflection','Function','cdf','Bandwidth',cdfbw);
        [out_F_f(selecpoints_notone_F_f_grid)]=ksdensity(w_f_now(selecobs_F_f)+pi_f_now(selecobs_F_f),grid_wpi_f(selecpoints_notone_F_f_grid),...
            'Support',[min(grid_wpi_f)-excess max(grid_wpi_f)+excess],...
            'Weights',v_f_now(selecobs_F_f),'BoundaryCorrection','reflection','Function','cdf','Bandwidth',cdfbw);

        out_F_m(1)=0;
        out_F_f(1)=0;

        % Define loss function for algorithm: difference between input F and
        % output F
        res_fun_F=[out_F_m(2:end); out_F_f(2:end)]-[guess_h_m2(2:end); guess_h_f2(2:end)];

        %graph current difference between input F and output F
        taskplot=getCurrentTask();
        if (isempty(taskplot) && graph_convergence)
            howmanypoints_m=sum(grid_wpi_m<=maxesout(1));
            howmanypoints_f=sum(grid_wpi_f<=maxesout(2));
            figure(1005); %sets figure for evolution of distribution
            subplot(1,2,1), plot(grid_wpi_m(grid_wpi_m<=maxesout(1)),out_F_m(grid_wpi_m<=maxesout(1)),'b');
            hold on; plot(grid_wpi_m(grid_wpi_m<=maxesout(1)),[0; guess_h_m2(2:howmanypoints_m)],'r'); hold off; legend('F_m','F_in_m','Location','northwest');
            title(sprintf('Int. Dist: %g',sqrt((sum(res_fun_F(1:howmanypoints_m-1).^2))/howmanypoints_m)));
            subplot(1,2,2), plot(grid_wpi_f(grid_wpi_f<=maxesout(2)),out_F_f(grid_wpi_f<=maxesout(2)),'b');
            hold on; plot(grid_wpi_f(grid_wpi_f<=maxesout(2)),[0; guess_h_f2(2:howmanypoints_f)],'r'); hold off; legend('F_f','F_in_f','Location','northwest');
            drawnow;

            grid_wpi_m_load=grid_wpi_m;
            grid_wpi_f_load=grid_wpi_f;

            allF2=[guess_h_m2(2:end); guess_h_f2(2:end)];
            save(loadfile_guess,'allF2','grid_wpi_m_load','grid_wpi_f_load');
        end
    end


    function [vout_m,vout_f,wpi_m,wpi_f,h_m,h_f,guess_h_m,guess_h_f,pi_m_out1,pi_f_out1] = mysystem_inline(cnow_m,cnow_f,vv_in_m,vv_in_f,...
            TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,previous_h_m,previous_h_f) % Inline function that attempts to find the offer CDF for both genders that is consistent with equilibrium

        %==========================================================================
        % DESCRIPTION: This function solves for the offer CDF by calling the above inline function to solve the firm's problem
        %
        % AUTHORS:     Iacopo Morchio (University of Bristol)
		%              Christian Moser (Columbia University)
        %
        % DATE:        November 4, 2025
        %==========================================================================

        guess_F_m=previous_h_m;
        guess_F_f=previous_h_f;

        guess_F_m=guess_F_m/max(guess_F_m);
        guess_F_f=guess_F_f/max(guess_F_f);

        v_m_old=ones(N_m,1).*vv_in_m;
        v_f_old=ones(N_f,1).*vv_in_f;

        w_m_old=rand(N,1);
        w_f_old=rand(N,1);
        old_profits_both2=zeros(N,1);
        old_profits_onlym2=zeros(N,1);
        old_profits_onlyf2=zeros(N,1);
        disthere=100;
        distf_old=100;
        dist_w=100;   distv_m=100;    distv_f=100;
        meandist_w=100; distf=100;
        meandistv_m=100;
        meandistv_f=100;

        iter_1=0;
        adjfac=0; %at the start, immediately update guess with new one
        % Given guesses, solve for wages and amenities
        while (disthere > toll) && (iter_1 < maxiter_iterative_solution)
            iter_1=iter_1+1;
            if iter_1 == 2
                adjfac=0.75;
            end

            % Solve the problem
            [res_fun_F_out,guess_F_m2,guess_F_f2,w_m_now,w_f_now,v_m_now,v_f_now,~,~,~,profits_both_out,profits_onlym_out,profits_onlyf_out]=...
                solve_f_with_fsolve([guess_F_m(2:end); guess_F_f(2:end);],cnow_m,cnow_f,vv_in_m,vv_in_f,TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,...
                w_m_old,w_f_old,v_m_old,v_f_old,old_profits_both2,old_profits_onlym2,old_profits_onlyf2,adjfac,false);

            % Slow adjustment of new guess in iterative solution
            guess_adj=0.5; %min(0.01,disthere);
            guess_F_m=guess_adj*guess_F_m + (1-guess_adj)*guess_F_m2;
            guess_F_f=guess_adj*guess_F_f + (1-guess_adj)*guess_F_f2; %slow adjustment of f to improve convergence
            guess_F_m=max(min(guess_F_m,1),0);
            guess_F_f=max(min(guess_F_f,1),0);

            % Construct distances of policies
            dist_w=max(abs(w_m_now-w_m_old))+max(abs(w_f_now-w_f_old));
            distv_m=max(abs(v_m_now-v_m_old));
            distv_f=max(abs(v_f_now-v_f_old));
            meandist_w=mean(abs(w_m_now-w_m_old))+mean(abs(w_f_now-w_f_old));
            meandistv_m=mean(abs(v_m_now-v_m_old));
            meandistv_f=mean(abs(v_f_now-v_f_old));

            w_m_old=w_m_now;
            w_f_old=w_f_now;
            v_m_old=v_m_now; v_f_old=v_f_now;
            old_profits_both2=profits_both_out;
            old_profits_onlym2=profits_onlym_out;
            old_profits_onlyf2=profits_onlyf_out;

            distf=sqrt(sum(res_fun_F_out.^2)/(2*gridpoints_F));
            disthere=distf;

            if mod(iter_1,10) == 0
                fprintf('Iter %g, Dist is %g, AdjFac is %g \n',iter_1,disthere,adjfac);
            end

            if distf > distf_old
                adjfac=adjfac+0.005;
            else
                if iter_1 < 300
                    adjfac=adjfac-0.001;
                elseif iter_1 < 600
                    adjfac=adjfac-0.0001;
                else
                    adjfac=adjfac-distf;
                end
            end

            %Keep adjustment factors of guesses within bounds
            adjfac=min(adjfac,0.9);
            adjfac=max(adjfac,0.5);

            distf_old=distf;

        end

        fprintf('Took %g iterations to converge. \n',iter_1);
        fprintf('Distances: w %g, v_m %g, v_f %g, f %g \n',dist_w,distv_m,distv_f,distf);
        fprintf('Mean Distance: w %g, v_m %g, v_f %g \n',meandist_w,meandistv_m,meandistv_f);

        %at the end of iterative loop, check solution. If within tolerance, just move on.
        %if not, improve with fsolve (SLOW)
        if (iter_1 > 0) || (immediate_solution)
            [dist_F_here,F_m_final,F_f_final,~,~,~,~,~,~,~]=solve_f_with_fsolve([guess_F_m(2:end); guess_F_f(2:end)],cnow_m,cnow_f,vv_in_m,vv_in_f,...
                TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,w_m_old,w_f_old,v_m_old,v_f_old,old_profits_both2,old_profits_onlym2,old_profits_onlyf2,0,use_sigmoid_code);
        else
            dist_F_here=100;
        end
        if sqrt(sum(dist_F_here.^2)/(2*gridpoints_F)) < toll_immediate
            fprintf('Equilibrium is within tolerance, stopping immediately. \n');
        elseif continue_with_fsolve==1
            if strcmp(algo_solution,'fsolve')
                %refine estimate of density with fsolve
                %convert Fguess to sigmoid coefficients if option is used
                if use_sigmoid_code
                    guess_F_m=min(max(guess_F_m,0.000001),0.9999);
                    guess_F_f=min(max(guess_F_f,0.000001),0.9999); %adjustment to avoid zeros and NaNs in sigmoid
                    guess_F_m(2:end)=-log( (1-guess_F_m(2:end))./guess_F_m(2:end));
                    guess_F_f(2:end)=-log( (1-guess_F_f(2:end))./guess_F_f(2:end));
                end
                [Fouthere]=fsolve(@(ff) (solve_f_with_fsolve(ff,cnow_m,cnow_f,vv_in_m,vv_in_f,...
                    TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,w_m_old,w_f_old,v_m_old,v_f_old,old_profits_both2,old_profits_onlym2,old_profits_onlyf2,0,use_sigmoid_code)),...
                    [guess_F_m(2:end); guess_F_f(2:end)],opts_fsolve);
                if use_sigmoid_code
                    Fouthere=1./(1+exp(-Fouthere));
                end
            elseif strcmp(algo_solution,'fminsearch')
                %refine estimate of density with fminsearch
                [Fouthere]=fminsearch(@(ff) sqrt(sum(solve_f_with_fsolve(ff,cnow_m,cnow_f,vv_in_m,vv_in_f,...
                    TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,w_m_old,w_f_old,v_m_old,v_f_old,old_profits_both2,old_profits_onlym2,old_profits_onlyf2,0,false).^2)/(gridpoints_F*2)),...
                    [guess_F_m(2:end); guess_F_f(2:end)],opts_neldermead);
            elseif strcmp(algo_solution,'fmincon')
                [Fouthere]=fmincon(@(ff) sum((solve_f_with_fsolve(ff,cnow_m,cnow_f,vv_in_m,vv_in_f,...
                    TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,w_m_old,w_f_old,v_m_old,v_f_old,old_profits_both2,old_profits_onlym2,old_profits_onlyf2,0,false)).^2),...
                    [guess_F_m(2:end); guess_F_f(2:end)],Acon,bcon,[],[],zeros(gridpoints_F*2,1)-eps,ones(gridpoints_F*2,1)+eps,[],opts_fmincon);
            end
            F_m_final=[0; Fouthere(1:gridpoints_F)];
            F_f_final=[0; Fouthere(gridpoints_F+1:2*gridpoints_F)];
        end
        if immediate_solution == 1
            F_m_final=guess_F_m;
            F_f_final=guess_F_f;
        end

        %calculate final policy functions
        [~,~,~,w_m_now,w_f_now,v_m_now,v_f_now,~,pi_m_out1,pi_f_out1]=solve_f_with_fsolve([F_m_final(2:end); F_f_final(2:end)],cnow_m,cnow_f,vv_in_m,vv_in_f,...
            TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,w_m_old,w_f_old,v_m_old,v_f_old,old_profits_both2,old_profits_onlym2,old_profits_onlyf2,0,false);

        % to calculate aggregate vacancies, use sorted ptilde (in case
        % distribution is used rather than discrete counts)
        vout_m=sum(v_m_now(idx_ppi_m).*d_allrungs_m.*change_ppi_in_m);
        vout_f=sum(v_f_now(idx_ppi_f).*d_allrungs_f.*change_ppi_in_f);

        % rest of policies is kept unsorted to keep it consistent
        wpi_m=w_m_now+pi_m_out1;
        wpi_f=w_f_now+pi_f_out1;
        wpi_m(v_m_now==0)=phi_m-1-rand(sum((v_m_now==0)),1)*0.2;
        wpi_f(v_f_now==0)=phi_f-1-rand(sum((v_f_now==0)),1)*0.2;
        guess_h_m=F_m_final;
        guess_h_f=F_f_final;
        guess_h_m=guess_h_m/max(guess_h_m);
        guess_h_f=guess_h_f/max(guess_h_f);

        % define interpolating functions for guesses
        h_m_fun=griddedInterpolant(grid_wpi_m,guess_h_m,mode_approx_F,mode_approx_outside_F);
        h_f_fun=griddedInterpolant(grid_wpi_f,guess_h_f,mode_approx_F,mode_approx_outside_F);
        h_m=max(min(h_m_fun(wpi_m),1),0);
        h_f=max(min(h_f_fun(wpi_f),1),0);
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END OF INLINE FUNCTIONS THAT SOLVE THE PROBLEM
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %outside guesses that are updated at each step to improve speed of
    %convergence
    current_guess_F_m=min(((grid_wpi_m-phi_m)/max((grid_wpi_m-phi_m))).^0.08,1);
    current_guess_F_f=min(((grid_wpi_f-phi_f)/max((grid_wpi_f-phi_f))).^0.06,1);

    %load best guess from previous attempts
    if isfile(loadfile_guess)
        %accommodate different grid and guess sizes
        load(loadfile_guess,'allF2','grid_wpi_m_load','grid_wpi_f_load');
        gridpoints_of_guess=numel(allF2)/2;
        current_guess_F_m(2:end)=interp1(grid_wpi_m_load(2:end),allF2(1:gridpoints_of_guess),grid_wpi_m(2:end),'makima','extrap');
        current_guess_F_f(2:end)=interp1(grid_wpi_f_load(2:end),allF2(gridpoints_of_guess+1:gridpoints_of_guess*2),grid_wpi_f(2:end),'makima','extrap');
    end


    function resres = findvacancies(vvvv)

        %==========================================================================
        % DESCRIPTION: This function finds aggregate vacancies that clear the market in equilibrium
        %
        % AUTHORS:     Iacopo Morchio (University of Bristol)
		%              Christian Moser (Columbia University)
        %
        % DATE:        November 4, 2025
        %==========================================================================

        resres=zeros(2,1);
        vvvv_m=vvvv(1);
        vvvv_f=vvvv(2);
        if (vvvv_m <= 0) || (vvvv_f <=0), resres(:)=10000; return, end

        u_old_m=0;
        u_old_f=0;
        dist_u=100;
        while dist_u > toll
            fhere_m=(vvvv_m/(meas_m.*(u_m + (lambda_e_m/lambda_u_m).*(1-u_m) + (lambda_god_m/lambda_u_m)))).^alpha;
            fhere_f=(vvvv_f/(meas_f.*(u_f + (lambda_e_f/lambda_u_f).*(1-u_f) + (lambda_god_f/lambda_u_f)))).^alpha;
            u_m=delta_m/(delta_m+fhere_m*(1+lambda_god_m/lambda_u_m));
            u_f=delta_f/(delta_f+fhere_f*(1+lambda_god_f/lambda_u_f));
            dist_u=abs(u_m-u_old_m)+abs(u_f-u_old_f);
            u_old_m=u_m;
            u_old_f=u_f;
        end
        adjf_m=fhere_m/lambda_u_m;
        adjf_f=fhere_f/lambda_u_f;
        T_m=meas_m.*((u_m + lambda_god_m/lambda_u_m)*fhere_m*(delta_m + lambda_e_m*(adjf_m) + lambda_god_m*adjf_m))/vvvv_m; %adjusted arrival rates
        T_f=meas_f.*((u_f + lambda_god_f/lambda_u_f)*fhere_f*(delta_f + lambda_e_f*(adjf_f) + lambda_god_f*adjf_f))/vvvv_f; %adjusted arrival rates

        %Solves the equilibrium
        [Vout_here_m,Vout_here_f,~,~,~,~,current_guess_F_m,current_guess_F_f] = mysystem_inline(costIN_m,costIN_f,vvvv_m,vvvv_f,T_m,T_f,adjf_m,adjf_f,current_guess_F_m,current_guess_F_f);

        resres=[vvvv_m-Vout_here_m; vvvv_f-Vout_here_f];
    end

    % Find equilibrium vacancies
    % Starting point is the one implied by the raw data
    u_m=delta_m/(delta_m+lambda_u_m+lambda_god_m);
    u_f=delta_f/(delta_f+lambda_u_f+lambda_god_f);
    Vstart_m=(lambda_u_m.^(1/alpha)).*(meas_m.*(u_m + (lambda_e_m./lambda_u_m).*(1-u_m) + lambda_god_m./lambda_u_m));
    Vstart_f=(lambda_u_f.^(1/alpha)).*(meas_f.*(u_f + (lambda_e_f./lambda_u_f).*(1-u_f) + lambda_god_f./lambda_u_f));

    % Load guesses of aggregate vacancies if available
    loadfile_guess_V=sprintf('%s/guesses/guess_V_policy_equalpay.mat',DIR_INPUT);
    if isfile(loadfile_guess_V)
        load(loadfile_guess_V,'Vout_m','Vout_f');
        Vstart_m=Vout_m;
        Vstart_f=Vout_f;
    end

    % Then solve for vacancies anyway, helps check that current vacancies
    % solve the problem for the current precision
    equalpay_tic=tic;

    % Solve with fsolve
    if immediate_solution
        dist_vac_check=findvacancies([Vstart_m; Vstart_f])./[Vstart_m; Vstart_f];
    else
        dist_vac_check=100;
    end
    if max(abs(dist_vac_check)) > toll_immediate
        Vout=fsolve(@(vv) findvacancies(vv)./[Vstart_m; Vstart_f],[Vstart_m; Vstart_f],opts_fsolve2);
    else
        Vout(1)=Vstart_m;
        Vout(2)=Vstart_f;
    end
    Vout_m=Vout(1);
    Vout_f=Vout(2);
    fprintf('Solving the equal pay policy took %g seconds \n',toc(equalpay_tic));
    save(loadfile_guess_V,'Vout_m','Vout_f');

    %OUTPUT COMMENTED FOR NOW
    fprintf(' Solved! Found vacancies when c constant. [Vm - Vm_start] = [%g - %g] \n',Vout_m,Vstart_m);
    fprintf('                                          [Vf - Vf_start] = [%g - %g] \n',Vout_f,Vstart_f);

    % Compute unemployment and job-finding rates
    u_old_m=0;
    u_old_f=0;
    dist_u=100;
    while dist_u > toll
        fhere_m=(Vout_m/(meas_m.*(u_m + (lambda_e_m/lambda_u_m).*(1-u_m) + (lambda_god_m/lambda_u_m)))).^alpha;
        fhere_f=(Vout_f/(meas_f.*(u_f + (lambda_e_f/lambda_u_f).*(1-u_f) + (lambda_god_f/lambda_u_f)))).^alpha;
        u_m=delta_m/(delta_m+fhere_m*(1+lambda_god_m/lambda_u_m));
        u_f=delta_f/(delta_f+fhere_f*(1+lambda_god_f/lambda_u_f));
        dist_u=abs(u_m-u_old_m)+abs(u_f-u_old_f);
        u_old_m=u_m;
        u_old_f=u_f;
    end
    adjf_m=fhere_m/lambda_u_m;
    adjf_f=fhere_f/lambda_u_f;
    Tout_m=meas_m.*((u_m + lambda_god_m/lambda_u_m)*fhere_m*(delta_m + lambda_e_m*(adjf_m) + lambda_god_m*adjf_m))/Vout_m; %adjusted arrival rates
    Tout_f=meas_f.*((u_f + lambda_god_f/lambda_u_f)*fhere_f*(delta_f + lambda_e_f*(adjf_f) + lambda_god_f*adjf_f))/Vout_f; %adjusted arrival rates

    %Compute policy functions
    [~,~,effwage_m,effwage_f,distrib_m,distrib_f,~,~,pi_m_out,pi_f_out] = mysystem_inline(costIN_m,costIN_f,Vout_m,Vout_f,Tout_m,Tout_f,adjf_m,adjf_f,current_guess_F_m,current_guess_F_f);
    if eta_amenities > 0
        pi_m_out(effwage_m<phi_m)=-10; %pi_m(effwage_m<phi_m);
        pi_f_out(effwage_f<phi_f)=-10; %pi_f(effwage_f<phi_f);
        pi_m_policy=pi_m_out;
        pi_f_policy=pi_f_out;
        % save the changed endogenous amenities
        save(sprintf('%s/results/policy_function/amenities_endo_policy.mat',DIR_INPUT),'pi_m_policy','pi_f_policy');
    end
    p_m=ppi_in_m-pi_m+pi_m_out;
    p_f=ppi_in_f-pi_f+pi_f_out;

    % Re-adjust ptilde to the new value that depends on the endogenous
    % amenities chosen in the optimization
    if eta_amenities > 0
        p_m(effwage_m>=phi_m)=p_m(effwage_m>=phi_m) + pi_m(effwage_m>=phi_m)/eta_amenities ...
            -(pi_cost_m(effwage_m>=phi_m)./eta_amenities).*pi_m_out(effwage_m>=phi_m).^eta_amenities;
        p_f(effwage_f>=phi_f)=p_f(effwage_f>=phi_f) + pi_f(effwage_f>=phi_f)/eta_amenities ...
            -(pi_cost_f(effwage_f>=phi_f)./eta_amenities).*pi_f_out(effwage_f>=phi_f).^eta_amenities;
    end
    p_m(effwage_m<phi_m)=min(effwage_m(effwage_m<phi_m),p_m(effwage_m<phi_m));
    p_f(effwage_f<phi_f)=min(effwage_f(effwage_f<phi_f),p_f(effwage_f<phi_f));
    distrib_m(effwage_m<phi_m)=0;
    distrib_f(effwage_f<phi_f)=0;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BEGINNING OF HELPER FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [out_f_w_pi_both,pi_m_out,pi_f_out] = max_problem_both_pi_w_DERIVATIVES_v2(p_inf_m_both_nocost_ww,p_inf_f_both_nocost_ww,ww,...
        pi_in_cost_m,pi_in_cost_f,precalc_m_in_both,precalc_f_in_both,~,~,...
        ~,~,~,~,eta_ame_in,~,~,...
        size_inf_m,size_inf_f,TT_in_m2_in,TT_in_f2_in,phi_m_in,phi_f_in,~,~,eta_v_here) % Separate maximization for amenities

    %==========================================================================
    % DESCRIPTION: This function maximizes for gender-specific amenities given the choice for wages
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
	%              Christian Moser (Columbia University)
    %
    % DATE:        November 4, 2025
    %==========================================================================

    toll_inside=10^(-5);
    % step_der=1e-6;
    lowest_pi=0.0000000001;
    lb_pi_m=max(lowest_pi.*numel(ww),phi_m_in-ww+lowest_pi);
    lb_pi_f=max(lowest_pi.*numel(ww),phi_f_in-ww+lowest_pi);
    lb_pi_m=min(lb_pi_m,lowest_pi);
    lb_pi_f=min(lb_pi_f,lowest_pi);

    % speed-up with log-exp
    ub_pi_m=max(min( exp((1/eta_ame_in).*log(max(p_inf_m_both_nocost_ww,0).*eta_ame_in./pi_in_cost_m)),10)-lowest_pi,lowest_pi);
    ub_pi_f=max(min( exp((1/eta_ame_in).*log(max(p_inf_f_both_nocost_ww,0).*eta_ame_in./pi_in_cost_f)),10)-lowest_pi,lowest_pi);

    pi_m_out=fun_golden_multi_correct(@(x1) -(((((p_inf_m_both_nocost_ww-(pi_in_cost_m./eta_ame_in).*exp(eta_ame_in.*log(x1))))).*size_inf_m(ww+x1)).*(ww+x1>=phi_m_in)) + ...
        1000.*((phi_m_in-(ww+x1)).*(ww+x1<phi_m_in)),lb_pi_m,ub_pi_m,toll_inside); %added a penalty for going below the outside option
    pi_f_out=fun_golden_multi_correct(@(x2) -(((((p_inf_f_both_nocost_ww-(pi_in_cost_f./eta_ame_in).*exp(eta_ame_in.*log(x2))))).*size_inf_f(ww+x2)).*(ww+x2>=phi_f_in))  + ...
        1000.*((phi_f_in-(ww+x2)).*(ww+x2<phi_f_in)),lb_pi_f,ub_pi_f,toll_inside);

    pi_m_cost_infunction=(pi_in_cost_m./eta_ame_in).*exp(eta_ame_in.*log(pi_m_out));
    pi_f_cost_infunction=(pi_in_cost_f./eta_ame_in).*exp(eta_ame_in.*log(pi_f_out));

    TT_term_size_m=(((TT_in_m2_in).*size_inf_m(ww+pi_m_out)));
    TT_term_size_f=(((TT_in_f2_in).*size_inf_f(ww+pi_f_out)));

    % speed-up using log-exp
    function_vacancies_m=exp((1./(eta_v_here-1)).*log(((p_inf_m_both_nocost_ww-pi_m_cost_infunction)).*...
        precalc_m_in_both.*TT_term_size_m));
    function_vacancies_f=exp((1./(eta_v_here-1)).*log(((p_inf_f_both_nocost_ww-pi_f_cost_infunction)).*...
        precalc_f_in_both.*TT_term_size_f));

    % optimized
    function_size_m=TT_term_size_m.*function_vacancies_m;
    function_size_f=TT_term_size_f.*function_vacancies_f;

    out_f_w_pi_both=-((p_inf_m_both_nocost_ww-pi_m_cost_infunction).*max(function_size_m,0)).*(ww+pi_m_out>=phi_m_in)...
        -(((p_inf_f_both_nocost_ww-pi_f_cost_infunction)).*max(function_size_f,0)).*(ww+pi_f_out>=phi_f_in)...
        + (ww+pi_m_out<phi_m_in).*1000.*(abs(phi_m_in-(ww+pi_m_out))) ...
        + (ww+pi_f_out<phi_f_in).*1000.*(abs(phi_f_in-(ww+pi_f_out)));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF HELPER FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
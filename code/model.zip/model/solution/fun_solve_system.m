function [effwage, distrib, p, correctc] = fun_solve_system(cost_in, delta, lambda_e, lambda_god, phi, Vin, Tin, eta_v, c_v_in, ppi_in)

    %==========================================================================
    % DESCRIPTION: This helper function solves the model by accumulating the
    %              differential equations firm-by-firm, and finds the aggregate vacancy cost to obtain vacancies
    %              consistent with the aggregate V
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - initial cost (cost_in), labor market objects (delta, lambda_u, lambda_e, lambda_god), economy-wide aggregates (Vin,Tin),
    %                the economy-wide parameter eta_v, costs of posting vacancies (c_v_in, to allow heterogeneity, never used), composite productivities (ppi_in)
    %
    % OUTPUTS:     - the utility postings (effwage), the offer distribution
    %                (distrib), composite productivity (p), the vacancy cost
    %                that obtains the same aggregate vacancies V (correctc)
    %
    % DATE:        November 4, 2025
    %==========================================================================
    
    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % parameters
    method_ladder = 2; %2 = just sum over firms. 1 = weigh by the distribution
    tol = 10^(-6);
    N = numel(ppi_in);
    Nf = N;
    opts_fzero=optimset('Display','off');
    
    % compute changes across rungs of the ladder
    d_allrungs=ones(numel(ppi_in),1).*(1/Nf);
    change_ppi_in=ppi_in(2:end)-ppi_in(1:end-1);
    change_ppi_in(end+1)=change_ppi_in(end);
    if method_ladder == 2, change_ppi_in=change_ppi_in.*0 + 1; end


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % BEGINNING OF INLINE FUNCTIONS
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function [vout,wpi,h] = mysystem_inline(cnow)

        %==========================================================================
        % DESCRIPTION: This function solves the firm's problem
        %
        % AUTHORS:     Iacopo Morchio (University of Bristol)
		%              Christian Moser (Columbia University)
        %
        % DATE:        November 4, 2025
        %==========================================================================

        ppp=ppi_in;
        wpi=ones(N,1)*phi;
        h=zeros(N,1);

        wpi_prime=zeros(N,1);
        h_prime=zeros(N,1);
        vv=zeros(N,1);
        term=0;

        % First, check how many values are below outside option
        below_phi=sum(ppp<phi);

        start_algo=below_phi+1;
        wpi(1:below_phi)=min(phi,ppp(1:below_phi))-(below_phi-(0:below_phi-1)').*10^(-8); %exclude effective wages below phi
        wpi(below_phi+1)=phi;
        h(1:below_phi)=0;
        vv(1:below_phi)=0;

        % Calculate derivative and accumulate into H (F) and w+pi
        for rr=start_algo:N-1

            h(rr+term)=min(h(rr+term),1);

            distterm=(1./(delta + lambda_god + lambda_e.*(1-h(rr+term))));

            if (ppp(rr+term) - wpi(rr+term) >= 0)
                vv(rr+term)=( ((Tin.*(distterm.^2)).^(1./(eta_v-1))) .* ...
                    ((1./(cnow.*c_v_in(rr+term))).^(1./(eta_v-1))) .*((ppp(rr+term) - wpi(rr+term)).^(1./(eta_v-1))) );
            else
                vv(rr+term)=0;
            end
            % Formula adjusted for precision
            h_prime(rr+term)=(vv(rr+term)./Vin).* d_allrungs(rr+term);

            % Turns out to be just as precise and faster
            wpi_prime(rr+term)=h_prime(rr+term).*distterm.*(2.*lambda_e).*(ppp(rr+term)-wpi(rr+term));

            % integrate the derivative to the next rung
            if method_ladder == 1, ppi_change=ppp(rr+1)-ppp(rr);
            elseif method_ladder == 2, ppi_change=1; end
            wpi(rr+1)=wpi(rr) + wpi_prime(rr)*ppi_change;
            h(rr+1)=h(rr) + h_prime(rr)*ppi_change;

            % correction for wage just above outside option
            if wpi(rr+1)==wpi(rr)
                ppp(rr:rr+1)=ppp(rr:rr+1)+1e-12;
                wpi(rr+1)=wpi(rr+1)+1e-13;
            end

        end
        if method_ladder == 1, vout=sum(vv.*d_allrungs.*change_ppi_in);
        elseif method_ladder == 2, vout=sum(vv.*d_allrungs); end
    end


    function [resres2] = findcost2(cccc)

        %==========================================================================
        % DESCRIPTION: This function finds the vacancy cost shifter that rationalizes the equilibrium job-finding rate
        %
        % AUTHORS:     Iacopo Morchio (University of Bristol)
		%              Christian Moser (Columbia University)
        %
        % DATE:        November 4, 2025
        %==========================================================================

        if cccc <= 0, resres2 = 10000; return, end
        [resres2, ~, ~] = mysystem_inline(cccc);
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % END OF INLINE FUNCTIONS
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    % New method using just the vacancies condition
    % If cost results in very different aggregate vacancies, refine search using the vacancy condition
    dist=10^(-5);

    oldC=findcost2(cost_in)/Vin;
    old2C=oldC;
    dist1=abs(oldC-cost_in);
    if dist1 > dist
        olddist=10000;
        dist=100;
        iter=0;
        strikes=0;
        while (iter < 100) && (dist > tol)
            iter=iter+1;
            newVbyC=findcost2(oldC);
            newCnow=newVbyC/Vin;
            newVnow=newVbyC/oldC;
            dist=abs((newVnow-Vin)/Vin);
            if (dist > olddist)
                strikes=strikes+1; %when an iteration has failed, adjust the factor
            end
            if (strikes > 3) || (iter > 5)   %when it stops improving, rely on fzero
                newC=old2C;
                break
            elseif (strikes == 2)
                newC=newCnow;
                old2C=oldC;
                oldC=(1/iter)*newC + (1-(1/iter))*oldC;
                olddist=dist;
            elseif strikes == 1
                newC=newCnow;
                old2C=oldC;
                oldC=0.5*newC + 0.5*oldC;
                olddist=dist;
            elseif strikes < 1
                newC=newCnow;
                old2C=oldC;
                oldC=newC;
                olddist=dist;
            end
            fprintf('Iter %g, Cost = %g, distance is %g \n',iter,newC,dist);
        end

        cost_guess = newC;
    else
        cost_guess = cost_in;
    end

    solved_fzero = 0;
    range_cost_guess = max(1, cost_guess); % modified with cost guess
    while solved_fzero == 0
        % Fastest method up to now: fzero
        try correctc = fzero(@(cost) (findcost2(cost) - Vin)./Vin, [0.01 range_cost_guess], opts_fzero);
            solved_fzero = 1;
        catch
            fprintf('No zero found in range [%g - %g], increasing range... \n', 0.01, range_cost_guess);
            fprintf('Results were [%g - %g] \n', (findcost2(0.01) - Vin)./Vin,(findcost2(range_cost_guess) - Vin)./Vin);
            solved_fzero = 0;
            range_cost_guess = range_cost_guess*2;
        end
    end

    % output everything
    [~, effwage, distrib] = mysystem_inline(correctc);
    p = ppi_in;
end
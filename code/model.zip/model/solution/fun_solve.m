function [effwage, distrib, p, uout, Vout, Tout, adjf] = fun_solve(params, delta, lambda_u, lambda_e, lambda_god, meas_g, phi, costIN, eta_v, c_v_in, ppi_in)

    %==========================================================================
    % DESCRIPTION: This helper function solves the model by accumulating the
    %              differential equations firm-by-firm, when the vacancy cost
    %              is held constant (for counterfactuals)
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - parameters (params), labor market objects (delta, lambda_u, lambda_e, lambda_god), economy-wide parameters (meas_g, eta_v), outside option (phi)
    %
    % OUTPUTS:     - the utility postings (effwage), the offer distribution
    %                (distrib), composite productivity (p), unemployment rate
    %                (uout), aggregate vacancies (Vout), T (Tout), the
    %                adjustment factor (adjf) for the job-finding rate
    %
    % DATE:        November 4, 2025
    %==========================================================================
    
    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % parameters
    method_ladder = 2; %2 = just sum over firms. 1 = weigh by the distribution
    alpha = params(4);
    toll = 10^(-6);
    s_G = lambda_god/lambda_u;
    N = numel(ppi_in);
    opts_fzero = optimset('Display','off');
    
    % compute changes across rungs of the ladder
    d_allrungs=ones(numel(ppi_in),1).*(1/N);
    change_ppi_in=ppi_in(2:end)-ppi_in(1:end-1);
    change_ppi_in(end+1)=change_ppi_in(end);
    if method_ladder == 2, change_ppi_in=change_ppi_in.*0 + 1; end

    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % BEGINNING OF INLINE FUNCTIONS
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function [vout, wpi, h] = mysystem_inline(cnow, vv_in, TT_in, adjf_in)

    %==========================================================================
    % DESCRIPTION: This inline function is used to solve the each firm's first order conditions and accumulate them in CDF and aggregate vacancies
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
	%              Christian Moser (Columbia University)
    %
    % DATE:        November 4, 2025
    %==========================================================================

        ppp=ppi_in;
        wpi=ones(N,1)*phi;
        h=zeros(N,1);

        wpi_prime=zeros(N,1);
        h_prime=zeros(N,1);
        vv=h_prime;
        term=0;

        % First, check how many values are below outside option
        below_phi=sum(ppp<phi);

        start_algo=below_phi+1;
        wpi(1:below_phi)=phi-(below_phi+1-(0:below_phi-1)').*10^(-8); %exclude effective wages below phi
        wpi(below_phi+1)=phi;
        h(1:below_phi)=0;
        vv(1:below_phi)=0;

        % Calculate derivative and accumulate into H (F) and w+pi
        for rr=start_algo:N-1

            h(rr+term)=min(h(rr+term),1);

            distterm=(1./(delta + adjf_in.*(lambda_god + lambda_e.*(1-h(rr+term)))));
            vv(rr+term)=((TT_in./(cnow.*c_v_in(rr+term))).*(ppp(rr+term) - wpi(rr+term)).*(distterm.*distterm)).^(1./(eta_v-1));
            h_prime(rr+term)=vv(rr+term).*d_allrungs(rr+term)./vv_in;
            wpi_prime(rr+term)=h_prime(rr+term).*(2.*adjf_in.*lambda_e).*(ppp(rr+term)-wpi(rr+term)).*distterm;

            %integrate the derivative to the next rung
            if method_ladder == 1, ppi_change=ppp(rr+1)-ppp(rr);
            elseif method_ladder == 2, ppi_change=1; end
            wpi(rr+1)=wpi(rr) + wpi_prime(rr)*ppi_change;
            h(rr+1)=h(rr) + h_prime(rr)*ppi_change;

            if wpi(rr+1)==wpi(rr)
                ppp(rr:rr+1)=ppp(rr:rr+1)+1e-12;
                wpi(rr+1)=wpi(rr+1)+1e-13;
            end

        end
        if method_ladder == 1, vout=sum(vv.*d_allrungs.*change_ppi_in);
        elseif method_ladder == 2, vout=sum(vv.*d_allrungs); end
    end
    

    function resres = findvacancies(vvvv)
    
    %==========================================================================
    % DESCRIPTION: This inline function is used to find equilibrium vacancies
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
	%              Christian Moser (Columbia University)
    %
    % DATE:        November 4, 2025
    %==========================================================================

        if vvvv <= 0, resres=10000; return, end

        u_old=0;
        dist_u=100;
        while dist_u > toll
            fhere=(vvvv/(meas_g.*(u + (lambda_e/lambda_u).*(1-u) + (lambda_god/lambda_u)))).^alpha;
            u=delta/(delta+fhere*(1+s_G));
            dist_u=abs(u-u_old);
            u_old=u;
        end
        adjf=fhere/lambda_u;
        T=meas_g.*((u + lambda_god/lambda_u)*fhere*(delta + lambda_e*(adjf) + lambda_god*adjf))/vvvv; %adjusted arrival rates

        [Vout_here,~,~] = mysystem_inline(costIN,vvvv,T,adjf);

        resres=(vvvv-Vout_here)/Vstart;
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % END OF INLINE FUNCTIONS
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    % Starting point is the u implied by the raw data
    u=delta/(delta+lambda_u+lambda_god);
    Vstart=(lambda_u.^(1/alpha)).*(meas_g.*(u + (lambda_e./lambda_u).*(1-u) + lambda_god./lambda_u));

    % fzero for solution
    solved_fzero=0;
    range_V_guess=1;
    while solved_fzero == 0
        % find the vacancies consistent with the constant vacancy cost and
        % changed fundamentals
        try Vout = fzero(@(vv)findvacancies(vv), [10^(-5) range_V_guess*Vstart + 1e-5], opts_fzero);
            solved_fzero = 1;
        catch ME
            fprintf('Fzero widening search interval... \n');
            solved_fzero = 0;
            range_V_guess = range_V_guess + 1;
        end
    end

    u_old=0;
    dist_u=100;
    while dist_u > toll
        fhere=(Vout/(meas_g.*(u + (lambda_e/lambda_u).*(1-u) + lambda_god/lambda_u))).^alpha;
        u=delta/(delta+fhere*(1+s_G));
        dist_u=abs(u-u_old);
        u_old=u;
    end
    uout=u;
    adjf=fhere/lambda_u;
    Tout=meas_g.*((u + lambda_god/lambda_u)*fhere*(delta + lambda_e*(adjf) + lambda_god*adjf))/Vout; %adjusted arrival rates

    [~, effwage, distrib] = mysystem_inline(costIN, Vout, Tout, adjf);
    p = ppi_in;
end
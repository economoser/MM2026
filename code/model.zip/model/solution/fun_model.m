function fun_model(solutionmethod, alreadydone)

    %==========================================================================
    % DESCRIPTION: This function solves all models and counterfactuals, and
    %              creates all the main tables in the paper
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - solutionmethod (now only DISCRETE allowed), alreadydone
    %                (either a scalar = 0 to re-compute everything, or = 1 to just read
    %                results for counterfactuals from the folders)
    %
    % OUTPUTS:     - results/tables/tab_counterfactuals_equilibrium_main_text.tex
    %                results/tables/tab_counterfactuals_policies.tex
    %                results/tables/tab_counterfactuals_equalhiring.tex
    %                results/tables/tab_cf_policy_equalamenities.tex
    %                results/tables/tab_cf_policy_equalhiring_public.tex
    %                results/tables/tab_cf_policy_equalhiring_public_v2.tex
    %                results/tables/tab_counterfactuals_equilibrium_appendix.tex
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % List of counterfactuals
    models_todo_cc=["baseline"; "baseline_amenities_equal_mean"; "baseline_noz"; "baseline_equal_lab_params"; "baseline_nodifference_all"; ...
        "baseline_equalpay"; "baseline_equalhiring"; "baseline_equal_amenities"; "baseline_equalhiring_public"];
    models_todo_vc=["baseline"; "baseline_equal_lab_params"; "baseline_nodifference_all"];

    % Default parameters
    if nargin < 1, solutionmethod='DISCRETE'; end
    if nargin < 2, alreadydone=1; end %=1 skips all computations; =2 skips equal pay; =3 skips equal pay AND equal hiring

    % Construct vectors of dummies for counterfactuals to run
    if isscalar(alreadydone)
        if alreadydone == 0
            models_todo_cc_check=ones(numel(models_todo_cc),1);
            models_todo_vc_check=ones(numel(models_todo_vc),1);
        elseif alreadydone == 10        %do ONLY the equal pay policy
            models_todo_cc_check=zeros(numel(models_todo_cc),1);
            models_todo_vc_check=zeros(numel(models_todo_vc),1);
            models_todo_cc_check(6)=1;
            models_todo_cc_check(1)=1; %needs the baseline for vcosts
        elseif alreadydone == 11        %do ONLY the equal amenities policy
            models_todo_cc_check=zeros(numel(models_todo_cc),1);
            models_todo_vc_check=zeros(numel(models_todo_vc),1);
            models_todo_cc_check(8)=1;
            models_todo_cc_check(1)=1; %needs the baseline for vcosts
        elseif alreadydone == 20        %do ONLY the equal hiring policy
            models_todo_cc_check=zeros(numel(models_todo_cc),1);
            models_todo_vc_check=zeros(numel(models_todo_vc),1);
            models_todo_cc_check(7)=1;
            models_todo_cc_check(1)=1; %needs the baseline for vcosts
        elseif alreadydone == 21        %do ONLY the equal hiring policy in the public sector
            models_todo_cc_check=zeros(numel(models_todo_cc),1);
            models_todo_vc_check=zeros(numel(models_todo_vc),1);
            models_todo_cc_check(9)=1;
            models_todo_cc_check(1)=1; %needs the baseline for vcosts
        elseif alreadydone == 31        %do ONLY baseline and amenities cf
            models_todo_cc_check=zeros(numel(models_todo_cc),1);
            models_todo_vc_check=zeros(numel(models_todo_vc),1);
            models_todo_cc_check(2)=1; %amenities counterfactual
            models_todo_cc_check(1)=1; %needs the baseline for vcosts
        elseif alreadydone == 1         %skip everything
            models_todo_cc_check=zeros(numel(models_todo_cc),1);
            models_todo_vc_check=zeros(numel(models_todo_vc),1);
        elseif alreadydone == 2     %skip the equal pay policy
            models_todo_cc_check=ones(numel(models_todo_cc),1); models_todo_cc_check(6)=0;
            models_todo_vc_check=ones(numel(models_todo_vc),1);
        elseif alreadydone == 3     %skip equal pay AND equal hiring
            models_todo_cc_check=ones(numel(models_todo_cc),1); models_todo_cc_check(6:7)=0;
            models_todo_vc_check=ones(numel(models_todo_vc),1);
        elseif alreadydone == 4     %skip equal pay, equal hiring, equal amenities and equal hiring in public sector
            models_todo_cc_check=ones(numel(models_todo_cc),1); models_todo_cc_check(6:9)=0;
            models_todo_vc_check=ones(numel(models_todo_vc),1);
        end
    else
        models_todo_cc_check=alreadydone;
        models_todo_vc_check=ones(numel(models_todo_vc),1);
    end

    % Load economy-wide parameters
    load(sprintf('%s/economywide_parameters.mat',DIR_TEMP),'params');
    measure_f=params(24);
    sim_vector="GE";

    % Load the distribution of firm fundamentals
    load(sprintf('%s/distribution_data.mat',DIR_TEMP),'eta_v','eta_amenities');

    % The next section solves the CFs specified above
    condi=(numel(alreadydone) > 1);
    if not(condi), condi=not(alreadydone == 1); end
    if condi
        vcosts=[0; 0];
        for k=1:numel(models_todo_cc)
            %code to skip the long equal pay policy
            if models_todo_cc_check(k) == 1
                fprintf(' Solving model %s with constant C \n',models_todo_cc(k));
                if strcmp(models_todo_cc(k),'baseline_equalposting')
                    fun_model_helper(models_todo_cc(k),[vcosts(1); vcosts(1)],0,eta_v,eta_amenities,solutionmethod);
                else
                    fun_model_helper(models_todo_cc(k),vcosts,0,eta_v,eta_amenities,solutionmethod);
                end
                if k == 1
                    load(sprintf('%s/policyf_baseline.mat',DIR_TEMP),'vcost_men','vcost_women');
                    vcosts=[vcost_men; vcost_women];
                end
                %move moments to cc folder
                momentsnow=sprintf('%s/results/moments_%s_%s.mat',DIR_INPUT,models_todo_cc(k),sim_vector(1));
                movefile(momentsnow,sprintf('%s/results/vacancy_cost_constant/moments_%s_%s.mat',DIR_INPUT,models_todo_cc(k),sim_vector(1)));
            end
        end

        % Here the model is solved re-adjusting the cost every time to match
        % the same job-finding rate as in the baseline
        for k=1:numel(models_todo_vc)
            % code to skip models already calculated
            if models_todo_vc_check(k) == 1
                fprintf(' Solving model %s with VARYING C \n',models_todo_vc(k));
                fun_model_helper(models_todo_vc(k),[0; 0],0,eta_v,eta_amenities,solutionmethod);

                % move moments to vc folder
                momentsnow=sprintf('%s/results/moments_%s_%s.mat',DIR_INPUT,models_todo_vc(k),sim_vector(1));
                movefile(momentsnow,sprintf('%s/results/vacancy_cost_reset/moments_%s_%s.mat',DIR_INPUT,models_todo_vc(k),sim_vector(1)));
            end
        end
    end
    % Model solutions finished

    % Codes for potential partial equilibrium counterfactuals, not used
    for k=1:numel(models_todo_cc)
        for sim_k = 1:1
            if (k < 8) || (sim_k==1)
                momentsnow=sprintf('%s/results/vacancy_cost_constant/moments_%s_%s.mat',DIR_INPUT,models_todo_cc(k),sim_vector(1));
                load(momentsnow,'mom','mom_policy_comparison');     mom_policy_comparison=mom_policy_comparison(1:80,:);
                mom_counterfactual_SIM(:,k)=mom;
                mom_counterfactual_policy_comp_SIM(:,:,k)=mom_policy_comparison;
            end
        end
    end

    % Load the moments from the results folder
    for k=1:numel(models_todo_vc)
        momentsnow=sprintf('%s/results/vacancy_cost_reset/moments_%s_%s.mat',DIR_INPUT,models_todo_vc(k),sim_vector(1));
        load(momentsnow,'mom','mom_policy_comparison');
        mom_counterfactual_varc_SIM(:,k)=mom;
        mom_counterfactual_varc_policy_comp_SIM(:,:,k)=mom_policy_comparison;
    end

    % For standard tables, select only general equilibrium models
    [rr,cc,~]=size(mom_counterfactual_SIM);
    [rr2,cc2,~]=size(mom_counterfactual_varc_SIM);
    [rr3,rrb3,cc3,~]=size(mom_counterfactual_policy_comp_SIM);
    mom_counterfactual=reshape(mom_counterfactual_SIM(:,:,1),rr,cc);
    mom_counterfactual_varc=reshape(mom_counterfactual_varc_SIM(:,:,1),rr2,cc2);
    mom_counterfactual_policy_comp=reshape(mom_counterfactual_policy_comp_SIM(:,:,:,1),rr3,rrb3,cc3);

    % version with all counterfactuals for appendix
    tab_cf_all=mom_counterfactual(:,(1:3));
    tab_cf_all(:,4)=mom_counterfactual_varc(:,2); %equal labor market parameters, moved to VC to keep lambda_u meaningful
    tab_cf_all(:,5)=mom_counterfactual_varc(:,3); %no difference, compensated cost

    % Table for main paper
    tab_cf=mom_counterfactual(:,(1:2));

    % Policy counterfactual tables
    tab_policy_cf=mom_counterfactual(:,[1 6 7]);
    tab_policy_cf2=mom_counterfactual(:,[1 7]);
    tab_policy_cf_equalhiring_public=mom_counterfactual(:,[1 7 9]);
    tab_policy_cf_equalamenities=mom_counterfactual(:,[1 8]);
    tab_policy_cf_equalhiring_public_new_temp=mom_counterfactual_policy_comp(:,:,[1 7 9]);

    % Reshape policy outcomes so that they correspond to the table's columns
    tab_policy_cf_equalhiring_public_new=[tab_policy_cf_equalhiring_public_new_temp(:,1,1) tab_policy_cf_equalhiring_public_new_temp(:,2,1) ...
        tab_policy_cf_equalhiring_public_new_temp(:,1,2) tab_policy_cf_equalhiring_public_new_temp(:,2,2) ...
        tab_policy_cf_equalhiring_public_new_temp(:,1,3) tab_policy_cf_equalhiring_public_new_temp(:,2,3)];

    % folder where tables are saved
    dirtowrite_cf=sprintf('%s/tables',DIR_RESULTS);

    % Start opening files and defining table headers
    fileid_cf_base=fopen(sprintf('%s/tab_counterfactuals_equilibrium_main_text.tex',dirtowrite_cf),'w+');
    fprintf(fileid_cf_base,' \\begin{tabular}{lccc} \\tabularnewline \\hline\\hline \n');
    fprintf(fileid_cf_base,'  & Baseline & & Same amenities \\\\ \\cline{2-2} \\cline{4-4} \n');
    fprintf(fileid_cf_base,' \\vspace{-.4cm} \\\\ \n');

    % Table 3, policy table
    fileid_policy_main=fopen(sprintf('%s/tab_counterfactuals_policies.tex',dirtowrite_cf),'w+');
    fprintf(fileid_policy_main,' \\begin{tabular}{lcccc} \\tabularnewline \\hline\\hline \n');
    fprintf(fileid_policy_main,'& Baseline & & Equal-pay policy & Equal-hiring policy \\\\ \\cline{2-2} \\cline{4-4} \\cline{5-5} \n');
    fprintf(fileid_policy_main,' & (0) & & (1) & (2) \\\\ \n');
    fprintf(fileid_policy_main,' \\vspace{-.4cm} \\\\ \\hline \n');
    fprintf(fileid_policy_main,' \\vspace{-.4cm} \\\\ \n');

    % Table 5, policy table
    fileid_policy_equalhiring=fopen(sprintf('%s/tab_counterfactuals_equalhiring.tex',dirtowrite_cf),'w+');
    fprintf(fileid_policy_equalhiring,' \\begin{tabular}{lccc} \\tabularnewline \\hline\\hline \n');
    fprintf(fileid_policy_equalhiring,'& Baseline & & Equal-hiring policy \\\\ \\cline{2-2} \\cline{4-4} \n');
    fprintf(fileid_policy_equalhiring,' & (0) & & (1) \\\\ \n');
    fprintf(fileid_policy_equalhiring,' \\vspace{-.4cm} \\\\ \\hline \n');
    fprintf(fileid_policy_equalhiring,' \\vspace{-.4cm} \\\\ \n');

    % Table A., policy equal amenities table
    fileid_policy_equalame=fopen(sprintf('%s/tab_cf_policy_equalamenities.tex',dirtowrite_cf),'w+');
    fprintf(fileid_policy_equalame,' \\begin{tabular}{lccc} \\tabularnewline \\hline\\hline \n');
    fprintf(fileid_policy_equalame,'& Baseline & & Equal-amenities policy \\\\ \\cline{2-2} \\cline{4-4} \n');
    fprintf(fileid_policy_equalame,' & (0) & & (1) \\\\ \n');
    fprintf(fileid_policy_equalame,' \\vspace{-.4cm} \\\\ \\hline \n');
    fprintf(fileid_policy_equalame,' \\vspace{-.4cm} \\\\ \n');

    % Table A., policy equal hiring in public sector only table
    fileid_policy_equalhire_pub=fopen(sprintf('%s/tab_cf_policy_equalhiring_public.tex',dirtowrite_cf),'w+');
    fprintf(fileid_policy_equalhire_pub,' \\begin{tabular}{lcccc} \\tabularnewline \\hline\\hline \n');
    fprintf(fileid_policy_equalhire_pub,'& Baseline & & Equal-hiring & Equal-hiring, public only \\\\ \\cline{2-2} \\cline{4-4} \\cline{5-5} \n');
    fprintf(fileid_policy_equalhire_pub,' & (0) & & (1) & (2) \\\\ \n');
    fprintf(fileid_policy_equalhire_pub,' \\vspace{-.4cm} \\\\ \\hline \n');
    fprintf(fileid_policy_equalhire_pub,' \\vspace{-.4cm} \\\\ \n');

    % New version of Table A., policy equal hiring in public sector only table
    % with comparison between private and public sector
    fileid_policy_equalhire_pub_v2=fopen(sprintf('%s/tab_cf_policy_equalhiring_public_v2.tex',dirtowrite_cf),'w+');
    fprintf(fileid_policy_equalhire_pub_v2,' \\begin{tabular}{lccccccc} \\tabularnewline \\hline\\hline \n');
    fprintf(fileid_policy_equalhire_pub_v2,'& \\multicolumn{2}{c}{Baseline} & & \\multicolumn{2}{c}{Equal-hiring} & \\multicolumn{2}{c}{Equal-hiring, public only} \\\\ \\cline{2-2} \\cline{4-4} \\cline{5-5} \n');
    fprintf(fileid_policy_equalhire_pub_v2,' & (0a) & (0b)  & & (1a) & (1b) & (2a) & (2b) \\\\ \n');
    fprintf(fileid_policy_equalhire_pub_v2,' \\vspace{-.4cm} \\\\ \\hline \n');
    fprintf(fileid_policy_equalhire_pub_v2,' \\vspace{-.4cm} \\\\ \n');

    % Table A., all equilibrium counterfactuals
    fileid_cf_appendix=fopen(sprintf('%s/tab_counterfactuals_equilibrium_appendix.tex',dirtowrite_cf),'w+');
    fprintf(fileid_cf_appendix,' \\begin{tabular}{lcccccc} \\tabularnewline \\hline\\hline \n');
    fprintf(fileid_cf_appendix,'  & Baseline & & \\multicolumn{4}{c}{Counterfactuals} \\\\ \\cline{2-2} \\cline{4-7} \n');
    fprintf(fileid_cf_appendix,' \\vspace{-.4cm} \\\\ \n');

    % Following instructions write the tables
    fprintf(fileid_cf_appendix,' Differences in ');
    for k=1:5
        fprintf(fileid_cf_appendix,' & (%g) ',k-1);
        if k == 1, fprintf(fileid_cf_appendix,' & '); end
    end
    fprintf(fileid_cf_appendix,' \\\\ \n');
    fprintf(fileid_cf_appendix,'  Amenities               & \\checkmark & &             & \\checkmark & \\checkmark &  \\\\ \n');
    fprintf(fileid_cf_appendix,'  Gender wedges           & \\checkmark & & \\checkmark &             & \\checkmark &  \\\\ \n');
    fprintf(fileid_cf_appendix,'  Labor market parameters & \\checkmark & & \\checkmark & \\checkmark &             &   \\\\ \\hline \n');

    option_extra_moments=false;

    % Starting moments here
    for kk = 1:7
        if kk==1, fileid_now=fileid_cf_base; usenow=tab_cf;
        elseif kk==2, fileid_now=fileid_policy_main; usenow=tab_policy_cf;
        elseif kk==3, fileid_now=fileid_policy_equalhiring; usenow=tab_policy_cf2;
        elseif kk==4, fileid_now=fileid_policy_equalame; usenow=tab_policy_cf_equalamenities;
        elseif kk==5, fileid_now=fileid_policy_equalhire_pub; usenow=tab_policy_cf_equalhiring_public;
        elseif kk==6, fileid_now=fileid_policy_equalhire_pub_v2; usenow=tab_policy_cf_equalhiring_public_new;
        elseif kk==7, fileid_now=fileid_cf_appendix; usenow=tab_cf_all;
        end

        if option_extra_moments
            % Report average wages
            tablerow_latex(fileid_now,sprintf('Mean log pay for men'),(usenow(1,:))-usenow(1,1),'raw',true);
            tablerow_latex(fileid_now,sprintf('Mean log pay for women'),(usenow(1,:)-usenow(9,:))-usenow(1,1),'raw',true);
            tablerow_latex(fileid_now,sprintf('Variance of wages of men'),usenow(2,:),'raw',true);
            tablerow_latex(fileid_now,sprintf('Variance of wages of women'),usenow(10,:),'raw',true);
        end

        % Report gender wage gap across counterfactuals
        tablerow_latex(fileid_now,'Gender log pay gap',usenow(9,:),'raw',true);
        tablerow_latex(fileid_now,'\quad between employers',usenow(27,:),'raw',true);
        tablerow_latex(fileid_now,'\quad within employers',usenow(28,:),'raw',true);

        % Amenities start here
        if option_extra_moments
            tablerow_latex(fileid_now,sprintf('Mean log amenities for men'),(usenow(59,:))-usenow(59,1),'raw',true);
            tablerow_latex(fileid_now,sprintf('Mean log amenities for women'),(usenow(60,:))-usenow(59,1),'raw',true);
        end

        if kk ~= 4
            % Report gender AMENITIES gap across counterfactuals
            tablerow_latex(fileid_now,'Gender log amenities gap',usenow(62,:),'raw',true);
            tablerow_latex(fileid_now,'\quad between employers',usenow(63,:),'raw',true);
            tablerow_latex(fileid_now,'\quad within employers',usenow(64,:),'raw',true);
        elseif kk == 4
            % Report gender ABSOLUTE AMENITIES gap across counterfactuals - used
            % for equal amenities for clarity of exposition
            tablerow_latex(fileid_now,'Gender total amenities gap',usenow(74,:),'raw',true);
            tablerow_latex(fileid_now,'\quad between employers',usenow(75,:),'raw',true);
            tablerow_latex(fileid_now,'\quad within employers',usenow(76,:),'raw',true);
        end

        %%%%%%%%%%%%%%%%UTILITIES%%%%%%%%%%%%%%%%%
        if option_extra_moments
            tablerow_latex(fileid_now,sprintf('Mean log utility for men'),(usenow(69,:))-usenow(69,1),'raw',true);
            tablerow_latex(fileid_now,sprintf('Mean log utility for women'),(usenow(70,:))-usenow(69,1),'raw',true);
        end

        % Report gender UTILITY gap across counterfactuals
        tablerow_latex(fileid_now,'Gender log utility gap',usenow(71,:),'raw',true);
        tablerow_latex(fileid_now,'\quad between employers',usenow(72,:),'raw',true);
        tablerow_latex(fileid_now,'\quad within employers',usenow(73,:),'raw',true);

        % Empty line for spacing
        fprintf(fileid_now,' \\vspace{-.25cm} \\\\ \n ');

        % Report output across counterfactuals
        if kk ~= 6
            tablerow_latex(fileid_now,'Output',usenow(36,:),'normalized',true);
        else
            % for spillovers table, normalize by private and public separately
            output_norm_here=repmat(usenow(36,1:2),1,3);
            tablerow_latex(fileid_now,'Output',usenow(36,:)./output_norm_here,'raw',true);
        end

        if option_extra_moments
            % Report output with wedges across counterfactuals
            tablerow_latex(fileid_now,'Output minus wedges',usenow(38,:)./usenow(36,1),'raw',true);
        end

        % Moments for main counterfactuals table
        usenow(53,:)=usenow(48,:) + usenow(49,:) + usenow(40,:) + usenow(41,:) + usenow(6,:) + usenow(14,:); %worker welfare
        usenow(54,:)=usenow(48,:) + usenow(49,:); %total payroll
        usenow(55,:)=usenow(40,:) + usenow(41,:); %total amenity value

        % worker welfare by gender
        [~,cccccc]=size(usenow);
        worker_welfare_gender_cf=zeros(2,cccccc);
        worker_welfare_gender_cf(1,:)=usenow(48,:) + usenow(41,:) + usenow(6,:);    %men's welfare
        worker_welfare_gender_cf(2,:)=usenow(49,:) + usenow(40,:) + usenow(14,:);   %women's welfare

        usenow(56,:)=usenow(47,:) - usenow(54,:) - usenow(51,:) - usenow(52,:) - usenow(45,:) - usenow(46,:) - usenow(42,:); %employer welfare
        usenow(57,:)=usenow(47,:) - usenow(54,:) - usenow(51,:) - usenow(52,:) - usenow(45,:) - usenow(46,:); %profits

        condi_worker_welfare_cf_m=zeros(53,cccccc);
        condi_worker_welfare_cf_f=zeros(53,cccccc);
        condi_worker_welfare_cf_m(53,:)=usenow(48,:) + usenow(41,:); %men's
        condi_worker_welfare_cf_f(53,:)=usenow(49,:) + usenow(40,:); %women's

        for type_welfare=1:3
            if type_welfare==1
                name_welfare='Worker welfare';
                name_welfare_formen='\quad for men';
                name_welfare_forwomen='\quad for women';
                denom_firstrow_cf=1;
                denom_base_cf=usenow(53,1);

                % new moments with worker welfare by gender
                if kk ~= 6
                    % WORKER WELFARE across counterfactuals
                    tablerow_latex(fileid_now,name_welfare,usenow(53,:)./denom_firstrow_cf,'normalized',true);
                    % WORKER WELFARE FOR MEN across counterfactuals
                    tablerow_latex(fileid_now,name_welfare_formen,worker_welfare_gender_cf(1,:)./worker_welfare_gender_cf(1,1),'normalized',true);
                    % WORKER WELFARE FOR WOMEN across counterfactuals
                    tablerow_latex(fileid_now,name_welfare_forwomen,worker_welfare_gender_cf(2,:)./worker_welfare_gender_cf(2,1),'normalized',true);
                else
                    % For the spillovers table, compute differently to normalize
                    % by public sector
                    % WORKER WELFARE across counterfactuals
                    norm_worker_welfare=repmat(usenow(53,1:2),1,3);
                    tablerow_latex(fileid_now,name_welfare,usenow(53,:)./norm_worker_welfare,'raw',true);

                    norm_worker_welfare_gender_cf(1,:)=repmat(worker_welfare_gender_cf(1,1:2),1,3);
                    norm_worker_welfare_gender_cf(2,:)=repmat(worker_welfare_gender_cf(2,1:2),1,3);

                    % WORKER WELFARE FOR MEN across counterfactuals
                    tablerow_latex(fileid_now,name_welfare_formen,worker_welfare_gender_cf(1,:)./norm_worker_welfare_gender_cf(1,:),'normalized',true);
                    % WORKER WELFARE FOR WOMEN across counterfactuals
                    tablerow_latex(fileid_now,name_welfare_forwomen,worker_welfare_gender_cf(2,:)./norm_worker_welfare_gender_cf(2,:),'normalized',true);
                end
                fprintf(fileid_now,' \\vspace{-.25cm} \\\\ \n ');
            end
            if option_extra_moments
                if type_welfare==2
                    name_welfare='Employee welfare for men';
                    denom_firstrow_cf=usenow(50,:);
                    denom_base_cf=(usenow(50,:)).*(condi_worker_welfare_cf_m(53,1)/(usenow(50,1)));

                    % WORKER WELFARE across counterfactuals
                    tablerow_latex(fileid_now,name_welfare,condi_worker_welfare_cf_m(53,:)./denom_firstrow_cf,'normalized',true);
                end
                if type_welfare==3
                    name_welfare='Employee welfare for women';
                    denom_firstrow_cf=usenow(39,:);
                    denom_base_cf=(usenow(39,:)).*(condi_worker_welfare_cf_f(53,1)/(usenow(39,1)));

                    % WORKER WELFARE across counterfactuals
                    tablerow_latex(fileid_now,name_welfare,condi_worker_welfare_cf_f(53,:)./denom_firstrow_cf,'normalized',true);
                end
            end

            if option_extra_moments
                % Breakdown of utility:
                if type_welfare==1
                    %0) unemployment
                    tablerow_latex(fileid_now,'\quad unemployment',(usenow(6,:)+usenow(14,:))./denom_base_cf,'raw',true);
                    tablerow_latex(fileid_now,'\quad \quad men',(usenow(6,:))./denom_base_cf,'raw',true);
                    tablerow_latex(fileid_now,'\quad \quad women',(usenow(14,:))./denom_base_cf,'raw',true);
                end

                %1) payroll
                if type_welfare==1
                    tablerow_latex(fileid_now,'\quad total payroll',usenow(54,:)./denom_base_cf,'raw',true);
                end
                if (type_welfare==1)|| (type_welfare==2)
                    % broken down by gender:
                    if type_welfare==1, string_inside='\quad \quad \quad men';
                    elseif type_welfare==2, string_inside='\quad payroll';
                    end
                    tablerow_latex(fileid_now,string_inside,usenow(48,:)./denom_base_cf,'raw',true);
                end
                if (type_welfare==1)|| (type_welfare==3)
                    if type_welfare==1, string_inside='\quad \quad \quad women';
                    elseif type_welfare==3, string_inside='\quad payroll';
                    end
                    tablerow_latex(fileid_now,string_inside,usenow(49,:)./denom_base_cf,'raw',true);
                end
                % 2) amenity value
                if type_welfare==1
                    tablerow_latex(fileid_now,'\quad total amenity value',usenow(55,:)./denom_base_cf,'raw',true);
                end
                % broken down by gender:
                if (type_welfare==1)|| (type_welfare==2)
                    if type_welfare==1, string_inside='\quad \quad \quad men';
                    elseif type_welfare==2, string_inside='\quad amenities';
                    end
                    tablerow_latex(fileid_now,string_inside,usenow(41,:)./denom_base_cf,'raw',true);
                end
                if (type_welfare==1)|| (type_welfare==3)
                    if type_welfare==1, string_inside='\quad \quad \quad women';
                    elseif type_welfare==3, string_inside='\quad amenities';
                    end
                    tablerow_latex(fileid_now,string_inside,usenow(40,:)./denom_base_cf,'raw',true);
                end
                fprintf(fileid_now,' \\vspace{-.25cm} \\\\ \n ');
            end


        end

        if option_extra_moments
            % EMPLOYER WELFARE across counterfactuals
            tablerow_latex(fileid_now,'Employer welfare',usenow(56,:)./usenow(56,1),'raw',true);

            % Breakdown of employer welfare:
            % 1) Profits
            tablerow_latex(fileid_now,'\quad profits',usenow(57,:)./usenow(56,1),'raw',true);
            % 2) Wedges
            tablerow_latex(fileid_now,'\quad wedges',-usenow(42,:)./usenow(56,1),'raw',true);

            fprintf(fileid_now,' \\vspace{-.25cm} \\\\ \n ');
        end

        % Total employment
        if kk==6
            % just sum
            tablerow_latex(fileid_now,sprintf('Total employment'),usenow(50,:) + usenow(39,:),'raw',true);
        else
            tablerow_latex(fileid_now,sprintf('Total employment'),(1-measure_f).*usenow(50,:) + measure_f.*usenow(39,:),'raw',true);
        end
        % Male employment
        tablerow_latex(fileid_now,sprintf('\\quad for men'),usenow(50,:),'raw',true);
        % Female employment
        tablerow_latex(fileid_now,sprintf('\\quad for women'),usenow(39,:),'raw',true);

        if option_extra_moments
            % Offer rate from nonemployment for men
            tablerow_latex(fileid_now,sprintf('Offer rate from nonemployment for men'),usenow(61,:),'raw',true);
            % Offer rate from nonemployment for women
            tablerow_latex(fileid_now,sprintf('Offer rate from nonemployment for women'),usenow(31,:),'raw',true);

            % Job-to-job transition rate for men
            tablerow_latex(fileid_now,sprintf('Job-to-job transition rate for men'),usenow(25,:),'raw',true);
            % Offer rate from nonemployment for women
            tablerow_latex(fileid_now,sprintf('Job-to-job transition rate for women'),usenow(26,:),'raw',true);
        end

        % Spacing, hlines and end of table
        fprintf(fileid_now,' \\vspace{-.25cm} \\\\ \\hline \n');
        fprintf(fileid_now,' \\end{tabular} \n');
        fclose(fileid_now);
    end


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Model fit table
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    load(sprintf('%s/targets_model.mat',DIR_TEMP),'targets');
    modelvsdata=[targets mom_counterfactual(1:68,1)];
    fileid_cf_base=fopen(sprintf('%s/tab_model_fit.tex',dirtowrite_cf),'w+');
    fprintf(fileid_cf_base,' \\begin{tabular}{l c c c c} \\hline\\hline \n');
    fprintf(fileid_cf_base,' Moment & Description & Data && Model \\\\ \\hline \n');

    tablerow_latex(fileid_cf_base,sprintf('$\\mathop{\\mathbb{E}}[\\psi_M-\\psi_F]$ &  Gender log pay gap'),(modelvsdata(9,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('$\\mathop{\\mathbb{E}}[\\psi_F \\vert g=M]-\\mathbb{E}[\\psi_F \\vert g=F)]$ &  Gender log pay gap between employers'),(modelvsdata(27,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('$\\mathop{\\mathbb{E}}[\\psi_F-\\psi_M \\vert g=F]$ &  Gender log pay gap within employers'),(modelvsdata(28,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('${\\text{\\it{Var}}}[\\psi_M]$ &  Variance of men''s pay'),(modelvsdata(2,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('${\\text{\\it{Var}}}[\\psi_F]$ &  Variance of women''s pay'),(modelvsdata(10,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('${\\text{\\it{Var}}}[\\psi_M-\\psi_F]$ &  Variance of gender pay gap'),(modelvsdata(35,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('$\\mathop{\\mathbb{E}}[\\lambda_M^E (1 - F_M(x)) + \\lambda_M^G]$ &  Job to job transition rate for men'),(modelvsdata(25,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('$\\mathop{\\mathbb{E}}[\\lambda_F^E (1 - F_F(x)) + \\lambda_F^G]$ &  Job to job transition rate for women'),(modelvsdata(26,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('$\\mathop{\\mathbb{P}}[\\psi_M''<\\psi_M]$ &  Wage decline probability after job to job for men'),(modelvsdata(8,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('$\\mathop{\\mathbb{P}}[\\psi_F''<\\psi_F]$ &  Wage decline probability after job to job for women'),(modelvsdata(16,1:2)),'raw',true);
    tablerow_latex(fileid_cf_base,sprintf('${\\text{\\it{Corr}}}(\\psi_M,\\psi_F)$ &  Correlation between men''s and women''s pay'),sqrt(modelvsdata(17,1:2)),'raw',true);

    fprintf(fileid_cf_base,' \\hline');
    fprintf(fileid_cf_base,' \\end{tabular} \n');
    fclose(fileid_cf_base);


    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%% From here on, small files are generated for the Latex code to make
    %%%% numbers mentioned in the paper text automatic
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % codes to define folder of text results
    dirtowrite_cf=sprintf('%s/text',DIR_RESULTS);

    % 1. eta_v
    fileid_texinput=fopen(sprintf('%s/txt_model_baseline_eta_v.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.3f',eta_v);
    fclose(fileid_texinput);

    % 2. eta_amenities
    fileid_texinput=fopen(sprintf('%s/txt_model_baseline_eta_a.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.3f',eta_amenities);
    fclose(fileid_texinput);

    % 3. understatement of gender gap difference in model fit
    fileid_texinput=fopen(sprintf('%s/txt_model_fit_gap_difference.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',(100*(modelvsdata(9,1)-modelvsdata(9,2))));
    fclose(fileid_texinput);

    % 4a. DECLINE in gender gap in CF with no amenity heterogeneity
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_amenities_gap_decline.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',-100*(tab_cf(9,2)-tab_cf(9,1)));
    fclose(fileid_texinput);

    % 4b. DECLINE in gender gap in CF with no amenity heterogeneity (percentage points)
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_amenities_gap_decline_pp.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',-100*(tab_cf(9,2)-tab_cf(9,1))/tab_cf(9,1));
    fclose(fileid_texinput);

    % 4c. DECLINE in between gender gap in CF with no amenity heterogeneity
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_amenities_gap_decline_between.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',-100*(tab_cf(27,2)-tab_cf(27,1)));
    fclose(fileid_texinput);

    % 4d. INCREASE in within gender gap in CF with no amenity heterogeneity
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_amenities_gap_increase_within.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',100*(tab_cf(28,2)-tab_cf(28,1)));
    fclose(fileid_texinput);

    % 4e. INCREASE in employment in CF with no amenity heterogeneity
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_amenities_employment_increase.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',100*((1-measure_f)*tab_cf(50,2)+measure_f*tab_cf(39,2)-(1-measure_f)*tab_cf(50,1)-measure_f*tab_cf(39,1)));
    fclose(fileid_texinput);

    % 4f. INCREASE in output in CF with no amenity heterogeneity
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_amenities_output_increase.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',100*(tab_cf(36,2)-tab_cf(36,1))/tab_cf(36,1));
    fclose(fileid_texinput);

    workerwelfare_fortext=tab_cf(48,:) + tab_cf(49,:) + tab_cf(40,:) + tab_cf(41,:) + tab_cf(6,:) + tab_cf(14,:);
    % 4g. INCREASE in worker welfare in CF with no amenity heterogeneity
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_amenities_workerwelfare_increase.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',100*(workerwelfare_fortext(2)-workerwelfare_fortext(1))/workerwelfare_fortext(1));
    fclose(fileid_texinput);

    % 5a. DECLINE in output in Equal Pay Policy (percentage)
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_equalpay_output_decrease.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',-100*(tab_policy_cf(36,2)-tab_policy_cf(36,1))/tab_policy_cf(36,1));
    fclose(fileid_texinput);

    % 5b. CLOSING of gender pay gap in Equal Pay Policy (percentage)
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_equalpay_gendergap_closing.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%2.1f',-100*(tab_policy_cf(9,2)-tab_policy_cf(9,1))/tab_policy_cf(9,1));
    fclose(fileid_texinput);

    % 6a. DECLINE of gender pay gap in Equal Hiring Policy
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_equalhiring_gendergap_decline.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%2.1f',-100*(tab_policy_cf(9,3)-tab_policy_cf(9,1)));
    fclose(fileid_texinput);

    % 7a. DECLINE of output in Equal Amenities Policy
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_equalamenities_output_decline.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%2.1f',-100*(tab_policy_cf_equalamenities(36,2)-tab_policy_cf_equalamenities(36,1))/tab_policy_cf_equalamenities(36,1));
    fclose(fileid_texinput);

    workerwelfare_fortext=tab_policy_cf_equalamenities(48,:) + tab_policy_cf_equalamenities(49,:) + tab_policy_cf_equalamenities(40,:) + ...
        tab_policy_cf_equalamenities(41,:) + tab_policy_cf_equalamenities(6,:) + tab_policy_cf_equalamenities(14,:);
    % 7b. DECLINE of welfare in Equal Amenities Policy
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_equalamenities_welfare_decline.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%2.1f',-100*(workerwelfare_fortext(2)-workerwelfare_fortext(1))/workerwelfare_fortext(1));
    fclose(fileid_texinput);

    % 8a. DECLINE of Gender Pay Gap in Equal Hiring Policy Public Sector Only
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_equalhiring_public_gendergap_decline.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%2.1f',-100*(tab_policy_cf_equalhiring_public(9,3)-tab_policy_cf_equalhiring_public(9,1)));
    fclose(fileid_texinput);

    % 8b. INCREASE of Gender Amenities Gap in Equal Hiring Policy Public Sector Only
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_equalhiring_public_amenitiesgap_increase.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%2.1f',100*(tab_policy_cf_equalhiring_public(62,3)-tab_policy_cf_equalhiring_public(62,1)));
    fclose(fileid_texinput);


    %%%%%%%%%%%%%%%%%% numbers for Appendix counterfactuals %%%%%%%%%%%%%%%%%%%
    % 9a. INCREASE of Output in No Wedges counterfactual
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_nowedges_output_increase.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',100*(tab_cf_all(36,3)-tab_cf_all(36,1))/tab_cf_all(36,1));
    fclose(fileid_texinput);

    % 9b. INCREASE of Gender amenities gap in No Wedges counterfactual
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_nowedges_amenitiesgap_increase.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%2.1f',100*(tab_cf_all(62,3)-tab_cf_all(62,1)));
    fclose(fileid_texinput);

    % 9c. DECREASE of Gender utility gap in No Wedges counterfactual
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_nowedges_utilitygap_decrease.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',-100*(tab_cf_all(71,3)-tab_cf_all(71,1)));
    fclose(fileid_texinput);

    % 9d. Baseline Gender utility gap in No Wedges counterfactual
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_utilitygap_baseline.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%2.1f',100*(tab_cf_all(71,1)));
    fclose(fileid_texinput);

    workerwelfare_fortext=tab_cf_all(49,:) + tab_cf_all(40,:) + tab_cf_all(14,:);
    % 9e. INCREASE of Women Worker Welfare in No Wedges counterfactual
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_nowedges_womenwelfare_increase.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',100*(workerwelfare_fortext(3)-workerwelfare_fortext(1))/workerwelfare_fortext(1));
    fclose(fileid_texinput);

    % 9f. DECREASE of Gender pay gap in Frictions counterfactual
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_frictions_wagegap_decrease.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',-100*(tab_cf_all(9,4)-tab_cf_all(9,1)));
    fclose(fileid_texinput);

    % 9g. DECREASE of Gender utility gap in Frictions counterfactual
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_frictions_utilitygap_decrease.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',-100*(tab_cf_all(71,4)-tab_cf_all(71,1)));
    fclose(fileid_texinput);

    % 9h. INCREASE of Output in Gender-neutral counterfactual
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_genderneutral_output_increase.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',100*(tab_cf_all(36,5)-tab_cf_all(36,1))/tab_cf_all(36,1));
    fclose(fileid_texinput);

    workerwelfare_fortext=tab_cf_all(48,:) + tab_cf_all(49,:) + tab_cf_all(40,:) + ...
        tab_cf_all(41,:) + tab_cf_all(6,:) + tab_cf_all(14,:);
    % 9i. INCREASE of Welfare in Gender-neutral counterfactual
    fileid_texinput=fopen(sprintf('%s/txt_model_cf_genderneutral_welfare_increase.tex',dirtowrite_cf),'w+');
    fprintf(fileid_texinput,'%1.1f',100*(workerwelfare_fortext(5)-workerwelfare_fortext(1))/workerwelfare_fortext(1));
    fclose(fileid_texinput);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BEGINNING OF HELPER FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function outrow = tablerow_latex(whichfile,namerow,moments_in,type_mom,firstin)

    %==========================================================================
    % DESCRIPTION: This helper function writes rows of tables with several options
    %              for relative moments, absolute differences etc.
    %
    % AUTHORS:     Iacopo Morchio
    %              Christian Moser
    %
    % DATE:        November 4, 2025
    %==========================================================================

    fprintf(whichfile,'  %s  ',namerow);

    if not(firstin)
        fprintf(whichfile,'& - & ');
        kstart=2;
    else
        kstart=1;
    end
    for k=kstart:numel(moments_in)
        if strcmp(type_mom,'raw')
            if moments_in(k)<0
                fprintf(whichfile,' & $%2.3f$ ',moments_in(k));
            else
                fprintf(whichfile,' & $\\hphantom{-}%2.3f$ ',moments_in(k));
            end
        elseif strcmp(type_mom,'raw_change')
            if moments_in(k)-moments_in(1) < 0
                fprintf(whichfile,' & $%2.3f$ ',moments_in(k)-moments_in(1));
            else
                fprintf(whichfile,' & $\\hphantom{-}%2.3f$ ',moments_in(k)-moments_in(1));
            end
        elseif strcmp(type_mom,'normalized')
            if moments_in(k)/moments_in(1) < 0
                fprintf(whichfile,' & $%2.3f$ ',moments_in(k)/moments_in(1));
            else
                fprintf(whichfile,' & $\\hphantom{-}%2.3f$ ',moments_in(k)/moments_in(1));
            end
        elseif strcmp(type_mom,'raw_percent')
            fprintf(whichfile,' & %2.3f ',100*moments_in(k));
        elseif strcmp(type_mom,'raw_percent2')
            fprintf(whichfile,' & %2.3f ',100*moments_in(k));
        elseif strcmp(type_mom,'raw_percent_normalized')
            fprintf(whichfile,' & %2.3f ',100*(moments_in(k)/moments_in(1)));
        elseif strcmp(type_mom,'percent_dev')
            if k == 1
                fprintf(whichfile,' & %2.3f ',moments_in(k));
            else
                fprintf(whichfile,' & (%2.3f) ',100*(moments_in(k)-moments_in(1))/moments_in(1));
            end
        elseif strcmp(type_mom,'percent_log_dev')
            if k == 1
                fprintf(whichfile,' & %2.3f ',100*moments_in(k));
            else
                fprintf(whichfile,' & (%2.3f) ',100*(moments_in(k)-moments_in(1)));
            end
        end
        if k == 1, fprintf(whichfile,' & '); end
    end
    fprintf(whichfile,' \\\\ \n');
    outrow=0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF HELPER FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
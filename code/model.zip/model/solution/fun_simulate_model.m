function [res, mom1, mom_distrib, mom_policy_comparison] = fun_simulate_model( ...
        wheretosave, dostats, eta_v, eta_amenities, loadpolicy, ...
        distribution_type, solutionmethod, counterfactual, policy_x, ...
        type_simu, params, ~, ~, phi_men, phi_women, F_wpi_men, ...
        F_wpi_women, effective_w_men, effective_w_women, egrid_ppi_men, ...
        egrid_ppi_women, ~, ~, vcost_men, vcost_women)

    %==========================================================================
    % DESCRIPTION: This function simulates the distribution of firms and
    %              computes statistics
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - wheretosave: where results are saved
    %                dostats: whether to compute additional statistics
    %                eta_v, eta_amenities: cost elasticities
    %                loadpolicy: load the policy function from file
    %                distributiontype: how the data is passed, default=nonparametric
    %                solutionmethod: DISCRETE
    %                counterfactual: the specific counterfactual simulation
    %                policy_x: the specific policy to be solved
    %                type_simu: type of simulation (GE or PE)
    %                params: the parameters
    %                MU, SIGMA: properties of continuous distribution, unused
    %                phi_men, phi_women: outside options
    %                F_wpi_men,F_wpi_women: offer CDFs
    %                effective_w_men,effective_w_women: utility offers
    %                egrid_ppi_men,egrid_ppi_women: grids for utility offers
    %                ptilde_grid: unused
    %                vcost_men,vcost_women: costs of posting vacancies
    %
    % OUTPUTS:     - res
    %                mom1: the main moments for tables
    %                mom_distrib: additional moments in the distribution
    %                mom_policy_comparison: further moments for policies
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % Start the simulation timing
    startsim_tic=tic;

    % Whether to trim top of distribution; shut down
    trim_high=1.1;

    % Set maximum computational threads
    maxNumCompThreads(4);

    % set options
    cost_type='absolute';
    type_of_stat='worker_weighted';
    typestat='log';
    nranks=1;
    nbins=1000;

    if (nargin < 1), wheretosave='none'; end
    if (nargin < 2), dostats=0; end
    if (nargin < 3), eta_v=0; end
    if (nargin < 4), eta_amenities=0; end
    if (nargin < 5), loadpolicy=1; end
    if (nargin < 6), distribution_type='parametric'; end
    if (nargin < 7), solutionmethod='DISCRETE'; end
    if (nargin < 8), counterfactual='baseline'; end
    if (nargin < 9), policy_x='none'; end
    if (nargin < 10), type_simu='GE'; end

    % set random seed
    rng(20250826, 'twister')

    % set an arbitrary result value
    res=0;

    % Load the policy function
    if loadpolicy == 1
        %Load policy functions
        load(sprintf('%s/policyf_%s.mat',DIR_TEMP,counterfactual),'params','egrid_ppi_men','egrid_ppi_women','effective_w_men','effective_w_women',...
            'firm_sizes_men','firm_sizes_women','ptilde_grid_m','ptilde_grid_f','MU','SIGMA','phi_men','phi_women',...
            'F_wpi_men','F_wpi_women','vcost_men','vcost_women','adjf_men','adjf_women','b_m','b_f');
    end

    % parameters are overwritten if reading from data
    delta_m=params(1);
    lambda_u_m=params(3);
    lambda_e_m=params(2)*lambda_u_m;
    alpha=params(4);
    p_scale=params(9);    varp=params(10);
    pi_men_scale=params(11);  varpi_men=params(12);
    pi_women_scale=params(13);  varpi_women=params(14);
    z_scale=params(15);  varz=params(16);

    delta_f=params(20);
    lambda_u_f=params(22).*lambda_u_m;
    lambda_e_f=params(21).*lambda_u_f;
    b_women=params(23);
    meas_f=params(24);
    meas_m=params(25);
    lambda_g_m=lambda_u_m*params(27);
    lambda_g_f=lambda_u_f*params(28);

    % read the firm-level fundamentals and parameters
    if strcmp(distribution_type,'nonparametric')
        load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_u_m','lambda_u_f','lambda_e_m','lambda_e_f','lambda_g_m','lambda_g_f',...
            'delta_m','delta_f','p','pi_m','pi_f','c_m','c_f','z','phi_load_men','phi_load_women',...
            'fe_m','fe_f','f_m','f_f','F_m','F_f','only_m','only_f','p_m','p_f','empid',...
            'g_m','g_f','public_sector');
        p_draw=p;
        pimen_draw=pi_m;
        piwomen_draw=pi_f;
        z_draw=z;
        onegender=max(only_m,only_f);

        % override parameters with those modified by counterfactuals
        load(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_u_m','lambda_u_f','lambda_e_m','lambda_e_f','lambda_g_m','lambda_g_f',...
            'delta_m','delta_f');

        nbins=round(numel(p_draw)/10000); %adjust number of bins to number of firms
        Nfirms=numel(p_draw);
        Nfirms_orig_men=Nfirms;
        Nfirms_orig_women=Nfirms;

        % adjustments
        if (eta_amenities > 0) && not(strcmp(counterfactual,'baseline_no_amenities'))
            pi_cost_m=1./(pimen_draw.^(eta_amenities-1));
            pi_cost_f=1./(piwomen_draw.^(eta_amenities-1));
        else
            pi_cost_m=zeros(numel(pimen_draw),1);
            pi_cost_f=zeros(numel(piwomen_draw),1);
        end

        %Load endogenous amenities created by policy solvers
        if strcmp(policy_x,'none')
        elseif strcmp(policy_x,'equalpay')
            if eta_amenities > 0
                load(sprintf('%s/results/policy_function/amenities_endo_policy.mat',DIR_INPUT),'pi_m_policy','pi_f_policy');
                %save old amenities to adjust productivity terms
                old_pi_m=pimen_draw;
                old_pi_f=piwomen_draw;
                pimen_draw=pi_m_policy;
                piwomen_draw=pi_f_policy;
            end
        elseif strcmp(policy_x,'equalpay_equalhiring')
            if eta_amenities > 0
                load(sprintf('%s/results/policy_function/amenities_endo_policy_pay_hire.mat',DIR_INPUT),'pi_m_policy','pi_f_policy','twogender_policy','only_m_policy','only_f_policy');
                %save old amenities to adjust productivity terms
                old_pi_m=pimen_draw;
                old_pi_f=piwomen_draw;
                pimen_draw=pi_m_policy;
                piwomen_draw=pi_f_policy;
                only_m=only_m_policy;
                only_f=only_f_policy;
            end
        elseif strcmp(policy_x,'equal_amenities')
            if eta_amenities > 0
                load(sprintf('%s/results/policy_function/amenities_endo_policy_equalame.mat',DIR_INPUT),'pi_m_policy','pi_f_policy','twogender_policy','only_m_policy','only_f_policy');
                %save old amenities to adjust productivity terms
                old_pi_m=pimen_draw;
                old_pi_f=piwomen_draw;
                pimen_draw=pi_m_policy;
                piwomen_draw=pi_f_policy;
                only_m=only_m_policy;
                only_f=only_f_policy;
            end
        end
    end

    % Transition rates are adjusted by the endogenous factor adjf solved by the
    % policy/counterfactual solvers
    lambda_u_m=lambda_u_m.*adjf_men;
    lambda_u_f=lambda_u_f.*adjf_women;
    lambda_e_m=lambda_e_m.*adjf_men;
    lambda_e_f=lambda_e_f.*adjf_women;
    lambda_g_m=lambda_g_m.*adjf_men;
    lambda_g_f=lambda_g_f.*adjf_women;

    % unemployment and vacancies
    u_m=delta_m/(delta_m+lambda_u_m+lambda_g_m);
    u_f=delta_f/(delta_f+lambda_u_f+lambda_g_f);
    V_m=(lambda_u_m.^(1/alpha)).*meas_m.*(u_m + (lambda_e_m./lambda_u_m).*(1-u_m) + (lambda_g_m/lambda_u_m));
    V_f=(lambda_u_f.^(1/alpha)).*meas_f.*(u_f + (lambda_e_f./lambda_u_f).*(1-u_f) + (lambda_g_f/lambda_u_f));

    % adjustments for counterfactuals
    if strcmp(counterfactual,'baseline_no_amenities')
        piwomen_draw=piwomen_draw.*0;
        pi_cost_f=pi_cost_f.*0;
    end
    if strcmp(counterfactual,'baseline_amenities_equal_mean')
        old_mean_pi_m=mean(pimen_draw(not(only_f)));
        old_mean_pi_f=mean(piwomen_draw(not(only_m)));

        pimen_draw=pimen_draw.*0 + old_mean_pi_m;
        piwomen_draw=piwomen_draw.*0 + old_mean_pi_f;

        pi_cost_f=pi_cost_f.*0 + old_mean_pi_f.^(1 - eta_amenities);
        pi_cost_m=pi_cost_m.*0 + old_mean_pi_m.^(1 - eta_amenities);
    end
    if (strcmp(counterfactual,'baseline_equal_amenities_M'))
        %Counterfactual equalizing amenities to value of MEN
        piwomen_draw(not(onegender))=pimen_draw(not(onegender));    %apply CF only to dual-gender firms
        pi_cost_f(not(onegender))=pi_cost_m(not(onegender));
        % Phi has already been adjusted previously
    end
    if (strcmp(counterfactual,'baseline_nodifference_all'))
        %Counterfactual equalizing all, and amenities to value of MEN
        piwomen_draw=pimen_draw;    %apply CF only to single-gender firms
        pi_cost_f=pi_cost_m;
        % Phi has already been adjusted previously
    end
    if strcmp(counterfactual,'baseline_equal_amenities_F')
        pimen_draw(not(onegender))=piwomen_draw(not(onegender));
        pi_cost_m(not(onegender))=pi_cost_f(not(onegender));
    end
    if (strcmp(counterfactual,'baseline_z_equal_mean'))
        %Counterfactual shutting down gender wedge heterogeneity
        tausim=p_draw.*0;
        tausim(not(onegender))=z_draw(not(onegender))./p_draw(not(onegender));
        meantau=sum(tausim(not(onegender)).*g_f(not(onegender)));
        z_draw(not(onegender))=meantau.*p_draw(not(onegender));
    end
    if (strcmp(counterfactual,'baseline_noz'))
        z_draw(not(onegender))=z_draw(not(onegender)).*0;
    end
    if (strcmp(counterfactual,'baseline_nodifference_all'))
        z_draw=z_draw.*0;
    end

    % Adjustments for composite productivity when amenities change
    if (strcmp(policy_x,'equalpay')) && (eta_amenities > 0)
        adjust_ppi_men=zeros(numel(pimen_draw),1);
        adjust_ppi_women=zeros(numel(piwomen_draw),1);
        adjust_ppi_men(not(onegender) & (pimen_draw>-1))=(old_pi_m(not(onegender) & (pimen_draw>-1))/eta_amenities) - ...
            (pi_cost_m(not(onegender) & (pimen_draw>-1))./eta_amenities).*(pimen_draw(not(onegender) & (pimen_draw>-1)).^eta_amenities);
        adjust_ppi_women(not(onegender) & (piwomen_draw>-1))=(old_pi_f(not(onegender) & (piwomen_draw>-1))/eta_amenities) - ...
            (pi_cost_f(not(onegender) & (piwomen_draw>-1))./eta_amenities).*(piwomen_draw(not(onegender) & (piwomen_draw>-1)).^eta_amenities);
    elseif (strcmp(policy_x,'equalpay_equalhiring') || strcmp(policy_x,'equal_amenities')) && (eta_amenities > 0)
        adjust_ppi_men=zeros(numel(pimen_draw),1);
        adjust_ppi_women=zeros(numel(piwomen_draw),1);
        adjust_ppi_men(twogender_policy & (pimen_draw>-1))=(old_pi_m(twogender_policy & (pimen_draw>-1))/eta_amenities) - ...
            (pi_cost_m(twogender_policy & (pimen_draw>-1))./eta_amenities).*(pimen_draw(twogender_policy & (pimen_draw>-1)).^eta_amenities);
        adjust_ppi_women(twogender_policy & (piwomen_draw>-1))=(old_pi_f(twogender_policy & (piwomen_draw>-1))/eta_amenities) - ...
            (pi_cost_f(twogender_policy & (piwomen_draw>-1))./eta_amenities).*(piwomen_draw(twogender_policy & (piwomen_draw>-1)).^eta_amenities);
    else
        adjust_ppi_men=0;
        adjust_ppi_women=0;
    end

    clear randdraw

    % Re-define composite productivity using adjustments
    if (strcmp(policy_x,'equalpay') || strcmp(policy_x,'equalpay_equalhiring') || strcmp(policy_x,'equal_amenities')) && (eta_amenities > 0)
        ptilde_m=p_draw+pimen_draw-old_pi_m/eta_amenities+adjust_ppi_men;
        ptilde_f=p_draw+piwomen_draw-old_pi_f/eta_amenities-z_draw+adjust_ppi_women;
        ptilde_m(pimen_draw<0)=phi_men-1;
        ptilde_f(piwomen_draw<0)=phi_women-1;
    elseif (eta_amenities > 0) && (not(strcmp(counterfactual,'baseline_no_amenities')))
        ptilde_m=p_draw+pimen_draw-pimen_draw/eta_amenities;
        ptilde_f=p_draw+piwomen_draw-z_draw-piwomen_draw/eta_amenities;
    elseif (eta_amenities > 0) && (strcmp(counterfactual,'baseline_no_amenities'))
        ptilde_m=p_draw+pimen_draw-pimen_draw/eta_amenities;
        ptilde_f=p_draw+piwomen_draw-z_draw;
    elseif (eta_amenities == 0)
        ptilde_m=p_draw+pimen_draw;
        ptilde_f=p_draw+piwomen_draw-z_draw;
    end

    %Last adjustment: when amenities are converted into productivity
    if strcmp(counterfactual,'baseline_amenities_are_p')
        % convert all of ptilde into productivity
        p_draw=ptilde_m;
        % Move productivity for women
        ptilde_f=p_draw - z_draw;
        % Eliminate amenities
        pimen_draw=pimen_draw.*0;
        piwomen_draw=piwomen_draw.*0;
    end

    % adjustments for single-gender firms
    if sum(only_f)>0
        if strcmp(policy_x,'equalpay')
            piwomen_draw(only_f)=old_pi_f(only_f);
        end
        ptilde_m(only_f)=phi_load_men-1-rand(sum(only_f),1)*0.5;
        if (eta_amenities > 0) && (not(strcmp(counterfactual,'baseline_no_amenities')))
            ptilde_f(only_f)=p_f(only_f)+piwomen_draw(only_f)-piwomen_draw(only_f)/eta_amenities;
        else
            ptilde_f(only_f)=p_f(only_f)+piwomen_draw(only_f);
        end
    end
    if sum(only_m)>0
        if strcmp(policy_x,'equalpay')
            pimen_draw(only_m)=old_pi_m(only_m);
        end
        ptilde_f(only_m)=phi_load_women-1-rand(sum(only_m),1)*0.5;
        if (eta_amenities > 0) && (not(strcmp(counterfactual,'baseline_no_amenities')))
            ptilde_m(only_m)=p_m(only_m)+pimen_draw(only_m)-pimen_draw(only_m)/eta_amenities;
        else
            ptilde_m(only_m)=p_m(only_m)+pimen_draw(only_m);
        end
    end
    if strcmp(counterfactual,'baseline_nodifference_all')
        ptilde_f(only_m)=ptilde_m(only_m);
        ptilde_f(only_f)=phi_women-1-rand(sum(only_f),1)*0.5;
    end

    ptilde_m(ptilde_m<phi_men)=0;
    ptilde_f(ptilde_f<phi_women)=0;

    % remove firms below outside option or above trimming point if set
    remove_low=zeros(numel(ptilde_m),1);
    if trim_high < 1
        remove_high=max((ptilde_m>quantile(ptilde_m,trim_high)),(ptilde_f>quantile(ptilde_f,trim_high)));
    end
    if trim_high > 1, remove_high=zeros(numel(ptilde_m),1); end
    removeobs=max(remove_low,remove_high);
    p_draw=p_draw(removeobs==0);
    pimen_draw=pimen_draw(removeobs==0);
    piwomen_draw=piwomen_draw(removeobs==0);
    pi_cost_m=pi_cost_m(removeobs==0);
    pi_cost_f=pi_cost_f(removeobs==0);
    z_draw=z_draw(removeobs==0);
    c_m=c_m(removeobs==0);
    c_f=c_f(removeobs==0);
    empid=empid(removeobs==0);
    only_m=only_m(removeobs==0);
    only_f=only_f(removeobs==0);
    public_sector=public_sector(removeobs==0);

    fe_m=fe_m(removeobs==0);
    fe_f=fe_f(removeobs==0);
    f_m=f_m(removeobs==0);
    f_f=f_f(removeobs==0);
    F_m=F_m(removeobs==0);
    F_f=F_f(removeobs==0);
    onegender=onegender(removeobs==0);
    if strcmp(policy_x,'equalpay_equalhiring') || strcmp(policy_x,'equal_amenities')
        twogender_policy=twogender_policy(removeobs==0);
    end

    % apply policy to public sector only for appropriate counterfactual
    if strcmp(policy_x,'equalhiring_public')
        policy_application=(public_sector==1);
    else
        policy_application=(public_sector.*0 == 0);
    end

    % if appropriate, equalize vacancy posting costs (for no-difference CF)
    if params(5) == 100000
        %equalize vacancy posting costs
        if varz ~= 100
            c_f(not(onegender))=c_m(not(onegender));    %apply only to single-gender firms
        else
            c_f=c_m;
        end
    end
    if strcmp(cost_type,'units_of_output')
        c_m=c_m.*p_draw;
        c_f=c_f.*(p_draw-z_draw);
    end
    ptilde_m=ptilde_m(removeobs==0);
    ptilde_f=ptilde_f(removeobs==0);

    % firms below outside options cannot post vacancies
    ptilde_m(isnan(ptilde_m))=phi_men-1-rand(numel(sum(isnan(ptilde_m))),1).*0.5;
    ptilde_f(isnan(ptilde_f))=phi_women-1-rand(numel(sum(isnan(ptilde_f))),1).*0.5;
    clear remove_low remove_high removeobs

    exit_m=(ptilde_m<phi_men);
    exit_f=(ptilde_f<phi_women);

    % calculate utility offers by firm
    eff_w_f_men=interp1(egrid_ppi_men,effective_w_men,ptilde_m,'spline');
    eff_w_f_women=interp1(egrid_ppi_women,effective_w_women,ptilde_f,'spline');
    eff_w_f_men(ptilde_m<phi_men)=-100;
    eff_w_f_women(ptilde_f<phi_women)=-100;
    eff_w_f_men(isnan(ptilde_m))=-100;
    eff_w_f_women(isnan(ptilde_f))=-100;
    eff_w_f_men(exit_m)=-100;
    eff_w_f_women(exit_f)=-100;
    ptilde_m(exit_m)=0;
    ptilde_f(exit_f)=0;
    p_draw(exit_m)=0;
    z_draw(exit_f)=0;

    % calculate wages
    w_f_men=eff_w_f_men-pimen_draw;
    w_f_women=eff_w_f_women-piwomen_draw;

    % convert to logs depending on type of statistics specified
    if strcmp(typestat,'log')
        w_f_men(eff_w_f_men-pimen_draw<0)=-100;
        w_f_women(eff_w_f_women-piwomen_draw<0)=-100;
        w_f_men(w_f_men<=0)=-100;
        w_f_women(w_f_women<=0)=-100;
        w_f_men(w_f_men>-100)=log(w_f_men(w_f_men>-100));
        w_f_women(w_f_women>-100)=log(w_f_women(w_f_women>-100));
    end

    w_f_men(exit_m)=-100;
    w_f_women(exit_f)=-100;

    % cutting non-active firms
    checknan=not(isnan(w_f_men).*isnan(w_f_women) == 1);
    fprintf('%g%% of observations can be cut! (draws below outside option) \n',(1-(sum(checknan)/numel(ptilde_m)))*100);
    ptilde_m=ptilde_m(checknan);
    ptilde_f=ptilde_f(checknan);
    p_draw=p_draw(checknan);
    pimen_draw=pimen_draw(checknan);
    piwomen_draw=piwomen_draw(checknan);
    z_draw=z_draw(checknan);
    eff_w_f_men=eff_w_f_men(checknan);
    eff_w_f_women=eff_w_f_women(checknan);
    w_f_men=w_f_men(checknan);
    w_f_women=w_f_women(checknan);
    c_m=c_m(checknan);
    c_f=c_f(checknan);
    f_m=f_m(checknan);
    f_f=f_f(checknan);
    F_m=F_m(checknan);
    F_f=F_f(checknan);
    fe_m=fe_m(checknan);
    fe_f=fe_f(checknan);
    empid=empid(checknan);
    only_m=only_m(checknan);
    only_f=only_f(checknan);
    pi_cost_m=pi_cost_m(checknan);
    pi_cost_f=pi_cost_f(checknan);
    onegender=onegender(checknan);
    exit_m=exit_m(checknan);
    exit_f=exit_f(checknan);
    policy_application=policy_application(checknan);
    public_sector=public_sector(checknan);
    if strcmp(policy_x,'equalpay_equalhiring') || strcmp(policy_x,'equal_amenities')
        twogender_policy=twogender_policy(checknan);
    end

    % Calculate T: rates have already been adjusted to new vacancy posting
    Tm=meas_m.*((u_m + lambda_g_m/lambda_u_m)*lambda_u_m*(delta_m + lambda_g_m + lambda_e_m))/V_m;
    Tf=meas_f.*((u_f + lambda_g_f/lambda_u_f)*lambda_u_f*(delta_f + lambda_g_f + lambda_e_f))/V_f;

    % Calculate offer CDF
    [sorted_egrid_ppi_men,idx_ppi_men]=sort(egrid_ppi_men);
    [sorted_egrid_ppi_women,idx_ppi_women]=sort(egrid_ppi_women);
    F_firm_m_interp=griddedInterpolant(sorted_egrid_ppi_men,F_wpi_men(idx_ppi_men),'makima','nearest');
    F_firm_f_interp=griddedInterpolant(sorted_egrid_ppi_women,F_wpi_women(idx_ppi_women),'makima','nearest');

    F_firm_m=F_firm_m_interp(ptilde_m);
    F_firm_f=F_firm_f_interp(ptilde_f);

    F_firm_m(exit_m)=0;
    F_firm_f(exit_f)=0;

    F_firm_m(w_f_men==-100)=0;
    F_firm_f(w_f_women==-100)=0;

    % calculate vacancies by firm
    if strcmp(solutionmethod,'DISCRETE')
        vmen=((Tm./(vcost_men.*c_m)).*(max(ptilde_m-eff_w_f_men,0)).*((1./(delta_m + lambda_g_m + lambda_e_m.*(1 - F_firm_m))).^2)).^(1./(eta_v-1));
        vwomen=((Tf./(vcost_women.*c_f)).*(max(ptilde_f-eff_w_f_women,0)).*((1./(delta_f + lambda_g_f + lambda_e_f.*(1 - F_firm_f))).^2)).^(1./(eta_v-1));

        if (strcmp(policy_x,'equalhiring')) || (strcmp(policy_x,'equalpay_equalhiring')) || (strcmp(policy_x,'equalhiring_public'))
            vjoint=(((Tm./(vcost_men.*c_m + vcost_women.*c_f)).*(ptilde_m-eff_w_f_men).*((1./(delta_m + lambda_g_m + lambda_e_m.*(1 - F_firm_m))).^2)) + ...
                ((Tf./(vcost_men.*c_m + vcost_women.*c_f)).*(ptilde_f-eff_w_f_women).*((1./(delta_f + lambda_g_f + lambda_e_f.*(1 - F_firm_f))).^2))).^(1./(eta_v-1));
            if strcmp(policy_x,'equalpay_equalhiring')
                vmen(twogender_policy)=vjoint(twogender_policy);
                vwomen(twogender_policy)=vjoint(twogender_policy);
            else
                vmen(not(onegender) & policy_application)=vjoint(not(onegender) & policy_application);
                vwomen(not(onegender) & policy_application)=vjoint(not(onegender) & policy_application);
            end
        end
        vmen=vmen/Nfirms_orig_men;
        vwomen=vwomen/Nfirms_orig_women;
    end

    vmen(exit_m)=0;
    vwomen(exit_f)=0;
    vmen(w_f_men==-100)=0;
    vwomen(w_f_women==-100)=0;
    vmen(eff_w_f_men==-100)=0;
    vwomen(eff_w_f_women==-100)=0;

    fprintf('Single-gender firms: M %g%%, F %g%% \n',100*sum(vwomen==0)/numel(vwomen),100*sum(vmen==0)/numel(vmen));

    %%%%%%%%%%% Model against data %%%%%%%%%%%%
    if strcmp(solutionmethod,'DISCRETE')
        fprintf('Correlations between model and data, firm by firm: \n');
        fprintf('Wages (men, women):  (%g, %g)  \n',corr(fe_m(not(only_f) & not(isnan(w_f_men))),w_f_men(not(only_f)  & not(isnan(w_f_men)))),...
            corr(fe_f(not(only_m) & not(isnan(w_f_women))),w_f_women(not(only_m) & not(isnan(w_f_women)))));
        fprintf('f     (men, women):  (%g, %g)  \n',corr(f_m(not(only_f)),vmen(not(only_f))),corr(f_f(not(only_m)),vwomen(not(only_m))));
        fprintf('F     (men, women):  (%g, %g)  \n',corr(F_m(not(only_f) & not(isnan(F_firm_m))),F_firm_m(not(only_f) & not(isnan(F_firm_m)))),...
            corr(F_f(not(only_m) & not(isnan(F_firm_f))),F_firm_f(not(only_m) & not(isnan(F_firm_f)))));
        constant_term_m=ones(sum(not(only_f) & not(isnan(w_f_men))),1);
        constant_term_f=ones(sum(not(only_m) & not(isnan(w_f_women))),1);
        wages_Xm=[constant_term_m fe_m(not(only_f) & not(isnan(w_f_men)))];    wages_Ym=w_f_men(not(only_f) & not(isnan(w_f_men)));
        wages_Xf=[constant_term_f fe_f(not(only_m) & not(isnan(w_f_women)))];  wages_Yf=w_f_women(not(only_m) & not(isnan(w_f_women)));
        betas_wages_m=(wages_Xm'*wages_Xm)\(wages_Xm'*wages_Ym);
        betas_wages_f=(wages_Xf'*wages_Xf)\(wages_Xf'*wages_Yf);
        fprintf('Alphas and Betas between model and data, firm by firm: \n');
        fprintf('Wages (men, women):  [%g, %g] [%g, %g]  \n',betas_wages_m(1),betas_wages_m(2),betas_wages_f(1),betas_wages_f(2));
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % calculate firm sizes
    size_f_men=(ptilde_m>=phi_men).*((((1./(delta_m + lambda_g_m + lambda_e_m.*(1 - F_firm_m_interp(ptilde_m)))).^2)) .* vmen.* Tm);
    size_f_women=(ptilde_f>=phi_women).*((((1./(delta_f + lambda_g_f + lambda_e_f.*(1 - F_firm_f_interp(ptilde_f)))).^2)) .* vwomen.* Tf);
    size_f_men(exit_m)=0;
    size_f_women(exit_f)=0;
    fprintf('Vacancies: M %g, F %g.   Size: M %g, F %g \n',sum(vmen),sum(vwomen),sum(size_f_men),sum(size_f_women));

    % calculate amenity costs
    if (eta_amenities > 0) && (not(strcmp(counterfactual,'baseline_no_amenities')))
        amenity_costs_men=sum(size_f_men.*(pi_cost_m.*pimen_draw.^eta_amenities)./eta_amenities);
        amenity_costs_women=sum(size_f_women.*(pi_cost_f.*piwomen_draw.^eta_amenities)./eta_amenities);
    else
        amenity_costs_men=0;
        amenity_costs_women=0;
    end

    % start calculating moments
    % vacancy posting costs
    vac_post_costs_men=sum((vcost_men.*c_m).*(vmen.^eta_v))/eta_v;
    vac_post_costs_women=sum((vcost_women.*c_f).*(vwomen.^eta_v))/eta_v;

    % total output and wedges
    tot_productivity=sum(p_draw.*size_f_men) + sum(p_draw.*size_f_women);
    tot_output=tot_productivity;
    tot_z=sum((z_draw(not(isnan(ptilde_f)))).*size_f_women(not(isnan(ptilde_f))));

    tot_output_withz=tot_output - tot_z;

    % total utility and amenities
    tot_utility=sum(ptilde_m(not(isnan(ptilde_m))).*size_f_men(not(isnan(ptilde_m)))) + ...
        sum((ptilde_f(not(isnan(ptilde_f)))).*size_f_women(not(isnan(ptilde_f)))) - ...
        vac_post_costs_men - vac_post_costs_women;
    female_amenities=sum((piwomen_draw(not(isnan(ptilde_f)))).*size_f_women(not(isnan(ptilde_f))));
    male_amenities=sum((pimen_draw(not(isnan(ptilde_m)))).*size_f_men(not(isnan(ptilde_m))));

    % Moments for breakdown of welfare
    if strcmp(typestat,'log')
        wagebill_men=sum(exp(w_f_men(not(isnan(ptilde_m)) & not(isnan(w_f_men)))).*size_f_men(not(isnan(ptilde_m)) & not(isnan(w_f_men))));
        wagebill_women=sum(exp(w_f_women(not(isnan(ptilde_f)) & not(isnan(w_f_women)))).*size_f_women(not(isnan(ptilde_f)) & not(isnan(w_f_women))));
    else
        wagebill_men=sum((w_f_men(not(isnan(ptilde_m)) & not(isnan(w_f_men)))).*size_f_men(not(isnan(ptilde_m)) & not(isnan(w_f_men))));
        wagebill_women=sum((w_f_women(not(isnan(ptilde_f)) & not(isnan(w_f_women)))).*size_f_women(not(isnan(ptilde_f)) & not(isnan(w_f_women))));

    end

    % Moments that impose distribution of men on women (normalized by emp. rate)
    tot_output_femaleemp_equal_maleemp=sum(p_draw.*size_f_men) + sum(p_draw.*size_f_men.*(sum(size_f_women)/sum(size_f_men)));
    tot_utility_femaleemp_equal_maleemp=sum(ptilde_m(not(isnan(ptilde_m))).*size_f_men(not(isnan(ptilde_m)))) + ...
        sum((ptilde_f(not(isnan(ptilde_f)))).*(size_f_men(not(isnan(ptilde_f))).*(sum(size_f_women(not(isnan(ptilde_f))))/sum(size_f_men(not(isnan(ptilde_m)))))));

    % female shares in every firm
    femaleshare_f=size_f_women./(size_f_women+size_f_men);
    femaleshare_f((size_f_women==0) & (size_f_men==0))=0.5;

    % convert sizes to logs
    if strcmp(typestat,'log')
        size_f_men(size_f_men<=0)=NaN;
        size_f_women(size_f_women<=0)=NaN;
        size_f_men=log(size_f_men);
        size_f_women=log(size_f_women);
    end

    w_f_men(isnan(size_f_men))=NaN;
    w_f_women(isnan(size_f_women))=NaN;

    % selection criteria within men, within women and for dual-gender firms
    sel_formen_stat=((not((isnan(ptilde_m))))&(ptilde_m>=phi_men)&not(isnan(w_f_men))&not(isnan(size_f_men)));
    sel_forwomen_stat=((not((isnan(ptilde_f))))&(ptilde_f>=phi_women)&not(isnan(w_f_women))&not(isnan(size_f_women)));
    sel_forall_stat=((sel_formen_stat.*sel_forwomen_stat)==1);

    % gender wage gap
    if strcmp(typestat,'log')
        gendergap=w_f_men-w_f_women;
    else
        %Gender gap defined in terms of average men wage
        gendergap=(w_f_men-w_f_women)./(sum(w_f_men(sel_formen_stat).*size_f_men(sel_formen_stat))/sum(size_f_men(sel_formen_stat)));
    end
    gendergap(isnan(w_f_men))=0;
    gendergap(isnan(w_f_women))=0;

    % Using tiedrank for precision
    rank_w_f_men=tiedrank(w_f_men);
    rank_w_f_women=tiedrank(w_f_women);
    rank_size_f_men=tiedrank(size_f_men);
    rank_size_f_women=tiedrank(size_f_women);
    % transform ranks
    rank_w_f_men=((rank_w_f_men/max(rank_w_f_men))*nranks);
    rank_w_f_women=((rank_w_f_women/max(rank_w_f_women))*nranks);
    rank_size_f_men=((rank_size_f_men/max(rank_size_f_men))*nranks);
    rank_size_f_women=((rank_size_f_women/max(rank_size_f_women))*nranks);

    % %weights for worker-weighted statistics are computed here
    if strcmp(typestat,'log')
        weights_obs_men=exp(size_f_men(sel_formen_stat))./sum(exp(size_f_men(sel_formen_stat)));
        weights_obs_women=exp(size_f_women(sel_forwomen_stat))./sum(exp(size_f_women(sel_forwomen_stat)));
        weights_obs_all=(exp(size_f_men(sel_forall_stat))+exp(size_f_women(sel_forall_stat)))./ ...
            sum(exp(size_f_men(sel_forall_stat))+exp(size_f_women(sel_forall_stat)));
        weights_obs_all_men=(exp(size_f_men(sel_forall_stat)))./ ...
            sum(exp(size_f_men(sel_forall_stat)));
        weights_obs_all_women=(exp(size_f_women(sel_forall_stat)))./ ...
            sum(exp(size_f_women(sel_forall_stat)));
    else
        weights_obs_men=size_f_men(sel_formen_stat)./sum(size_f_men(sel_formen_stat));
        weights_obs_women=size_f_women(sel_forwomen_stat)./sum(size_f_women(sel_forwomen_stat));
        weights_obs_all=(size_f_men(sel_forall_stat)+size_f_women(sel_forall_stat))./sum(size_f_men(sel_forall_stat)+size_f_women(sel_forall_stat));
        weights_obs_all_men=((size_f_men(sel_forall_stat)))./ ...
            sum((size_f_men(sel_forall_stat)));
        weights_obs_all_women=((size_f_women(sel_forall_stat)))./ ...
            sum((size_f_women(sel_forall_stat)));
    end

    % J2J transition rates
    J2J_men=lambda_e_m.*sum(weights_obs_men.*(1-F_firm_m(sel_formen_stat))) + lambda_g_m;
    J2J_women=lambda_e_f.*sum(weights_obs_women.*(1-F_firm_f(sel_forwomen_stat))) + lambda_g_f;

    % distributional statistics
    % Men:
    [w_f_men_sorted,idx_w_f]=sort(w_f_men(not(isnan(w_f_men))));
    sizenow=(exp(size_f_men(not(isnan(w_f_men)))));
    cumdist_w_men=cumsum(sizenow(idx_w_f))/sum(sizenow);
    median_w_men_left=min(w_f_men_sorted(cumdist_w_men>=0.495));
    median_w_men_right=min(w_f_men_sorted(cumdist_w_men>=0.505));
    selecmedian_men=(w_f_men_sorted>median_w_men_left).*(w_f_men_sorted<median_w_men_right);
    median_w_men=sum(w_f_men_sorted.*sizenow(idx_w_f).*selecmedian_men)/sum(sizenow.*selecmedian_men);
    clear selecmedian_men
    bottom1_w_men_left=min(w_f_men_sorted(cumdist_w_men>=0.005));
    bottom1_w_men_right=min(w_f_men_sorted(cumdist_w_men>=0.015));
    selecbottom1_men=(w_f_men_sorted>bottom1_w_men_left).*(w_f_men_sorted<bottom1_w_men_right);
    bottom1_w_men=sum(w_f_men_sorted.*sizenow(idx_w_f).*selecbottom1_men)/sum(sizenow.*selecbottom1_men);
    clear selecbottom1_men sizenow w_f_men_sorted idx_w_f cumdist_w_men
    % Women:
    [w_f_women_sorted,idx_w_f]=sort(w_f_women(not(isnan(w_f_women))));
    sizenow=(exp(size_f_women(not(isnan(w_f_women)))));
    cumdist_w_women=cumsum(sizenow(idx_w_f))/sum(sizenow);
    median_w_women_left=min(w_f_women_sorted(cumdist_w_women>=0.495));
    median_w_women_right=min(w_f_women_sorted(cumdist_w_women>=0.505));
    selecmedian_women=(w_f_women_sorted>median_w_women_left).*(w_f_women_sorted<median_w_women_right);
    median_w_women=sum(w_f_women_sorted.*sizenow(idx_w_f).*selecmedian_women)/sum(sizenow.*selecmedian_women);
    clear selecmedian_women
    bottom1_w_women_left=min(w_f_women_sorted(cumdist_w_women>=0.005));
    bottom1_w_women_right=min(w_f_women_sorted(cumdist_w_women>=0.015));
    selecbottom1_women=(w_f_women_sorted>bottom1_w_women_left).*(w_f_women_sorted<bottom1_w_women_right);
    bottom1_w_women=sum(w_f_women_sorted.*sizenow(idx_w_f).*selecbottom1_women)/sum(sizenow.*selecbottom1_women);
    clear selecbottom1_women sizenow w_f_women_sorted idx_w_f cumdist_w_women

    % export simulation data
    if strcmp(type_simu,'GE')
        %export simulation data to Stata
        AAA=[empid p_draw pimen_draw piwomen_draw z_draw w_f_men w_f_women ...
            size_f_men size_f_women vmen vwomen F_firm_m F_firm_f fe_m fe_f F_m F_f f_m f_f];
        AAA(isnan(AAA))=-10000;
        dlmwrite(sprintf('%s/sim_data.txt',DIR_TEMP),AAA,'delimiter','\t','precision',15);
        clear AAA
    end


    % start outputting moments
    if strcmp(type_of_stat,'worker_weighted')

        mom_distrib=zeros(8,1);
        if dostats > 0
            %compute statistics for distribution of p, pi and z
            mom_distrib(1)=sum(p_draw(sel_formen_stat).*weights_obs_men);
            mom_distrib(2)=sum(p_draw(sel_forwomen_stat).*weights_obs_women);
            mom_distrib(3)=sum(pimen_draw(sel_formen_stat).*weights_obs_men);
            mom_distrib(4)=sum(pimen_draw(sel_forwomen_stat).*weights_obs_women);
            mom_distrib(5)=sum(piwomen_draw(sel_formen_stat).*weights_obs_men);
            mom_distrib(6)=sum(piwomen_draw(sel_forwomen_stat).*weights_obs_women);
            mom_distrib(7)=sum(z_draw(sel_formen_stat).*weights_obs_men);
            mom_distrib(8)=sum(z_draw(sel_forwomen_stat).*weights_obs_women);
        end

        mean_w_men=sum(w_f_men(sel_formen_stat).*weights_obs_men);
        mean_w_women=sum(w_f_women(sel_forwomen_stat).*weights_obs_women);

        if not(strcmp(counterfactual,'baseline_no_amenities'))
            mean_log_amenities_m=sum(log(pimen_draw(sel_formen_stat)).*weights_obs_men);
            mean_log_amenities_f=sum(log(piwomen_draw(sel_forwomen_stat)).*weights_obs_women);
            mean_log_utility_m=sum(log(exp(w_f_men(sel_formen_stat))+pimen_draw(sel_formen_stat)).*weights_obs_men);
            mean_log_utility_f=sum(log(exp(w_f_women(sel_forwomen_stat))+piwomen_draw(sel_forwomen_stat)).*weights_obs_women);
        else
            mean_log_amenities_m=0;
            mean_log_amenities_f=0;
            mean_log_utility_m=sum(((w_f_men(sel_formen_stat))).*weights_obs_men);
            mean_log_utility_f=sum(((w_f_women(sel_forwomen_stat))).*weights_obs_women);
        end

        var_w_men=sum(((w_f_men(sel_formen_stat)-mean_w_men).^2).*weights_obs_men);
        var_w_women=sum(((w_f_women(sel_forwomen_stat)-mean_w_women).^2).*weights_obs_women);

        mean_size_men=sum(size_f_men(sel_formen_stat).*weights_obs_men);
        mean_size_women=sum(size_f_women(sel_forwomen_stat).*weights_obs_women);

        var_size_men=sum(((size_f_men(sel_formen_stat)-mean_size_men).^2).*weights_obs_men);
        var_size_women=sum(((size_f_women(sel_forwomen_stat)-mean_size_women).^2).*weights_obs_women);

        mean_rank_w_men=sum(rank_w_f_men(sel_formen_stat).*weights_obs_men);
        mean_rank_w_women=sum(rank_w_f_women(sel_forwomen_stat).*weights_obs_women);
        mean_rank_size_men=sum(rank_size_f_men(sel_formen_stat).*weights_obs_men);
        mean_rank_size_women=sum(rank_size_f_women(sel_forwomen_stat).*weights_obs_women);
        mean_gendergap=sum(gendergap(sel_forall_stat).*weights_obs_all);

        var_rank_w_men=sum(((rank_w_f_men(sel_formen_stat)-mean_rank_w_men).^2).*weights_obs_men);
        var_rank_w_women=sum(((rank_w_f_women(sel_forwomen_stat)-mean_rank_w_women).^2).*weights_obs_women);
        var_rank_size_men=sum(((rank_size_f_men(sel_formen_stat)-mean_rank_size_men).^2).*weights_obs_men);
        var_rank_size_women=sum(((rank_size_f_women(sel_forwomen_stat)-mean_rank_size_women).^2).*weights_obs_women);

        mean_w_men_forall=sum(w_f_men(sel_forall_stat).*weights_obs_all_men);
        mean_w_women_forall=sum(w_f_women(sel_forall_stat).*weights_obs_all_women);
        mean_femaleshare_forall=sum(femaleshare_f(sel_forall_stat).*weights_obs_all_women);
        mean_rank_w_men_forall=sum(rank_w_f_men(sel_forall_stat).*weights_obs_all_men);
        mean_rank_w_women_forall=sum(rank_w_f_women(sel_forall_stat).*weights_obs_all_women);
        mean_size_men_forall=sum(size_f_men(sel_forall_stat).*weights_obs_all_men);
        mean_size_women_forall=sum(size_f_women(sel_forall_stat).*weights_obs_all_women);
        mean_rank_size_men_forall=sum(rank_size_f_men(sel_forall_stat).*weights_obs_all_men);
        mean_rank_size_women_forall=sum(rank_size_f_women(sel_forall_stat).*weights_obs_all_women);

        var_w_men_forall=sum(((w_f_men(sel_forall_stat)-mean_w_men_forall).^2).*weights_obs_all_men);
        var_w_women_forall=sum(((w_f_women(sel_forall_stat)-mean_w_women_forall).^2).*weights_obs_all_women);
        var_femaleshare_forall=sum(((femaleshare_f(sel_forall_stat)-mean_femaleshare_forall).^2).*weights_obs_all_women);
        var_size_men_forall=sum(((size_f_men(sel_forall_stat)-mean_size_men_forall).^2).*weights_obs_all_men);
        var_size_women_forall=sum(((size_f_women(sel_forall_stat)-mean_size_women_forall).^2).*weights_obs_all_women);
        var_rank_w_men_forall=sum(((rank_w_f_men(sel_forall_stat)-mean_rank_w_men_forall).^2).*weights_obs_all_men);
        var_rank_w_women_forall=sum(((rank_w_f_women(sel_forall_stat)-mean_rank_w_women_forall).^2).*weights_obs_all_women);
        var_rank_size_men_forall=sum(((rank_size_f_men(sel_forall_stat)-mean_rank_size_men_forall).^2).*weights_obs_all_men);
        var_rank_size_women_forall=sum(((rank_size_f_women(sel_forall_stat)-mean_rank_size_women_forall).^2).*weights_obs_all_women);
        var_gendergap=sum(((gendergap(sel_forall_stat)-mean_gendergap).^2).*weights_obs_all);

        corr_w_size_men=sum((w_f_men(sel_formen_stat)-mean_w_men).*...
            (size_f_men(sel_formen_stat)-mean_size_men).*weights_obs_men)/sqrt(var_w_men*var_size_men);
        corr_w_size_women=(sum((w_f_women(sel_forwomen_stat)-mean_w_women).*...
            (size_f_women(sel_forwomen_stat)-mean_size_women).*weights_obs_women))/sqrt(var_w_women*var_size_women);

        corr_w_size_men_ranks=sum((rank_w_f_men(sel_formen_stat)-mean_rank_w_men).*...
            (rank_size_f_men(sel_formen_stat)-mean_rank_size_men).*weights_obs_men)/sqrt(var_rank_w_men*var_rank_size_men);
        corr_w_size_women_ranks=sum((rank_w_f_women(sel_forwomen_stat)-mean_rank_w_women).*...
            (rank_size_f_women(sel_forwomen_stat)-mean_rank_size_women).*weights_obs_women)/sqrt(var_rank_w_women*var_rank_size_women);

        corr_w_men_w_women=sum((w_f_men(sel_forall_stat)-mean_w_men_forall).*...
            (w_f_women(sel_forall_stat)-mean_w_women_forall).*weights_obs_all)/sqrt(var_w_men_forall*var_w_women_forall);
        corr_w_men_w_women_ranks=sum((rank_w_f_men(sel_forall_stat)-mean_rank_w_men_forall).*...
            (rank_w_f_women(sel_forall_stat)-mean_rank_w_women_forall).*weights_obs_all)/sqrt(var_rank_w_men_forall*var_rank_w_women_forall);

        corr_size_men_size_women=sum((size_f_men(sel_forall_stat)-mean_size_men_forall).*...
            (size_f_women(sel_forall_stat)-mean_size_women_forall).*weights_obs_all)/sqrt(var_size_men_forall*var_size_women_forall);
        corr_rank_size_men_rank_size_women=sum((rank_size_f_men(sel_forall_stat)-mean_rank_size_men_forall).*...
            (rank_size_f_women(sel_forall_stat)-mean_rank_size_women_forall).*weights_obs_all)/sqrt(var_rank_size_men_forall*var_rank_size_women_forall);

        beta_rank_w_men_gendergap=sum((rank_w_f_men(sel_forall_stat)-mean_rank_w_men_forall).*...
            (gendergap(sel_forall_stat)-mean_gendergap).*weights_obs_all)/(var_rank_w_men_forall);

        %New formula for optimization, uses corr = beta*sqrt(var x1)/sqrt(var x2)
        corr_rank_w_men_gendergap=beta_rank_w_men_gendergap.*sqrt(var_rank_w_men_forall)./sqrt(var_gendergap);

        beta_w_size_men=sum((w_f_men(sel_forall_stat)-mean_w_men_forall).*...
            (size_f_men(sel_forall_stat)-mean_size_men_forall).*weights_obs_all_men)/(var_size_men_forall);

        beta_w_size_women=sum((w_f_men(sel_forall_stat)-mean_w_women_forall).*...
            (size_f_women(sel_forall_stat)-mean_size_women_forall).*weights_obs_all_women)/(var_size_women_forall);

        %Moments concerning the female share
        beta_gendergap_fshare=sum((femaleshare_f(sel_forall_stat)-mean_femaleshare_forall).*...
            (gendergap(sel_forall_stat)-mean_gendergap).*weights_obs_all_women)/(var_femaleshare_forall);
        corr_gendergap_fshare=beta_gendergap_fshare.*sqrt(var_femaleshare_forall)./sqrt(var_gendergap);

        if strcmp(typestat,'log')
            fe_women=w_f_men-w_f_women;
            gendergap_between=sum(w_f_men(sel_forall_stat).*weights_obs_all_men)-sum(w_f_men(sel_forall_stat).*weights_obs_all_women);
            gendergap_within=sum(fe_women(sel_forall_stat).*weights_obs_all_women);
            if (not(strcmp(counterfactual,'baseline_no_amenities'))) && (not(strcmp(counterfactual,'baseline_amenities_are_p')))
                amenities_gap=log(pimen_draw)-log(piwomen_draw);
                utility_gap=log(exp(w_f_men)+pimen_draw)-log(exp(w_f_women)+piwomen_draw);

                % Absolute gaps useful for equal amenities policy
                abs_amenities_gap=sum((pimen_draw(sel_forall_stat)).*weights_obs_all_men)-sum((piwomen_draw(sel_forall_stat)).*weights_obs_all_women);
                abs_amenities_gap_between=sum((pimen_draw(sel_forall_stat)).*weights_obs_all_men)-sum((pimen_draw(sel_forall_stat)).*weights_obs_all_women);
                abs_amenities_gap_within=sum((pimen_draw(sel_forall_stat)-piwomen_draw(sel_forall_stat)).*weights_obs_all_women);

                % KOB terms based on multiplicative amenity term
                x_utility_m=log(exp(w_f_men(sel_forall_stat)) + pimen_draw(sel_forall_stat));
                x_utility_f=log(exp(w_f_women(sel_forall_stat)) + piwomen_draw(sel_forall_stat));
                x_utility_gap=x_utility_m-x_utility_f;
                atilde_m=x_utility_m-w_f_men(sel_forall_stat);
                atilde_f=x_utility_f-w_f_women(sel_forall_stat);
                atilde_gap=atilde_m-atilde_f;
                log_amenities_gap = sum(atilde_m.*weights_obs_all_men) - sum(atilde_f.*weights_obs_all_women);
                log_amenities_gap_between=sum(atilde_m.*weights_obs_all_men)-sum(atilde_m.*weights_obs_all_women);
                log_amenities_gap_within=sum(atilde_gap.*weights_obs_all_women);
                log_utility_gap=sum(x_utility_m.*weights_obs_all_men)-sum(x_utility_f.*weights_obs_all_women);
                log_utility_gap_between=sum(x_utility_m.*weights_obs_all_men)-sum(x_utility_m.*weights_obs_all_women);
                log_utility_gap_within=sum(x_utility_gap.*weights_obs_all_women);

                %Moments split by sample
                for kp=1:2
                    %select policy vs nonpolicy samples
                    if kp==1
                        samplenow=not(public_sector==1);   samplesolo=not(public_sector==1);   sample_weights=not(public_sector(sel_forall_stat)==1);
                        sample_weights_men=not(public_sector(sel_formen_stat)==1);
                        sample_weights_women=not(public_sector(sel_forwomen_stat)==1);
                    elseif kp==2, samplenow=(public_sector==1);    samplesolo=(public_sector==1);    sample_weights=(public_sector(sel_forall_stat)==1);
                        sample_weights_men=(public_sector(sel_formen_stat)==1);
                        sample_weights_women=(public_sector(sel_forwomen_stat)==1);
                    end

                    weights_obs_all_policy=weights_obs_all(sample_weights)./sum(weights_obs_all(sample_weights));
                    weights_obs_all_men_policy=weights_obs_all_men(sample_weights)./sum(weights_obs_all_men(sample_weights));
                    weights_obs_all_women_policy=weights_obs_all_women(sample_weights)./sum(weights_obs_all_women(sample_weights));
                    weights_obs_men_policy=weights_obs_men(sample_weights_men)./sum(weights_obs_men(sample_weights_men));
                    weights_obs_women_policy=weights_obs_women(sample_weights_women)./sum(weights_obs_women(sample_weights_women));

                    %Employment in each sector using model-implied sizes
                    male_emp_policy(kp)=sum(exp(size_f_men(sel_formen_stat & samplenow)));
                    female_emp_policy(kp)=sum(exp(size_f_women(sel_forwomen_stat & samplenow)));

                    %Mean pay
                    mean_w_men_forall_policy(kp)=sum(w_f_men(sel_formen_stat & samplenow).*weights_obs_men_policy);
                    mean_w_women_forall_policy(kp)=sum(w_f_women(sel_forwomen_stat & samplenow).*weights_obs_women_policy);
                    %Mean log amenities
                    mean_log_amenities_m_policy(kp)=sum((atilde_m(sample_weights)).*weights_obs_all_men_policy);
                    mean_log_amenities_f_policy(kp)=sum((atilde_f(sample_weights)).*weights_obs_all_women_policy);
                    %Mean log utility
                    mean_log_utility_m_policy(kp)=sum(log(exp(w_f_men(sel_formen_stat & samplenow))+pimen_draw(sel_formen_stat & samplenow)).*weights_obs_men_policy);
                    mean_log_utility_f_policy(kp)=sum(log(exp(w_f_women(sel_forwomen_stat & samplenow))+piwomen_draw(sel_forwomen_stat & samplenow)).*weights_obs_women_policy);

                    gendergap_policy(kp)=sum(w_f_men(sel_forall_stat & samplenow).*weights_obs_all_men_policy) - sum(w_f_women(sel_forall_stat & samplenow).*weights_obs_all_women_policy);
                    gendergap_between_policy(kp)=sum(w_f_men(sel_forall_stat & samplenow).*weights_obs_all_men_policy)-sum(w_f_men(sel_forall_stat & samplenow).*weights_obs_all_women_policy);
                    gendergap_within_policy(kp)=sum(fe_women(sel_forall_stat & samplenow).*weights_obs_all_women_policy);
                    log_amenities_gap_policy(kp) = sum(atilde_m(sample_weights).*weights_obs_all_men_policy) - sum(atilde_f(sample_weights).*weights_obs_all_women_policy);
                    log_amenities_gap_between_policy(kp)=sum(atilde_m(sample_weights).*weights_obs_all_men_policy)-sum(atilde_m(sample_weights).*weights_obs_all_women_policy);
                    log_amenities_gap_within_policy(kp)=sum(atilde_gap(sample_weights).*weights_obs_all_women_policy);
                    log_utility_gap_policy(kp)=sum(x_utility_m(sample_weights).*weights_obs_all_men_policy)-sum(x_utility_f(sample_weights).*weights_obs_all_women_policy);
                    log_utility_gap_between_policy(kp)=sum(x_utility_m(sample_weights).*weights_obs_all_men_policy)-sum(x_utility_m(sample_weights).*weights_obs_all_women_policy);
                    log_utility_gap_within_policy(kp)=sum(x_utility_gap(sample_weights).*weights_obs_all_women_policy);

                    tot_output_policy(kp)=sum(p_draw(samplesolo).*size_f_men(samplesolo)) + sum(p_draw(samplesolo).*size_f_women(samplesolo));

                    female_amenities_policy(kp)=sum((piwomen_draw(not(isnan(ptilde_f)) & samplesolo)).*size_f_women(not(isnan(ptilde_f)) & samplesolo));
                    male_amenities_policy(kp)=sum((pimen_draw(not(isnan(ptilde_m)) & samplesolo)).*size_f_men(not(isnan(ptilde_m)) & samplesolo));

                    % Moments for breakdown of welfare in policies
                    if strcmp(typestat,'log')
                        wagebill_men_policy(kp)=sum(exp(w_f_men(not(isnan(ptilde_m)) & not(isnan(w_f_men)) & samplesolo)).*size_f_men(not(isnan(ptilde_m)) & not(isnan(w_f_men)) & samplesolo));
                        wagebill_women_policy(kp)=sum(exp(w_f_women(not(isnan(ptilde_f)) & not(isnan(w_f_women)) & samplesolo)).*size_f_women(not(isnan(ptilde_f)) & not(isnan(w_f_women)) & samplesolo));
                    end
                end

            else
                log_amenities_gap=0;
                log_amenities_gap_between=0;
                log_amenities_gap_within=0;
                log_utility_gap_between=gendergap_between;
                log_utility_gap_within=gendergap_within;
                log_utility_gap=log_utility_gap_between+log_utility_gap_within;
            end
        end

        if strcmp(typestat,'log')
            median_to_min_w_men=(median_w_men-bottom1_w_men);
            %median_to_min_w_women=(median_w_women-bottom1_w_women);
            median_to_min_w_women=(median_w_men-bottom1_w_women);  %modded version, comparing to median of men
        else
            median_to_min_w_men=(median_w_men/bottom1_w_men);
            %median_to_min_w_women=(median_w_women/bottom1_w_women);
            median_to_min_w_women=(median_w_men/bottom1_w_women);
        end

        %Shares of workers working at single-gender firms
        share_males_onlymales=sum(exp(size_f_men(sel_formen_stat-sel_forall_stat==1)))/sum(exp(size_f_men(sel_formen_stat)));
        share_females_onlyfemales=sum(exp(size_f_women(sel_forwomen_stat-sel_forall_stat==1)))/sum(exp(size_f_women(sel_forwomen_stat)));

        female_emp=1 - u_f;
        male_emp=1 - u_m;

        % value of unemployment
        welfare_value_u_m=meas_m.*(1-male_emp).*b_m;  %6
        welfare_value_u_f=meas_f.*(1-female_emp).*b_f;    %14

        %New calculation of the probability of wage and rank declines after EE
        %transitions
        p_EE_m_new=0;
        p_EE_f_new=0;
        p_wagedecline_EE_m_new=0;
        p_wagedecline_EE_f_new=0;
        %These are vectors of J2J probability across ranks
        J2J_switch_across_ranks_m=lambda_g_m + lambda_e_m.*(1-F_m(sel_formen_stat));
        J2J_switch_across_ranks_f=lambda_g_f + lambda_e_f.*(1-F_f(sel_forwomen_stat));

        nbins_firm_changes=100;
        J2J_p_across_ranks_m=zeros(nbins_firm_changes,1);
        J2J_p_across_ranks_f=zeros(nbins_firm_changes,1);

        F_m_percentiles=prctile(F_m(sel_formen_stat),linspace(0,100,101));
        F_f_percentiles=prctile(F_f(sel_forwomen_stat),linspace(0,100,101));

        %probability of J2J across ranks in 100 percentiles
        for jj=1:100
            J2J_p_across_ranks_m(jj)=sum(J2J_switch_across_ranks_m.*(F_m(sel_formen_stat) > F_m_percentiles(jj) & F_m(sel_formen_stat)<=F_m_percentiles(jj+1)));
            J2J_p_across_ranks_f(jj)=sum(J2J_switch_across_ranks_f.*(F_f(sel_forwomen_stat) > F_f_percentiles(jj) & F_f(sel_forwomen_stat)<=F_f_percentiles(jj+1)));
        end

        scaler_precision=1000; %this is needed to avoid small numbers and imprecision in calculations
        % calculates J2J probabilities of wage decline only for the baseline case, the computations are expensive
        % uses a random sample of 30% to speed up calculations
        randomsample_size_j2j=0.3;
        if (strcmp(counterfactual,'baseline')) && (strcmp(policy_x,'none')) && (strcmp(type_simu,'GE'))
            vmennorm=vmen(sel_formen_stat)./sum(vmen(sel_formen_stat));
            vwomennorm=vwomen(sel_forwomen_stat)./sum(vwomen(sel_forwomen_stat));
            size_f_men_norm=weights_obs_men;
            size_f_women_norm=weights_obs_women;
            wage_passage_f_men=w_f_men(sel_formen_stat);
            wage_passage_f_women=w_f_women(sel_forwomen_stat);
            F_passage_f_men=F_firm_m(sel_formen_stat);
            F_passage_f_women=F_firm_f(sel_forwomen_stat);

            randomsample_m=(rand(sum(sel_formen_stat),1)<randomsample_size_j2j);
            randomsample_f=(rand(sum(sel_forwomen_stat),1)<randomsample_size_j2j);
            fprintf('Calculating the probability of wage decline for men... \n')

            for kk=1:numel(vmennorm)
                if randomsample_m(kk)
                    %vectorized version
                    weighted_likelihood_m=scaler_precision.*vmennorm.*size_f_men_norm(kk);
                    transition_happening_m=lambda_g_m + lambda_e_m.*(F_passage_f_men>F_passage_f_men(kk));
                    wagedecline_m=(wage_passage_f_men<wage_passage_f_men(kk));
                    weighted_likelihood_times_transition_happening_m=weighted_likelihood_m.*transition_happening_m;
                    p_EE_m_new=p_EE_m_new+sum(weighted_likelihood_times_transition_happening_m);
                    p_wagedecline_EE_m_new=p_wagedecline_EE_m_new+sum(weighted_likelihood_times_transition_happening_m.*wagedecline_m);
                end

            end
            fprintf('Done! \n');
            fprintf('Calculating the probability of wage decline for women... \n')
            for kk=1:numel(vwomennorm)
                if randomsample_f(kk)
                    %vectorized version
                    weighted_likelihood_f=scaler_precision.*vwomennorm.*size_f_women_norm(kk);
                    transition_happening_f=lambda_g_f + lambda_e_f.*(F_passage_f_women>F_passage_f_women(kk));
                    wagedecline_f=(wage_passage_f_women<wage_passage_f_women(kk));
                    weighted_likelihood_times_transition_happening_f=weighted_likelihood_f.*transition_happening_f;
                    p_EE_f_new=p_EE_f_new+sum(weighted_likelihood_times_transition_happening_f);
                    p_wagedecline_EE_f_new=p_wagedecline_EE_f_new+sum(weighted_likelihood_times_transition_happening_f.*wagedecline_f);
                end

            end
            fprintf('Done! \n');

        end

        % final normalizations
        p_wagedecline_EE_m_new=p_wagedecline_EE_m_new/p_EE_m_new;
        p_wagedecline_EE_f_new=p_wagedecline_EE_f_new/p_EE_f_new;
        p_EE_m_new=p_EE_m_new/scaler_precision;
        p_EE_f_new=p_EE_f_new/scaler_precision;

        % Export moments in order
        mom1=[mean_w_men; var_w_men; mean_size_men; var_size_men; ...
            corr_w_size_men; welfare_value_u_m; mean_w_women_forall; p_wagedecline_EE_m_new; ... %p_wagedecline_men; ...
            mean_w_men_forall-mean_w_women_forall; var_w_women; mean_size_women; var_size_women; ...
            corr_w_size_women; welfare_value_u_f; beta_w_size_women; p_wagedecline_EE_f_new; ... %p_wagedecline_women; ...
            corr_w_men_w_women; corr_w_men_w_women_ranks; ...
            corr_rank_size_men_rank_size_women; ...
            corr_rank_w_men_gendergap; beta_rank_w_men_gendergap; ...
            mean_gendergap; ...
            median_to_min_w_men; median_to_min_w_women; ...
            J2J_men; J2J_women; ...
            gendergap_between; gendergap_within; ...
            corr_gendergap_fshare; beta_gendergap_fshare; ...
            lambda_u_f; share_males_onlymales; share_females_onlyfemales;
            var_femaleshare_forall;
            var_gendergap;
            tot_output;
            tot_utility;
            tot_output_withz;
            female_emp;
            female_amenities;   %#40
            male_amenities;     %#41
            tot_z;      %#42
            tot_output_femaleemp_equal_maleemp;   %#43
            tot_utility_femaleemp_equal_maleemp; %#44
            vac_post_costs_men; %45
            vac_post_costs_women; %46
            tot_productivity; %47
            wagebill_men; %48
            wagebill_women; %49
            male_emp; %50
            amenity_costs_men; %51
            amenity_costs_women; %52
            zeros(6,1);             %placeholder zeros for welfare calculations
            mean_log_amenities_m; %59
            mean_log_amenities_f; %60
            lambda_u_m; %61
            log_amenities_gap; %62
            log_amenities_gap_between; %63
            log_amenities_gap_within; %64
            p_EE_m_new; %65
            p_EE_f_new; %66
            p_wagedecline_EE_m_new; %67
            p_wagedecline_EE_f_new; %68
            mean_log_utility_m; %69
            mean_log_utility_f; %70
            log_utility_gap; %71
            log_utility_gap_between; %72
            log_utility_gap_within; %73
            abs_amenities_gap; %74
            abs_amenities_gap_between; %75
            abs_amenities_gap_within; %76
            zeros(4,1);         %placeholder zeros
            ];

        % New moments for policy evaluation are saved and outputted in a
        % different file, matching positions in original moments
        mom_policy_comparison=[...
            mean_w_men_forall_policy; %1
            zeros(7-1-1,2);
            mean_w_men_forall_policy; %7
            zeros(9-7-1,2);
            gendergap_policy; %9
            zeros(27-9-1,2);
            gendergap_between_policy; %27
            gendergap_within_policy; %28
            zeros(36-28-1,2);
            tot_output_policy; %36
            zeros(39-36-1,2);
            female_emp_policy; %39
            female_amenities_policy; %40
            male_amenities_policy; %41
            zeros(48-41-1,2);
            wagebill_men_policy; %48
            wagebill_women_policy; %49
            male_emp_policy; %50
            zeros(59-50-1,2);
            mean_log_amenities_m_policy; %59
            mean_log_amenities_f_policy; %60
            zeros(62-60-1,2);
            log_amenities_gap_policy; %62
            log_amenities_gap_between_policy; %63
            log_amenities_gap_within_policy; %64
            zeros(69-64-1,2);
            mean_log_utility_m_policy; %69
            mean_log_utility_f_policy; %70
            log_utility_gap_policy; %71
            log_utility_gap_between_policy; %72
            log_utility_gap_within_policy; %73
            zeros(7,2);
            ];

    elseif strcmp(type_of_stat,'firm_weighted')
        mom1=[mean(w_f_men(sel_formen_stat)); var(w_f_men(sel_formen_stat));
            mean(size_f_men(sel_formen_stat)); var(size_f_men(sel_formen_stat)); ...
            corr(w_f_men(sel_formen_stat),size_f_men(sel_formen_stat));
            corr(rank_w_f_men(sel_formen_stat),rank_size_f_men(sel_formen_stat)); ...
            mean(w_f_women(sel_forwomen_stat)); var(w_f_women(sel_forwomen_stat));
            mean(size_f_women(sel_forwomen_stat)); var(size_f_women(sel_forwomen_stat)); ...
            corr(w_f_women(sel_forwomen_stat),size_f_women(sel_forwomen_stat));
            corr(rank_w_f_women(sel_forwomen_stat),rank_size_f_women(sel_forwomen_stat)); ...
            corr(w_f_men(sel_forall_stat),w_f_women(sel_forall_stat)); corr(rank_w_f_men(sel_forall_stat),rank_w_f_women(sel_forall_stat)); ...
            corr(size_f_women(sel_forall_stat),size_f_men(sel_forall_stat)); corr(rank_size_f_men(sel_forall_stat),rank_size_f_women(sel_forall_stat));...
            corr(rank_w_f_men(sel_forall_stat),gendergap(sel_forall_stat))];
    end

    if (isempty(wheretosave) == 0) && (not(strcmp(wheretosave,'none')))
        wheretosave=sprintf('results/%s',wheretosave);
        save(wheretosave,'mom1');
    end

    fprintf('Simulation completed, time elapsed is %g sec \n',toc(startsim_tic));
end
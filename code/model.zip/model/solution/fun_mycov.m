function res = fun_mycov(x, y, outvar, weights)

    %==========================================================================
    % DESCRIPTION: Calculates covariances or correlations, now takes an
    %              optional argument "weights" for observation weight
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - x and y for covariance; outvar (can be CovXY for
    %                covariance, VarX, VarY, CorrXY for correlation)
    %
    % OUTPUTS:     The required statistic
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % arguments
    nx = numel(x);
    if nargin < 3, outvar = "CovXY"; end
    if nargin < 4, weights = x.*0 + 1/nx; end

    weights = weights./sum(weights);

    % Scalars to make numbers more numerically stable
    scalerx = max(max(x), (max(x)-min(x)));
    scalery = max(max(y), (max(y)-min(y)));
    x = x(:)./scalerx;
    y = y(:)./scalery;
    meanx = sum(x.*weights);
    meany = sum(y.*weights);
    varx = (sum(x.*weights.*x)) - meanx*meanx; % faster formula
    vary = (sum(y.*weights.*y)) - meany*meany; % faster formula
    covxy = sum((x - meanx).*weights.*y);
    % varx = sum((x - meanx).^2)/nx;

    % Rescaling
    varx = varx*(scalerx*scalerx);
    vary = vary*scalery*scalery;
    covxy = covxy*scalerx*scalery;
    if strcmp(outvar, 'VarX')
        res = varx;
    elseif strcmp(outvar, 'VarY')
        res = vary;
    elseif strcmp(outvar, 'CovXY')
        res = covxy;
    elseif strcmp(outvar, 'CorrXY')
        res = covxy/sqrt(varx*vary);
    end
end
function [mom, mom_distrib] = fun_model_helper(counterfactual, vcosts, dostats, eta_v, eta_amenities, solutionmethod, policy_x)

    %==========================================================================
    % DESCRIPTION: This helper function solves specific
    %              models/counterfactuals and is called by fun_model
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - counterfactual to run (counterfactual), vacancy posting
    %                costs if they are kept constant (vcosts), whether to
    %                compute additional statistics (dostats), the elasticity of
    %                vacancy costs (eta_v) and of amenity costs
    %                (eta_amenities), the specific solution method
    %                (solutionmethod, only DISCRETE allowed)
    %
    % OUTPUTS:     - moments that are read by fun_model for tables
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % Default options
    if nargin < 1, counterfactual='baseline'; end
    if nargin < 2, vcosts=[0; 0]; end
    if nargin < 3, dostats=1; end
    if nargin < 4, eta_v=2; end
    if nargin < 5, eta_amenities=0; end
    if nargin < 6, solutionmethod='ODE'; end
    if nargin < 7, policy_x='none'; end
    numcores=1;

    % Load economy-wide parameters
    load(sprintf('%s/economywide_parameters.mat',DIR_TEMP),'params');

    % Load labor market objects
    load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
    % Save a copy of labor market objects to be modified for counterfactuals
    save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');

    % Instructions that modify parameters appropriately for each counterfactual
    if strcmp(counterfactual,'baseline')
        fprintf('Running baseline calibration! \n');
    elseif strcmp(counterfactual,'baseline_equalpay')
        fprintf('Running POLICY: EQUAL PAY! \n');
    elseif strcmp(counterfactual,'baseline_equalhiring')
        fprintf('Running POLICY: EQUAL HIRING! \n');
    elseif strcmp(counterfactual,'baseline_equalhiring_public')
        fprintf('Running POLICY: EQUAL HIRING ONLY IN PUBLIC SECTOR! \n');
    elseif strcmp(counterfactual,'baseline_equalpay_equalhiring')
        fprintf('Running POLICY: EQUAL PAY + HIRING! \n');
    elseif strcmp(counterfactual,'baseline_equal_amenities')
        fprintf('Running POLICY: EQUAL AMENITIES! \n');
    elseif strcmp(counterfactual,'baseline_noz')
        fprintf('Running baseline calibration with no z! \n');
    elseif strcmp(counterfactual,'baseline_z_sector')
        fprintf('Running baseline calibration with z set to sector average! \n');
        params(15)=100;
    elseif strcmp(counterfactual,'baseline_no_amenities')
        fprintf('Running baseline calibration without any amenities! \n');
        % all amenities are set to zero
    elseif strcmp(counterfactual,'baseline_equal_amenities_M')
        fprintf('Running baseline calibration with amenities F = amenities M! \n');
        % female amenities are set equal to those of men
    elseif strcmp(counterfactual,'baseline_amenities_are_p')
        fprintf('Running baseline calibration with amenities converted to productivity! \n');
        % male amenities are converted to productivity
    elseif strcmp(counterfactual,'baseline_equal_b')
        fprintf('Running baseline calibration with the same b! \n');
        params(23)=params(7); %equalize flow value of U
    elseif strcmp(counterfactual,'baseline_equal_J2J')
        fprintf('Running baseline calibration with the same lambda_e! \n');
        load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
        lambda_e_f=lambda_e_m;
        save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
    elseif strcmp(counterfactual,'baseline_equal_lab_params')
        fprintf('Running baseline calibration with the same LABOR MARKET PARAMETERS! \n');
        load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_e_m','delta_m','lambda_g_m','lambda_u_m');
        lambda_u_f=lambda_u_m;
        % vcosts(2)=vcosts(1);
        lambda_e_f=(lambda_e_m/lambda_u_m)*lambda_u_f;
        delta_f=delta_m;
        lambda_g_f=(lambda_g_m/lambda_u_m)*lambda_u_f;
        save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
        % params(5)=100000; %indicate to equalize vacancy posting costs
    elseif strcmp(counterfactual,'baseline_nodifference_1')
        fprintf('Running baseline calibration with no z, same amenities and lambda_e! \n');
        params(15)=0;
        load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
        lambda_e_f=lambda_e_m;
        save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
        % When means = 10, female amenities are set equal to those of men
        params(11)=10;
        params(13)=10;
    elseif strcmp(counterfactual,'baseline_nodelta')
        fprintf('Running baseline calibration with same delta! \n');
        load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
        delta_f=delta_m;
        save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
    elseif strcmp(counterfactual,'baseline_nogod')
        fprintf('Running baseline calibration with same godfather! \n');
        load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
        lambda_g_f=lambda_g_m;
        save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
    elseif (strcmp(counterfactual,'baseline_nodifference_all')) || (strcmp(counterfactual,'nodifference_with_z')) || ...
            (strcmp(counterfactual,'nodifference_with_pi_f')) || (strcmp(counterfactual,'nodifference_with_lab_params'))
        if (strcmp(counterfactual,'baseline_nodifference_all'))
            fprintf('Running baseline calibration with no z, same amenities and lambda_e, delta and godfather! \n');
            load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_e_m','delta_m','lambda_g_m','lambda_u_m');
            lambda_u_f=lambda_u_m;
            lambda_e_f=(lambda_e_m/lambda_u_m)*lambda_u_f;
            delta_f=delta_m;
            lambda_g_f=(lambda_g_m/lambda_u_m)*lambda_u_f;
            save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
        elseif (strcmp(counterfactual,'nodifference_with_z'))
            fprintf('Running baseline calibration with no difference except z! \n');
        elseif (strcmp(counterfactual,'nodifference_with_pi_f'))
            fprintf('Running baseline calibration with no difference except pi! \n');
        elseif (strcmp(counterfactual,'nodifference_with_lab_params'))
            fprintf('Running baseline calibration with no difference except lab params! \n');
        end
        if not(strcmp(counterfactual,'nodifference_with_z')), params(15)=0; end
        params(16)=100; % special code to indicate that single-gender firms must be copied across genders
        load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
        if not(strcmp(counterfactual,'nodifference_with_lab_params'))
            lambda_e_f=lambda_e_m;
            delta_f=delta_m;
            lambda_g_f=lambda_g_m;
            lambda_u_f=lambda_u_m;
        end
        save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_e_m','lambda_e_f','delta_m','delta_f','lambda_g_m','lambda_g_f','lambda_u_m','lambda_u_f');
        % When means = 10, female amenities are set equal to those of men
        if not(strcmp(counterfactual,'nodifference_with_pi_f'))
            params(11)=10;
            params(13)=10;
        end
        params(5)=100000; % indicate to equalize vacancy posting costs
    elseif strcmp(counterfactual,'baseline_equalposting')
        fprintf('Running baseline calibration with same vacancy posting costs! \n');
        params(5)=100000; % indicate to equalize vacancy posting costs
    end

    % passage variable for codes
    counterfactual_model=counterfactual;
    if strcmp(counterfactual,'baseline_equalpay')
        counterfactual_model='baseline';
        policy_x='equalpay';
        if numcores > 1, poolobj=parpool(numcores); end
    elseif strcmp(counterfactual,'baseline_equalhiring')
        counterfactual_model='baseline';
        policy_x='equalhiring';
    elseif strcmp(counterfactual,'baseline_equalhiring_public')
        counterfactual_model='baseline';
        policy_x='equalhiring_public';
    elseif strcmp(counterfactual,'baseline_equal_amenities')
        counterfactual_model='baseline';
        policy_x='equal_amenities';
    elseif strcmp(counterfactual,'baseline_equalpay_equalhiring')
        counterfactual_model='baseline';
        policy_x='equalpay_equalhiring';
    else
        policy_x='none';
    end

    % Solve the policy function
    fun_model_GG(params,0,1,vcosts,eta_v,eta_amenities,counterfactual_model,policy_x);
    if numcores > 1, delete(poolobj); end
    sim_vector="GE";

    % Simulate the distribution
    [~,mom,mom_distrib,mom_policy_comparison]=fun_simulate_model('none',dostats,eta_v,eta_amenities,1,'nonparametric',solutionmethod,counterfactual_model,policy_x,sim_vector(1));

    % Save the moments in an appropriate file to be read by fun_model.m
    namesave=sprintf('%s/results/moments_%s_%s.mat', DIR_INPUT, counterfactual, sim_vector(1));
    save(namesave, 'params', 'mom', 'mom_policy_comparison');
end
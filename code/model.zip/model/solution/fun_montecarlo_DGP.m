function [pi_out, p_out, pi_graph_comparison, p_graph_comparison] = fun_montecarlo_DGP(N, eta_v, shared_correlation, create_figures)

    %==========================================================================
    % DESCRIPTION: This function draws a distribution of fundamentals by groups, solves
    %              the model for each group, then estimates it to showcase that the algorithm recovers the
    %              true average parameters across groups subject to model
    %              structure from a known data-generating process (DGP)
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      Number of observations (N), elasticity of vacancy costs, eta_v, correlation across groups in group-specific components (shared_correlation), whether to create the figures or not (create_figures)
    %
    % OUTPUTS:     - results/figures/MC_AB_scatter_phat_vs_real_average_p_X_N_rho(shared_correlation)_Y.eps, where
    %                X is the specific experiment type, N is the above input, Y
    %                is the number of the specific experiment
    %              - results/figures/MC_AB_scatter_ahat_vs_real_average_a_X_N_rho(shared_correlation)_Y.eps, where
    %                X is the specific experiment type, N is the above input, Y is the number of
    %                specific experiment
    %              - results/tables/tab_montecarlo_misspecification_N_etav(eta_v)_rho(shared_correlation).tex, where N is the above
    %                input
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % set random seed
    rng(20250826, 'twister')

    % set solution method
    method='FOCs';

    % Set default options
    if nargin < 1, N=100000; end
    if nargin < 2, eta_v=2; end
    if nargin < 3, shared_correlation=0; end
    if nargin < 4, create_figures=false; end

    % run different experiments with different variance of p_noise, pi_noise and
    % correlation between p and pi across groups
    p_noise_exp=[0.0 0.1 0.2 0.5 1.0 2.0];
    pi_noise_exp=[0.0 0.1 0.2 0.5 1.0 2.0];
    p_corr_exp=ones(1,6)*shared_correlation;
    pi_corr_exp=ones(1,6)*shared_correlation;

    % Set up baseline variance of amenities
    varamenities=0.15;
    corramenities=0;

    nexp=numel(p_noise_exp);
    ngroups=2;

    %Parameters
    % Set up variance/covariance matrix of initial joint random normal
    % (converted to Pareto for productivity)
    var_p=1;
    var_pi=varamenities(1);
    corr_p_pi=corramenities(1);
    SIGMA=[var_p  corr_p_pi*sqrt(var_p)*sqrt(var_pi)  corr_p_pi*sqrt(var_p)*sqrt(var_pi)  0;...
        corr_p_pi*sqrt(var_p)*sqrt(var_pi)  var_pi  0.9*var_pi  0; ...
        corr_p_pi*sqrt(var_p)*sqrt(var_pi) 0.9*var_pi var_pi 0; ...
        0 0 0 0.00001;];

    lambda_u_m=0.09;
    lambda_u_f=0.09;
    lambda_e_m=0.01;
    lambda_e_f=0.01;
    lambda_g_m=0.01;
    lambda_g_f=0.01;
    delta_m=0.02;
    delta_f=0.02;
    randdraw_base=mvnrnd([0; 0; 0; 0],SIGMA,N);

    eta_amenities=6;
    counterfactual_model='baseline';
    policy_x='none';
    vcosts=[0; 0];

    for k=1:nexp

        p_ranks_noise=p_noise_exp(k);
        pi_ranks_noise=pi_noise_exp(k);
        corr_p1_p2_rank=p_corr_exp(k);
        corr_pi1_pi2_rank=pi_corr_exp(k);

        % Add idiosyncratic features of groups
        % with arbitrary correlation structure
        SIGMA_ranks_noise = [(p_ranks_noise)*var_p (p_ranks_noise)*var_p*corr_p1_p2_rank 0 0; ...
            p_ranks_noise*var_p*corr_p1_p2_rank (p_ranks_noise)*var_p 0 0; ...
            0 0 (pi_ranks_noise)*var_pi (pi_ranks_noise)*var_pi*corr_pi1_pi2_rank; ...
            0 0 (pi_ranks_noise)*var_pi*corr_pi1_pi2_rank (pi_ranks_noise)*var_pi];
        draw_noise_groups = mvnrnd([0; 0; 0; 0],SIGMA_ranks_noise,N);

        % Generate group-specific data, solve model group-by-group
        for jj=1:ngroups
            randdraw=randdraw_base;

            randdraw(:,1)=randdraw(:,1)+draw_noise_groups(:,jj);
            randdraw(:,2)=randdraw(:,2)+draw_noise_groups(:,2+jj);

            %adjustment so that variance of amenities remains unchanged
            randdraw(:,1)=(randdraw(:,1)./sqrt(var(randdraw(:,1))))*sqrt(varamenities);
            randdraw(:,2)=(randdraw(:,2)./sqrt(var(randdraw(:,2))))*sqrt(varamenities);

            fprintf('Correlation of p and p_group_%g is %g \n',jj,corr(randdraw(:,1),randdraw_base(:,1)));
            fprintf('Correlation of a and a_group_%g is %g \n',jj,corr(randdraw(:,2),randdraw_base(:,2)));

            randdraw_pareto=normcdf(randdraw(:,1)./sqrt(var(randdraw(:,1))));
            kappa_pareto=1/6;   sigma_pareto=0.5;     theta_pareto=sigma_pareto/kappa_pareto;
            p_dgp(:,jj)=gpinv(randdraw_pareto,kappa_pareto,sigma_pareto,theta_pareto);
            p=p_dgp(:,jj);

            pi_m_dgp(:,jj)=randdraw(:,2);   pi_m_dgp(:,jj)=pi_m_dgp(:,jj)-min(pi_m_dgp(:,jj))+0.01;         pi_m=pi_m_dgp(:,jj);
            pi_f_dgp(:,jj)=randdraw(:,3);   pi_f_dgp(:,jj)=pi_f_dgp(:,jj)-min(pi_f_dgp(:,jj))+0.01;         pi_f=pi_f_dgp(:,jj);
            z_dgp(:,jj)=randdraw(:,4);      z=z_dgp(:,jj);
            phi_load_men_dgp(jj)=3;         phi_load_men=phi_load_men_dgp(jj);
            phi_load_women_dgp(jj)=3;       phi_load_women=phi_load_women_dgp(jj);
            c_m_dgp(:,jj)=100000*ones(N,1)*mean(p_dgp(:,jj));   c_m=c_m_dgp(:,jj);
            c_f_dgp(:,jj)=100000*ones(N,1)*mean(p_dgp(:,jj));   c_f=c_f_dgp(:,jj);

            fe_m=zeros(N,1);    fe_f=zeros(N,1);
            f_m=zeros(N,1);     f_f=zeros(N,1);
            g_m=zeros(N,1);    g_f=zeros(N,1);
            F_m=zeros(N,1);     F_f=zeros(N,1);
            only_m=zeros(N,1);  only_f=zeros(N,1);
            public_sector=zeros(N,1);
            p_m_dgp(:,jj)=p_dgp(:,jj);                p_m=p_m_dgp(:,jj);
            p_f_dgp(:,jj)=p_dgp(:,jj)-z_dgp(:,jj);    p_f=p_f_dgp(:,jj);
            empid=(1:N)';

            % Save fundamentals data
            save(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_u_m','lambda_u_f','lambda_e_m','lambda_e_f','lambda_g_m','lambda_g_f',...
                'delta_m','delta_f','p','pi_m','pi_f','z','phi_load_men','phi_load_women','c_m','c_f','public_sector',...
                'fe_m','fe_f','f_m','f_f','F_m','F_f','only_m','only_f','p_m','p_f','empid','g_m','g_f');
            save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_u_m','lambda_u_f','lambda_e_m','lambda_e_f','lambda_g_m','lambda_g_f',...
                'delta_m','delta_f');

            %Set up all parameters depending on the experiment
            %load(sprintf('%s/economywide_parameters.mat',DIR_TEMP),'params');

            % Set up placeholder parameters, overridden by the Monte Carlo
            % simulation
            params=zeros(29,1);

            % Override parameters to make Monte Carlo independent from estimation
            params(24)=0.5; %measure of women
            params(25)=0.5; %measure of men
            params(7)=0.5; %b_m
            params(23)=0.5; %b_f;
            params(4)=0.5; %alpha

            measure_men=params(25);
            alpha=params(4);

            %Solve and simulate the model
            fun_model_GG(params,0,1,vcosts,eta_v,eta_amenities,counterfactual_model,policy_x);
            [~,~,~]=fun_simulate_model('none',0,eta_v,eta_amenities,1,'nonparametric','DISCRETE',counterfactual_model,policy_x,'GE');

            %Read the simulated data
            AA=dlmread(sprintf('%s/sim_data.txt',DIR_TEMP));
            p_draw(:,jj)=AA(:,2);
            pimen_draw(:,jj)=AA(:,3);
            piwomen_draw(:,jj)=AA(:,4);
            z_draw(:,jj)=AA(:,5);
            w_f_men(:,jj)=AA(:,6);
            w_f_women(:,jj)=AA(:,7);
            size_f_men(:,jj)=AA(:,8);
            size_f_women(:,jj)=AA(:,9);
            vmen(:,jj)=AA(:,10);
            vwomen(:,jj)=AA(:,11);
            F_f_men(:,jj)=AA(:,12);
            F_f_women(:,jj)=AA(:,13);
            eff_w_f_men(:,jj)=exp(w_f_men(:,jj))+pimen_draw(:,jj);
            eff_w_f_women(:,jj)=exp(w_f_women(:,jj))+piwomen_draw(:,jj);

            selec_these(:,jj)=(not(isnan(w_f_men(:,jj))) & (w_f_men(:,jj) > -10000));
            w=exp(w_f_men(selec_these(:,jj),jj));
            f_weights=vmen(selec_these(:,jj),jj);
            firm_rank=tiedrank(eff_w_f_men(selec_these(:,jj),jj));

            pi=pimen_draw(selec_these(:,jj),jj);
            pnow=p_draw(selec_these(:,jj),jj);
            netprod=pnow-pi/eta_amenities;

            laborshare_weights=exp(size_f_men(selec_these(:,jj),jj))./sum(exp(size_f_men(selec_these(:,jj),jj)));

            laborshare(jj)=sum(laborshare_weights.*w)./sum(laborshare_weights.*netprod);
            fprintf('The labor share in the model data is %g \n',laborshare);

        end

        %Now produce the average of the two (observable data: only aggregates
        %across firms because groups are unobservable)
        size_men_average=(exp(size_f_men(:,1)) + exp(size_f_men(:,2)));
        p_draw_average=(p_draw(:,1).*exp(size_f_men(:,1)) + p_draw(:,2).*exp(size_f_men(:,2)))./size_men_average;
        pimen_draw_average=(pimen_draw(:,1).*exp(size_f_men(:,1)) + pimen_draw(:,2).*exp(size_f_men(:,2)))./size_men_average;
        w_f_men_average=(w_f_men(:,1).*exp(size_f_men(:,1)) + w_f_men(:,2).*exp(size_f_men(:,2)))./size_men_average;
        vmen_average=(vmen(:,1) + vmen(:,2));
        eff_w_f_men_average=exp(w_f_men_average) + pimen_draw_average;

        %Convert to the data used by algorithm
        selec_these_average=(not(isnan(w_f_men(:,1))) & (w_f_men(:,1) > -1000) & not(isnan(w_f_men(:,2))) & (w_f_men(:,2) > -1000));
        w_average=exp(w_f_men_average(selec_these_average));
        f_weights_average=vmen_average(selec_these_average);
        firm_rank_average=tiedrank(size_men_average(selec_these_average));
        p_average=p_draw_average(selec_these_average);

        netp_average=p_average-pimen_draw_average/eta_amenities;

        share_pi_target=sum(pimen_draw_average.*size_men_average./eta_amenities)/sum(netp_average.*size_men_average);

        laborshare_weights_average=(size_men_average(selec_these_average))./sum((size_men_average(selec_these_average)));
        laborshare_average=sum(laborshare_weights_average.*w_average)./sum(laborshare_weights_average.*netp_average);

        fprintf('The labor share in the model data is %g \n',laborshare);

        %Estimate using new algorithm using only aggregated data
        [pi_out,p_out]=fun_estimation(w_average,firm_rank_average,f_weights_average,delta_m,lambda_g_m,lambda_e_m,...
            lambda_u_m,[measure_men; alpha],laborshare_average,eta_v,0,1.32,share_pi_target,false);
        %adjustment for average cost of amenities
        p_out=p_out+pi_out/eta_amenities;

        fprintf('Correlation between p and p_1, p_2 is [%g, %g] \n',fun_mycov(p_out,p_draw(selec_these_average,1),'CorrXY'),fun_mycov(p_out,p_draw(selec_these_average,2),'CorrXY'));
        fprintf('Correlation between a and a_1, a_2 is [%g, %g] \n',fun_mycov(pi_out,pimen_draw(selec_these_average,1),'CorrXY'),fun_mycov(pi_out,pimen_draw(selec_these_average,2),'CorrXY'));

        pi_graph_comparison=pimen_draw(selec_these_average,:);
        p_graph_comparison=p_draw(selec_these_average,:);
        size_men_comparison=size_men_average(selec_these_average);

        nq=100;
        p_out_graph=zeros(nq,1);
        p_real_average_graph=zeros(nq,1);
        pi_out_graph=zeros(nq,1);
        pi_real_average_graph=zeros(nq,1);
        p_real_average=((p_graph_comparison(:,1).*exp(size_f_men(selec_these_average,1)) + p_graph_comparison(:,2).*exp(size_f_men(selec_these_average,2)))./size_men_comparison);
        pi_real_average=((pi_graph_comparison(:,1).*exp(size_f_men(selec_these_average,1)) + pi_graph_comparison(:,2).*exp(size_f_men(selec_these_average,2)))./size_men_comparison);

        fprintf('Correlation of avg. p vs phat is %g \n',fun_mycov(p_out,p_real_average,'CorrXY'));
        fprintf('Correlation of avg. pi vs pihat is %g \n',fun_mycov(pi_out,pi_real_average,'CorrXY'));

        % Create figures if specified
        if create_figures
            for jj=1:nq
                selecpnow=(p_real_average>quantile(p_real_average,(jj-1)/100) & p_real_average<=quantile(p_real_average,jj/100));
                p_out_graph(jj)=mean(p_out(selecpnow));
                p_real_average_graph(jj)=mean(p_real_average(selecpnow));
                selecpinow=(pi_real_average>quantile(pi_real_average,(jj-1)/100) & pi_real_average<=quantile(pi_real_average,jj/100));
                pi_out_graph(jj)=mean(pi_out(selecpinow));
                pi_real_average_graph(jj)=mean(pi_real_average(selecpinow));
            end

            f1=figure('Name','Estimates vs Data','Position',[100 100 600 500],'Color','white');
            scatter(p_real_average_graph,p_out_graph,20,'filled'); hold on; plot(p_real_average_graph,p_real_average_graph,'r'); hold off; legend({' $\hat{p}$','45-degree line'},'Interpreter','latex'); xlabel({'Average $p$'},'Interpreter','latex'); ylabel({'$\hat{p}$'},'Interpreter','latex');
            gggg=gca;
            gggg.XAxis.FontSize=12;
            gggg.YAxis.FontSize=12;
            gggg.Legend.FontSize=12;
            drawnow;
            saveas(f1,sprintf('%s/figures/MC_AB_scatter_phat_vs_real_average_p_%s_%g_rho%g_%g.eps',DIR_RESULTS,method,N,shared_correlation,k),'epsc');

            f2=figure('Name','Estimates vs Data','Position',[100 100 600 500],'Color','white');
            scatter(pi_real_average_graph,pi_out_graph,20,'filled'); hold on; plot(pi_real_average_graph,pi_real_average_graph,'r'); hold off; legend({'$\hat{\pi}$','45-degree line'},'Interpreter','latex'); xlabel({'Average $\pi$'},'Interpreter','latex'); ylabel({'$\hat{\pi}$'},'Interpreter','latex');
            gggg=gca;
            gggg.XAxis.FontSize=12;
            gggg.YAxis.FontSize=12;
            gggg.Legend.FontSize=12;
            drawnow;
            saveas(f2,sprintf('%s/figures/MC_AB_scatter_ahat_vs_real_average_a_%s_%g_rho%g_%g.eps',DIR_RESULTS,method,N,shared_correlation,k),'epsc');
        end

        % Create employment weights for moments
        weightshere=size_men_average(selec_these_average)./sum(size_men_average(selec_these_average));
        corr_pavg_phat(k)=fun_mycov(p_out,p_real_average,'CorrXY',weightshere);
        corr_piavg_pihat(k)=fun_mycov(pi_out,pi_real_average,'CorrXY',weightshere);
        MSE_p(k)=sum(((p_out-p_real_average).^2).*weightshere);
        MSE_pi(k)=sum(((pi_out-pi_real_average).^2).*weightshere);

        corr_p1_phat(k)=fun_mycov(p_out,p_graph_comparison(:,1),'CorrXY',weightshere);
        corr_p2_phat(k)=fun_mycov(p_out,p_graph_comparison(:,2),'CorrXY',weightshere);
        corr_pi1_pihat(k)=fun_mycov(pi_out,pi_graph_comparison(:,1),'CorrXY',weightshere);
        corr_pi2_pihat(k)=fun_mycov(pi_out,pi_graph_comparison(:,2),'CorrXY',weightshere);
        MSE_p1(k)=sum(((p_out-p_graph_comparison(:,1)).^2).*weightshere);
        MSE_p2(k)=sum(((p_out-p_graph_comparison(:,2)).^2).*weightshere);
        MSE_pi1(k)=sum(((pi_out-pi_graph_comparison(:,1)).^2).*weightshere);
        MSE_pi2(k)=sum(((pi_out-pi_graph_comparison(:,2)).^2).*weightshere);

        %clear simulations
        clear p_draw pimen_draw piwomen_draw z_draw w_f_men w_f_women size_f_men size_f_women vmen vwomen F_f_men F_f_women eff_w_f_men eff_w_f_women selec_these
    end

    % Write table
    filename=sprintf('%s/tables/tab_montecarlo_misspecification_%g_etav%g_rho%g.tex',DIR_RESULTS,N,eta_v,shared_correlation);
    fileid=fopen(filename,'w+');
    fprintf(fileid,' \\begin{tabular}{lcccccc} \\hline\\hline \n');
    fprintf(fileid,'             & (1) & (2) & (3) & (4) & (5) & (6) \\\\ \\hline \n');
    fprintf(fileid,' \\multicolumn{6}{l}{\\emph{Panel A. Properties of group-specific components}} \\tabularnewline \n');
    fprintf(fileid,' Relative variance of productivity component, $\\varepsilon_i$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',p_noise_exp(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Relative variance of amenity component, $\\zeta_i$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',pi_noise_exp(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,'\\\\ \n');

    fprintf(fileid,'   \\multicolumn{6}{l}{\\emph{Panel B. Goodness of fit of pooled estimates vs. population average}} \\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{p}$ and $\\bar{p}$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_pavg_phat(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{a}$ and $\\bar{a}$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_piavg_pihat(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\hat{p}-\\bar{p}$');
    for k=1:nexp, fprintf(fileid,' & %9.3f',MSE_p(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\hat{a}-\\bar{a}$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',MSE_pi(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,'   \\multicolumn{6}{l}{\\emph{Panel C. Goodness of fit of pooled estimates vs. group-specific fundamentals}} \\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{p}$ and $p_A$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_p1_phat(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,'  Correlation between $\\hat{p}$ and $p_B$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_p2_phat(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{a}$ and $a_A$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_pi1_pihat(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{a}$ and $a_B$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_pi2_pihat(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\hat{p}-p_A$');
    for k=1:nexp, fprintf(fileid,' & %9.3f',MSE_p1(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\hat{p}-p_B$');
    for k=1:nexp, fprintf(fileid,' & %9.3f',MSE_p2(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\hat{a}-a_A$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',MSE_pi1(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\hat{a}-a_B$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',MSE_pi2(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,'\\hline \n');
    fprintf(fileid,' \\end{tabular} \n');
    fclose(fileid);

    close all;
end
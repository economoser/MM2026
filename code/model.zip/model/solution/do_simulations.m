fprintf('\n==============================================================')
fprintf('\FILE NAME:    do_simulations.m')
fprintf('\n')
fprintf('\nDESCRIPTION: This script runs Monte Carlo simulations and creates the tables with Monte Carlo evaluation of estimation and the misspecification experiments')
fprintf('\n')
fprintf('\nAUTHORS:     Iacopo Morchio (University of Bristol)')
fprintf('\n             Christian Moser (Columbia University)')
fprintf('\n')
fprintf('\nINPUTS:      None')
fprintf('\n')
fprintf('\nOUTPUTS:     Monte Carlo tables and figures')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n==============================================================')


fprintf('\n==============================================================')
fprintf('\n INITIAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Clear memory\n')
clc
clear

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Assign folders\n')
if exist('paths.txt', 'file')
    replicationpaths = readlines('paths.txt');
    DIR_MAIN = replicationpaths(1);
    DIR_TEMP = replicationpaths(2);
else
    fprintf('\nUSER ERROR: Directory not found.\n')
    exit
end
    DIR_DO = fullfile(DIR_MAIN, 'code'); % code directory
        DIR_DO_MODEL = fullfile(DIR_DO, 'model'); % model-code directory
            DIR_DO_MODEL_SOLUTION = fullfile(DIR_DO_MODEL, 'solution'); % model-estimation-code directory
            addpath(DIR_DO_MODEL_SOLUTION);
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % directory for log files
        FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_do_simulations.log']);
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');
clear DIR_DO DIR_DO_MODEL DIR_DO_MODEL_SOLUTION STR_TIME_STAMP

fprintf('\n  --> Add estimation folder to path\n')
addpath(sprintf('%s/code/model/estimation',DIR_MAIN));

fprintf('\n  --> Set headless-safe graphics defaults\n')
set(0, 'DefaultFigureVisible', 'off'); % no windows needed
set(0, 'DefaultFigureColor', 'white');
set(0, 'DefaultAxesFontSize', 12);

fprintf('\n  --> Set random seed\n')
seed = 20250828;
rng(seed, 'twister')
clear seed

fprintf('\n  --> Start log file\n')
% XXX REMOVE THE BELOW AFTER NEXT RUN!
whos DIR_LOG STR_TIME_STAMP FILE_LOG
%FILE_LOG
% XXX REMOVE THE ABOVE AFTER NEXT RUN!
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n RUNNING MONTE CARLO SIMULATIONS')
fprintf('\n==============================================================')
N_obs = 100000; % number of observations for MC simulations
fun_montecarlo_table(N_obs, true);
eta_v = 2; % set elasticity of vacancy posting costs
for correl = [-1 0 1] % correlation between group-specific components for misspecification experiments
    fun_montecarlo_DGP(N_obs, eta_v, correl);
end

fprintf('\n  --> Write empty file to tell Stata that MATLAB has finished\n')
writematrix(0, fullfile(DIR_TEMP, 'ihavefinished.txt'));


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF do_MC_simulations.m')
fprintf('\n==============================================================')

fprintf('\n  --> Close log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> Exit\n')
exit
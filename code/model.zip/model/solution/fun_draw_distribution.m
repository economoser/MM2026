function fun_draw_distribution(type, cost_type, selection_criterion)

    %==========================================================================
    % DESCRIPTION: This helper function loads the data and saves them in mat
    %              format for the model
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - estimated by fun_estimation_men: economywide_parameters.mat
    %              - estimated and re-outputted from MM_7_FIRM_PARAMETERS.do:
    %              - TEMP/lab_params_data.txt
    %              - TEMP/pop_shares.txt
    %              - TEMP/distribution_data.txt
    %
    % OUTPUTS:     None
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % inputs
    if nargin < 1, type='data'; end
    if nargin < 2, cost_type='absolute'; end
    if nargin < 3, selection_criterion='dualgender'; end

    % parameters
    trim_v_cost=0; % 0.005

    load(sprintf('%s/economywide_parameters.mat',DIR_TEMP),'params');
    rho=params(8);

    % This function draws from the empirical distribution in order to construct
    % the smoother distributions and moments for solution and simulation
    if strcmp(type,'f')
        % density has been passed
    elseif strcmp(type,'data')
        % data have been directly passed
        data=importdata(sprintf('%s/lab_params_data.txt',DIR_TEMP));
        idx=returncell(data.colheaders,'lambda_u_m'); lambda_u_m=mean(data.data(:,idx));
        idx=returncell(data.colheaders,'lambda_u_f'); lambda_u_f=mean(data.data(:,idx));
        idx=returncell(data.colheaders,'lambda_e_m'); lambda_e_m=mean(data.data(:,idx));
        idx=returncell(data.colheaders,'lambda_e_f'); lambda_e_f=mean(data.data(:,idx));
        idx=returncell(data.colheaders,'lambda_g_m'); lambda_g_m=mean(data.data(:,idx));
        idx=returncell(data.colheaders,'lambda_g_f'); lambda_g_f=mean(data.data(:,idx));
        idx=returncell(data.colheaders,'delta_m');    delta_m=mean(data.data(:,idx));
        idx=returncell(data.colheaders,'delta_f');    delta_f=mean(data.data(:,idx));
        %data have been directly passed - just load population share from

        data=importdata(sprintf('%s/pop_shares.txt',DIR_TEMP));
        idx=returncell(data.colheaders,'rank_concept');  rank_identifiers=data.data(:,idx);
        idx=returncell(data.colheaders,'gender');        gender_identifier=data.data(:,idx);
        idx=returncell(data.colheaders,'pop_share');     measure_f=mean(data.data((rank_identifiers==5 & gender_identifier==2),idx));

        data=importdata(sprintf('%s/distribution_data.txt',DIR_TEMP));
        idx=returncell(data.colheaders,'empid');      empid=data.data(:,idx);
        idx=returncell(data.colheaders,'p');          p=data.data(:,idx);
        idx=returncell(data.colheaders,'p_m');        p_m=data.data(:,idx);
        idx=returncell(data.colheaders,'p_f');        p_f=data.data(:,idx);
        idx=returncell(data.colheaders,'pi_m');       pi_m=data.data(:,idx);
        idx=returncell(data.colheaders,'pi_f');       pi_f=data.data(:,idx);
        %idx=returncell(data.colheaders,'z');          z=data.data(:,idx);
        idx=returncell(data.colheaders,'c_m');        c_m=data.data(:,idx);
        idx=returncell(data.colheaders,'c_f');        c_f=data.data(:,idx);
        idx=returncell(data.colheaders,'fe_m');       fe_m=data.data(:,idx);
        idx=returncell(data.colheaders,'fe_f');       fe_f=data.data(:,idx);
        idx=returncell(data.colheaders,'f_m');        f_m=data.data(:,idx);
        idx=returncell(data.colheaders,'f_f');        f_f=data.data(:,idx);
        idx=returncell(data.colheaders,'g_m');        g_m=data.data(:,idx);
        idx=returncell(data.colheaders,'g_f');        g_f=data.data(:,idx);
        idx=returncell(data.colheaders,'F_m');        F_m=data.data(:,idx);
        idx=returncell(data.colheaders,'F_f');        F_f=data.data(:,idx);
        idx=returncell(data.colheaders,'only_m');     only_m=data.data(:,idx);
        idx=returncell(data.colheaders,'only_f');     only_f=data.data(:,idx);
        idx=returncell(data.colheaders,'eta_v');      eta_v=mean(data.data(:,idx));
        idx=returncell(data.colheaders,'eta_pi');     eta_amenities=mean(data.data(:,idx));
        idx=returncell(data.colheaders,'public');     public_sector=data.data(:,idx);

        only_m=logical(only_m);
        only_f=logical(only_f);

        % Keep only dual gender firms
        if strcmp(selection_criterion,'dualgender')
            selecdata=((not(isnan(p)).*not(isnan(pi_m)).*not(isnan(pi_f)).*not(isnan(c_m)).*not(isnan(c_f)))==1);
        else
            selecdata=((not(isnan(c_m)).*not(isnan(p_m)).*not(isnan(pi_m)).*(c_m>=quantile(c_m,trim_v_cost)))+(not(isnan(c_f)).*not(isnan(p_f)).*not(isnan(pi_f)).*(c_f>=quantile(c_f,trim_v_cost)))>0);
        end

        empid=empid(selecdata);
        p=p(selecdata);
        pi_m=pi_m(selecdata);
        pi_f=pi_f(selecdata);
        p_m=p_m(selecdata);
        p_f=p_f(selecdata);

        % Re-defining productivity (model-consistent)
        if eta_amenities > 0
            %readjust productivity and wedges to account for amenities creation
            %cost
            p_m = p_m + pi_m/eta_amenities;
            p_f = p_f + pi_f/eta_amenities;
            p = p_m;
            z = -(p_f - p);
        elseif eta_amenities==0
            p = p_m;
            z= (-p_f - p);
        end

        % FROM NOW ON, NOTATION FOLLOWS THE MODEL STRICTLY.
        only_m=only_m(selecdata);
        only_f=only_f(selecdata);
        public_sector=public_sector(selecdata);

        % corrections for only-men firms
        if sum(only_m) > 0
            p(only_m)=p_m(only_m);
            z(only_m)=0;
            pi_f(only_m)=min(pi_f(not(only_m)))-1;
            fe_f_temp=fe_f; %passage variable for later statistics
            fe_f(only_m)=min(fe_f(not(only_m)));
        end
        if sum(only_f) > 0
            p(only_f)=p_f(only_f);
            z(only_f)=0;
            pi_m(only_f)=min(pi_m(not(only_f)))-1;
            fe_m_temp=fe_m; %passage variable for later statistics
            fe_m(only_f)=min(fe_m(not(only_f)));
        end
        fprintf('Single-gender firms: %g%% only-men, %g%% only-women \n',100*sum(only_m)/numel(only_m),100*sum(only_f)/numel(only_f));

        % Calculation of outside option from here
        c_m=c_m(selecdata)/10^(6);
        c_f=c_f(selecdata)/10^(6);

        % Adjust vacancy posting costs so that it's impossible to hire the other
        % gender for single-gender firms
        if sum(only_f) > 0, c_m(only_f)=max(c_m)*10^35; end
        if sum(only_m) > 0, c_f(only_m)=max(c_f)*10^35; end

        if strcmp(cost_type,'units_of_output')
            c_m=c_m./p_m;
            c_f=c_f./(p_f);
        end

        % Keeps data to selected sample
        if sum(only_m) > 0, fe_m_temp=fe_m_temp(selecdata);
        else, fe_m_temp=fe_m(selecdata); end
        if sum(only_f) > 0, fe_f_temp=fe_f_temp(selecdata);
        else, fe_f_temp=fe_f(selecdata); end
        fe_m=fe_m(selecdata);
        fe_f=fe_f(selecdata);
        f_m=f_m(selecdata);
        f_f=f_f(selecdata);
        g_m=g_m(selecdata);
        g_f=g_f(selecdata);
        F_m=F_m(selecdata);
        F_f=F_f(selecdata);
        F_m(only_f)=0;
        F_f(only_m)=0;

        % Defines composite productivity
        if eta_amenities > 0
            ptilde_m = p + pi_m - pi_m/eta_amenities;
            ptilde_f = p + pi_f - pi_f/eta_amenities - z;
        elseif eta_amenities == 0
            ptilde_m = p + pi_m;
            ptilde_f = p + pi_f - z;
        end

        % Prints sanity checks on unique utilities and the correlation between
        % utility and rank
        fprintf('Sanity check 1): unique utilities: M %g / %g , F %g / %g \n',numel(unique(exp(fe_m(not(only_f)))+pi_m(not(only_f)))),numel(fe_m(not(only_f))),numel(unique(exp(fe_f(not(only_m)))+pi_f(not(only_m)))),numel(fe_f(not(only_m))));
        fprintf('Sanity check 2): corr rank utility/ptilde: M %g , F %g \n',corr(tiedrank(exp(fe_m(not(only_f)))+pi_m(not(only_f))),tiedrank(ptilde_m(not(only_f)))), ...
            corr(tiedrank(exp(fe_f(not(only_m)))+pi_f(not(only_m))),tiedrank(ptilde_f(not(only_m)))));

        % Defines utilities and objects to calculate outside options
        wpi_m=exp(fe_m(not(only_f)))+pi_m(not(only_f));
        wpi_f=exp(fe_f(not(only_m)))+pi_f(not(only_m));
        [wpi_m,idx_m]=sort(wpi_m);
        [wpi_f,idx_f]=sort(wpi_f);
        F_m_selec=F_m(not(only_f));
        F_f_selec=F_f(not(only_m));

        phi_load_men=min(wpi_m);
        phi_load_women=min(wpi_f);

        save(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_u_m','lambda_u_f','lambda_e_m','lambda_e_f','lambda_g_m','lambda_g_f',...
            'delta_m','delta_f','p','pi_m','pi_f','z','phi_load_men','phi_load_women','c_m','c_f',...
            'fe_m','fe_f','f_m','f_f','F_m','F_f','only_m','only_f','p_m','p_f','empid','eta_v','eta_amenities',...
            'g_m','g_f','public_sector'); %latest addition, to compute average amenities worker-weighted?

        % Computes flow value of outside option
        b_m = phi_load_men - (lambda_u_m-lambda_e_m)*integral(@(wd)righthandside_phi(wd,wpi_m,F_m_selec(idx_m),delta_m,lambda_e_m,lambda_g_m,1,rho),min(wpi_m),max(wpi_m));
        b_f = phi_load_women - (lambda_u_f-lambda_e_f)*integral(@(wd)righthandside_phi(wd,wpi_f,F_f_selec(idx_f),delta_f,lambda_e_f,lambda_g_f,1,rho),min(wpi_f),max(wpi_f));

        % Loads economy-wide parameters in OUTPUT
        load(sprintf('%s/economywide_parameters.mat',DIR_TEMP),'params');

        % Plugs the estimated parameters into the mat file
        params(1)=delta_m;
        params(2)=lambda_e_m/lambda_u_m;
        params(3)=lambda_u_m;
        params(20)=delta_f;
        params(21)=lambda_e_f/lambda_u_f;
        params(22)=lambda_u_f/lambda_u_m;
        params(27)=lambda_g_m/lambda_u_m;
        params(28)=lambda_g_f/lambda_u_f;
        params(7)=b_m;
        params(23)=b_f;
        params(24)=measure_f;
        params(25)=1-measure_f;

        % Saves updated parameters from estimates
        save(sprintf('%s/economywide_parameters.mat',DIR_TEMP),'params');

        % Writes file of flow values for paper text
        file_flow_values=fopen(sprintf('%s/lab_params_flow_values.txt',DIR_TEMP),'w+');
        fprintf(file_flow_values,'b_m \t b_f \n');
        fprintf(file_flow_values,' %1.9f \t %1.9f \n',b_m,b_f);
        fclose(file_flow_values);
    end

    % Targets are generated from scratch here
    targets=zeros(68,1);

    % Load moments calculated in Stata
    empirical_targets=readmatrix(sprintf('%s/model_fit_data.csv',DIR_TEMP));
    J2J_men=empirical_targets(1);   p_wagedecline_men=empirical_targets(2);
    J2J_women=empirical_targets(3); p_wagedecline_women=empirical_targets(4);

    % Fixes for single-gender firms
    g_m(only_f)=0;
    g_f(only_m)=0;
    selec_for_GG=(not(only_m) & not(only_f));
    fe_m=fe_m_temp;
    fe_f=fe_f_temp;

    % dual-gender weighted version of target calculations
    mean_fe_m_GG=sum(fe_m(selec_for_GG).*g_m(selec_for_GG))/sum(g_m(selec_for_GG));
    mean_fe_f_GG=sum(fe_f(selec_for_GG).*g_f(selec_for_GG))/sum(g_f(selec_for_GG));
    targets(9)=sum((fe_m(selec_for_GG).*g_m(selec_for_GG))./sum(g_m(selec_for_GG))) - ...
        sum((fe_f(selec_for_GG).*g_f(selec_for_GG))./sum(g_f(selec_for_GG))); %GWG
    targets(27)=sum((fe_m(selec_for_GG).*g_m(selec_for_GG))./sum(g_m(selec_for_GG))) - ...
        sum((fe_m(selec_for_GG).*g_f(selec_for_GG))./sum(g_f(selec_for_GG))); %GWG, Between
    targets(28)=sum(((fe_m(selec_for_GG)-fe_f(selec_for_GG)).*g_f(selec_for_GG))./sum(g_f(selec_for_GG))); %GWG, Within

    mean_fe_m_forvar=sum(fe_m(not(only_f)).*g_m(not(only_f)))/sum(g_m(not(only_f)));
    mean_fe_f_forvar=sum(fe_f(not(only_m)).*g_f(not(only_m)))/sum(g_f(not(only_m)));
    targets(2)=sum(((fe_m(not(only_f))-mean_fe_m_forvar).^2).*g_m(not(only_f)))/sum(g_m(not(only_f)));
    targets(10)=sum(((fe_f(not(only_m))-mean_fe_f_forvar).^2).*g_f(not(only_m)))/sum(g_f(not(only_m)));
    mean_GG_for_GGvar=sum((fe_m(selec_for_GG)-fe_f(selec_for_GG)).*(g_m(selec_for_GG)+g_f(selec_for_GG))./sum(g_m(selec_for_GG)+g_f(selec_for_GG)));
    targets(35)=sum((((fe_m(selec_for_GG)-fe_f(selec_for_GG)-mean_GG_for_GGvar)).^2).*(g_m(selec_for_GG)+g_f(selec_for_GG))./sum(g_m(selec_for_GG)+g_f(selec_for_GG)));
    targets(17)=(sum((((fe_m(selec_for_GG)-mean_fe_m_GG).*(fe_f(selec_for_GG)-mean_fe_f_GG)).*(g_m(selec_for_GG)+g_f(selec_for_GG))))/sum(g_m(selec_for_GG)+g_f(selec_for_GG)))/...
        sqrt((sum(((fe_m(selec_for_GG)-mean_fe_m_GG).^2).*(g_m(selec_for_GG)+g_f(selec_for_GG)))/sum(g_m(selec_for_GG)+g_f(selec_for_GG)))*(sum(((fe_f(selec_for_GG)-mean_fe_f_GG).^2).*(g_m(selec_for_GG)+g_f(selec_for_GG)))/sum(g_m(selec_for_GG)+g_f(selec_for_GG))));

    targets(25)=J2J_men;
    targets(26)=J2J_women;
    targets(8)=p_wagedecline_men;
    targets(16)=p_wagedecline_women;

    % Saves targets for the model in OUTPUT folder
    save(sprintf('%s/targets_model.mat',DIR_TEMP),'targets');

    fprintf('Successfully imported %g observations \n', numel(p));
    % res = 'ImportData.success';
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BEGINNING OF HELPER FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function res = righthandside_phi(wwdd, endogrid_wpi_in, FFF, delta_in, lambda_e_in, lambda_god_in, adjf_in, rho)

%==========================================================================
% DESCRIPTION: This helper function calculates b_m and b_f using the right-hand side of the outside option formula.
%
% AUTHORS:     Iacopo Morchio (University of Bristol)
%              Christian Moser (Columbia University)
%
% INPUTS:      - wwdd: point of the integral for evaluation
%              - endogrid_wpi_in: the grid of utility values
%              - FFF: the offer CDF
%              - delta_in, lambda_e_in, lambda_god_in: labor market parameters
%              - adjf_in: adjustment factor for when transition rates are different from baseline one in counterfactuals
%              - rho: discount parameter
%
% OUTPUTS:     - TBC
%
% DATE:        November 4, 2025
%==========================================================================

    intermediate = 1-interp1(endogrid_wpi_in,FFF,wwdd,'makima');
    res = (intermediate)./(rho + delta_in + adjf_in.*lambda_god_in + (adjf_in.*lambda_e_in*intermediate));
end


function res = returncell(incell, varnow)

%==========================================================================
% DESCRIPTION: This helper function returns the appropriate cell of the data.
%
% AUTHORS:     Iacopo Morchio (University of Bristol)
%              Christian Moser (Columbia University)
%
% INPUTS:      - incell: cells passed to the function
%              - varnow: the name of the variable to be returned
%
% OUTPUTS:     - res: the column of data to be returned
%
% DATE:        November 4, 2025
%==========================================================================

    for k=1:numel(incell)
        if strcmp(incell{k}, varnow) == 1
            res = k;
            return
        end
    end
    res = 0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF HELPER FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
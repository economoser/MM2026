function [effwage_m, effwage_f, distrib_m, distrib_f, p_m, p_f, u_m, u_f, Vout_m, Vout_f, Tout_m, Tout_f, adjf_m, adjf_f] = fun_solve_equalhiring_CDF( ...
        params, delta_m, delta_f, lambda_u_m, lambda_u_f, lambda_e_m, ...
        lambda_e_f, lambda_god_m, lambda_god_f, meas_m, meas_f, phi, ...
        costIN_m, costIN_f, c_v_in_m, c_v_in_f, ptilde_in_m, ptilde_in_f, ...
        pi_m, pi_f, only_m, only_f, eta_v, ~, policy_application)

    %==========================================================================
    % DESCRIPTION: Solves the equal hiring policy and finds the offer distribution that is consistent with firms' choices
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - parameters, labor market objects, measures of men and
    %                women, outside options, vacancy costs, composite productivities,
    %                amenities, single-gender dummies, elasticities
    %
    % OUTPUTS:     - the utility postings (effwage_x), the offer distributions
    %                (distrib_x), composite productivity (p_x), the
    %                unemployment rates (u_x), the aggregate vacancies (V_x), T
    %                (Tout_x), the adjustment factors for lambda_u (adjf_x) for
    %                each gender x = m,f
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % options and single-gender dummy
    method_ladder=2; %2 = just sum over firms. 1 = weigh by the distribution
    onegender=(only_m | only_f);

    % Set parameters and options for fsolve
    phi_m=phi(1);
    phi_f=phi(2);
    alpha=params(4);
    toll=10^(-6);
    % opts_fzero=optimset('Display','iter');
    algo_solution='fsolve';
    opts_fsolve=optimoptions(@fsolve,'Display','iter','FiniteDifferenceStepSize',10^(-4),...
        'FunctionTolerance',toll,'OptimalityTolerance',toll,'UseParallel',true,'FiniteDifferenceType','central');
    opts_fsolve2=optimoptions(@fsolve,'Display','iter','FiniteDifferenceStepSize',10^(-6),...
        'FunctionTolerance',toll,'OptimalityTolerance',toll,'UseParallel',false);
    %options for solution algorithm
    maxiter_iterative_solution=400;
    continue_with_fsolve=1;
    immediate_solution=0;
    adj_equalhiring=0; %if solution is close enough, set this to zero
    mode_approx_F='makima';
    mode_approx_outside_F='linear';
    use_sigmoid_code=false;
    graph_convergence=false; %set to true to visually check convergence

    % number of firms
    N=numel(ptilde_in_m);
    N_m=numel(ptilde_in_m);
    N_f=numel(ptilde_in_f);

    % dummy to apply policies only to a subset of firms (used for equal pay
    % restricted to the public sector. If absent, set to one for all firms
    if nargin < 25
        policy_application=(ones(N,1)==1);
    end

    %set up file name for guess
    if sum(not(policy_application)) == 0
        loadfile_guess=sprintf('%s/guesses/guess_F_policy_equalhiring.mat',DIR_INPUT);
    else
        loadfile_guess=sprintf('%s/guesses/guess_F_policy_equalhiring_public.mat',DIR_INPUT);
    end

    % Here the guess is in terms of ptilde
    [ptilde_in_m_sorted,idx_ppi_m]=sort(ptilde_in_m);
    [ptilde_in_f_sorted,idx_ppi_f]=sort(ptilde_in_f);

    % useful indices to sort back firms at the end
    [~,sortback_m]=sort(idx_ppi_m);
    [~,sortback_f]=sort(idx_ppi_f);

    % distributions
    d_allrungs_m=ones(numel(ptilde_in_m),1).*(1/N);
    d_allrungs_f=ones(numel(ptilde_in_f),1).*(1/N);

    change_ppi_in_m=ptilde_in_m_sorted(2:end)-ptilde_in_m_sorted(1:end-1);
    change_ppi_in_m(N_m)=change_ppi_in_m(N_m-1);
    change_ppi_in_f=ptilde_in_f_sorted(2:end)-ptilde_in_f_sorted(1:end-1);
    change_ppi_in_f(N_f)=change_ppi_in_f(N_f-1);
    if method_ladder == 2
        change_ppi_in_m=change_ppi_in_m.*0 + 1;
        change_ppi_in_f=change_ppi_in_f.*0 + 1;
    end

    p_in_m=ptilde_in_m-pi_m;
    p_in_f=ptilde_in_f-pi_f;

    gridpoints_F=128;    % default is 128
    %sqrt-spaced grids
    grid_ppi_m=(linspace(0,sqrt(max(ptilde_in_m-phi_m)),gridpoints_F+1)').^2+phi_m;
    grid_ppi_f=(linspace(0,sqrt(max(ptilde_in_f-phi_f)),gridpoints_F+1)').^2+phi_f;
    minstep_m=min(grid_ppi_m(2:end)-grid_ppi_m(1:end-1));
    minstep_f=min(grid_ppi_f(2:end)-grid_ppi_f(1:end-1));
    cdfbw=min(minstep_m,minstep_f); %bandwidth for CDF is based on grids


    function [res_fun_F,out_F_m,out_F_f,w_men_out,w_women_out,v_m_now,v_f_now,maxesout] = solve_f_with_fsolve(allF,cnow_m2,cnow_f2,~,~,...
            TT_in_m2,TT_in_f2,adjf_in_m2,adjf_in_f2,w_men_old2,w_women_old2,v_m_old2,v_f_old2,adjfac2,use_sigmoid)

        %==========================================================================
        % DESCRIPTION: This inline function solves the problem of the firm under the constraint that vacancies must be equal for both genders
        %
        % AUTHORS:     Iacopo Morchio (University of Bristol)
		%              Christian Moser (Columbia University)
        %
        % DATE:        November 4, 2025
        %==========================================================================

        maxNumCompThreads(3);

        %extract f_m and f_f
        if use_sigmoid      %trick from deep learning: use continuous function
            guess_h_m2=[0; 1./(1+exp(-allF(1:gridpoints_F)))];
            guess_h_f2=[0; 1./(1+exp(-allF(gridpoints_F+1:gridpoints_F*2)))];
        else
            guess_h_m2=[0; allF(1:gridpoints_F)];
            guess_h_f2=[0; allF(gridpoints_F+1:gridpoints_F*2)];
        end
        %define interpolating functions for guesses

        %interpolators for the offer CDF
        h_intermed_m=griddedInterpolant(grid_ppi_m,guess_h_m2,mode_approx_F,mode_approx_outside_F);
        h_intermed_f=griddedInterpolant(grid_ppi_f,guess_h_f2,mode_approx_F,mode_approx_outside_F);

        h_fun_m=@(x)min(max(h_intermed_m(x),0),1);
        h_fun_f=@(x)min(max(h_intermed_f(x),0),1);

        % Under equal hiring, wages still maximize the same problem (only
        % efficient scale of firm changes)

        % loop of the standard solution
        for ggg=1:2
            if ggg==1
                pppp=ptilde_in_m_sorted;
                phi_kk=phi_m;
                below_phi=sum(ptilde_in_m_sorted<phi_m); %check how many values are below outside option
                delta_kk=delta_m; lambda_e_kk=lambda_e_m; lambda_god_kk=lambda_god_m;
                adjf_in_kk=adjf_in_m2;
            elseif ggg==2
                pppp=ptilde_in_f_sorted;
                phi_kk=phi_f;
                below_phi=sum(ptilde_in_f_sorted<phi_f); %check how many values are below outside option
                delta_kk=delta_f; lambda_e_kk=lambda_e_f; lambda_god_kk=lambda_god_f;
                adjf_in_kk=adjf_in_f2;
            end

            wpi_kk=ones(N,1)*phi_kk;
            start_algo=below_phi+1;
            wpi_kk(1:below_phi)=phi_kk-(below_phi+1-(0:below_phi-1)').*10^(-8); %unacceptable effective wages below phi
            wpi_kk(below_phi+1)=phi_kk;
            wpi_prime_kk=zeros(N,1);
            term=0;

            % Using the guess to figure out H at all points
            if ggg==1
                hhh=min(max(h_intermed_m(pppp),0),1);
            elseif ggg==2
                hhh=min(max(h_intermed_f(pppp),0),1);
            end

            % Calculate derivative and accumulate into H (F) and w+pi
            for rr=start_algo:N-1

                distterm=(1./(delta_kk + adjf_in_kk.*(lambda_god_kk + lambda_e_kk.*(1-hhh(rr+term)))));
                h_prime=hhh(rr+term+1)-hhh(rr+term);
                wpi_prime_kk(rr+term)=h_prime.*(2.*adjf_in_kk.*lambda_e_kk).*(pppp(rr+term)-wpi_kk(rr+term)).*distterm;

                %integrate the derivative to the next rung
                ppi_change=1;
                wpi_kk(rr+1)=wpi_kk(rr) + wpi_prime_kk(rr)*ppi_change;

                if wpi_kk(rr+1)==wpi_kk(rr)
                    pppp(rr:rr+1)=pppp(rr:rr+1)+1e-12;
                    wpi_kk(rr+1)=wpi_kk(rr+1)+1e-13;
                end

            end

            if ggg==1
                w_men_out2=wpi_kk-pi_m(idx_ppi_m);
            elseif ggg==2
                w_women_out2=wpi_kk-pi_f(idx_ppi_f);
            end
        end

        % Utility and wages have been solved
        % Sort them back to their original positions
        w_men_out=w_men_out2(sortback_m);
        w_women_out=w_women_out2(sortback_f);
        w_men_out(ptilde_in_m<phi_m)=0;
        w_women_out(ptilde_in_f<phi_f)=0;

        % Here firms do not have a choice: if they hire both genders, they MUST
        % hire equally (same vacancies): no profit-computation and no
        % profit-maximization choice between being single-gender or not
        v_m_both=zeros(N,1);
        v_f_both=zeros(N,1);
        v_m_onlymen=((TT_in_m2./(cnow_m2.*c_v_in_m)).*(max(p_in_m - w_men_out,0)).*(1./(delta_m + adjf_in_m2.*(lambda_god_m + lambda_e_m.*(1-h_fun_m(ptilde_in_m)))).^2)).^(1./(eta_v-1));
        v_f_onlymen=zeros(N,1);
        v_m_onlywomen=zeros(N,1);
        v_f_onlywomen=((TT_in_f2./(cnow_f2.*c_v_in_f)).*(max(p_in_f - w_women_out,0)).*(1./(delta_f + adjf_in_f2.*(lambda_god_f + lambda_e_f.*(1-h_fun_f(ptilde_in_f)))).^2)).^(1./(eta_v-1));
        v_joint_out=( ((TT_in_m2./(cnow_m2.*c_v_in_m + cnow_f2.*c_v_in_f)).*(p_in_m - w_men_out).*(1./(delta_m + adjf_in_m2.*(lambda_god_m + lambda_e_m.*(1-h_fun_m(ptilde_in_m)))).^2) + ...
            (TT_in_f2./(cnow_m2.*c_v_in_m + cnow_f2.*c_v_in_f)).*(p_in_f - w_women_out).*(1./(delta_f + adjf_in_f2.*(lambda_god_f + lambda_e_f.*(1-h_fun_f(ptilde_in_f)))).^2)) ).^(1./(eta_v-1));
        v_m_both(not(onegender) & policy_application)=v_joint_out(not(onegender) & policy_application);
        v_f_both(not(onegender) & policy_application)=v_joint_out(not(onegender) & policy_application);
        if sum(not(policy_application)) > 0
            v_m_both(not(onegender) & not(policy_application))=v_m_onlymen(not(onegender) & not(policy_application));
            v_f_both(not(onegender) & not(policy_application))=v_f_onlywomen(not(onegender) & not(policy_application));
        end

        % eliminate firms with negative vacancies (if they exist)
        v_m_onlymen(v_m_onlymen<0)=0;
        v_f_onlywomen(v_f_onlywomen<0)=0;
        v_m_onlymen(w_men_out==0)=0;
        v_f_onlywomen(w_women_out==0)=0;
        v_m_both(w_men_out==0)=0;
        v_f_both(w_women_out==0)=0;
        v_m_both(v_m_both<0)=0;
        v_f_both(v_f_both<0)=0;

        whattodo=double(not(onegender));
        whattodo(only_m)=2;
        whattodo(only_f)=3;
        v_m_now=((whattodo==1).*v_m_both + (whattodo==2).*v_m_onlymen + (whattodo==3).*v_m_onlywomen);
        v_f_now=((whattodo==1).*v_f_both + (whattodo==2).*v_f_onlymen + (whattodo==3).*v_f_onlywomen);

        w_men_out=adjfac2.*w_men_old2 + (1-adjfac2).*w_men_out;
        w_women_out=adjfac2.*w_women_old2 + (1-adjfac2).*w_women_out;
        v_m_now(w_men_out>0)=adjfac2*v_m_old2(w_men_out>0) + (1-adjfac2)*v_m_now(w_men_out>0);
        v_f_now(w_women_out>0)=adjfac2*v_f_old2(w_women_out>0) + (1-adjfac2)*v_f_now(w_women_out>0);

        %Use kernel density to obtain f estimate
        maxesout=[max(w_men_out(v_m_now>0)+pi_m(v_m_now>0)); max(w_women_out(v_f_now>0)+pi_f(v_f_now>0))];
        excess=0.00000001;
        out_F_m=zeros(gridpoints_F+1,1);
        out_F_f=zeros(gridpoints_F+1,1);

        selecpoints_notone_F_m_grid=(grid_ppi_m>0);
        selecpoints_notone_F_f_grid=(grid_ppi_f>0);
        selecobs_F_m=(v_m_now>0);
        selecobs_F_f=(v_f_now>0);
        [out_F_m(selecpoints_notone_F_m_grid)]=ksdensity(ptilde_in_m(selecobs_F_m),grid_ppi_m(selecpoints_notone_F_m_grid),...
            'Support',[min(grid_ppi_m)-excess max(grid_ppi_m)+excess],...
            'Weights',v_m_now(selecobs_F_m),'BoundaryCorrection','reflection','Function','cdf','Bandwidth',cdfbw);
        [out_F_f(selecpoints_notone_F_f_grid)]=ksdensity(ptilde_in_f(selecobs_F_f),grid_ppi_f(selecpoints_notone_F_f_grid),...
            'Support',[min(grid_ppi_f)-excess max(grid_ppi_f)+excess],...
            'Weights',v_f_now(selecobs_F_f),'BoundaryCorrection','reflection','Function','cdf','Bandwidth',cdfbw);

        out_F_m(1)=0;
        out_F_f(1)=0;

        res_fun_F=[out_F_m(2:end); out_F_f(2:end)]-[guess_h_m2(2:end); guess_h_f2(2:end)];
        if not(use_sigmoid)
            res_fun_F(allF<0)=res_fun_F(allF<0)+2.*res_fun_F(allF<0).^2;
        end

        taskplot=getCurrentTask();
        if (isempty(taskplot) && graph_convergence)
            %graph current difference between input F and output F
            howmanypoints_m=gridpoints_F;
            howmanypoints_f=gridpoints_F;
            figure(1005); %sets figure for evolution of distribution
            subplot(1,2,1), plot(grid_ppi_m(1:howmanypoints_m),out_F_m(1:howmanypoints_m),'b');
            hold on; plot(grid_ppi_m(1:howmanypoints_m),[0; guess_h_m2(2:howmanypoints_m)],'r'); hold off; legend('F_m','F_in_m','Location','northwest');
            title(sprintf('Int. Dist: %g',sqrt((sum(res_fun_F(1:howmanypoints_m-1).^2))/howmanypoints_m)));
            subplot(1,2,2), plot(grid_ppi_f(1:howmanypoints_f),out_F_f(1:howmanypoints_f),'b');
            hold on; plot(grid_ppi_f(1:howmanypoints_f),[0; guess_h_f2(2:howmanypoints_f)],'r'); hold off; legend('F_f','F_in_f','Location','northwest');
            drawnow;
            grid_ppi_m_load=grid_ppi_m;
            grid_ppi_f_load=grid_ppi_f;
            if use_sigmoid
                allF2=[guess_h_m2(2:end); guess_h_f2(2:end)];
                save(loadfile_guess,'allF2','grid_ppi_m_load','grid_ppi_f_load');
            else
                allF2=allF;
                save(loadfile_guess,'allF2','grid_ppi_m_load','grid_ppi_f_load');
            end
        end

    end


    function [vout_m,vout_f,wpi_m,wpi_f,h_m,h_f,guess_h_m,guess_h_f] = mysystem_inline(cnow_m,cnow_f,vv_in_m,vv_in_f,...
            TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,previous_h_m,previous_h_f)

        %==========================================================================
        % DESCRIPTION: This function solves the equilibrium offer CDF by calling the above helper to solve the firm's problem
        %
        % AUTHORS:     Iacopo Morchio (University of Bristol)
		%              Christian Moser (Columbia University)
        %
        % DATE:        November 4, 2025
        %==========================================================================

        % set up guesses
        guess_F_m=previous_h_m;
        guess_F_f=previous_h_f;

        guess_F_m=guess_F_m/max(guess_F_m);
        guess_F_f=guess_F_f/max(guess_F_f);

        % initializations
        v_m_old=ones(N_m,1).*vv_in_m;
        v_f_old=ones(N_f,1).*vv_in_f;

        w_men_old=rand(N,1);
        w_women_old=rand(N,1);
        disthere=100;
        distf_old=100;
        dist_w=100;   distv_m=100;    distv_f=100;
        meandist_w=100; distf=100;
        meandistv_m=100;
        meandistv_f=100;

        iter_1=0;
        adjfac=0;%at the start, immediately update guess with new one
        % given guesses, solve wages
        while (disthere > toll) && (iter_1 < maxiter_iterative_solution)
            iter_1=iter_1+1;
            if iter_1 == 2
                adjfac=0.5;
            end

            % solve the problem
            [res_fun_F_out,guess_F_m2,guess_F_f2,w_men_now,w_women_now,v_m_now,v_f_now]=...
                solve_f_with_fsolve([guess_F_m(2:end); guess_F_f(2:end);],cnow_m,cnow_f,vv_in_m,vv_in_f,TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,...
                w_men_old,w_women_old,v_m_old,v_f_old,adj_equalhiring,false);

            guess_adj=0.5;
            guess_F_m=guess_adj*guess_F_m + (1-guess_adj)*guess_F_m2;
            guess_F_f=guess_adj*guess_F_f + (1-guess_adj)*guess_F_f2; %slow adjustment of f to improve convergence
            guess_F_m=max(min(guess_F_m,1),0);
            guess_F_f=max(min(guess_F_f,1),0);

            dist_w=max(abs(w_men_now-w_men_old)) + max(abs(w_women_now-w_women_old));
            distv_m=max(abs(v_m_now-v_m_old));
            distv_f=max(abs(v_f_now-v_f_old));
            meandist_w=mean(abs(w_men_now-w_men_old)) + mean(abs(w_women_now-w_women_old));
            meandistv_m=mean(abs(v_m_now-v_m_old));
            meandistv_f=mean(abs(v_f_now-v_f_old));

            w_men_old=w_men_now;    w_women_old=w_women_now;
            v_m_old=v_m_now;        v_f_old=v_f_now;

            distf=sqrt(sum(res_fun_F_out.^2)/(2*gridpoints_F));
            disthere=distf;

            if mod(iter_1,10) == 0
                fprintf('Iter %g, Dist is %g, AdjFac is %g \n',iter_1,disthere,adjfac);
            end

            if distf > distf_old
                adjfac=adjfac+0.005;
            else
                if iter_1 < 300
                    adjfac=adjfac-0.001;
                elseif iter_1 < 600
                    adjfac=adjfac-0.0001;
                else
                    adjfac=adjfac-distf;
                end
            end

            % keep adjustment factor within bounds
            adjfac=min(adjfac,0.9);
            adjfac=max(adjfac,0.5);

            distf_old=distf;

        end

        fprintf('Took %g iterations to converge. \n',iter_1);
        fprintf('Distances: w %g, v_m %g, v_f %g, f %g \n',dist_w,distv_m,distv_f,distf);
        fprintf('Mean Distance: w %g, v_m %g, v_f %g \n',meandist_w,meandistv_m,meandistv_f);

        % at the end of loop, check solution. If acceptable, just move on.
        % if not, improve with fsolve (SLOW)
        if (iter_1 > 0)
            [dist_F_here,F_m_final,F_f_final,~,~,~,~,~]=solve_f_with_fsolve([guess_F_m(2:end); guess_F_f(2:end)],cnow_m,cnow_f,vv_in_m,vv_in_f,...
                TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,w_men_old,w_women_old,v_m_old,v_f_old,0,false);
        else
            dist_F_here=100;
        end
        if sqrt(sum(dist_F_here.^2)/(2*gridpoints_F)) < toll
        elseif continue_with_fsolve==1
            if strcmp(algo_solution,'fsolve')
                %refine estimate of density with fsolve
                %convert Fguess to sigmoid coefficients
                if use_sigmoid_code
                    guess_F_m=min(max(guess_F_m,0.000001),0.9999);
                    guess_F_f=min(max(guess_F_f,0.000001),0.9999); %adjustment to avoid zeros and NaNs in sigmoid
                    guess_F_m(2:end)=-log( (1-guess_F_m(2:end))./guess_F_m(2:end));
                    guess_F_f(2:end)=-log( (1-guess_F_f(2:end))./guess_F_f(2:end));
                end
                [Fouthere]=fsolve(@(ff)(solve_f_with_fsolve(ff,cnow_m,cnow_f,vv_in_m,vv_in_f,...
                    TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,w_men_old,w_women_old,v_m_old,v_f_old,0,use_sigmoid_code)),...
                    [guess_F_m(2:end); guess_F_f(2:end)],opts_fsolve);
                %convert back with sigmoid function
                if use_sigmoid_code
                    Fouthere=1./(1+exp(-Fouthere));
                end
            end
            F_m_final=[0; Fouthere(1:gridpoints_F)];
            F_f_final=[0; Fouthere(gridpoints_F+1:2*gridpoints_F)];
        end
        if immediate_solution == 1
            F_m_final=guess_F_m;
            F_f_final=guess_F_f;
        end

        %calculate final policy functions
        [~,~,~,w_men_now,w_women_now,v_m_now,v_f_now,~]=solve_f_with_fsolve([F_m_final(2:end); F_f_final(2:end)],cnow_m,cnow_f,vv_in_m,vv_in_f,...
            TT_in_m,TT_in_f,adjf_in_m,adjf_in_f,w_men_old,w_women_old,v_m_old,v_f_old,0,false);

        %to calculate vacancies, use sorted ptilde
        vout_m=sum(v_m_now(idx_ppi_m).*d_allrungs_m.*change_ppi_in_m);
        vout_f=sum(v_f_now(idx_ppi_f).*d_allrungs_f.*change_ppi_in_f);

        %define all outputs
        wpi_m=w_men_now+pi_m;
        wpi_f=w_women_now+pi_f;
        wpi_m(v_m_now==0 | wpi_m<phi_m)=phi_m-1-rand(sum((v_m_now==0 | wpi_m<phi_m)),1)*0.2;
        wpi_f(v_f_now==0 | wpi_f<phi_f)=phi_f-1-rand(sum((v_f_now==0 | wpi_f<phi_f)),1)*0.2;
        guess_h_m=F_m_final;
        guess_h_f=F_f_final;
        guess_h_m=guess_h_m/max(guess_h_m);
        guess_h_f=guess_h_f/max(guess_h_f);

        %define interpolating functions for guesses
        h_m_fun=griddedInterpolant(grid_ppi_m,guess_h_m,mode_approx_F,mode_approx_outside_F);
        h_f_fun=griddedInterpolant(grid_ppi_f,guess_h_f,mode_approx_F,mode_approx_outside_F);
        h_m=max(min(h_m_fun(ptilde_in_m),1),0);
        h_f=max(min(h_f_fun(ptilde_in_f),1),0);
    end
    %END OF OPTIMIZERS

    %outside guesses that are updated at each step to improve speed of
    %convergence
    current_guess_F_m=min(((grid_ppi_m-phi_m)/max((grid_ppi_m-phi_m))).^0.08,1);
    current_guess_F_f=min(((grid_ppi_f-phi_f)/max((grid_ppi_f-phi_f))).^0.06,1);

    %load best guess from previous attempts
    if isfile(loadfile_guess)
        %accommodate different grid and guess sizes
        load(loadfile_guess,'allF2','grid_ppi_m_load','grid_ppi_f_load');
        gridpoints_of_guess=numel(allF2)/2;
        current_guess_F_m(2:end)=interp1(grid_ppi_m_load(2:end),allF2(1:gridpoints_of_guess),grid_ppi_m(2:end),'makima','extrap');
        current_guess_F_f(2:end)=interp1(grid_ppi_f_load(2:end),allF2(gridpoints_of_guess+1:gridpoints_of_guess*2),grid_ppi_f(2:end),'makima','extrap');
    end


    function resres = findvacancies(vvvv)

        %==========================================================================
        % DESCRIPTION: Finds aggregate vacancies that clear the market.
        %
        % AUTHORS:     Iacopo Morchio (University of Bristol)
		%              Christian Moser (Columbia University)
        %
        % DATE:        November 4, 2025
        %==========================================================================

        resres=zeros(2,1);
        vvvv_m=vvvv(1);
        vvvv_f=vvvv(2);
        if (vvvv_m <= 0) || (vvvv_f <=0), resres(:)=10000; return, end

        u_old_m=0;
        u_old_f=0;
        dist_u=100;
        while dist_u > toll
            fhere_m=(vvvv_m/(meas_m.*(u_m + (lambda_e_m/lambda_u_m).*(1-u_m) + (lambda_god_m/lambda_u_m)))).^alpha;
            fhere_f=(vvvv_f/(meas_f.*(u_f + (lambda_e_f/lambda_u_f).*(1-u_f) + (lambda_god_f/lambda_u_f)))).^alpha;
            u_m=delta_m/(delta_m+fhere_m*(1+lambda_god_m/lambda_u_m));
            u_f=delta_f/(delta_f+fhere_f*(1+lambda_god_f/lambda_u_f));
            dist_u=abs(u_m-u_old_m)+abs(u_f-u_old_f);
            u_old_m=u_m;
            u_old_f=u_f;
        end
        adjf_m=fhere_m/lambda_u_m;
        adjf_f=fhere_f/lambda_u_f;
        T_m=meas_m.*((u_m + lambda_god_m/lambda_u_m)*fhere_m*(delta_m + lambda_e_m*(adjf_m) + lambda_god_m*adjf_m))/vvvv_m; %adjusted arrival rates
        T_f=meas_f.*((u_f + lambda_god_f/lambda_u_f)*fhere_f*(delta_f + lambda_e_f*(adjf_f) + lambda_god_f*adjf_f))/vvvv_f; %adjusted arrival rates

        [Vout_here_m,Vout_here_f,~,~,~,~,current_guess_F_m,current_guess_F_f] = mysystem_inline(costIN_m,costIN_f,vvvv_m,vvvv_f,T_m,T_f,adjf_m,adjf_f,current_guess_F_m,current_guess_F_f);

        resres=[vvvv_m-Vout_here_m; vvvv_f-Vout_here_f];
    end

    % Find equilibrium vacancies
    % Starting point is the one implied by the raw data
    u_m=delta_m/(delta_m+lambda_u_m+lambda_god_m);
    u_f=delta_f/(delta_f+lambda_u_f+lambda_god_f);
    Vstart_m=(lambda_u_m.^(1/alpha)).*(meas_m.*(u_m + (lambda_e_m./lambda_u_m).*(1-u_m) + lambda_god_m./lambda_u_m));
    Vstart_f=(lambda_u_f.^(1/alpha)).*(meas_f.*(u_f + (lambda_e_f./lambda_u_f).*(1-u_f) + lambda_god_f./lambda_u_f));

    equalhiring_tic=tic;
    %ONLY method up to now - with fsolve
    % load precalculated results for speedup
    if sum(not(policy_application)) == 0
        loadfile_guess_V=sprintf('%s/guesses/guess_V_equalhiring.mat',DIR_INPUT);
    else
        loadfile_guess_V=sprintf('%s/guesses/guess_V_equalhiring_public.mat',DIR_INPUT);
    end

    if isfile(loadfile_guess_V)
        load(loadfile_guess_V,'Vout_m','Vout_f');
        Vstart_m=Vout_m;
        Vstart_f=Vout_f;
    end

    % Solve vacancies
    Vout=fsolve(@(vv)findvacancies(vv)./[Vstart_m; Vstart_f],[Vstart_m; Vstart_f],opts_fsolve2);
    Vout_m=Vout(1);
    Vout_f=Vout(2);
    fprintf('Solving the equal hiring policy took %g seconds \n',toc(equalhiring_tic));

    % Save aggregate vacancies
    save(loadfile_guess_V,'Vout_m','Vout_f');

    % Calculate aggregate unemployment
    u_old_m=0;
    u_old_f=0;
    dist_u=100;
    while dist_u > toll
        fhere_m=(Vout_m/(meas_m.*(u_m + (lambda_e_m/lambda_u_m).*(1-u_m) + (lambda_god_m/lambda_u_m)))).^alpha;
        fhere_f=(Vout_f/(meas_f.*(u_f + (lambda_e_f/lambda_u_f).*(1-u_f) + (lambda_god_f/lambda_u_f)))).^alpha;
        u_m=delta_m/(delta_m+fhere_m*(1+lambda_god_m/lambda_u_m));
        u_f=delta_f/(delta_f+fhere_f*(1+lambda_god_f/lambda_u_f));
        dist_u=abs(u_m-u_old_m)+abs(u_f-u_old_f);
        u_old_m=u_m;
        u_old_f=u_f;
    end

    % compute adjustment factors for job-finding rates
    adjf_m=fhere_m/lambda_u_m;
    adjf_f=fhere_f/lambda_u_f;
    Tout_m=meas_m.*((u_m + lambda_god_m/lambda_u_m)*fhere_m*(delta_m + lambda_e_m*(adjf_m) + lambda_god_m*adjf_m))/Vout_m; %adjusted arrival rates
    Tout_f=meas_f.*((u_f + lambda_god_f/lambda_u_f)*fhere_f*(delta_f + lambda_e_f*(adjf_f) + lambda_god_f*adjf_f))/Vout_f; %adjusted arrival rates

    % compute all policies
    [~,~,effwage_m,effwage_f,distrib_m,distrib_f,~,~] = mysystem_inline(costIN_m,costIN_f,Vout_m,Vout_f,Tout_m,Tout_f,adjf_m,adjf_f,current_guess_F_m,current_guess_F_f);
    p_m=ptilde_in_m;
    p_f=ptilde_in_f;
    distrib_m(effwage_m<phi_m)=0;
    distrib_f(effwage_f<phi_f)=0;

end
fprintf('\n==============================================================')
fprintf('\FILE NAME:    do_counterfactuals.m')
fprintf('\n')
fprintf('\nDESCRIPTION: This script runs counterfactual simulations')
fprintf('\n')
fprintf('\nAUTHORS:     Iacopo Morchio (University of Bristol)')
fprintf('\n             Christian Moser (Columbia University)')
fprintf('\n')
fprintf('\nINPUTS:      - TEMP/cfs_to_run.txt: set by MM_0_MASTER.do, specifies which counterfactuals to run')
fprintf('\n')
fprintf('\nOUTPUTS:     All counterfactual tables')
fprintf('\n')
fprintf('\nNOTES:       This file runs all counterfactuals')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n==============================================================')


fprintf('\n==============================================================')
fprintf('\n INITIAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Clear memory\n')
clc
clear

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Assign folders\n')
if exist('paths.txt', 'file')
    replicationpaths = readlines('paths.txt');
    DIR_MAIN = replicationpaths(1);
    DIR_TEMP = replicationpaths(2);
else
    fprintf('\nUSER ERROR: Directory not found.\n')
    exit
end
    DIR_DO = fullfile(DIR_MAIN, 'code'); % code directory
        DIR_DO_MODEL = fullfile(DIR_DO, 'model'); % model-code directory
            DIR_DO_MODEL_SOLUTION = fullfile(DIR_DO_MODEL, 'solution'); % model-estimation-code directory
            addpath(DIR_DO_MODEL_SOLUTION);
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % directory for log files
        FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_do_counterfactuals.log']);
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');
clear DIR_DO DIR_DO_MODEL DIR_DO_MODEL_SOLUTION STR_TIME_STAMP

fprintf('\n  --> Set random seed\n')
seed = 20250828;
rng(seed, 'twister')
clear seed

fprintf('\n  --> Start log file\n')
% XXX REMOVE THE BELOW AFTER NEXT RUN!
whos DIR_LOG STR_TIME_STAMP FILE_LOG
%FILE_LOG
% XXX REMOVE THE ABOVE AFTER NEXT RUN!
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n COUNTERFACTUALS')
fprintf('\n==============================================================')

fprintf('\n  --> Read which counterfactuals should be run\n')
counterfactuals_to_run = readmatrix(sprintf('%s/cfs_to_run.txt', DIR_TEMP));
% 0 = also do equal pay policy;
% 1 = everything already done;
% 2 = equal pay policy already done
% 3 = equal pay policy AND equal hiring policy already done
% 4 = all policies already done
% vector of ones and zeros: specify which simulations to run   

fprintf('\n  --> Selection based on firm-level gender composition\n')
gender_options = 'dualgender'; % singlegender = keep all firms; dualgender = keep only 2-gender firms

fprintf('\n  --> Draw distribution and build the table of transition rates\n')
fun_draw_distribution('data', 'absolute', gender_options);

fprintf('\n  --> Do all simulations as specified by dothepolicy\n')
fun_model('DISCRETE', counterfactuals_to_run);

fprintf('\n  --> Write empty file to tell Stata that MATLAB has finished\n')
writematrix(0, fullfile(DIR_TEMP, 'ihavefinished.txt'));


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF do_counterfactuals.m')
fprintf('\n==============================================================')

fprintf('\n  --> Close log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> Exit\n')
exit
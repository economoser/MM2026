function [params, MU, SIGMA, phi_men, phi_women, F_wpi_men, F_wpi_women, effective_w_men, effective_w_women, firm_sizes_men, firm_sizes_women, vacancies_men, vacancies_women, egrid_ppi_men, egrid_ppi_women, ptilde_grid_m, ptilde_grid_f, lambda_u_f, vcost_men, vcost_women] = fun_model_GG( ...
    params, showgraph, savepolicy, vcosts, eta_v, eta_amenities, ...
    counterfactual, policy_x, cost_type)

    %==========================================================================
    % DESCRIPTION: This function solves the model's policy function by passing to the
    %              differential equations solver the appropriate distribution
    %              of fundamentals depending on the counterfactuals,
    %              calculating the outside option, and then saves the policy
    %              function for simulation
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - parameters (params), whether to show graphs or not
    %                (showgraph), whether to save the policy function
    %                (savepolicy), potentially constant vacancy posting costs
    %                (vcosts, =0 to compute baseline equilibrium), vacancy cost
    %                elasticity (eta_v), amenity cost elasticity
    %                (eta_amenities), which counterfactual to run
    %                (counterfactual), which specific policy is applied
    %                (policy_x), whether vacancy costs are accounted for as proportions
    %                of productivity or absolute numbers (cost_type)
    %
    % OUTPUTS:     - parameters (params, potentially modified by
    %                counterfactuals), outside options of men and women
    %                (phi_men,phi_women), offer CDFs in equilibrium
    %                (F_wpi_men,F_wpi_women), utility offers
    %                (effective_w_men,effective_w_women), firm sizes
    %                (firm_sizes_men,firm_size_women), vacancies
    %                (vacancies_men, vacancies_women), grids of ptilde for
    %                effective wages (egrid_ppi_men,egrid_ppi_women), general
    %                grids for ptilde (ptilde_grid_m,ptilde_grid_f),
    %                equilibrium job-finding rate (lambda_u_m,lambda_u_f),
    %                baseline vacancy costs that rationalize empirical lambda_u
    %                (vcost_men,vcost_women)
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % Set default values if not passed
    if nargin < 2, showgraph=0; end
    if nargin < 3, savepolicy=0; end
    if nargin < 4, vcosts=[0; 0]; end
    if nargin < 5, eta_v=2; end
    if nargin < 6, eta_amenities=0; end
    if nargin < 7, counterfactual='baseline'; end
    if nargin < 8, policy_x='NONE'; end
    if nargin < 9, cost_type='absolute'; end

    % User options
    trim_high=1.1; %0.999;
    adjust_outside='yes';
    pctile_oo=35; %percentile of firms to check outside option
    shift_oo=1e-16;

    maxNumCompThreads(4);

    % start timer
    tic;

    % set random seed
    rng(20250826, 'twister')

    % define number of gridpoints
    gridpoints=128;

    rho=params(8);

    %Step 1: set parameters
    delta_m=params(1);
    s_e_m=params(2);
    lambda_u_m=params(3);
    lambda_e_m=lambda_u_m*s_e_m;
    alpha=params(4);
    b_m=params(7);
    delta_f=params(20);
    s_e_f=params(21);
    lambda_u_f=params(22)*lambda_u_m;
    lambda_e_f=s_e_f*lambda_u_f;
    b_f=params(23);
    meas_f=params(24);
    meas_m=params(25);
    A_f=params(22);
    lambda_g_m=lambda_u_m*params(27);
    lambda_g_f=lambda_u_f*params(28);

    % Read nonparametric empirical distribution of fundamentals
    load(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_u_m','lambda_u_f','lambda_e_m','lambda_e_f','lambda_g_m','lambda_g_f',...
        'delta_m','delta_f','p','pi_m','pi_f','z','phi_load_men','phi_load_women','c_m','c_f','only_m','only_f','p_m','p_f',...
        'g_m','g_f','public_sector');

    % Dummy for one-gender firms
    onegender=max(only_m,only_f);

    % Load potentially modified transition rates for counterfactuals
    load(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_u_m','lambda_u_f','lambda_e_m','lambda_e_f','lambda_g_m','lambda_g_f',...
        'delta_m','delta_f');

    MU=0;
    SIGMA=0;
    % Maintain empirical discrepancy between outside options and
    % composite p at the bottom of the ladder
    keep_discrepancy_phi_m=phi_load_men-min(p_m(not(only_f)) + (pi_m(not(only_f)).*(1 - 1./eta_amenities)));
    keep_discrepancy_phi_f=phi_load_women-min(p_f(not(only_m)) + (pi_f(not(only_m)).*(1 - 1./eta_amenities)));

    %Adjustment to apply policy only to a subset of firms (used only for
    %policies applied only to the public sector)
    if strcmp(policy_x,'equalhiring_public')
        policy_application=(public_sector==1);
    else
        policy_application=(public_sector.*0 == 0);
    end

    % Adjustments to mean amenities depending on counterfactuals, to avoid
    % mean utility shifts across counterfactuals that manipulate amenities
    if strcmp(counterfactual,'baseline_no_amenities')
        old_mean_pi_m=sum(pi_m(not(only_f)).*g_m(not(only_f)));
        old_mean_pi_f=sum(pi_f(not(only_m)).*g_f(not(only_m)));
        pi_f=pi_f.*0;
        phi_load_women=phi_load_women-old_mean_pi_f;
    end
    if strcmp(counterfactual,'baseline_amenities_equal_mean')
        old_mean_pi_m=mean(pi_m(not(only_f)));
        old_mean_pi_f=mean(pi_f(not(only_m)));
        pi_m=pi_m.*0 + old_mean_pi_m;
        pi_f=pi_f.*0 + old_mean_pi_f;
    end
    if (strcmp(counterfactual,'baseline_equal_amenities_M'))
        % Counterfactual equalizing amenities to value of MEN
        old_mean_pi_f=mean(pi_f(not(only_m)));
        pi_f(not(onegender))=pi_m(not(onegender));
        new_mean_pi_f=mean(pi_f(not(only_m)));
        % Adjust outside option to reflect change in mean amenities
        phi_load_women=phi_load_women-old_mean_pi_f+new_mean_pi_f;
        b_f=b_f-old_mean_pi_f+new_mean_pi_f;
    end
    if (strcmp(counterfactual,'baseline_nodifference_all'))
        % Counterfactual equalizing everything, but amenities to value of MEN IN
        % ALL FIRMS HIRING BOTH OR ONLY MEN
        old_mean_pi_f=mean(pi_f(not(only_m)));
        pi_f=pi_m;
        new_mean_pi_f=mean(pi_f(not(only_f)));
        % Adjust outside option to reflect change in mean amenities
        phi_load_women=phi_load_women-old_mean_pi_f+new_mean_pi_f;
        b_f=b_f-old_mean_pi_f+new_mean_pi_f;
    end
    if strcmp(counterfactual,'baseline_equal_amenities_F')
        % Counterfactual equalizing amenities to value of WOMEN
        old_mean_pi_m=mean(pi_m(not(only_f)));
        pi_m(not(onegender))=pi_f(not(onegender));
        new_mean_pi_m=mean(pi_m(not(only_f)));
        % Adjust outside option to reflect change in mean amenities
        phi_load_men=phi_load_men-old_mean_pi_m+new_mean_pi_m;
        b_m=b_m-old_mean_pi_m+new_mean_pi_m;
    end
    if (strcmp(counterfactual,'baseline_z_equal_mean'))
        % Counterfactual shutting down GENDER WEDGE HETEROGENEITY
        tau=p.*0;
        tau(not(onegender))=z(not(onegender))./p(not(onegender));
        meantau=sum(tau(not(onegender)).*g_f(not(onegender)));
        z(not(onegender))=meantau.*p(not(onegender));
        fprintf('Mean tau was %g \n',meantau);
    end
    if (strcmp(counterfactual,'baseline_noz')) || (strcmp(counterfactual,'baseline_nodifference_all'))
        % Counterfactual shutting down GENDER WEDGES
        z(not(onegender))=0;
    end

    % Generate ptilde based on fundamentals
    ptilde_m=p+pi_m;
    ptilde_f=p+pi_f-z;
    if (eta_amenities > 0) && (not(strcmp(counterfactual,'baseline_no_amenities')))
        ptilde_m=ptilde_m-pi_m/eta_amenities;
        ptilde_f=ptilde_f-pi_f/eta_amenities;
    end
    if ((strcmp(counterfactual,'baseline_no_amenities')))
        ptilde_m=ptilde_m-pi_m/eta_amenities;
        %ptilde_f=ptilde_f-pi_f/eta_amenities;
    end

    % Modified outside options when amenities are shut down
    if (strcmp(counterfactual,'baseline_no_amenities'))
        %load results/amenities_share_utility.mat amenities_share_utility_m amenities_share_utility_f
        %Overridden b_m and b_f for keeping distributions in line with amenities = mean counterfactuals
        b_f=b_f-old_mean_pi_m;
        phi_load_women=b_f;
        fprintf('Outside options have been set to: [M %g, F %g] \n',b_m,b_f);
    end

    % % Counterfactual converting amenities to productivity
    % if strcmp(counterfactual,'baseline_amenities_are_p')
    %     %First, convert z into tau (proportional wedge)
    %     %tau_z = z./p;
    %     %Next, convert all of ptilde into productivity
    %     p=ptilde_m;
    %     %Move productivity for women
    %     old_phi_load_women=min(ptilde_f);
    %     ptilde_f=p - z;
    %     %Eliminate amenities
    %     pi_m=pi_m.*0;
    %     pi_f=pi_f.*0;
    %     %Adjust outside options to new productivity of men
    %     phi_load_men=min(ptilde_m);
    %
    %     %Do not adjust outside option for women!!!! if some firms have too
    %     %large wedges, so be it
    %     phi_load_women=min(ptilde_f);
    %
    % end

    % Adjustments to keep the small difference (that must exist) between
    % outside option and lowest ptilde of active firms
    phi_load_men=max(phi_load_men,min(ptilde_m)+keep_discrepancy_phi_m);
    phi_load_women=max(phi_load_women,min(ptilde_f)+keep_discrepancy_phi_f);

    if strcmp(counterfactual,'baseline_nodifference_all') || strcmp(counterfactual,'baseline_equal_phi')
        % equalize outside options
        phi_load_women=phi_load_men;
        b_f=b_m;
    end

    % adjustments for single-gender firms
    if sum(only_f)>0
        ptilde_m(only_f)=phi_load_men-1-rand(sum(only_f),1)*0.5;
        if eta_amenities > 0
            ptilde_f(only_f)=p_f(only_f)+pi_f(only_f)-pi_f(only_f)/eta_amenities;
        else
            ptilde_f(only_f)=p_f(only_f)+pi_f(only_f);
        end
    end
    if sum(only_m)>0
        ptilde_f(only_m)=phi_load_women-1-rand(sum(only_m),1)*0.5;
        if eta_amenities > 0
            ptilde_m(only_m)=p_m(only_m)+pi_m(only_m)-pi_m(only_m)/eta_amenities;
        else
            ptilde_m(only_m)=p_m(only_m)+pi_m(only_m);
        end
    end
    if strcmp(counterfactual,'baseline_nodifference_all')
        ptilde_f(only_m)=ptilde_m(only_m);
        ptilde_f(only_f)=phi_load_women-1-rand(sum(only_f),1)*0.5;
    end

    ptilde_m=ptilde_m(not(isnan(ptilde_m)));
    ptilde_f=ptilde_f(not(isnan(ptilde_m)));
    % Assign low value to women's draws that are missing (must be below outside option of women)
    ptilde_f(isnan(ptilde_f))=phi_load_women-1-rand((sum(isnan(ptilde_f))),1).*0.5;

    % Potential trimming of the top of the distribution, now always shut down
    if trim_high < 1
        remove_high=max((ptilde_m>quantile(ptilde_m,trim_high)),(ptilde_f>quantile(ptilde_f,trim_high)));
    end
    if trim_high > 1, remove_high=zeros(numel(ptilde_m),1); end
    removeobs=remove_high;
    fprintf('Trimming %g%% observations...\n',(sum(removeobs)/numel(ptilde_m))*100);
    ptilde_m=ptilde_m(removeobs==0);
    ptilde_f=ptilde_f(removeobs==0);

    if strcmp(policy_x,'equalpay') || strcmp(policy_x,'equalpay_equalhiring') || (strcmp(policy_x,'equalhiring_public')) || strcmp(policy_x,'equal_amenities')
        pi_m=pi_m(removeobs==0);
        pi_f=pi_f(removeobs==0);
        policy_application=policy_application(removeobs==0);
    end
    c_m=c_m(removeobs==0);
    c_f=c_f(removeobs==0);
    onegender=onegender(removeobs==0);
    if (strcmp(counterfactual,'baseline_nodiff_vcosts'))
        % equalize vacancy posting costs
        c_f(not(onegender))=c_m(not(onegender));    %apply only to single-gender firms
    end
    if (strcmp(counterfactual,'baseline_nodifference_all')) || (strcmp(counterfactual,'baseline_nodiff_vcosts')) || ...
            (strcmp(counterfactual,'baseline_equal_lab_params'))
        % equalize vacancy posting costs
        c_f=c_m;   %apply to all firms
    end
    if strcmp(cost_type,'units_of_output')
        c_m=c_m.*p(removeobs==0);
        c_f=c_f.*(p(removeobs==0)-z(removeobs==0));
    end

    % Show characteristics of fundamentals (already modified by
    % counterfactuals)
    fprintf('Distribution of ptilde_men:       mean %g    stddev %g   [%g,%g] \n',mean(ptilde_m),sqrt(var(ptilde_m)),min(ptilde_m),max(ptilde_m));
    fprintf('Distribution of ptilde_women:     mean %g    stddev %g   [%g,%g] \n',mean(ptilde_f),sqrt(var(ptilde_f)),min(ptilde_f),max(ptilde_f));
    fprintf('Conditional on hiring: \n');
    fprintf('    ptilde_men:      mean %g    stddev %g   [%g,%g] \n',mean(ptilde_m(not(only_f))),sqrt(var(ptilde_m(not(only_f)))),min(ptilde_m(not(only_f))),max(ptilde_m(not(only_f))));
    fprintf('    ptilde_women:    mean %g    stddev %g   [%g,%g] \n',mean(ptilde_f(not(only_m))),sqrt(var(ptilde_f(not(only_m)))),min(ptilde_f(not(only_m))),max(ptilde_f(not(only_m))));

    % Create grids for some policy functions
    ptilde_grid_m=linspace((min(ptilde_m)),(max(ptilde_m)),gridpoints)';
    ptilde_grid_f=linspace((min(ptilde_f)),(max(ptilde_f)),gridpoints)';

    % Show characteristics of distribution of fundamentals
    fprintf('Correlation between ptilde m and f is %g \n',fun_mycov(ptilde_m(not(only_f)),ptilde_f(not(only_f)),'CorrXY'));
    fprintf('Correlation between amenities m and f is %g \n',fun_mycov(pi_m(not(onegender)),pi_f(not(onegender)),'CorrXY'));

    % sort observations for later use in discrete algorithm - used only if no
    % policy is involved, otherwise sorting is not useful
    if (strcmp(policy_x,'equalpay')) || (strcmp(policy_x,'equalhiring')) || (strcmp(policy_x,'equalhiring_public')) || ...
            (strcmp(policy_x,'equalpay_equalhiring')) || (strcmp(policy_x,'equal_amenities'))
        %do not sort data in this case
    else
        [ptilde_m,idx_m]=sort(ptilde_m);
        [ptilde_f,idx_f]=sort(ptilde_f);
        c_m=c_m(idx_m);
        c_f=c_f(idx_f);
    end


    function res = righthandside_phi(wwdd, endogrid_wpi_in, FFF, delta_in, lambda_e_in, lambda_god_in, adjf_in)

        %==========================================================================
        % DESCRIPTION: Calculates the outside option.
        %
        % AUTHORS:     TBC
        %
        % INPUTS:      - TBC
        %
        % OUTPUTS:     - TBC
        %
        % DATE:        November 4, 2025
        %==========================================================================

        whatineed=1-interp1(endogrid_wpi_in,FFF,wwdd,'makima');
        res = (whatineed)./(rho+delta_in+adjf_in.*lambda_god_in+(adjf_in.*lambda_e_in*whatineed));
    end


    function [res, F_out, effective_w_out, l_out, v_x, endogrid_ppi, correct_cost] = funphi(x_input, ppi_grid_in, b_x, delta_x, lambda_u_x, lambda_e_x, lambda_god_x, meas_x, ppi_x, c_x)

        %==========================================================================
        % DESCRIPTION: Finds the outside option.
        %
        % AUTHORS:     TBC
        %
        % INPUTS:      - TBC
        %
        % OUTPUTS:     - TBC
        %
        % DATE:        November 4, 2025
        %==========================================================================

        % Endogenous objects start here
        u_x=delta_x/(delta_x+lambda_u_x+lambda_god_x);
        V_x=(lambda_u_x.^(1/alpha)).*meas_x.*(u_x + (lambda_e_x./lambda_u_x).*(1-u_x) + (lambda_god_x./lambda_u_x));
        T_x=meas_x.*((u_x + lambda_god_x/lambda_u_x)*lambda_u_x*(delta_x + lambda_e_x + lambda_god_x))/V_x;

        % Return with negative value if outside option is outside distribution boundaries
        if (x_input < min(ppi_grid_in)-1), res=100000; return
        elseif (x_input > max(ppi_grid_in)), res=-x_input + b_x; return, end

        % Call the solution to the system
        [effective_w_out,F_out,endogrid_ppi,correct_cost]=...
            fun_solve_system(params(5),delta_x,lambda_e_x,lambda_god_x,x_input,V_x,T_x,eta_v,c_x,ppi_x);
        % Calculate vacancies
        v_x=((T_x./(correct_cost.*c_x)).*(endogrid_ppi - effective_w_out).*((1./(delta_x + lambda_god_x + lambda_e_x.*(1-F_out))).^2)).^(1./(eta_v-1));
        v_x(v_x<0)=0;

        % Calculate firm sizes
        l_out=((1./(delta_x + lambda_god_x + lambda_e_x.*(1 - F_out))).^2) .* (v_x./V_x) .* meas_x.* (u_x + (lambda_god_x./lambda_u_x)).* (delta_x + lambda_god_x + lambda_e_x);

        % Compute outside option as differential equation (more precise and continuous)
        if (x_input < max(ppi_grid_in)) && (x_input > min(ppi_grid_in))
            allbspan=b_x + (lambda_u_x-lambda_e_x)*integral(@(wd)righthandside_phi(wd,effective_w_out,F_out,delta_x,lambda_e_x,lambda_god_x,1),max(x_input,min(effective_w_out)),max(effective_w_out));
            res = -x_input + allbspan;
        else
            res= -x_input;
        end
    end



    % Helper function used to find the outside option when the vacancy cost is
    % kept constant
    function [res,F_out,effective_w_out,l_out,v_x,endogrid_ppi,adjf] = funphi_constantc(x_input,ppi_grid_in,const_c,b_x,delta_x,lambda_u_x,lambda_e_x,lambda_god_x,meas_x,ppi_x,c_x)

        %==========================================================================
        % DESCRIPTION: Finds the outside option.
        %
        % AUTHORS:     TBC
        %
        % INPUTS:      - TBC
        %
        % OUTPUTS:     - TBC
        %
        % DATE:        November 4, 2025
        %==========================================================================

        % Return that a solution was not found if the outside option is
        % outside the distribution of firm fundamentals
        if (x_input < min(ppi_grid_in)-1), res=100000; [x_input min(ppi_grid_in)], return
        elseif (x_input > max(ppi_grid_in)), res=-x_input + b_x; return, end

        % Call the solution to the system
        % DIFFERENT METHOD: keep cost constant
        % find vacancies implied
        % adjust rates so that they are consistent

        % Solution
        [effective_w_out,F_out,endogrid_ppi,u_xx,V_xx,T_xx,adjf]=...
            fun_solve(params,delta_x,lambda_u_x,lambda_e_x,lambda_god_x,meas_x,x_input,const_c,eta_v,c_x,ppi_x);
        % Vacancies
        v_x=((T_xx./(const_c.*c_x)).*(endogrid_ppi - effective_w_out).*((1./(delta_x + adjf.*lambda_god_x + adjf.*lambda_e_x.*(1-F_out))).^2)).^(1./(eta_v-1));
        v_x(v_x<0)=0;

        % Firm Sizes
        l_out=((1./(delta_x + adjf.*lambda_god_x + adjf.*lambda_e_x.*(1 - F_out))).^2) .* (v_x./V_xx) .* meas_x.* (u_xx + (lambda_god_x./lambda_u_x)).* (delta_x + adjf.*lambda_god_x + adjf.*lambda_e_x);

        % Outside option as differential equation: higher precision
        if x_input < max(ppi_grid_in)
            allbspan=b_x + (lambda_u_x-lambda_e_x).*(adjf)*integral(@(wd)righthandside_phi(wd,effective_w_out,F_out,delta_x,lambda_e_x,lambda_god_x,adjf),max(x_input,min(effective_w_out)),max(effective_w_out));
            res = -x_input + allbspan;
            [x_input allbspan b_x adjf]
        else
            res= -x_input;
        end
    end

    %%%%%%%%%%%%%%%%%%POLICY-RELEVANT FUNCTIONS START HERE%%%%%%%%%%%%%%%%%%%%%
    % Function used to find the outside option when the vacancy cost is
    % kept constant for EQUAL PAY, EQUAL HIRING and EQUAL AMENITIES
    function [res,F_out_m,F_out_f,effective_w_out_m,effective_w_out_f,l_out_m,l_out_f,v_out_m,v_out_f,...
            endogrid_ppi_m,endogrid_ppi_f,adjf_m,adjf_f] = funphi_cc_equalpay(x_input,...
            const_c_m,const_c_f,ppi_m,ppi_f)

        %==========================================================================
        % DESCRIPTION: Finds the outside option.
        %
        % AUTHORS:     TBC
        %
        % INPUTS:      - TBC
        %
        % OUTPUTS:     - TBC
        %
        % DATE:        November 4, 2025
        %==========================================================================

        % Return no solution if outside option is out of distribution
        % boundaries
        res=zeros(2,1);
        if (x_input(1) < min(ptilde_grid_m)-1) || (x_input(2) < min(ptilde_grid_f)-1)
            res(:)=100000; [x_input; min(ptilde_grid_m)], return
        elseif (x_input(1) > max(ptilde_grid_m)) || (x_input(2) > max(ptilde_grid_f))
            res=-x_input + [b_m; b_f]; return
        end

        % Call the solution to the system
        % DIFFERENT METHOD: keep cost constant
        % find vacancies implied
        % adjust rates so that they are consistent

        if strcmp(policy_x,'equalpay')
            % Solving the equal pay policy with endogenous amenities
            [effective_w_out_m,effective_w_out_f,F_out_m,F_out_f,endogrid_ppi_m,endogrid_ppi_f,u_m,u_f,V_m,V_f,...
                T_m,T_f,adjf_m,adjf_f]=...
                fun_solve_equalpay(params,delta_m,delta_f,lambda_u_m,lambda_u_f,lambda_e_m,lambda_e_f,...
                lambda_g_m,lambda_g_f,meas_m,meas_f,x_input,const_c_m,const_c_f,...
                c_m,c_f,ppi_m,ppi_f,pi_m,pi_f,only_m,only_f,eta_v,eta_amenities);
        elseif strcmp(policy_x,'equal_amenities')
            % Solving the equal amenities policy with endogenous pay
            [effective_w_out_m,effective_w_out_f,F_out_m,F_out_f,endogrid_ppi_m,endogrid_ppi_f,u_m,u_f,V_m,V_f,...
                T_m,T_f,adjf_m,adjf_f]=...
                fun_solve_equalamenities(params,delta_m,delta_f,lambda_u_m,lambda_u_f,lambda_e_m,lambda_e_f,...
                lambda_g_m,lambda_g_f,meas_m,meas_f,x_input,const_c_m,const_c_f,...
                c_m,c_f,ppi_m,ppi_f,pi_m,pi_f,only_m,only_f,eta_v,eta_amenities);
        elseif strcmp(policy_x,'equalhiring')
            % Solving the equal hiring policy
            [effective_w_out_m,effective_w_out_f,F_out_m,F_out_f,endogrid_ppi_m,endogrid_ppi_f,u_m,u_f,V_m,V_f,...
                T_m,T_f,adjf_m,adjf_f]=...
                fun_solve_equalhiring(params,delta_m,delta_f,lambda_u_m,lambda_u_f,lambda_e_m,lambda_e_f,...
                lambda_g_m,lambda_g_f,meas_m,meas_f,x_input,const_c_m,const_c_f,...
                c_m,c_f,ppi_m,ppi_f,pi_m,pi_f,only_m,only_f,eta_v,eta_amenities);
        elseif strcmp(policy_x,'equalhiring_public')
            % Solving the equal hiring policy restricted to the public
            % sector only
            [effective_w_out_m,effective_w_out_f,F_out_m,F_out_f,endogrid_ppi_m,endogrid_ppi_f,u_m,u_f,V_m,V_f,...
                T_m,T_f,adjf_m,adjf_f]=...
                fun_solve_equalhiring(params,delta_m,delta_f,lambda_u_m,lambda_u_f,lambda_e_m,lambda_e_f,...
                lambda_g_m,lambda_g_f,meas_m,meas_f,x_input,const_c_m,const_c_f,...
                c_m,c_f,ppi_m,ppi_f,pi_m,pi_f,only_m,only_f,eta_v,eta_amenities,policy_application);
        end
        % Vacancies
        v_out_m=((T_m./(const_c_m.*c_m)).*max(endogrid_ppi_m - effective_w_out_m,0).*((1./(delta_m + adjf_m.*lambda_g_m + adjf_m.*lambda_e_m.*(1-F_out_m))).^2)).^(1./(eta_v-1));
        v_out_f=((T_f./(const_c_f.*c_f)).*max(endogrid_ppi_f - effective_w_out_f,0).*((1./(delta_f + adjf_f.*lambda_g_f + adjf_f.*lambda_e_f.*(1-F_out_f))).^2)).^(1./(eta_v-1));

        % Adjustments for policies in which vacancies are joint across
        % genders
        if strcmp(policy_x,'equalhiring') || strcmp(policy_x,'equalpay_equalhiring') || strcmp(policy_x,'equalhiring_public')
            v_out_joint=( ((T_m./(const_c_m.*c_m + const_c_f.*c_f)).*(endogrid_ppi_m - effective_w_out_m).*((1./(delta_m + adjf_m.*lambda_g_m + adjf_m.*lambda_e_m.*(1-F_out_m))).^2)) + ...
                ((T_f./(const_c_m.*c_m + const_c_f.*c_f)).*(endogrid_ppi_f - effective_w_out_f).*((1./(delta_f + adjf_f.*lambda_g_f + adjf_f.*lambda_e_f.*(1-F_out_f))).^2)) ).^(1./(eta_v-1));
            if strcmp(policy_x,'equalpay_equalhiring')
                load amenities_endo_policy_pay_hire.mat twogender_policy
                v_out_m(twogender_policy)=v_out_joint(twogender_policy);
                v_out_f(twogender_policy)=v_out_joint(twogender_policy);
            else
                v_out_m(not(onegender) & policy_application)=v_out_joint(not(onegender) & policy_application);
                v_out_f(not(onegender) & policy_application)=v_out_joint(not(onegender) & policy_application);
            end
        end
        v_out_m(v_out_m<0)=0;
        v_out_f(v_out_f<0)=0;

        % Firm sizes
        l_out_m=((1./(delta_m + adjf_m.*lambda_g_m + adjf_m.*lambda_e_m.*(1 - F_out_m))).^2) .* (v_out_m./V_m) .* meas_m.* (u_m + (lambda_g_m./lambda_u_m)).* (delta_m + adjf_m.*lambda_g_m + adjf_m.*lambda_e_m);
        l_out_f=((1./(delta_f + adjf_f.*lambda_g_f + adjf_f.*lambda_e_f.*(1 - F_out_f))).^2) .* (v_out_f./V_f) .* meas_f.* (u_f + (lambda_g_f./lambda_u_f)).* (delta_f + adjf_f.*lambda_g_f + adjf_f.*lambda_e_f);

        % Outside options
        if (x_input(1) < max(ptilde_grid_m)) && (x_input(2) < max(ptilde_grid_f))
            [ew_grid_m,idx_s_m]=sort(effective_w_out_m);     F_sorted_m=F_out_m(idx_s_m);
            [ew_grid_f,idx_s_f]=sort(effective_w_out_f);     F_sorted_f=F_out_f(idx_s_f);
            % add epsilon deviation to make rungs different if they are
            % equal (possible with limited numerical precision)
            ew_grid_m=ew_grid_m+(1e-15)*(1:numel(ew_grid_m))';
            ew_grid_f=ew_grid_f+(1e-15)*(1:numel(ew_grid_f))';
            allbspan(1)=b_m + (lambda_u_m-lambda_e_m).*(adjf_m)*integral(@(wd)righthandside_phi(wd,ew_grid_m,F_sorted_m,delta_m,lambda_e_m,lambda_g_m,adjf_m),x_input(1),max(effective_w_out_m));
            allbspan(2)=b_f + (lambda_u_f-lambda_e_f).*(adjf_f)*integral(@(wd)righthandside_phi(wd,ew_grid_f,F_sorted_f,delta_f,lambda_e_f,lambda_g_f,adjf_f),x_input(2),max(effective_w_out_f));
            res = -x_input + allbspan;
        else
            res= -x_input;
        end
    end

    adjf_men=1;
    adjf_women=1;

    % Solution with vacancy posting

    % Optional options for fzero
    % opti_fzero=optimset('Display','iter','TolX',1e-6);

    mentic=tic;
    % First solve men
    % Step 1: set parameters for men
    alpha=params(4);
    % Step 2: calculate men's outside option
    if (vcosts(1) == 0) || (strcmp(adjust_outside,'no'))
        % Baseline outside option does not need to be solved
        phi_men=phi_load_men;
    elseif not(strcmp(policy_x,'equalpay')) && not(strcmp(policy_x,'equalhiring')) && not(strcmp(policy_x,'equalhiring_public')) && ...
            not(strcmp(policy_x,'equalpay_equalhiring')) && not(strcmp(policy_x,'equal_amenities'))
        funphi_constantc(phi_load_men+0.1,ptilde_grid_m,vcosts(1),b_m,delta_m,lambda_u_m,lambda_e_m,lambda_g_m,meas_m,ptilde_m,c_m)
        try
            phi_men=fzero(@(x)funphi_constantc(x,ptilde_grid_m,vcosts(1),b_m,delta_m,lambda_u_m,lambda_e_m,lambda_g_m,meas_m,ptilde_m,c_m),[phi_load_men; prctile(ptilde_m(ptilde_m>phi_load_men),pctile_oo)]);
        catch ME
            fprintf('Fzero could not solve in available interval. \n');
            if strcmp(ME.identifier,'MATLAB:fzero:ValuesAtEndPtsSameSign')
                fprintf('outside option must go at the left of PHI: assign PHI_baseline instead \n');
                phi_men=max(phi_load_men,min(ptilde_m)+keep_discrepancy_phi_m);
            end
        end

    end

    if not(strcmp(policy_x,'equalpay')) && not(strcmp(policy_x,'equalhiring')) && not(strcmp(policy_x,'equalhiring_public')) && ...
            not(strcmp(policy_x,'equalpay_equalhiring')) && not(strcmp(policy_x,'equal_amenities'))
        fprintf('Phi for men is %g, took %g sec. \n',phi_men,toc(mentic));
    end

    % Step 3: calculate all policies and grids
    if vcosts(1) == 0
        [~,F_wpi_men,effective_w_men,firm_sizes_men,vacancies_men,egrid_ppi_men,vcost_men]=funphi(phi_men,ptilde_grid_m,b_m,delta_m,lambda_u_m,lambda_e_m,lambda_g_m,meas_m,ptilde_m,c_m);
    else
        if strcmp(policy_x,'equalpay') || strcmp(policy_x,'equalhiring') || (strcmp(policy_x,'equalhiring_public')) || ...
                strcmp(policy_x,'equalpay_equalhiring') || strcmp(policy_x,'equal_amenities')
            % For policy simulations, we keep outside options constant (too
            % numerically taxing otherwise)
            phi_men=phi_load_men;
            phi_women=phi_load_women;

            [~,F_wpi_men,F_wpi_women,effective_w_men,effective_w_women,firm_sizes_men,firm_sizes_women,...
                vacancies_men,vacancies_women,egrid_ppi_men,egrid_ppi_women,adjf_men,adjf_women]=...
                funphi_cc_equalpay([phi_men; phi_women],vcosts(1),vcosts(2),ptilde_m,ptilde_f);
            vcost_men=vcosts(1);
            vcost_women=vcosts(2);
        else
            [~,F_wpi_men,effective_w_men,firm_sizes_men,vacancies_men,egrid_ppi_men,adjf_men]=funphi_constantc(phi_men,ptilde_grid_m,vcosts(1),b_m,delta_m,lambda_u_m,lambda_e_m,lambda_g_m,meas_m,ptilde_m,c_m);
            vcost_men=vcosts(1);
        end
    end

    % Now solve women
    % Step 1: set parameters for women
    womentic=tic;
    % Step 2: calculate women's outside option
    if (vcosts(2) == 0) || (strcmp(adjust_outside,'no'))
        % No need to re-solve outside option in baseline solution
        phi_women=phi_load_women;
    elseif not(strcmp(policy_x,'equalpay')) && not(strcmp(policy_x,'equalhiring')) && not(strcmp(policy_x,'equalhiring_public')) && ...
            not(strcmp(policy_x,'equalpay_equalhiring')) && not(strcmp(policy_x,'equal_amenities'))
        try
            phi_women=fzero(@(x)funphi_constantc(x,ptilde_grid_f,vcosts(2),b_f,delta_f,lambda_u_f,lambda_e_f,lambda_g_f,meas_f,ptilde_f,c_f),[phi_load_women,prctile(ptilde_f(ptilde_f>phi_load_women),pctile_oo)]);
        catch ME
            fprintf('Fzero could not solve in available interval. \n');
            if strcmp(ME.identifier,'MATLAB:fzero:ValuesAtEndPtsSameSign')
                fprintf('outside option must go at the left of PHI: assign PHI_baseline instead \n');
                phi_women=max(phi_load_women,min(ptilde_f)+keep_discrepancy_phi_f);
            end
        end
    end

    if vcosts(2) == 0
        [~,F_wpi_women,effective_w_women,firm_sizes_women,vacancies_women,egrid_ppi_women,vcost_women]=funphi(phi_women,ptilde_grid_f,b_f,delta_f,lambda_u_f,lambda_e_f,lambda_g_f,meas_f,ptilde_f,c_f);
    else
        if strcmp(policy_x,'equalpay') || strcmp(policy_x,'equalhiring') || strcmp(policy_x,'equalhiring_public') || ...
                strcmp(policy_x,'equalpay_equalhiring') || strcmp(policy_x,'equal_amenities')
        else
            [~,F_wpi_women,effective_w_women,firm_sizes_women,vacancies_women,egrid_ppi_women,adjf_women]=funphi_constantc(phi_women,ptilde_grid_f,vcosts(2),b_f,delta_f,lambda_u_f,lambda_e_f,lambda_g_f,meas_f,ptilde_f,c_f);
            vcost_women=vcosts(2);
        end
    end
    fprintf('Phi for women is %g, took %g sec. \n',phi_women,toc(womentic));

    % Show graphs if option is set
    if showgraph == 1
        f1=figure(30);
        set(f1,'pos',[10 10 900 600])
        %the next graph is better if sorted
        [ew_m_sorted,idx_ew_m_s]=sort(effective_w_men);
        [ew_f_sorted,idx_ew_f_s]=sort(effective_w_women);
        subplot(2,3,1), plot(egrid_ppi_men(idx_ew_m_s),ew_m_sorted,'b',egrid_ppi_women(idx_ew_f_s),ew_f_sorted,'r'); legend('EW, Men','EW, Women','Location','northwest');
        subplot(2,3,2), plot(egrid_ppi_men(idx_ew_m_s),firm_sizes_men(idx_ew_m_s),'b',egrid_ppi_women(idx_ew_f_s),firm_sizes_women(idx_ew_f_s),'r'); legend('Firm Sizes, M','Firm Sizes, W','Location','northwest');
        subplot(2,3,3), plot(egrid_ppi_men(idx_ew_m_s),vacancies_men(idx_ew_m_s),'b',egrid_ppi_women(idx_ew_f_s),vacancies_women(idx_ew_f_s),'r'); legend('V, Men','V, Women','Location','northwest');
        subplot(2,3,4), plot(ew_m_sorted,F_wpi_men(idx_ew_m_s),'b',ew_f_sorted,F_wpi_women(idx_ew_f_s),'r'); legend('Eff. W D, Men','Eff. W D, Women','Location','northwest');
        subplot(2,3,5), scatter(egrid_ppi_men(idx_ew_m_s),F_wpi_men(idx_ew_m_s),'b'); hold on; scatter(egrid_ppi_women(idx_ew_f_s),F_wpi_women(idx_ew_f_s),'r'); hold off; legend('Ptilde CDF, Men','Ptilde CDF, Women','Location','northwest');
    end

    % end timer
    toc

    % Save the policy function in TEMP
    if savepolicy == 1
        save(sprintf('%s/policyf_%s.mat',DIR_TEMP,counterfactual),'params','egrid_ppi_men','egrid_ppi_women','ptilde_grid_m','ptilde_grid_f',...
            'effective_w_men','effective_w_women','firm_sizes_men','firm_sizes_women',...
            'vacancies_men','vacancies_women','F_wpi_men','F_wpi_women','phi_men','phi_women','MU','SIGMA',...
            'vcost_men','vcost_women','adjf_men','adjf_women','b_m','b_f');
    end
end
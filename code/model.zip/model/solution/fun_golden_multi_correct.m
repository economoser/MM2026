function [xres, fval] = fun_golden_multi_correct(funin, a, b, toll, showstuff, varargin)

    %==========================================================================
    % DESCRIPTION: This helper function solves a vector of minimization
    %              problems using golden search
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %
    % INPUTS:      - a vector of functions (funin), interval extremes (a,b), a
    %                termination tolerance (toll), whether to show iterations
    %                (showstuff)
    %
    % OUTPUTS:     - the vector of values that minimizes the vector of
    %                functions (xres), the value of these functions at the minimum (fval)
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % Step 1: convert function handle
    fun = fcnchk(funin, length(varargin));

    if nargin < 4, toll=0.000001; end
    if nargin < 5, showstuff=0; end

    phi = (1 + sqrt(5)) / 2; % Golden ratio
    resphi = 1/phi; % 1/phi

    maxiter=100000;
    miniter=max(round(log(1e-4)/log(0.62))-1,1); % minimum number of iterations (convergence)

    % Initial points
    c = b - resphi * (b - a);
    d = a + resphi * (b - a);

    % Function evaluations at initial points
    fc = fun(c);
    fd = fun(d);

    % Step 3: Multiple Dimension Golden Section Search
    dist_metrics=10000000;
    for i= 1:maxiter
        fc_better_fd = (fc<fd);

        b = d + (1-fc_better_fd).*(b-d);
        a = a + (1-fc_better_fd).*(c-a);

        % optimization computing resphi * (b-a)
        resphi_b_minus_a = resphi*(b-a);

        % passage variables
        dpass=d;    fcpass=fc;

        d = c + (1-fc_better_fd).*(a + resphi_b_minus_a - c);       %removed redundant passage, update before other update, streamlined
        c = (fc_better_fd).*(b - resphi_b_minus_a - dpass) + dpass;   %slightly more efficient update

        newpoint=c + (1-fc_better_fd).*(d-c);

        % optimize by keeping old valuations and remembering whether the new
        % point is C or D
        fnewpoint = fun(newpoint);
        fc=fd + (fc_better_fd).*(fnewpoint-fd);                   %removed redundant passage, update before other update
        fd=fcpass + (1-fc_better_fd).*(fnewpoint-fcpass);

        if (i >= miniter) && (dist_metrics < toll)
            xres=(b+a)/2;
            fval=fc;
            return
        end

        if i >= miniter, dist_metrics=max(resphi_b_minus_a); end
        if showstuff, fprintf('Iteration: %g           Metrics %g         \n',i,dist_metrics); end
    end
end
function fun_montecarlo_table(N, create_figures)

    %==========================================================================
    % DESCRIPTION: This function draws a distribution of fundamentals, solves
    %              the model, then estimates it to showcase that the algorithm recovers the
    %              true parameters subject to model structure
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - number of observations (N), whether to create the figures
    %                or not (create_figures)
    %
    % OUTPUTS:     - results/figures/fig_MC_scatter_phat_vs_p_X_N_k.eps, where
    %                X is the specific experiment type, N is the above input, k is the number of
    %                specific experiment
    %              - results/figures/fig_MC_scatter_ahat_vs_a_.eps, where
    %                X is the specific experiment type, N is the above input, k is the number of
    %                specific experiment
    %              - results/tables/tab_montecarlo_N.tex, where N is the above
    %                input
    %
    % DATE:        November 4, 2025
    %==========================================================================
    
    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % inputs
    if nargin < 1, N=100000; end
    if nargin < 2, create_figures=false; end

    % Options for algorithm
    method='FOCs';

    % set random seed
    rng(20250826, 'twister')

    %Parameters across simulations
    varamenities=[0.1 0.15 0.125 0.2 0.15];
    corramenities=[0 0 0 -0.5 0.5];
    eta_v_vector=[2 3 3.5 2 2.5];
    eta_amenities_vector=[8 4 7 9 10];
    nexp=numel(varamenities);

    varpi_est=zeros(nexp,1);
    corr_pi_est=zeros(nexp,1);
    corr_pi_poach_true=zeros(nexp,1);
    corr_pi_poach_est=zeros(nexp,1);
    corr_w_poach=zeros(nexp,1);

    for k=1:nexp

        eta_v=eta_v_vector(k);
        eta_amenities=eta_amenities_vector(k);

        % Set the variance-covariance matrix of the baseline joint normal
        % (converted to Pareto for productivity via copula)
        var_p=1;
        var_pi=varamenities(k);
        corr_p_pi=corramenities(k);
        SIGMA=[var_p  corr_p_pi*sqrt(var_p)*sqrt(var_pi)  corr_p_pi*sqrt(var_p)*sqrt(var_pi)  0; ...
            corr_p_pi*sqrt(var_p)*sqrt(var_pi)  var_pi  1*var_pi  0; ...
            corr_p_pi*sqrt(var_p)*sqrt(var_pi) 1*var_pi var_pi 0; ...
            0 0 0 0.00001];

        % Set labor market parameters, they do not influence results
        lambda_u_m=0.09;
        lambda_u_f=0.09;
        lambda_e_m=0.01;
        lambda_e_f=0.01;
        lambda_g_m=0.01;
        lambda_g_f=0.01;
        delta_m=0.02;
        delta_f=0.02;

        % Draw the distribution
        randdraw=mvnrnd([0; 0; 0; 0],SIGMA,N);
        randdraw_pareto=normcdf(randdraw(:,1));
        kappa_pareto=1/6;   sigma_pareto=0.5;     theta_pareto=sigma_pareto/kappa_pareto;
        p=gpinv(randdraw_pareto,kappa_pareto,sigma_pareto,theta_pareto);

        pi_m=randdraw(:,2)-min(randdraw(:,2))+0.01; %keep amenities positive
        pi_f=randdraw(:,3)-min(randdraw(:,3))+0.01;

        %redefine p to include amenity costs to avoid negative ptilde
        if eta_amenities > 0
            p=p+pi_m/eta_amenities;
        end

        % Define wedges, outside options, vacancy costs; preallocate vectors
        z=randdraw(:,4);
        phi_load_men=3;
        phi_load_women=3;
        c_m=100000*ones(N,1)*mean(p);
        c_f=100000*ones(N,1)*mean(p);
        fe_m=zeros(N,1);    fe_f=zeros(N,1);
        f_m=zeros(N,1);     f_f=zeros(N,1);
        g_m=zeros(N,1);     g_f=zeros(N,1);
        F_m=zeros(N,1);     F_f=zeros(N,1);
        only_m=zeros(N,1);  only_f=zeros(N,1);
        public_sector=zeros(N,1);
        p_m=p;
        p_f=p-z;
        empid=(1:N)';

        % Save the distributions
        save(sprintf('%s/distribution_data.mat',DIR_TEMP),'lambda_u_m','lambda_u_f','lambda_e_m','lambda_e_f','lambda_g_m','lambda_g_f',...
            'delta_m','delta_f','p','pi_m','pi_f','z','phi_load_men','phi_load_women','c_m','c_f','public_sector',...
            'fe_m','fe_f','f_m','f_f','F_m','F_f','only_m','only_f','p_m','p_f','empid','eta_v','eta_amenities','g_m','g_f');
        save(sprintf('%s/distribution_data_MOD.mat',DIR_TEMP),'lambda_u_m','lambda_u_f','lambda_e_m','lambda_e_f','lambda_g_m','lambda_g_f',...
            'delta_m','delta_f');

        % Set up all parameters depending on the experiment
        %load(sprintf('%s/economywide_parameters.mat',DIR_TEMP),'params');

        % Set up placeholder parameters, overridden by the Monte Carlo
        % simulation
        params=zeros(29,1);
        
        % Override parameters to make Monte Carlo independent from estimation
        params(24)=0.5; %measure of women
        params(25)=0.5; %measure of men
        params(7)=0.5; %b_m
        params(23)=0.5; %b_f;
        params(4)=0.5; %alpha
        
        measure_men=params(25);
        params(7)=-100;
        params(23)=-100;
        alpha=0.5;

        % Solve the model
        fun_model_GG(params,0,1,[0; 0],eta_v,eta_amenities);

        % Simulate the model
        [~,~,~]=fun_simulate_model('none',0,eta_v,eta_amenities,1,'nonparametric','DISCRETE');

        % Read the data
        AA=dlmread(sprintf('%s/sim_data.txt',DIR_TEMP));
        p_draw=AA(:,2);
        pimen_draw=AA(:,3);
        piwomen_draw=AA(:,4);
        z_draw=AA(:,5);
        w_f_men=AA(:,6);
        w_f_women=AA(:,7);
        size_f_men=AA(:,8);
        size_f_women=AA(:,9);
        vmen=AA(:,10);
        vwomen=AA(:,11);
        F_f_men=AA(:,12);
        F_f_women=AA(:,13);
        eff_w_f_men=exp(w_f_men)+pimen_draw;
        eff_w_f_women=exp(w_f_women)+piwomen_draw;

        % Select nonmissing (some firms may be below outside option)
        selec_these=(not(isnan(w_f_men)) & (w_f_men > -10000));
        w=exp(w_f_men(selec_these));
        f_weights=vmen(selec_these);
        firm_rank=tiedrank(eff_w_f_men(selec_these));
        pi=pimen_draw(selec_these);
        p=p_draw(selec_these);

        % Statistics generate by simulations are in logs, therefore
        % exponentiate sizes before creating labor share weights
        laborshare_weights=exp(size_f_men(selec_these))./sum(exp(size_f_men(selec_these)));

        %construct value added for computation of labor share
        if eta_amenities == 0
            netprod=p;
        else
            netprod=(p-(pi./eta_amenities));
        end
        laborshare=sum(laborshare_weights.*w)./sum(laborshare_weights.*netprod);
        fprintf('The labor share in the model data is %g \n',laborshare);

        % Construct target of slope of log pay on log productivity (known in data)
        cov_pay_p=fun_mycov(log(w),log(netprod),'CovXY',laborshare_weights);
        var_log_p=fun_mycov(log(netprod),log(netprod),'VarX',laborshare_weights);
        p_target=cov_pay_p/var_log_p;

        % Construct the target for the share of amenities (known in data)
        share_pi_target=sum(laborshare_weights.*(pi./eta_amenities))/sum(laborshare_weights.*netprod);

        %Estimate using new algorithm
        [pi_out,p_out,~,eta_v_hat,eta_pi_hat]=fun_estimation(w,firm_rank,f_weights,delta_m,lambda_g_m,lambda_e_m,lambda_u_m,[measure_men; alpha],laborshare,0,0,p_target,share_pi_target,false);
        wpi_out=w+pi_out;

        %Adjust productivity estimates by pi/eta_amenities
        p_out=p_out+(pi_out./eta_pi_hat);

        %Display statistics
        cov1=cov(pi_out,pi); beta_pi=cov1(1,2)/var(pi_out);
        cov2=cov(firm_rank,tiedrank(wpi_out)); beta_poach=cov2(1,2)/var(firm_rank);
        cov3=cov(tiedrank(pi),tiedrank(pi_out)); beta_pi_rks=cov3(1,2)/var(tiedrank(pi));

        cov11=cov(p_out,p); beta_p=cov11(1,2)/var(p_out);
        cov33=cov(tiedrank(p),tiedrank(p_out)); beta_p_rks=cov33(1,2)/var(tiedrank(p));

        fprintf('Correlation(Poach,w): %g                        \n',corr(firm_rank,w));
        fprintf('Var(w):        %g                        \n',var(w));
        fprintf('-----------------------------------------\n');
        fprintf('Corr Poach Rks (True, Est): %g (Beta %g) \n',corr(firm_rank,tiedrank(wpi_out)),beta_poach);
        fprintf('Corr Pi (True, Est):        %g (Beta %g) \n',corr(pi_out,pi),beta_pi);
        fprintf('Corr Pi Rks (True, Est):    %g (Beta %g) \n',corr(tiedrank(pi_out),tiedrank(pi)),beta_pi_rks);
        fprintf('Corr P (True, Est):         %g (Beta %g) \n',corr(p_out,p),beta_p);
        fprintf('Corr P Rks (True, Est):     %g (Beta %g) \n',corr(tiedrank(p_out),tiedrank(p)),beta_p_rks);
        fprintf('-----------------------------------------\n');
        fprintf('-Pi----Data vs Estimates-----------Data----Estimate\n');
        fprintf('Mean(Pi)                           %3.4f    %3.4f \n',mean(pi),mean(pi_out));
        fprintf('Var(Pi)                            %3.4f    %3.4f \n',var(pi),var(pi_out));
        fprintf('Correlation(Pi,w):                        %3.4f    %3.4f \n',corr(pi,w),corr(pi_out,w));
        fprintf('Correlation(Pi,Poach):                    %3.4f    %3.4f \n',corr(pi,firm_rank),corr(pi_out,firm_rank));
        fprintf('Mean Error                         %3.4f    \n',mean((pi-pi_out)));
        fprintf('MSE                                %3.4f    \n',mean((pi-pi_out).^2));
        fprintf('MSE (poach_rank < 0.1)             %3.4f    \n',mean((pi(firm_rank<0.1*max(firm_rank))-pi_out(firm_rank<0.1*max(firm_rank))).^2));
        fprintf('MSE (poach_rank > 0.9)             %3.4f    \n',mean((pi(firm_rank>0.9*max(firm_rank))-pi_out(firm_rank>0.9*max(firm_rank))).^2));
        fprintf('-P-----Data vs Estimates-----------Data----Estimate\n');
        fprintf('Mean(P)                            %3.4f    %3.4f \n',mean(p),mean(p_out));
        fprintf('Var(P)                             %3.4f    %3.4f \n',var(p),var(p_out));
        fprintf('Correlation(P,w):                         %3.4f    %3.4f \n',corr(p,w),corr(p_out,w));
        fprintf('Correlation(P,Poach):                     %3.4f    %3.4f \n',corr(p,firm_rank),corr(p_out,firm_rank));
        fprintf('Mean Error                         %3.4f    \n',mean((p-p_out)));
        fprintf('MSE                                %3.4f    \n',mean((p-p_out).^2));
        fprintf('MSE (poach_rank < 0.1)             %3.4f    \n',mean((p(firm_rank<0.1*max(firm_rank))-p_out(firm_rank<0.1*max(firm_rank))).^2));
        fprintf('MSE (poach_rank > 0.9)             %3.4f    \n',mean((p(firm_rank>0.9*max(firm_rank))-p_out(firm_rank>0.9*max(firm_rank))).^2));
        fprintf('Correlation(P,Pi):                        %3.4f    %3.4f \n',corr(p,pi),corr(p_out,pi_out));
        fprintf('Eta_V                                     %3.4f    %3.4f \n',eta_v,eta_v_hat);
        fprintf('Eta_Pi                                    %3.4f    %3.4f \n',eta_amenities,eta_pi_hat);

        % Create the figures if option is set
        if create_figures
            nq=100;
            p_graph=zeros(nq,1);
            pi_graph=zeros(nq,1);
            p_out_graph=zeros(nq,1);
            pi_out_graph=zeros(nq,1);
            for jj=1:nq
                selecpnow=(p>quantile(p,(jj-1)/100) & p<=quantile(p,jj/100));
                p_graph(jj)=mean(p(selecpnow));
                p_out_graph(jj)=mean(p_out(selecpnow));
                selecpinow=(pi>quantile(pi,(jj-1)/100) & pi<=quantile(pi,jj/100));
                pi_graph(jj)=mean(pi(selecpinow));
                pi_out_graph(jj)=mean(pi_out(selecpinow));
            end

            axis_limit_p=[3 9];
            f1=figure('Name','Estimates vs Data','Position',[100 100 600 500],'Color','white');
            scatter(p_graph,p_out_graph,20,'filled'); hold on; plot(axis_limit_p,axis_limit_p,'r'); hold off; legend({'$\hat{p}$','45-degree line'},'Interpreter','latex'); xlabel({'$p$'},'Interpreter','latex'); ylabel({'$\hat{p}$'},'Interpreter','latex');
            gggg=gca;
            gggg.XAxis.FontSize=12;
            gggg.YAxis.FontSize=12;
            gggg.XLim=axis_limit_p;
            gggg.YLim=axis_limit_p;
            gggg.Legend.FontSize=12;
            drawnow;
            %saveas(f1,sprintf('%s/figures/fig_MC_scatter_phat_vs_p_%s_%g_%g.eps',DIR_RESULTS,method,N,k),'epsc');
            exportgraphics(f1, sprintf('%s/figures/fig_MC_scatter_phat_vs_p_%s_%g_%g.eps',DIR_RESULTS,method,N,k),'ContentType','vector');

            axis_limit_a=[0.5 3.5];
            f2=figure('Name','Estimates vs Data','Position',[100 100 600 500],'Color','white');
            scatter(pi_graph,pi_out_graph,20,'filled'); hold on; plot(axis_limit_a,axis_limit_a,'r'); hold off; legend({'$\hat{a}$','45-degree line'},'Interpreter','latex'); xlabel({'$a$'},'Interpreter','latex'); ylabel({'$\hat{a}$'},'Interpreter','latex');
            gggg=gca;
            gggg.XAxis.FontSize=12;
            gggg.YAxis.FontSize=12;
            gggg.XLim=axis_limit_a;
            gggg.YLim=axis_limit_a;
            gggg.Legend.FontSize=12;
            drawnow;
            %saveas(f2,sprintf('%s/figures/fig_MC_scatter_ahat_vs_a_%s_%g_%g.eps',DIR_RESULTS,method,N,k),'epsc');
            exportgraphics(f2,sprintf('%s/figures/fig_MC_scatter_ahat_vs_a_%s_%g_%g.eps',DIR_RESULTS,method,N,k),'ContentType','vector');

        end

        % Include all observations
        selecobs=(p>0);

        % Compute statistics across experiments
        varpi(k)=var(pi(selecobs));
        varp(k)=var(p(selecobs));
        varpi_est(k)=var(pi_out(selecobs));
        varp_est(k)=var(p_out(selecobs));
        corr_p_pi_true(k)=corr(p(selecobs),pi(selecobs));
        corr_p_pi_est(k)=corr(p_out(selecobs),pi_out(selecobs));
        corr_pi_est(k)=corr(pi_out(selecobs),pi(selecobs));
        corr_p_est(k)=corr(p_out(selecobs),p(selecobs));
        corr_pi_w_true(k)=corr(pi(selecobs),w(selecobs));
        corr_p_w_true(k)=corr(p(selecobs),w(selecobs));
        corr_pi_w_est(k)=corr(pi_out(selecobs),w(selecobs));
        corr_p_w_est(k)=corr(p_out(selecobs),w(selecobs));
        corr_pi_poach_true(k)=corr(pi(selecobs),firm_rank(selecobs));
        corr_p_poach_true(k)=corr(p(selecobs),firm_rank(selecobs));
        corr_pi_poach_est(k)=corr(pi_out(selecobs),firm_rank(selecobs));
        corr_p_poach_est(k)=corr(p_out(selecobs),firm_rank(selecobs));
        mean_error_pi(k)=mean((pi(selecobs)-pi_out(selecobs)))/sqrt(var(pi(selecobs)));
        mean_error_p(k)=mean((p(selecobs)-p_out(selecobs)))/sqrt(var(p(selecobs)));
        MSE_pi(k)=mean((pi(selecobs)-pi_out(selecobs)).^2);
        MSE_p(k)=mean((p(selecobs)-p_out(selecobs)).^2);
        corr_w_poach(k)=corr(firm_rank(selecobs),w(selecobs));
        etavhat(k)=eta_v_hat;
        etapihat(k)=eta_pi_hat;
    end

    % Write the Monte Carlo table
    filename=sprintf('%s/tables/tab_montecarlo_%g.tex',DIR_RESULTS,N);
    fileid=fopen(filename,'w+');
    fprintf(fileid,' \\begin{tabular}{lrrrrr} \\hline\\hline \n');
    fprintf(fileid,'             & \\multicolumn{1}{c}{(1)} & \\multicolumn{1}{c}{(2)} & \\multicolumn{1}{c}{(3)} & \\multicolumn{1}{c}{(4)} & \\multicolumn{1}{c}{(5)} \\\\ \\hline \n');
    fprintf(fileid,' \\multicolumn{6}{l}{\\emph{Panel A. Properties of true wages $w$}} \\tabularnewline \n');
    fprintf(fileid,' Correlation between $w$ and $r$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_w_poach(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' \\multicolumn{6}{l}{\\emph{Panel B. Properties of true amenity values $a$}} \\\\ \n');
    fprintf(fileid,' Standard deviation of $a$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',sqrt(varpi(k))); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $a$ and $w$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_pi_w_true(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $a$ and $r$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_pi_poach_true(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,'\\\\ \n');

    fprintf(fileid,' \\multicolumn{6}{l}{\\emph{Panel C. Properties of true productivity $p$}} \\\\ \n');
    fprintf(fileid,' Standard deviation of $p$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',sqrt(varp(k))); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $p$ and $w$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_p_w_true(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $p$ and $r$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_p_poach_true(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $p$ and $a$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_p_pi_true(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,'\\\\ \n');

    fprintf(fileid,' \\multicolumn{6}{l}{\\emph{Panel D. Properties of estimated amenity values $\\hat{a}$ and productivity $\\hat{p}$}} \\\\ \n');
    fprintf(fileid,' Standard deviation of $\\hat{a}$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',sqrt(varpi_est(k))); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{a}$ and $w$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_pi_w_est(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{a}$ and $r$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_pi_poach_est(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Standard deviation of $\\hat{p}$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',sqrt(varp_est(k))); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{p}$ and $w$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_p_w_est(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{p}$ and $r$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_p_poach_est(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{p}$ and $\\hat{a}$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_p_pi_est(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,'\\\\ \n');

    fprintf(fileid,'   \\multicolumn{6}{l}{\\emph{Panel E. Goodness of fit}} \\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{a}$ and $a$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_pi_est(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\hat{a}$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',MSE_pi(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Correlation between $\\hat{p}$ and $p$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',corr_p_est(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\hat{p}$ ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',MSE_p(k)); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\eta^{v}$  ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',(etavhat(k)-eta_v_vector(k))^2); end
    fprintf(fileid,'\\\\ \n');
    fprintf(fileid,' Mean squared error of $\\eta^{a}$  ');
    for k=1:nexp, fprintf(fileid,' & %9.3f',(etapihat(k)-eta_amenities_vector(k))^2); end
    fprintf(fileid,'\\\\ \\hline \n');
    fprintf(fileid,' \\end{tabular} \n');
    fclose(fileid);
end
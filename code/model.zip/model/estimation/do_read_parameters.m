fprintf('\n==============================================================')
fprintf('\nFILE NAME:   do_read_parameters.m')
fprintf('\n')
fprintf('\nDESCRIPTION: This script reads the exogenous parameters set in')
fprintf('\n             the Master file and writes them in a .mat file')
fprintf('\n             economywide_parameters, placed in 6_output')
fprintf('\n')
fprintf('\nAUTHORS:     Iacopo Morchio (University of Bristol)')
fprintf('\n             Christian Moser (Columbia University)')
fprintf('\n')
fprintf('\nINPUTS:      - output/pop_shares.txt, output/exogenous_parameters.txt')
fprintf('\n')
fprintf('\nOUTPUTS:     - output/economywide_parameters.mat')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n==============================================================')


fprintf('\n==============================================================')
fprintf('\n INITIAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Clear memory\n')
clc
clear

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Assign folders\n')
if exist('paths.txt', 'file')
    replicationpaths = readlines('paths.txt');
    DIR_MAIN = replicationpaths(1);
    DIR_TEMP = replicationpaths(2);
else
    fprintf('\nUSER ERROR: Directory not found.\n')
    exit
end
    DIR_DO = fullfile(DIR_MAIN, 'code'); % code directory
        DIR_DO_MODEL = fullfile(DIR_DO, 'model'); % model-code directory
            DIR_DO_MODEL_ESTIMATION = fullfile(DIR_DO_MODEL, 'estimation'); % model-estimation-code directory
            addpath(DIR_DO_MODEL_ESTIMATION);
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % directory for log files
        FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_do_read_parameters.log']);
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');
clear replicationpaths DIR_MAIN DIR_DO DIR_DO_MODEL DIR_DO_MODEL_ESTIMATION STR_TIME_STAMP

fprintf('\n  --> Set random seed\n')
seed = 20250828;
rng(seed, 'twister')
clear seed

fprintf('\n  --> Start log file\n')
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n READ EXOGENOUS PARAMETERS')
fprintf('\n==============================================================')

fprintf('\n  --> Define matrix to be read\n')
data_exo = readmatrix(sprintf('%s/exogenous_parameters.txt', DIR_TEMP));
params = zeros(28, 1);
params(8) = data_exo(1); % rho
params(4) = data_exo(2); % alpha
clear data_exo

fprintf('\n  --> Read population shares\n')
pop_shares = readmatrix(sprintf('%s/pop_shares.txt', DIR_TEMP));
params(25) = pop_shares(1, 3);
params(24) = 1 - params(25);
clear pop_shares

fprintf('\n  --> Save economy-wide parameters\n')
save(sprintf('%s/economywide_parameters.mat', DIR_TEMP), 'params');
clear params

fprintf('\n  --> Write empty file to tell Stata that MATLAB has finished\n')
writematrix(0, fullfile(DIR_TEMP, 'ihavefinished.txt'));
clear DIR_TEMP


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF do_read_parameters.m')
fprintf('\n==============================================================')

fprintf('\n  --> Close log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> Exit\n')
exit
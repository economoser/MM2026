function [pi_out, p_out, F_out, eta_v, eta_pi] = fun_estimation( ...
    w, firm_rank, f_weights, delta, lambda_g, lambda_e, lambda_u, ...
    exo_params, laborshare, eta_v, eta_pi, p_target, share_pi_target, ...
    perform_kdensity)

    %==========================================================================
    % DESCRIPTION: This function estimates amenities and productivity using
    %              data on wages, ranks, hiring intensities, labor market objects and
    %              targets for outside loops
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - wages w, firm rank firm_rank, hiring intensities
    %                f_weights, labor market objects, exogenous parameters,
    %                target for the labor share, options for estimating eta_v
    %                and eta_pi, further targets for outside loops, options to
    %                perform smoothing of hiring (necessary)
    %
    % OUTPUTS:     - amenities pi_out, productivities (net of wedges for women)
    %                p_out, smoothed offer CDF F_out, economy-wide elasticities
    %                eta_v and eta_pi
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % inputs
    if nargin < 10, eta_v=0; end    %if eta_v is not passed as a number >0, it is estimated
    if nargin < 11, eta_pi=0; end   %if eta_pi is not passed as a number >0, it is estimated
    if nargin < 12, p_target=1.32; end
    if nargin < 13, share_pi_target=0.08; end
    if nargin < 14, perform_kdensity=true; end

    starttic=tic;

    toll=1e-8; % tolerance for convergence algorithms
    excess=0.0000001; % adjustment to avoid kdensity boundary errors
    bw=250; % number of points for kdensity. default 250

    [~,idx]=sort(firm_rank); % get the sorting index
    [~,sortback]=sort(idx); % to sort back to original at the end
    synthetic_rank=(1:numel(firm_rank))';

    converted_ranks=synthetic_rank(sortback);

    % Rank density estimation to smooth the hiring distribution with discrete
    % data
    Nf=numel(idx);
    if perform_kdensity==true
        f_grid=linspace(min(converted_ranks),max(converted_ranks),Nf);
        % Estimate the density of ranks using weights provided in f
        [f_est,f_grid]=ksdensity(converted_ranks,f_grid,'Support',[min(converted_ranks)-excess max(converted_ranks)+excess],...
            'Weights',f_weights,'BoundaryCorrection','reflection','Bandwidth',bw);

        f_est_interp=griddedInterpolant(f_grid,f_est,'spline');

        f=f_est_interp(converted_ranks);

    else
        f=f_weights;
    end

    % Sorted versions of f, F and wages
    f_ranked=f(idx)./sum(f);
    F_ranked=cumsum(f_ranked);
    w_ranked=w(idx);

    % Set measure of workers
    meas=exo_params(1);

    % Preliminary parameters: alpha, u, V, T
    alpha=exo_params(2);
    s_g=lambda_g/lambda_u;
    u=delta/(delta+lambda_u+lambda_g);
    V=(lambda_u.^(1/alpha)).*meas.*(u + (lambda_e./lambda_u).*(1-u) + (lambda_g/lambda_u));
    T=meas*((u + s_g)*lambda_u*(delta + lambda_g + lambda_e))/V;
    s_g=lambda_g/lambda_u;

    % Initialization of bisection for outer loop
    dist_moment_p=100;
    if eta_v == 0
        a=1.1;
        b=8;
        eta_v=a;
        estimating_eta_v=true;
    else
        % eta_v is given as a value when estimating for women
        a=eta_v;
        b=eta_v;
        estimating_eta_v=false;
    end
    iter=0;

    model_firm_sizes=f_ranked.*(1./((delta+lambda_g+lambda_e.*(1-F_ranked)).^2)).*(meas).*(u+s_g).*(lambda_u).*(delta+lambda_g+lambda_e);
    laborshare_weights=model_firm_sizes./sum(model_firm_sizes);

    scaler=1; % optional scaler to avoid small numbers in computation

    w_ranked=w_ranked*scaler;

    % Outer loop to match the target related to productivity
    while abs(dist_moment_p) > toll
        iter=iter+1;
        cost_per_firm=ones(Nf,1); % preallocation
        cost=3000*scaler;
        dist=100;
        iter_cost=0;
        x=zeros(Nf,1);

        Nf_by_V=Nf*V;

        % Loop to estimate the vacancy posting cost to match the labor share
        % Start with vacancies and sizes: f_ranked = v/V at the firm level.
        while dist > toll
            iter_cost=iter_cost+1;
            % Original formula for comparison
            % p_minus_x=((f_ranked.*Nf.*V).^(eta_v-1)).*((cost_per_firm.*cost/T).*((delta+lambda_g+lambda_e.*(1-F_ranked)).^2));

            % Rearrangement of terms for precision
            p_minus_x=(((scaler.^(1/(eta_v-1))).*f_ranked.*Nf_by_V.*((1./T).^(1./(eta_v-1)))).^(eta_v-1)).*((cost_per_firm.*cost).*((delta+lambda_g+lambda_e.*(1-F_ranked)).^2));

            p=p_minus_x+w_ranked;

            % Calculation of labor share with current vacancy cost
            estimated_laborshare=sum(laborshare_weights.*w_ranked)/sum(laborshare_weights.*p);
            dist=abs(estimated_laborshare-laborshare)/laborshare;
            if estimated_laborshare > laborshare
                cost=cost + cost*0.5*abs(estimated_laborshare-laborshare);
            else
                cost=cost - cost*0.5*abs(estimated_laborshare-laborshare);
            end
        end

        % Original formula for comparison
        % xprime=(2*lambda_e*p_minus_x.*(1./((delta+lambda_g+lambda_e.*(1-F_ranked))))).*(1./(Nf_by_V)).* ...
        %     (((T.*p_minus_x./(cost.*cost_per_firm)).*(1./((delta+lambda_g+lambda_e.*(1-F_ranked)).^2))).^(1./(eta_v-1)));

        % More numerically accurate version moving terms around to avoid
        % multiplying small terms consecutively
        xprime=(2*lambda_e*p_minus_x.*(1./((delta+lambda_g+lambda_e.*(1-F_ranked))))).* ... %small term
            (1./(Nf_by_V)).* ... %small term
            (((1./((delta+lambda_g+lambda_e.*(1-F_ranked)).^2))).^(1./(eta_v-1))).* ... %bigger term moved up to avoid small rounding errors
            ((T.^(1./(eta_v-1))).*(p_minus_x.^(1./(eta_v-1)))./((cost.*cost_per_firm).^(1./(eta_v-1)))); %small terms separately square-rooted
        x=[x(1); cumsum(xprime(1:end-1))];

        % Calculate productivity
        p=p_minus_x+w_ranked;

        % Calculate moment of slope of log pay on log p
        cov_pay_p=fun_mycov(log(w_ranked/scaler),log(p/scaler),'CovXY',model_firm_sizes);
        var_log_p=fun_mycov(log(p/scaler),log(p/scaler),'VarX',model_firm_sizes);
        beta_pay_p=cov_pay_p/var_log_p;
        p_moment=beta_pay_p;

        dist_moment_p=p_moment-p_target;

        % Bisection for eta_v
        if estimating_eta_v
            if iter == 1
                eta_v=b;
                a_dist_moment_p=dist_moment_p;
            elseif iter == 2
                eta_v=(a+b)/2;
            else
                if dist_moment_p*a_dist_moment_p > 0
                    a=eta_v;
                    % b=b;
                    a_dist_moment_p=dist_moment_p;
                else
                    % a=a;
                    b=eta_v;
                end
                eta_v=(a+b)/2;
            end
            fprintf('Bisection iter %g, std(log(p-x))=%g, slope(log(w),log(p))=%g, trying eta_v = %g \n',iter,sqrt(var(log(p_minus_x))),p_moment,eta_v);
            fprintf('Slope (cov) of log pay pw on log value added pw: %g (%g) \n',beta_pay_p,cov_pay_p);
        else
            dist_moment_p=0;
        end

    end

    fprintf('Estimation finished! Took %g iterations, estimated vs true labor share: %g - %g \n',iter,estimated_laborshare,laborshare);

    fprintf('Estimated eta_v: %g, implied slope of log pay on log p: %g vs %g \n',eta_v,p_moment,p_target);
    fprintf('                 implied stddev of log p: %g \n',sqrt(var(log(p))));

    % STEP 6: get amenities as x-w
    pi_sorted=(x-w_ranked);
    p_sorted=(p_minus_x+w_ranked);

    % Adjustment for scaler
    pi_sorted=pi_sorted/scaler;
    p_sorted=p_sorted/scaler;

    fprintf('P range:  [%g - %g] \n',min(p_sorted),max(p_sorted));
    fprintf('Pi range: [%g - %g] \n',min(pi_sorted),max(pi_sorted));
    fprintf('U %g + E %g = %g, Measure %g \n',u*meas,sum(model_firm_sizes),(u*meas)+sum(model_firm_sizes),meas);
    fprintf('Total cost share of vacancies: %g \n',sum((cost/scaler).*((f_ranked.*V).^eta_v)./eta_v)./sum(p_sorted.*model_firm_sizes));

    % Sort back to original
    pi_out=pi_sorted(sortback);
    p_out=p_sorted(sortback);
    F_out=F_ranked(sortback);

    % sort back also labor share weights for final calculations
    laborshare_weights=laborshare_weights(sortback);

    pi_out=pi_out-min(pi_out)+0.01; %small positive floor for amenities

    cost_of_pi_each=pi_out;

    if eta_pi == 0
        eta_pi=(sum( cost_of_pi_each.*laborshare_weights)/sum((p_out).*laborshare_weights)) / share_pi_target;
    end
    fprintf('Estimated eta_pi is %g \n',eta_pi);
    fprintf('Estimated cost share of amenities is %g \n',sum((cost_of_pi_each.*laborshare_weights)./eta_pi)./sum((p_out).*laborshare_weights));
    fprintf('Amenities estimated, time %g \n',toc(starttic));
end
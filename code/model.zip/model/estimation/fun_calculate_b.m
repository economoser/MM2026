function b = fun_calculate_b(wpi, F, delta, lambda_u, lambda_e, lambda_g, rho)

    %==========================================================================
    % DESCRIPTION: This helper function calculates gender-specific flow values of nonemployment (b_m and b_f) using the right-hand side of the outside option formula
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - w + a (wpi), the hiring CDF, labor market objects and the discount rate rho
    %
    % OUTPUTS:     - flow value of nonemployment (b)
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');
    
    % calculations
    [wpi, idx] = sort(wpi);
    b = min(wpi) - (lambda_u - lambda_e)*integral(@(wd) righthandside_phi(wd, wpi, F(idx), delta, lambda_e, lambda_g, rho), min(wpi), max(wpi));
end


function res = righthandside_phi(wwdd,endogrid_wpi_in,FFF,delta_in,lambda_e_in,lambda_god_in,rho)

    %==========================================================================
    % DESCRIPTION: This helper function calculates the right-hand side of phi.
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');
    
    % calculations
    intermediate = 1 - interp1(endogrid_wpi_in, FFF, wwdd, 'makima');
    res = (intermediate)./(rho + delta_in + lambda_god_in + (lambda_e_in*intermediate));
end
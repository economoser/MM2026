function fun_estimation_robustness_women(type_of_estimation)

    %==========================================================================
    % DESCRIPTION: This function estimates amenities with the ranks provided in the inputted file as robustness checks that can be used to generalize the routine
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - all_estimation_data_baseline_f.txt or all_estimation_data_hetdelta_f
    %
    % OUTPUTS:     - w_pi_f_X.txt, where X is the specific robustness experiment
    %
    % NOTES:       - The algorithm returns productivity minus the cost of amenities, that must be separately estimated
    %              - Type of experiment can be:
    %                 --- baseline
    %                 --- hetdelta
    %                 --- UScase
    %                 --- rob_amenity_share_006
    %                 --- rob_amenity_share_004
    %                 --- rob_amenity_share_012
    %                 --- rob_amenity_share_016
    %
    % DATE:        November 4, 2025
    %==========================================================================
    
    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');
    
    % print status
    fprintf('RUNNING ESTIMATION FOR WOMEN: EXPERIMENT %s \n', type_of_estimation); %USING ETA_V and ETA_PI FROM MEN'S ESTIMATION

    % Convert the data from .txt to .mat, loads estimated economy-wide
    % parameters
    if strcmp(type_of_estimation,'rob_amenity_share_006') || strcmp(type_of_estimation,'rob_amenity_share_004') || strcmp(type_of_estimation,'rob_amenity_share_012') || strcmp(type_of_estimation,'rob_amenity_share_016')
        fun_import_data('all_estimation_data_baseline_f',type_of_estimation,DIR_TEMP); %this function converts the data from .txt format to .mat format
        load(sprintf('%s/common_parameters_baseline.mat',DIR_TEMP),'eta_v','eta_pi');
    else
        fun_import_data(sprintf('all_estimation_data_%s_f',type_of_estimation),type_of_estimation,DIR_TEMP); %this function converts the data from .txt format to .mat format
        load(sprintf('%s/common_parameters_%s.mat',DIR_TEMP,type_of_estimation),'eta_v','eta_pi');
    end

    % Load the data
    if strcmp(type_of_estimation,'rob_amenity_share_006') || strcmp(type_of_estimation,'rob_amenity_share_004') || strcmp(type_of_estimation,'rob_amenity_share_012') || strcmp(type_of_estimation,'rob_amenity_share_016')
        load(sprintf('%s/estimation_data_baseline.mat',DIR_TEMP),'empid','fe','rank','f','delta','lambda_e','lambda_g','lambda_u');
        delta_firm=fe.*0 + delta; %create constant delta_firm for consistency across datasets
    elseif strcmp(type_of_estimation,'hetdelta')
        load(sprintf('%s/estimation_data_hetdelta.mat',DIR_TEMP),'empid','fe','rank','f','delta_firm','delta','lambda_e','lambda_g','lambda_u');
    else
        load(sprintf('%s/estimation_data_%s.mat',DIR_TEMP,type_of_estimation),'empid','fe','rank','f','delta','lambda_e','lambda_g','lambda_u');
        delta_firm=fe.*0 + delta; %create constant delta_firm for consistency across datasets
    end

    % Select data with valid rank and hiring intensity
    selecdata=(not(isnan(rank)) & not(isnan(f)) & (f>0));
    fprintf('\nCurrent sample is %g observations. \n',sum(selecdata));

    % Restrict to selected sample
    empid=empid(selecdata);
    fe=fe(selecdata);
    rank=rank(selecdata);
    f=f(selecdata);
    delta_firm=delta_firm(selecdata);

    % Set target moments for outside loops
    laborshare=0.48; %excluding self-employed

    %load share of women from parameters
    load(sprintf('%s/economywide_parameters.mat',DIR_TEMP),'params');
    measure_women=params(24);
    alpha=params(4);

    if strcmp(type_of_estimation,'UScase')
        %override targets with US numbers
        laborshare=0.533; %US value, payroll compensation from Table 1 in Elsby, Hobjin and Sahin (2013) Brookings papers on economic activity
    end

    % Estimation algorithm
    % Takes as inputs wages (exp(fe)), ranks, hiring intensities, labor market transition rates,
    % exogenous parameters, the labor share, whether to estimate eta_v and the
    % remaining targets
    % Estimation hetdelta also takes delta_firm as input, the firm-specific
    % separation rates
    if strcmp(type_of_estimation,'hetdelta') % robustness: estimation with heterogeneous deltas
        [pi_x,p_composite,F] = fun_estimation_heterogeneous_delta(exp(fe),rank,f,delta_firm,delta,lambda_g,lambda_e,lambda_u,[measure_women; alpha],laborshare,eta_v,eta_pi);
    else
        [pi_x,p_composite,F] = fun_estimation(exp(fe),rank,f,delta,lambda_g,lambda_e,lambda_u,[measure_women; alpha],laborshare,eta_v,eta_pi);
    end

    % Save estimation results
    save(sprintf('%s/w_pi_f_%s_matlab_output.mat',DIR_TEMP,type_of_estimation),'empid','fe','rank','f','pi_x','p_composite','F','delta_firm');

    % Clear memory
    clear empid fe rank f pi_x p_composite F delta_firm eta_v eta_pi

    % Export data to Stata
    load(sprintf('%s/w_pi_f_%s_matlab_output.mat',DIR_TEMP,type_of_estimation),'empid','fe','rank','pi_x','p_composite','F','delta_firm');
    load(sprintf('%s/common_parameters_%s.mat',DIR_TEMP,type_of_estimation),'eta_v','eta_pi');
    pi_x=pi_x(:,1);
    pi_x(isnan(pi_x))=-100000;
    eta_v=eta_v*ones(size(empid));
    eta_pi=eta_pi*ones(size(empid));
    dlmwrite(sprintf('%s/w_pi_f_%s.txt',DIR_TEMP,type_of_estimation),[empid fe rank pi_x p_composite F delta_firm eta_v eta_pi],'delimiter','\t','precision',19);
end
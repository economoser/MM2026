function res = fun_import_data(dataname, type_of_estimation, location)

    %==========================================================================
    % DESCRIPTION: This helper function reads the .txt data created by Stata and
    %              saves it in MATLAB-readable format
    %
    % AUTHORS:     Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %
    % INPUTS:      - all_estimation_data.txt (created by MM_7_FIRM_PARAMETERS.do)
    %
    % OUTPUTS:     - estimation_data_X, where X varies depending on the specific type of estimation (can be = baseline, hetdelta, UScase)
    %
    % DATE:        November 4, 2025
    %==========================================================================

    % set directories
    if exist('paths.txt', 'file')
        replicationpaths = readlines('paths.txt');
        DIR_MAIN = replicationpaths(1);
        DIR_TEMP = replicationpaths(2);
    else
        fprintf('\nUSER ERROR: Directory not found.\n')
        exit
    end
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');

    % inputs
    if nargin < 1, dataname='all_estimation_data.txt'; end
    if nargin < 2, type_of_estimation='baseline'; end
    if nargin < 3, error('location of data unknown'); end
    %types of estimation: 'baseline', 'hetdelta', 'UScase'

    % load data
    data=importdata(sprintf('%s/%s.txt',location,dataname));
    idx=returncell(data.colheaders,'empid');  empid=data.data(:,idx);
    idx=returncell(data.colheaders,'fe');     fe=data.data(:,idx);
    idx=returncell(data.colheaders,'f');        f=data.data(:,idx);
    idx=returncell(data.colheaders,'rank');     rank=data.data(:,idx);
    idx=returncell(data.colheaders,'lambda_e'); datanow=data.data(:,idx); lambda_e=mean(datanow(not(isnan(datanow))));
    idx=returncell(data.colheaders,'lambda_g'); datanow=data.data(:,idx); lambda_g=mean(datanow(not(isnan(datanow))));
    idx=returncell(data.colheaders,'lambda_u'); datanow=data.data(:,idx); lambda_u=mean(datanow(not(isnan(datanow))));
    idx=returncell(data.colheaders,'delta');    datanow=data.data(:,idx); delta=mean(datanow(not(isnan(datanow))));
    if strcmp(type_of_estimation,'hetdelta')
        idx=returncell(data.colheaders,'delta_firm');    delta_firm=data.data(:,idx);
    end

    %for now, select all data
    selecdata=(1:numel(empid))';

    empid=empid(selecdata);
    fe=fe(selecdata);
    f=f(selecdata);
    rank=rank(selecdata);
    if strcmp(type_of_estimation,'hetdelta'), delta_firm=delta_firm(selecdata); end

    fprintf('Successfully imported %g observations. \n',numel(fe));
    fprintf('Successfully imported labor market parameters. \n');

    if strcmp(type_of_estimation,'baseline') || strcmp(type_of_estimation,'UScase')
        save(sprintf('%s/estimation_data_%s.mat',location,type_of_estimation),'empid','lambda_e','lambda_g','lambda_u','delta','fe','f','rank');
    elseif strcmp(type_of_estimation,'hetdelta')
        save(sprintf('%s/estimation_data_%s.mat',location,type_of_estimation),'empid','lambda_e','lambda_g','lambda_u','delta','delta_firm','fe','f','rank');
    end
    fprintf('Written data to estimation_data_%s.mat \n',type_of_estimation);
    fprintf('Lambda_U is %g \n',lambda_u);
    fprintf('Lambda_G is %g \n',lambda_g);
    fprintf('Lambda_E is %g \n',lambda_e);
    fprintf('Delta is %g \n',delta);
    res = 'ImportData.success';
end


function res = returncell(incell, varnow)

    %==========================================================================
	% DESCRIPTION: This helper function returns the appropriate cell of the data.
	%
	% AUTHORS:     Iacopo Morchio (University of Bristol)
	%              Christian Moser (Columbia University)
	%
	% INPUTS:      - incell: cells passed to the function
	%              - varnow: the name of the variable to be returned
	%
	% OUTPUTS:     - res: the column of data to be returned
	%
	% DATE:        November 4, 2025
	%==========================================================================

    for k = 1:numel(incell)
        if strcmp(incell{k}, varnow) == 1
            res = k;
            return
        end
    end
    res = 0;
end
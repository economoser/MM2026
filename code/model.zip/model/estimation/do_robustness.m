fprintf('\n==============================================================')
fprintf('\nFILE NAME:   do_robustness.m')
fprintf('\n')
fprintf('\nDESCRIPTION: This script executes all robustness exercises')
fprintf('\n')
fprintf('\nAUTHORS:     Iacopo Morchio (University of Bristol)')
fprintf('\n             Christian Moser (Columbia University)')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n==============================================================')


fprintf('\n==============================================================')
fprintf('\n OPENING HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Clear memory\n')
clc
clear

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Assign folders\n')
if exist('paths.txt', 'file')
    replicationpaths = readlines('paths.txt');
    DIR_MAIN = replicationpaths(1);
    DIR_TEMP = replicationpaths(2);
else
    fprintf('\nUSER ERROR: Directory not found.\n')
    exit
end
    DIR_DO = fullfile(DIR_MAIN, 'code'); % code directory
        DIR_DO_MODEL = fullfile(DIR_DO, 'model'); % model-code directory
            DIR_DO_MODEL_ESTIMATION = fullfile(DIR_DO_MODEL, 'estimation'); % model-estimation-code directory
            addpath(DIR_DO_MODEL_ESTIMATION);
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % directory for log files
        FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_do_robustness.log']);
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');
clear DIR_DO DIR_DO_MODEL DIR_DO_MODEL_ESTIMATION STR_TIME_STAMP

fprintf('\n  --> Set random seed\n')
seed = 20250828;
rng(seed, 'twister')
clear seed

fprintf('\n  --> Start log file\n')
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n RUN ROBUSTNESS ANALYSIS')
fprintf('\n==============================================================')

fprintf('\n  --> Run estimation routines with different options\n')
fun_estimation_robustness_men('baseline');
fun_estimation_robustness_men('UScase');
fun_estimation_robustness_men('hetdelta');
fun_estimation_robustness_men('rob_amenity_share_004');
fun_estimation_robustness_men('rob_amenity_share_012');
fun_estimation_robustness_men('rob_amenity_share_016');

fun_estimation_robustness_women('baseline');
fun_estimation_robustness_women('UScase');
fun_estimation_robustness_women('hetdelta');
fun_estimation_robustness_women('rob_amenity_share_004');
fun_estimation_robustness_women('rob_amenity_share_012');
fun_estimation_robustness_women('rob_amenity_share_016');

fprintf('\n  --> Write empty file to tell Stata that MATLAB has finished\n')
writematrix(0, fullfile(DIR_TEMP, 'ihavefinished.txt'));
pause(1); % pause for a second to prevent Stata from accessing the file too early


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF do_robustness.m')
fprintf('\n==============================================================')

fprintf('\n  --> Close log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> Exit\n')
exit
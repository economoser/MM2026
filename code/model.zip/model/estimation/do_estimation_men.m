fprintf('\n==============================================================')
fprintf('\nFILE NAME:   do_estimation_men.m')
fprintf('\n')
fprintf('\nDESCRIPTION: This file estimates amenities for men with the ranks provided in the inputted file')
fprintf('\n')
fprintf('\nAUTHORS:     Iacopo Morchio (University of Bristol)')
fprintf('\n             Christian Moser (Columbia University)')
fprintf('\n')
fprintf('\nINPUTS:      - all_estimation_data_m.txt (created by MM_7_FIRM_PARAMETERS.do)')
fprintf('\n')
fprintf('\nOUTPUTS:     - w_pi.txt (file with amenities, firm identifiers and other data)')
fprintf('\n')
fprintf('\nNOTES:       - The algorithm returns productivity minus the cost of amenities, that must be separately estimated')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n==============================================================')


fprintf('\n==============================================================')
fprintf('\n INITIAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Clear memory\n')
clc
clear

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Assign folders\n')
if exist('paths.txt', 'file')
    replicationpaths = readlines('paths.txt');
    DIR_MAIN = replicationpaths(1);
    DIR_TEMP = replicationpaths(2);
else
    fprintf('\nUSER ERROR: Directory not found.\n')
    exit
end
    DIR_DO = fullfile(DIR_MAIN, 'code'); % code directory
        DIR_DO_MODEL = fullfile(DIR_DO, 'model'); % model-code directory
            DIR_DO_MODEL_ESTIMATION = fullfile(DIR_DO_MODEL, 'estimation'); % model-estimation-code directory
            addpath(DIR_DO_MODEL_ESTIMATION);
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % directory for log files
        FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_do_estimation_men.log']);
    DIR_INPUT = fullfile(DIR_TEMP, 'temp_matlab');
    DIR_RESULTS = fullfile(DIR_MAIN, 'results');
clear replicationpaths DIR_MAIN DIR_DO DIR_DO_MODEL DIR_DO_MODEL_ESTIMATION STR_TIME_STAMP

fprintf('\n  --> Set random seed\n')
seed = 20250828;
rng(seed, 'twister')
clear seed

fprintf('\n  --> Start log file\n')
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n RUNNING ESTIMATION FOR MEN')
fprintf('\n==============================================================')

fprintf('\n  --> Convert the data from .txt to .mat\n')
fun_import_data('all_estimation_data_m','baseline', DIR_TEMP);
eta_v_option=0; % tells the algorithm to estimate eta_v rather than imposing a specific value

fprintf('\n  --> Load the data\n')
load(sprintf('%s/estimation_data_baseline.mat', DIR_TEMP),'empid','fe','rank','f','delta','lambda_e','lambda_g','lambda_u');

fprintf('\n  --> Select data with valid rank and hiring intensity\n')
selectdata = (not(isnan(rank)) & not(isnan(f)) & (f > 0));   
fprintf('\nCurrent sample is %g observations. \n', sum(selectdata));

fprintf('\n  --> Restrict to selected sample\n')
empid=empid(selectdata);
fe=fe(selectdata);
rank=rank(selectdata);
f=f(selectdata);
clear selectdata

fprintf('\n  --> Set target moments for outside loops\n')
laborshare=0.48; %target for labor share
slope_logw_logp_moment=0.179; %beta of log w on log p, Source: Alvarez et al. (2018) p. 185 Appendix Table E.1 (balanced, no controls, 2004-2008)
share_pi_target = 0.08; %Target for the cost share of amenities;

fprintf('\n  --> Load share of men and alpha from parameters\n')
load(sprintf('%s/economywide_parameters.mat',DIR_TEMP),'params');
measure_men=params(25);
alpha=params(4);
rho=params(8);

fprintf('\n  --> Estimation algorithm\n')
% Takes as inputs wages (exp(fe)), ranks, hiring intensities, labor market transition rates,
% exogenous parameters, the labor share, whether to estimate eta_v and the
% remaining targets
[pi_x,p_composite,F,eta_v,eta_pi]=fun_estimation(exp(fe),rank,f,delta,lambda_g,lambda_e,lambda_u,[measure_men; alpha],laborshare,eta_v_option,0,slope_logw_logp_moment,share_pi_target,true);
clear alpha eta_v_option

fprintf('\n  --> Save estimation results and economy-wide parameters\n')
save(sprintf('%s/w_pi_matlab_output.mat',DIR_TEMP),'empid','fe','rank','f','pi_x','p_composite','F');
save(sprintf('%s/common_parameters.mat',DIR_TEMP),'eta_v','eta_pi');
clear f

fprintf('\n  --> Export flow value of outside option of men b_m using helper function\n')
b_m=fun_calculate_b(exp(fe)+pi_x,F,delta,lambda_u,lambda_e,lambda_g,rho);
clear delta

fprintf('\n  --> Export data to Stata\n')
clear empid fe rank pi_x p_composite F
load(sprintf('%s/w_pi_matlab_output.mat',DIR_TEMP),'empid','fe','rank','pi_x','p_composite','F');
load(sprintf('%s/common_parameters.mat',DIR_TEMP),'eta_v','eta_pi');
pi_x=pi_x(:,1);
pi_x(isnan(pi_x))=-100000;
eta_v=eta_v*ones(size(empid));
eta_pi=eta_pi*ones(size(empid));
b_m=b_m*ones(size(empid));
dlmwrite(sprintf('%s/w_pi.txt',DIR_TEMP),[empid fe rank pi_x p_composite F eta_v eta_pi b_m],'delimiter','\t','precision',19);
clear empid fe rank pi_x p_composite F eta_v eta_pi b_m

fprintf('\n  --> Write empty file to tell Stata that MATLAB has finished\n')
writematrix(0, fullfile(DIR_TEMP, 'ihavefinished.txt'));
pause(1); % pause for one second or Stata will attempt to overwrite file too quickly
clear DIR_TEMP


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF do_estimation_men.m')
fprintf('\n==============================================================')

fprintf('\n  --> Close log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> Exit\n')
exit
********************************************************************************
* FILE NAME:   MM_14_ANALYSIS_DATA.do
*
* DESCRIPTION: Conducts additional analyses of the data
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_14_ANALYSIS_DATA"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 15

* set random-number stream
clear rngstream
set rngstream 14

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** switches for which parts to run
global run_analysis_data_part_1 = 1 // run code for data analysis part 1
global run_analysis_data_part_2 = 1 // run code for data analysis part 2
global run_analysis_data_part_3 = 1 // run code for data analysis part 3
global run_analysis_data_part_4 = 1 // run code for data analysis part 4


*** data analysis part 1
if $run_analysis_data_part_1 {
	
	
	*** additional model fit statistics based on the data
	* define macros
	global frequency = "monthly" // frequency of data used to compute statistics ("monthly" or "annual")
	global n_lags = 1 // number of months of lag to use when computing wage changes
	
	* loop over genders to compute the same statistics in the data
	forval g = 1/2 {
		
		* define macros
		if `g' == 1 {
			local g_str = "m"
			local g_str_long = "men"
		}
		else if `g' == 2 {
			local g_str = "f"
			local g_str_long = "women"
		}
		
		* load data
		if "${frequency}" == "annual" local var_date = "year"
		else if "${frequency}" == "monthly" local var_date = "date"
		else {
			di as error "USER ERROR: Must select global macro frequency as either annual or monthly."
			error 1
		}
		use ///
			id_pers `var_date' id_emp gender ///
			if gender == `g' & mod(id_pers, 1) == 0 ///
			using "${DIR_TEMP}/selection_${frequency}.dta", clear // note: could contemplate using an even larger file here (e.g., including all firms), but would need rank measures for them!
		rename `var_date' date
		
		* merge in post-estimation results incl. firm-gender pay FEs and firm ranks
		merge m:1 id_emp using "${DIR_TEMP}/post_est.dta", keepusing(log_w_`g_str' rank_`g_str') keep(match) nogen
		rename log_w_`g_str' w
		rename rank_`g_str' rank
		
		* drop variables that are no longer needed
		drop gender
		
		* set panel
		xtset id_pers date
		
		* compute probability of E-to-E transition
		gen byte EE = (id_emp != L${n_lags}.id_emp) if L${n_lags}.id_emp < .
		lab var EE "Ind: Made an E-to-E transition?"
		
		* compute wage changes upon E-to-E transition
		gen float w_change = w - L${n_lags}.w if EE == 1
		lab var w_change "Wage change upon E-to-E transition"
		
		* compute rank changes upon E-to-E transition
		gen float rank_change = rank - L${n_lags}.rank if EE == 1
		lab var rank_change "Rank change upon E-to-E transition"
		
		* collapse to grid
		foreach var of varlist w_change rank_change {
			preserve
			local grid_min = -1 // minimum point of grid
			local grid_max = 1 // maximum point of grid
			local N_grid_points = 100 // number of grid points between `grid_min' and `grid_max'
			egen int `var'_bin = cut(`var'), at(`grid_min'(`= (`grid_max' - `grid_min')/(`N_grid_points' - 2)')`grid_max')
			replace `var'_bin = `var'_bin + (`grid_max' - `grid_min')/(2*(`N_grid_points' - 2))
			replace `var'_bin = -1 if `var' < 0 & `var'_bin == .
			replace `var'_bin = 1 if `var' > 0 & `var' < . & `var'_bin == .
			keep if `var'_bin < .
			${gtools}collapse ///
				(count) dens_`var'_`g_str'=id_pers ///
				, ///
				by(`var'_bin) fast
			rename `var'_bin `var'
			if "`var'" == "w_change" local var_str = "wage"
			else if "`var'" == "rank_change" local var_str = "rank"
			local var_str_proper = proper("`var_str'")
			lab var dens_`var'_`g_str' "Density of `var_str' changes for `g_str_long'"
			lab var `var' "`var_str_proper' change upon E-to-E transition"
			sort `var'
			gen int id = _n
			lab var id "Sorting variable"
			order id `var' dens_`var'_`g_str'
			sort id
			prog_comp_desc_sum_save "${DIR_TEMP}/`var'_`g_str'.dta"
			restore
		}
		local grid_min = 0 // minimum point of grid
		local grid_max = 1 // maximum point of grid
		local N_grid_points = 100 // number of grid points between `grid_min' and `grid_max'
		egen int rank_bin = cut(rank), at(`grid_min'(`= (`grid_max' - `grid_min')/`N_grid_points'')`grid_max')
		replace rank_bin = rank_bin + (`grid_max' - `grid_min')/(2*`N_grid_points')
		if `g' == 1 local g_str = "m"
		else if `g' == 2 local g_str = "f"
		keep if rank_bin < .
		${gtools}collapse ///
			(mean) prob_ee_`g_str'=EE ///
			, ///
			by(rank_bin) fast
		rename rank_bin rank
		if `g' == 1 local g_str_long = "men"
		else if `g' == 2 local g_str_long = "women"
		lab var prob_ee_`g_str' "Probability of E-to-E transition for `g_str_long'"
		lab var rank "Employer rank"
		sort rank
		gen int id = _n
		lab var id "Sorting variable"
		order id rank prob_ee_`g_str'
		sort id
		prog_comp_desc_sum_save "${DIR_TEMP}/prob_ee_`g_str'_data.dta"
	}
	
	* plot data distributions
	foreach var in w_change rank_change {
		use "${DIR_TEMP}/`var'_m.dta", clear
		merge 1:1 id using "${DIR_TEMP}/`var'_f.dta", keepusing(dens_`var'_f) keep(master match) nogen
		sort `var'
		gen float dx = .
		replace dx = `var'[2] - `var'[1] if _n == 1
		replace dx = `var'[_n] - `var'[_n - 1] if _n > 1
		lab var dx "Change in variable between grid points"
		foreach g in m f {
			gen float dx_times_dens_`var'_`g' = dx*dens_`var'_`g'
			lab var dx_times_dens_`var'_`g' "Integral of the probability density function at each grid point"
			qui sum dx_times_dens_`var'_`g'
			replace dens_`var'_`g' = dens_`var'_`g'/r(sum)
		}
		foreach g in m f {
			sum `var' [aw=dens_`var'_`g'], meanonly
			local `var'_mean_`g' = r(mean)
		}
		if "`var'" == "w_change" {
			local yl = "0(.5)3.5"
			local yf = "format(%2.1f)"
		}
		else if "`var'" == "rank_change" {
			local yl = "0(1)8"
			local yf = "format(%1.0f)"
		}
		tw ///
			(line dens_`var'_m `var', lcolor(blue) lpattern(l) xline(``var'_mean_m', lcolor(blue) lpattern(l))) ///
			(line dens_`var'_f `var', lcolor(red) lpattern(_) xline(``var'_mean_f', lcolor(red) lpattern(_))) ///
			, ///
			xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ylabel(`yl', `yf' gmin gmax grid gstyle(dot)) ///
			xtitle("Wage change upon E-to-E transition") ytitle("Density") ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "Men" 2 "Women") symxsize(*.66) region(color(none)) cols(2) ring(0) pos(11)) ///
			name(dens_`var'_data_${n_lags}, replace)
	}
	
	
	*** additional model vs. data fit
	* plot model vs. data distributions of firm pay and firm size
	use ///
		id_emp ///
		using "${DIR_TEMP}/selection_annual.dta", clear
	merge m:1 id_emp using "${DIR_TEMP}/post_est.dta", keepusing(log_w_m log_w_f size_m model_size_m size_f model_size_f) keep(match) nogen
	rename log_w_m w_m
	rename log_w_f w_f
	rename model_size_m size_m_model
	rename model_size_f size_f_model
	rename size_m size_m_data
	rename size_f size_f_data
	${gtools}collapse ///
		(firstnm) w_m w_f size_m_data size_m_model size_f_data size_f_model ///
		, ///
		by(id_emp) fast
	foreach var of varlist size_m_data size_f_data size_m_model size_f_model {
		gen float ln_`var' = ln(`var')
	}
	foreach var in ln_size_m ln_size_f {
		sum `var'_data, meanonly
		local mean_data = r(mean)
		sum `var'_model, meanonly
		local mean_model = r(mean)
		replace `var'_model = `var'_model - `mean_model' + `mean_data'
	}
	tw ///
		(kdensity w_m [aw=size_m_data], lcolor(blue) lpattern(l) lwidth(thick)) ///
		(kdensity w_m [aw=size_m_model], lcolor(blue) lpattern(-) lwidth(thick)) ///
		(kdensity w_f [aw=size_f_data], lcolor(red) lpattern(l) lwidth(thick)) ///
		(kdensity w_f [aw=size_f_model], lcolor(red) lpattern(-) lwidth(thick)) ///
		, ///
		xlabel(-.4(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ylabel(0(.5)3.0, format(%2.1f) gmin gmax grid gstyle(dot)) ///
		xtitle("Firm pay") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men (data)" 2 "Men (model)" 3 "Women (data)" 4 "Women (model)") symxsize(*.25) region(color(none)) cols(2) ring(0) pos(1)) ///
		name(fit_pay, replace)
	qui graph export "${DIR_RES_FIG}/fig_fit_pay.eps", replace
	tw ///
		(kdensity ln_size_m_data, lcolor(blue) lpattern(l) lwidth(thick)) ///
		(kdensity ln_size_m_model, lcolor(blue) lpattern(-) lwidth(thick)) ///
		(kdensity ln_size_f_data, lcolor(red) lpattern(l) lwidth(thick)) ///
		(kdensity ln_size_f_model, lcolor(red) lpattern(-) lwidth(thick)) ///
		, ///
		xlabel(2(2)14, format(%2.0f) gmin gmax grid gstyle(dot)) ylabel(0(.1).6, format(%2.1f) gmin gmax grid gstyle(dot)) ///
		xtitle("Employer size") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men (data)" 2 "Men (model)" 3 "Women (data)" 4 "Women (model)") symxsize(*.25) region(color(none)) cols(2) ring(0) pos(1)) ///
		name(fit_size, replace)
	qui graph export "${DIR_RES_FIG}/fig_fit_size.eps", replace
	
	
	*** correlation between firm rankings of different worker subgroups
	* generate mini-dataset containing worker education
	prog_load_data $year_min $year_max "id_pers year gender edu parent age" // i.e., "year id_pers gender edu age id_est ind07_5 muni hours hours_year occ02_6 tenure exp_act earn_mean_mw month_hire month_sep id_unique"
	gen int yob = year - age
	lab var yob "Year of birth"
	drop year age
	${gtools}collapse ///
		(firstnm) gender edu parent yob ///
		, ///
		by(id_pers) fast
	lab var gender "Gender"
	lab var edu "Ind: More than high school?"
	recode edu (1/7=0) (8/9=1)
	lab def edu_l ///
		0 "0: At most high school" ///
		1 "1: More than high school" ///
		, replace
	lab val edu edu_l
	lab var parent "Ind: Ever parent?"
	lab var yob "Year of birth"
	recode yob (1968/2024=0) (1900/1967=1)
	lab def yob_l ///
		0 "0: Young cohorts (YOB >= 1968)" ///
		1 "1: Old cohorts (YOB <= 1967)" ///
		, replace
	lab val yob yob_l
	gen float rand = runiform(0,2)
	replace rand = min(floor(rand), 1)
	lab var rand "Random grouping"
	lab def rnd_l ///
		0 "0: Random group number 0" ///
		1 "1: Random group number 1" ///
		, replace
	lab val rand rnd_l
	order id_pers gender edu parent yob rand
	sort id_pers
	prog_comp_desc_sum_save "${DIR_TEMP}/demographics.dta"
	
	* define list of demographic groups
	global list_dem_vars = `" "gender" "gender edu" "gender parent" "gender yob" "'
	
	* loop through list of demographic groups to create dataset of firm ranks (sizes) by demographic group
	foreach dem_vars of global list_dem_vars {
		
		* load data
		use ///
			id_pers year id_emp ///
			using "${DIR_TEMP}/selection_annual.dta", clear
		
		* merge in demographics
		merge m:1 id_pers using "${DIR_TEMP}/demographics.dta", keepusing(`dem_vars') keep(match) nogen
		
		* define demographic groups
		${gtools}egen byte dem = group(`dem_vars')
		lab var dem "Demographic group (`dem_vars')"
		
		* cross-tabulate demographic variables
		tab `dem_vars'
		
		* generate one indicator per unique demographic-employer year
		bys dem id_emp year: gen long emp_year_unique = 1 if _n == 1
		lab var emp_year_unique "Ind: Unique demographics-employer-year?"
		drop year
		
		* collapse to demographic-employer level
		gen long ones = 1
		lab var ones "Indicator = 1"
		foreach var of global dem_vars {
			local l_`var': var label `var'
		}
		${gtools}collapse ///
			(firstnm) `dem_vars' ///
			(sum) n_emp_years=emp_year_unique ///
			(count) size=ones ///
			, ///
			by(id_emp dem) fast
		foreach var of global dem_vars {
			lab var `var' "`l_`var''"
		}
		
		* compute average employment
		replace size = size/n_emp_years
		lab var size "Avg employer size, based on annual data"
		drop n_emp_years
		
		* save
		local dem_vars_str = subinstr("`dem_vars'", " ", "_", .)
		order id_emp dem `dem_vars' size
		sort id_emp dem
		prog_comp_desc_sum_save "${DIR_TEMP}/size_annual_dem_`dem_vars_str'.dta"
	}
	
	* open postfile
	cap postutil clear
	postfile corr_dem ///
		str10 balance str13 dem str8 corr rho_g rho_m rho_f ///
		using "${DIR_TEMP}/postfile_corr_dem.dta", replace
	
	* loop through list of demographic groups to compute statistics of interest by demographic group
	global list_dem_vars = `" "gender" "gender edu" "gender parent" "gender yob" "'
	foreach dem_vars of global list_dem_vars {
		
		* create separate variables by demographic group
		local dem_vars_str = subinstr("`dem_vars'", " ", "_", .)
		use "${DIR_TEMP}/size_annual_dem_`dem_vars_str'.dta", clear
		${gtools}reshape wide size, i(id_emp `dem_vars') j(dem)
		foreach var of varlist size* {
			local var_name = subinstr("`var'", "size", "size_", .)
			bys id_emp (`var'): replace `var' = `var'[1]
			rename `var' `var_name'
		}
		bys id_emp: keep if _n == 1
		egen float size = rowtotal(size*)
		lab var size "Total size (weight)"
		drop `dem_vars'
		
		* compute correlations
		di "--> demographic variable(s): `dem_vars'"
		foreach b in balanced unbalanced {
			preserve
			if "`b'" == "balanced" {
				foreach var of varlist size_* {
					drop if `var' == .
				}
			}
			foreach corr in corr spearman {
				if "`corr'" == "corr" local w = "[aw=size]"
				else if "`corr'" == "spearman" local w = ""
				`corr' size_* `w'
				if "`dem_vars'" == "gender" {
					`corr' size_1 size_2 `w'
					local rho_g = r(rho)
					post corr_dem ("`b'") ("`dem_vars'") ("`corr'") (`rho_g') (.) (.)
				}
				else if inlist("`dem_vars'", "gender edu", "gender parent", "gender yob") {
					local dem_subvar = subinstr("`dem_vars'", "gender ", "", .)
					`corr' size_1 size_2 `w'
					local rho_m_`dem_subvar' = r(rho)
					`corr' size_3 size_4 `w'
					local rho_f_`dem_subvar' = r(rho)
					post corr_dem ("`b'") ("`dem_vars'") ("`corr'") (.) (`rho_m_`dem_subvar'') (`rho_f_`dem_subvar'')
				}
			}
			restore
		}

		* create ranks
		foreach var of varlist size* {
			${gtools}egen rank_`var' = rank(`var') [aw=`var']
			sum rank_`var', meanonly
			replace rank_`var' = (rank_`var' - r(min))/(r(max) - r(min))
		}

		* plot ranks of one subgroup against that of another
		if "`dem_vars'" == "gender" {
			binscatter rank_size_2 rank_size_1 [aw=size_2], ///
				n(20) mcolor(blue) msymbol(O) lcolor(red) ///
				xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ///
				xtitle("Employer rank, women") ytitle("Employer rank, men") ///
				graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
				legend(off) ///
				name(dem_rank_g, replace) // binscatter of firm ranks across dem groups for men
			qui graph export "${DIR_RES_FIG}/fig_corr_dem_rank_g.eps", replace
		}
		else {
			binscatter rank_size_2 rank_size_1 [aw=size_2], ///
				n(20) mcolor(blue) msymbol(O) lcolor(red) ///
				xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ///
				xtitle("Employer rank, subgroup 1") ytitle("Employer rank, subgroup 2") ///
				graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
				legend(off) ///
				name(dem_rank_`dem_vars_str'_m, replace) // binscatter of firm ranks across dem groups for men
			qui graph export "${DIR_RES_FIG}/fig_corr_dem_rank_`dem_vars_str'_m.eps", replace
			binscatter rank_size_4 rank_size_3 [aw=size_4], ///
				n(20) mcolor(blue) msymbol(O) lcolor(red) ///
				xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ///
				xtitle("Employer rank, subgroup 1") ytitle("Employer rank, subgroup 2") ///
				graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
				legend(off) ///
				name(dem_rank_`dem_vars_str'_f, replace) // binscatter of firm ranks across dem groups for women
			qui graph export "${DIR_RES_FIG}/fig_corr_dem_rank_`dem_vars_str'_f.eps", replace
		}
	}
	postclose corr_dem
	
	* format postfile
	use "${DIR_TEMP}/postfile_corr_dem.dta", clear
	lab var balance "Require all demographics represented at each firm"
	lab var dem "Demographic variables"
	lab var corr "Correlation type (Pearson or Spearman Rank)"
	lab var rho_g "Correlation coefficient across genders"
	lab var rho_m "Correlation coefficient, men"
	lab var rho_f "Correlation coefficient, women"
	order balance dem corr rho_g rho_m rho_f
	sort balance dem corr
	prog_comp_desc_sum_save "${DIR_TEMP}/postfile_corr_dem.dta"
}


*** data analysis part 2
if $run_analysis_data_part_2 {


	*** comparison between alternative firm rank measures
	* load data
	use ///
		id_emp gender size rank_size pagerank rank_pagerank poaching rank_poaching ///
		using "${DIR_TEMP}/ranks.dta", clear
	
	* merge in firm-level observables
	merge m:1 id_emp using "${DIR_TEMP}/id_emp_ind.dta", keepusing(ind_2 ind) keep(master match) nogen
	merge m:1 id_emp using "${DIR_TEMP}/covariates_g1.dta", keepusing(muni) keep(master match) nogen // note: since muni is not gender-specific, it does not matter which file ("_g1" or "_g2") we merge with
	merge m:1 id_emp using "${DIR_TEMP}/covariates_g2.dta", keepusing(muni) keep(master match match_update match_conflict) update nogen // note: since muni is not gender-specific, it does not matter which file ("_g1" or "_g2") we merge with
	
	* compute weighted Spearman rank correlations between employer rank measures
	foreach var of varlist rank_pagerank rank_poaching { //
		forval g = 1/2 {
			if `g' == 1 local g_str = "Men"
			else if `g' == 2 local g_str = "Women"
			qui corr rank_size `var' [aw = size] if gender == `g'
			local var_str = subinstr("`var'", "rank_", "", .)
			local corr_size_`var_str' = r(rho)
			local corr_size_`var_str'_str: di %4.3f `corr_size_`var_str''
			di "Corr(size, `var_str') for `g_str' = `corr_size_`var_str'_str'"
			file open corr_size_`var_str' using "${DIR_RES_TXT}/txt_corr_size_`var_str'.tex", write replace
			file write corr_size_`var_str' "`corr_size_`var_str'_str'"
			file close corr_size_`var_str'
		}
	}
	
	* collapse to industry level
	${gtools}collapse ///
		(mean) rank_* ///
		(rawsum) size ///
		[aw=size] ///
		, ///
		by(ind_2 gender) fast
	
	* generate log industry size
	gen float log_size = ln(size)
	lab var log_size "Log industry size"
	
	* compare different ranks by industry
	forval g = 1/2 {
		if `g' == 1 {
			local g_str = "men"
			local color = "blue"
		}
		else if `g' == 2 {
			local g_str = "women"
			local color = "red"
		}
		foreach rank_measure in pagerank poaching {
			if "`rank_measure'" == "pagerank" local rank_measure_str = "PageRank"
			else if "`rank_measure'" == "poaching" local rank_measure_str = "poaching rank"
			egen clock = mlabvpos(rank_size rank_`rank_measure') if gender == `g'
			tw ///
				(scatter rank_`rank_measure' rank_size [aw=size] if gender == `g', msymbol(Oh) mcolor(`color')) ///
				(scatter rank_`rank_measure' rank_size [aw=size] if gender == `g', mlabel(ind_2) mlabvpos(clock) msymbol(none) mlabcolor(black)) ///
				(lfit rank_`rank_measure' rank_size [aw=size] if gender == `g', lcolor(`color') lpattern(_) lwidth(thick)) ///
				, ///
				xtitle("Mean employer size rank, `g_str'") ytitle("Mean `rank_measure_str' rank, `g_str'") ///
				graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
				xlabel(.6(.1)1, format(%2.1f) gmin gmax grid gstyle(dot)) ylabel(.3(.1)1, format(%2.1f) gmin gmax grid gstyle(dot)) ///
				legend(off) ///
				name(compare_`rank_measure'_size_`g', replace)
			graph export "${DIR_RES_FIG}/compare_`rank_measure'_size_`g'.eps", replace
			drop clock
		}
	}
	

	*** model validation using external data on firm productivity
	* options
	local single_obs_per_firm = 4 // how to choose a single obseration per firm: 1 = choose first year in panel; 2 = choose first nonmissing year in panel; 3 = choose last year in panel; 4 = choose last nonmissing year in panel; 5 = compute mean of log variables of interest; 6 = compute log of mean variables of interest
	
	* simulate productivity data
	if !$sim_orbis {
		use ///
			empid_est year ///
			using "${FILE_ORBIS}", clear
		foreach var in ///
			operatingrevenueturnover ///
			plbeforetax ///
			plforperiodnetincome ///
			cashflow ///
			{
			gen float `var' = exp(runiform())
		}
		foreach var in ///
			numberofemployees ///
			{
			gen int `var' = round(exp(exp(runiform())))
		}
		lab var operatingrevenueturnover "Operating revenue or turnover (millions BRL)"
        lab var plbeforetax "P/L before tax (millions BRL)"
		lab var plforperiodnetincome "P/L for period or net income (millions BRL)"
        lab var cashflow "Cash flow (millions BRL)"
		lab var numberofemployees "Number of employees"
		compress
		save "${FILE_ORBIS_SIM}", replace
	}
	
	* load productivity data
	if $sim_orbis {
		use ///
			empid_est year operatingrevenueturnover plbeforetax plforperiodnetincome cashflow numberofemployees ///
			using "${FILE_ORBIS_SIM}", clear
	}
	else {
		use ///
			empid_est year operatingrevenueturnover plbeforetax plforperiodnetincome cashflow numberofemployees ///
			using "${FILE_ORBIS}", clear
	}

	* format productivity data
	rename empid_est id_emp
	rename operatingrevenueturnover revenue
	rename plbeforetax profits
	rename plforperiodnetincome net_income
	rename cashflow cash_flow
	rename numberofemployees emp
	
	* drop negative observations
	foreach var of varlist revenue profits net_income cash_flow emp {
		drop if `var' <= 0
	}

	* generate log variables per worker
	foreach var of varlist ///
		revenue profits net_income cash_flow ///
		{
		gen float log_`var'_pw_data = ln(`var'/emp)
		local l_`var': var label `var' 
		lab var log_`var'_pw_data "Log `l_`var'' per worker, data"
	}

	* keep only a single observation per firm
	if `single_obs_per_firm' == 1 {
		gen float rand = runiform()
		bys id_emp (year rand): keep if _n == 1
		drop year
		drop rand
	}
	else if `single_obs_per_firm' == 2 {
		sort id_emp year
		${gtools}collapse ///
			(firstnm) log_revenue_pw_data log_profits_pw_data log_net_income_pw_data log_cash_flow_pw_data ///
			, ///
			by(id_emp) fast
	}
	else if `single_obs_per_firm' == 3 {
		gen float rand = runiform()
		bys id_emp (year rand): keep if _n == _N
		drop year
		drop rand
	}
	else if `single_obs_per_firm' == 4 {
		gsort id_emp -year
		${gtools}collapse ///
			(firstnm) log_revenue_pw_data log_profits_pw_data log_net_income_pw_data log_cash_flow_pw_data ///
			, ///
			by(id_emp) fast
	}
	else if `single_obs_per_firm' == 5 {
		${gtools}collapse ///
			(mean) log_revenue_pw_data log_profits_pw_data log_net_income_pw_data log_cash_flow_pw_data ///
			, ///
			by(id_emp) fast
	}
	else if `single_obs_per_firm' == 6 {
		foreach var of varlist ///
			revenue profits net_income cash_flow ///
			{
			local l_`var': var label `var'
		}
		${gtools}collapse ///
			(mean) revenue profits net_income cash_flow emp ///
			, ///
			by(id_emp) fast
		foreach var of varlist ///
			revenue profits net_income cash_flow ///
			{
			gen float log_`var'_pw_data = ln(`var'/emp)
			lab var log_`var'_pw_data "Log `l_`var'' per worker, data"
		}
	}

	* save productivity data
	compress
	order id_emp log_revenue_pw_data log_profits_pw_data log_net_income_pw_data log_cash_flow_pw_data
	sort id_emp
	save "${DIR_TEMP}/orbis_bra.dta", replace

	* load model estimates
	use ///
		id_emp g_m g_f g log_p_m log_w_m log_w_f log_pi_m log_pi_f eta_pi log_size ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename log_p_m log_va_pw_model
	lab var log_va_pw_model "Log value added per worker, model"

	* merge in productivity data
	merge 1:1 id_emp using "${DIR_TEMP}/orbis_bra.dta" ///
		, ///
		keepusing(log_revenue_pw_data log_profits_pw_data log_net_income_pw_data log_cash_flow_pw_data) ///
		keep(master match) ///
		gen(has_orbis)

	* merge in industry data
	merge 1:1 id_emp using "${DIR_TEMP}/id_emp_ind.dta", keepusing(ind_2 ind) keep(master match) nogen
	
	* merge in municipality data
	merge 1:1 id_emp using "${DIR_TEMP}/id_emp_muni_state.dta", keepusing(muni) keep(master match) nogen

	* generate indicator for whether this firm can be matched to Orbis Historical data
	replace has_orbis = (has_orbis == 3) if has_orbis < .
	lab var has_orbis "Ind: Has Orbis Historical financial data?"
	lab def orb_l ///
		0 "0: Does not have Orbis Historical financial data" ///
		1 "1: Has Orbis Historical financial data" ///
		, replace
	lab val has_orbis orb_l
	tab has_orbis

	* compute shares of firms and employment that can be matched with Orbis
	qui count if has_orbis == 1
	local has_orbis_N = r(N)
	local has_orbis_N_str: di %6.0fc `has_orbis_N'
	di as result "Number of firms with Orbis Historical financial data = `has_orbis_N_str'"
	sum has_orbis, meanonly
	local has_orbis_mean_firms = r(mean)
	local has_orbis_mean_firms_str: di %4.3f `has_orbis_mean_firms'
	di as result "Share of firms with Orbis Historical financial data = `has_orbis_mean_firms_str'"
	sum has_orbis [aw=g], meanonly
	local has_orbis_mean_workers = r(mean)
	local has_orbis_mean_workers_str: di %4.3f `has_orbis_mean_workers'
	di as result "Share of workers with Orbis Historical financial data = `has_orbis_mean_workers_str'"
	forval o = 0/1 {
		qui sum log_size if has_orbis == `o', meanonly
		local log_size_orbis_`o' = r(mean)
	}
	local log_size_diff = (`log_size_orbis_1' - `log_size_orbis_0')*100
	local log_size_diff_str: di %3.1f `log_size_diff'
	di `log_size_diff_str'

	* generate gender-specific employment shares in each firm
	gen float m_share = g_m/(g_m + g_f)
	lab var m_share "Employment share of men, model"
	gen float f_share = g_f/(g_m + g_f)
	lab var f_share "Employment share of women, model"
	drop g_m g_f

	* generate mean wage per worker
	gen float log_w_mean = ln((m_share*exp(log_w_m) + f_share*exp(log_w_f)))
	lab var log_w_mean "Mean wage per worker"

	* generate amenity cost per worker
	gen float log_c_pi_mean = ln((m_share*exp(log_pi_m) + f_share*exp(log_pi_f))/eta_pi)
	lab var log_c_pi_mean "Mean amenity cost per worker"

	* generate profits per worker in the model by subtracting the mean expontentiated wages and amenity cost from productivity p
	gen float log_profits_pw_model = ln(exp(log_va_pw_model) - exp(log_w_mean) - exp(log_c_pi_mean))
	lab var log_profits_pw_model "Log profits per worker, model"
	drop m_share f_share
	
	* correlate model estimates of productivity to external productivity data
	foreach var of varlist ///
		log_revenue_pw_data log_profits_pw_data log_net_income_pw_data log_cash_flow_pw_data ///
		{
		local var_str = subinstr("`var'", "_data", "", .)
		local var_str = subinstr("`var_str'", "_", " ", .)
		local var_str_nolog = subinstr("`var_str'", "log ", "", .)
		local var_str_short = subinstr("`var_str_nolog'", " pw", "", .)
		local var_str_short = subinstr("`var_str_short'", " ", "_", .)
		di _newline(1)
		di as text "--> data variable: `var_str' (`var_str_short')"
		
		qui count if `var' < .
		local N_`var_str_short' = r(N)
		local N_`var_str_short'_str: di %5.0fc `N_`var_str_short''
		file open txt_financials_N using "${DIR_RES_TXT}/txt_financials_N_`var'.tex", write replace
		file write txt_financials_N "`N_`var_str_short'_str'"
		file close txt_financials_N
		
		qui corr `var' log_va_pw_model [aw=g]
		local corr_pearson_`var_str_short' = r(rho)
		local corr_pearson_`var_str_short'_str: di %4.3f `corr_pearson_`var_str_short''
		file open txt_financials_corr_pearson using "${DIR_RES_TXT}/txt_financials_corr_pearson_`var'.tex", write replace
		file write txt_financials_corr_pearson "`corr_pearson_`var_str_short'_str'"
		file close txt_financials_corr_pearson
		di as result "Pearson Corr(data `var_str', model log productivity) = `corr_pearson_`var_str_short'_str'"
		
		qui spearman `var' log_va_pw_model
		local corr_spearman_`var_str_short' = r(rho)
		local corr_spearman_`var_str_short'_str: di %4.3f `corr_spearman_`var_str_short''
		file open txt_financials_corr_spearman using "${DIR_RES_TXT}/txt_financials_corr_spearman_`var'.tex", write replace
		file write txt_financials_corr_spearman "`corr_spearman_`var_str_short'_str'"
		file close txt_financials_corr_spearman
		di as result "Spearman Rank Corr(data `var_str', model log productivity) = `corr_spearman_`var_str_short'_str'"
		
		cap reghdfe `var' c.log_va_pw_model [aw=g], noabsorb keepsingletons vce(cluster id_emp)
		
		local b_`var_str_short' = _b[c.log_va_pw_model]
		local b_`var_str_short'_str: di %4.3f `b_`var_str_short''
		file open txt_financials_b using "${DIR_RES_TXT}/txt_financials_b_`var'.tex", write replace
		file write txt_financials_b "`b_`var_str_short'_str'"
		file close txt_financials_b
		
		local se_`var_str_short' = _se[c.log_va_pw_model]
		local se_`var_str_short'_str: di %4.3f `se_`var_str_short''
		file open txt_financials_se using "${DIR_RES_TXT}/txt_financials_se_`var'.tex", write replace
		file write txt_financials_se "`se_`var_str_short'_str'"
		file close txt_financials_se
		
		local stars_`var_str_short' = ""
		if $show_stars {
			if abs(`b_`var_str_short'')/`se_`var_str_short'' >= ${sig_level_010} local stars_`var_str_short' = "*"
			if abs(`b_`var_str_short'')/`se_`var_str_short'' >= ${sig_level_005} local stars_`var_str_short' = "**"
			if abs(`b_`var_str_short'')/`se_`var_str_short'' >= ${sig_level_001} local stars_`var_str_short' = "***"
		}
		file open txt_financials_stars using "${DIR_RES_TXT}/txt_financials_stars_`var'.tex", write replace
		file write txt_financials_stars "`stars_`var_str_short'_str'"
		file close txt_financials_stars
		
		local r2_`var_str_short' = e(r2)
		local r2_`var_str_short'_str: di %4.3f `r2_`var_str_short''
		file open txt_financials_r2 using "${DIR_RES_TXT}/txt_financials_r2_`var'.tex", write replace
		file write txt_financials_r2 "`r2_`var_str_short'_str'"
		file close txt_financials_r2
		
		local reject_h0_`var_str_short' = (abs(`b_`var_str_short'' - 1)/`se_`var_str_short'' >= ${sig_level_005})
		if `reject_h0_`var_str_short'' local reject_h0_`var_str_short'_str = "Yes"
		else local reject_h0_`var_str_short'_str = "No"
		
		di as result "Elasticity of data `var_str_nolog' w.r.t. model productivity = `b_`var_str_short'_str' (se = `se_`var_str_short'_str', R^2 = `r2_`var_str_short'_str')"
		
		cap reghdfe `var' c.log_va_pw_model [aw=g], a(ind muni) keepsingletons vce(cluster id_emp)
		
		local b_`var_str_short'_absorb = _b[c.log_va_pw_model]
		local b_`var_str_short'_absorb_str: di %4.3f `b_`var_str_short'_absorb'
		file open txt_financials_b_absorb using "${DIR_RES_TXT}/txt_financials_b_`var'_absorb.tex", write replace
		file write txt_financials_b_absorb "`b_`var_str_short'_absorb_str'"
		file close txt_financials_b_absorb
		
		local se_`var_str_short'_absorb = _se[c.log_va_pw_model]
		local se_`var_str_short'_absorb_str: di %4.3f `se_`var_str_short'_absorb'
		file open txt_financials_se_absorb using "${DIR_RES_TXT}/txt_financials_se_`var'_absorb.tex", write replace
		file write txt_financials_se_absorb "`se_`var_str_short'_absorb_str'"
		file close txt_financials_se_absorb
		
		local stars_`var_str_short'_absorb = ""
		if $show_stars {
			if abs(`b_`var_str_short'_absorb')/`se_`var_str_short'_absorb' >= ${sig_level_010} local stars_`var_str_short'_absorb = "*"
			if abs(`b_`var_str_short'_absorb')/`se_`var_str_short'_absorb' >= ${sig_level_005} local stars_`var_str_short'_absorb = "**"
			if abs(`b_`var_str_short'_absorb')/`se_`var_str_short'_absorb' >= ${sig_level_001} local stars_`var_str_short'_absorb = "***"
		}
		file open txt_financials_stars_absorb using "${DIR_RES_TXT}/txt_financials_stars_`var'_absorb.tex", write replace
		file write txt_financials_stars_absorb "`stars_`var_str_short'_absorb'"
		file close txt_financials_stars_absorb
		
		local r2_`var_str_short'_absorb = e(r2)
		local r2_`var_str_short'_absorb_str: di %4.3f `r2_`var_str_short'_absorb'
		file open txt_financials_r2_absorb using "${DIR_RES_TXT}/txt_financials_r2_`var'_absorb.tex", write replace
		file write txt_financials_r2_absorb "`r2_`var_str_short'_absorb_str'"
		file close txt_financials_r2_absorb
		
		local r2_within_`var_str_short'_absorb = e(r2_within)
		local r2_within_`var_str_short'_absorb_str: di %4.3f `r2_within_`var_str_short'_absorb'
		file open txt_financials_r2_within_absorb using "${DIR_RES_TXT}/txt_financials_r2_`var'_absorb.tex", write replace
		file write txt_financials_r2_within_absorb "`r2_within_`var_str_short'_absorb_str'"
		file close txt_financials_r2_within_absorb
		
		local reject_h0_`var_str_short'_absorb = (abs(`b_`var_str_short'_absorb' - 1)/`se_`var_str_short'_absorb' >= ${sig_level_005})
		if `reject_h0_`var_str_short'_absorb' local reject_h0_`var_str_short'_absorb_str = "Yes"
		else local reject_h0_`var_str_short'_absorb_str = "No"
		
		di as result "Elasticity of data `var_str_nolog' w.r.t. model productivity = `b_`var_str_short'_absorb_str' (se = `se_`var_str_short'_absorb_str', R^2 = `r2_`var_str_short'_absorb_str')"
		
		if "`var'" == "log_revenue_pw_data" {
			local ylabel_str = "0(1)5"
			local yformat_str = "%1.0f"
			local ytitle_str = "Log revenue per worker, data"
		}
		else if "`var'" == "log_profits_pw_data" {
			local ylabel_str = "-2(1)3"
			local yformat_str = "%1.0f"
			local ytitle_str = "Log profits per worker, data"
		}
		else if "`var'" == "log_net_income_pw_data" {
			local ylabel_str = "-2(1)3"
			local yformat_str = "%1.0f"
			local ytitle_str = "Log net income per worker, data"
		}
		else if "`var'" == "log_cash_flow_pw_data" {
			local ylabel_str = "-2(1)3"
			local yformat_str = "%1.0f"
			local ytitle_str = "Log cash flow per worker, data"
		}
		binscatter `var' log_va_pw_model [aw=g] ///
			, ///
			n(20) mcolor(blue) msymbol(O) lcolor(red) ///
			xlabel(0(.5)2.5, format(%2.1f) gmin gmax grid gstyle(dot)) ylabel(`ylabel_str', format(`yformat_str') gmin gmax grid gstyle(dot)) ///
			xtitle("Log productivity, model") ytitle("`ytitle_str'") ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(off) ///
			name(`var', replace)
		qui graph export "${DIR_RES_FIG}/fig_financials_`var_str_short'.eps", replace
	}
	
	* create a shorter LaTeX table containing results for only our preferred measure of firm productivity
	cap macro drop file_financials_reg
	cap file close file_financials_reg
	file open file_financials_reg using "${DIR_RES_TAB}/tab_reg_productivity.tex", write replace
	file write file_financials_reg ///
		"\begin{tabular}{lcc}" _n ///
		" &  &  \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n /// 
		" & Coefficient & (std. err.) \tabularnewline" _n ///
		"\hline" _n ///
		"Revenue per worker & `b_revenue_str'`stars_revenue' & (`se_revenue_str') \tabularnewline" _n ///
		"\$R^{2}\$ & \hphantom{$-$}`r2_revenue_str'\hphantom{$***$} & \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_financials_reg
	
	* create a shorter LaTeX table containing results for only our preferred measure of firm productivity incl. controls for municipality and industry
	cap macro drop file_financials_reg_absorb
	cap file close file_financials_reg_absorb
	file open file_financials_reg_absorb using "${DIR_RES_TAB}/tab_reg_productivity_absorb.tex", write replace
	file write file_financials_reg_absorb ///
		"\begin{tabular}{lcc}" _n ///
		" &  &  \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n /// 
		" & Coefficient & (std. err.) \tabularnewline" _n ///
		"\hline" _n ///
		"Revenue per worker & `b_revenue_absorb_str'`stars_revenue' & (`se_revenue_absorb_str') \tabularnewline" _n ///
		"Industry and municipality FEs & Yes & \tabularnewline" _n ///
		"\$R^{2}\$ & \hphantom{$-$}`r2_revenue_absorb_str'\hphantom{$***$} & \tabularnewline" _n ///
		"Within-\$R^{2}\$ & \hphantom{$-$}`r2_within_revenue_absorb_str'\hphantom{$***$} & \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_financials_reg_absorb
	
	* create LaTeX table containing results across all measures of firm productivity
	cap macro drop file_financials_reg_long
	cap file close file_financials_reg_long
	file open file_financials_reg_long using "${DIR_RES_TAB}/tab_reg_productivity_long.tex", write replace
	file write file_financials_reg_long ///
		"\begin{tabular}{lcccc}" _n ///
		" &  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n /// 
		" & (1) & (2) & (3) & (4) \tabularnewline" _n ///
		" & Revenue p.w. & Profits p.w. & Net income p.w. & Cash flow p.w. \tabularnewline" _n ///
		"\hline" _n ///
		"Model productivity \$p\$ & `b_revenue_str'`stars_revenue' & `b_profits_str'`stars_profits' & `b_net_income_str'`stars_net_income' & `b_cash_flow_str'`stars_cash_flow' \tabularnewline" _n ///
		" & (`se_revenue_str') & (`se_profits_str') & (`se_net_income_str') & (`se_cash_flow_str') \tabularnewline" _n ///
		"\$R^{2}\$ & \hphantom{$-$}`r2_revenue_str'\hphantom{$***$} & \hphantom{$-$}`r2_profits_str'\hphantom{$***$} & \hphantom{$-$}`r2_net_income_str'\hphantom{$***$} & \hphantom{$-$}`r2_cash_flow_str'\hphantom{$***$} \tabularnewline" _n ///
		"Reject \$H_{0}: \eta = 1\$? & `reject_h0_revenue_str' & `reject_h0_profits_str' & `reject_h0_cash_flow_str' & `reject_h0_`var_str_short'_str' \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_financials_reg_long
	
	* create LaTeX table containing results across all measures of firm productivity incl. controls for municipality and industry
	cap macro drop file_financials_reg_absorb_long
	cap file close file_financials_reg_absorb_long
	file open file_financials_reg_absorb_long using "${DIR_RES_TAB}/tab_reg_productivity_absorb_long.tex", write replace
	file write file_financials_reg_absorb_long ///
		"\begin{tabular}{lcccc}" _n ///
		" &  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n /// 
		" & (1) & (2) & (3) & (4) \tabularnewline" _n ///
		" & Revenue p.w. & Profits p.w. & Net income p.w. & Cash flow p.w. \tabularnewline" _n ///
		"\hline" _n ///
		"Model productivity \$p\$ & `b_revenue_absorb_str'`stars_revenue' & `b_profits_absorb_str'`stars_profits' & `b_net_income_absorb_str'`stars_net_income' & `b_cash_flow_absorb_str'`stars_cash_flow' \tabularnewline" _n ///
		" & (`se_revenue_absorb_str') & (`se_profits_absorb_str') & (`se_net_income_absorb_str') & (`se_cash_flow_absorb_str') \tabularnewline" _n ///
		"Industry and municipality FEs & Yes & Yes & Yes & Yes \tabularnewline" _n ///
		"\$R^{2}\$ & \hphantom{$-$}`r2_revenue_absorb_str'\hphantom{$***$} & \hphantom{$-$}`r2_profits_absorb_str'\hphantom{$***$} & \hphantom{$-$}`r2_net_income_absorb_str'\hphantom{$***$} & \hphantom{$-$}`r2_cash_flow_absorb_str'\hphantom{$***$} \tabularnewline" _n ///
		"Reject \$H_{0}: \eta = 1\$? & `reject_h0_revenue_absorb_str' & `reject_h0_profits_absorb_str' & `reject_h0_net_income_absorb_str' & `reject_h0_cash_flow_absorb_str' \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_financials_reg_absorb_long
	
	
	*** binscatter plots of amenity covariates
	* load data
	forval g = 1/2 {
		if `g' == 1 {
			local g_str = "men"
			local g_str_short = "m"
		}
		else if `g' == 2 {
			local g_str = "women"
			local g_str_short = "f"
		}
		local vars_indep = "part_time hours_change parental_gen inc_change acc_work sep_fired sep_death size_est"
		
		use ///
			log_pi ///
			`vars_indep' ///
			ind muni ///
			id_emp ///
			weight ///
			using "${DIR_TEMP}/projections_g`g'.dta", clear
		
		* create binscatter plots
		foreach var of local vars_indep {
			if "`var'" == "part_time" {
				local var_str = "Part-time work incidence "
				local yticks = "0(.2)1"
				local yformat = "%2.1f"
			}
			else if "`var'" == "hours_change" {
				local var_str = "Working hours flexibility"
				local yticks = "-.1(.1).5"
				local yformat = "%2.1f"
			}
			else if "`var'" == "parental_gen" {
				local var_str = "Parental leave generosity"
				local yticks = ".4(.1)1"
				local yformat = "%2.1f"
			}
			else if "`var'" == "inc_change" {
				local var_str = "Income fluctuations"
				local yticks = "-.1(.1).2"
				local yformat = "%2.1f"
			}
			else if "`var'" == "acc_work" {
				local var_str = "Workplace hazards"
				local yticks = "-.2(.1).2"
				local yformat = "%2.1f"
			}
			else if "`var'" == "sep_fired" {
				local var_str = "Incidence of unjust firings"
				local yticks = "-1(.2)0"
				local yformat = "%2.1f"
			}
			else if "`var'" == "sep_death" {
				local var_str = "Incidence of workplace deaths"
				local yticks = "-.1(.1).3"
				local yformat = "%2.1f"
			}
			else if "`var'" == "size_est" {
				local var_str = "Employer size"
				local yticks = "0(.5)2"
				local yformat = "%2.1f"
			}
			binscatter `var' log_pi [aw=weight], ///			
				n(10) mcolor(blue) msymbol(O) lcolor(red) ///
				xlabel(-1(.2).6, format(%2.1f) gmin gmax grid gstyle(dot)) ylabel(`yticks', format(`yformat') gmin gmax grid gstyle(dot)) ///
				xtitle("Log amenity value, `g_str'") ytitle("`var_str'") ///
				graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
				legend(off) ///
				name(cov_pi_`var'_`g_str_short', replace)
			qui graph export "${DIR_RES_FIG}/fig_covariates_pi_`var'_`g_str_short'.eps", replace
		}
	}
	
}


*** data analysis part 3
if $run_analysis_data_part_3 {


	*** compute Mincerian gender gaps
	* load data
	use ///
		year id_emp gender inc age edu hours occ tenure exp_act ///
		using "${DIR_TEMP}/akm.dta", clear

	* take a 1-percent random sample
	keep if mod(_n, 100) == 0

	* merge in normalized employer FEs
	merge m:1 id_emp using "${DIR_TEMP}/post_est.dta", keepusing(log_w_m log_w_f) keep(master match) nogen
	gen float fe_emp = .
	replace fe_emp = log_w_m if gender == 1
	replace fe_emp = log_w_f if gender == 2
	lab var fe_emp "Predicted AKM employer FE (normalized)"
	drop log_w_m log_w_f

	* compute gender gap in firm pay
	foreach var of varlist inc fe_emp {
		sum `var' if gender == 1, meanonly
		local `var'_mean_m = r(mean)
		sum `var' if gender == 2, meanonly
		local `var'_mean_f = r(mean)
		local `var'_gap = ``var'_mean_m' - ``var'_mean_f'
		di as result "Gender gap in `var' == ``var'_gap'"
	}

	* open postfile
	cap postclose postfile_mincer
	postfile postfile_mincer str32 controls gap using "${DIR_TEMP}/postfile_mincer.dta", replace

	* run Mincerian regressions with and without controls
	local vars_absorb = ""
	foreach var of varlist gender age edu hours occ tenure exp_act {
		if "`var'" == "gender" {
			cap reghdfe inc ib2.gender, noabsorb keepsingletons
			local gap = _b[1.gender]
			local gap_str: di %4.3f `gap'
			di as result "Gender gap without controls = `gap_str'"
			post postfile_mincer ("") (`gap')
		}
		else {
			local vars_absorb = strtrim("`vars_absorb' `var'")
			cap reghdfe inc ib2.gender, a(`vars_absorb') keepsingletons
			local gap = _b[1.gender]
			local gap_str: di %4.3f `gap'
			di as result "Gender gap with controls (`vars_absorb') = `gap_str'"
			post postfile_mincer ("`vars_absorb'") (`gap')
		}
	}

	* close postfile
	postclose postfile_mincer

	* format postfile
	use "${DIR_TEMP}/postfile_mincer.dta", clear
	lab var controls "List of controls"
	lab var gap "(Conditional) Gender pay gap"
	format %4.3f gap
	prog_comp_desc_sum_save "${DIR_TEMP}/postfile_mincer.dta"
	
	
	*** firm-level heterogeneity in separation rates
	* binscatter of firm-level deltas by gender -- note: make sure that Iacopo's estimation routine is run before this part
	use "${DIR_TEMP}/firm_parameters_hetdelta_matchG_5_p_pi_z.dta", clear
	foreach g in m f {
		if "`g'" == "m" {
			local g_color = "blue"
			local g_str = "men"
		}
		else if "`g'" == "f" {
			local g_color = "red"
			local g_str = "women"
		}
		binscatter ///
			delta_firm_`g' rank_${baseline_rank}_`g' ///
			, ///
			n(10) ///
			mcolor(`g_color') lcolor(`g_color') ///
			xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ylabel(.025(.005).055, format(%4.3f) gmin gmax grid gstyle(dot)) ///
			xtitle("Employer rank, `g_str'") ytitle("Firm-level separation rate") ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(off) ///
			name(delta_firm_`g', replace)
		graph export "${DIR_RES_FIG}/fig_delta_firm_`g'.eps", replace
	}
}


*** data analysis part 4
if $run_analysis_data_part_4 {


	*** share of public sector employment across employer ranks
	* load data
	use ///
		id_emp ///
		log_pi* log_w_* log_x_* ///
		rank_* ///
		size_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* merge in industry codes
	merge m:1 id_emp using "${DIR_TEMP}/id_emp_public.dta", keepusing(public) keep(master match) nogen

	* collapse to rank quantiles using gender-specific employment weights, separately by gender
	foreach g in m f {
		preserve
		gquantiles rank_q = rank_`g' [aw=weight_`g'], xtile n(50)
		lab var rank_q "Gender-specific employer rank quantile"
		rename public public_`g'
		${gtools}collapse ///
			(mean) log_w_*`g' log_pi_*`g' log_x_*`g' public_`g' ///
			[aw=weight_`g'] ///
			, ///
			by(rank_q) fast
		save "${DIR_TEMP}/temp_rank_collapse_`g'.dta", replace
		restore
	}

	* merge files for both genders
	use "${DIR_TEMP}/temp_rank_collapse_m.dta", clear
	merge 1:1 rank_q ///
		using "${DIR_TEMP}/temp_rank_collapse_f.dta" ///
		, ///
		keepusing(*w_* *pi_* *x_* *public_*) keep(match) nogen

	* normalize variables in logs
	foreach var of varlist log* {
		sum rank_q, meanonly
		local rank_q_min = r(min)
		sum `var' if rank_q == `rank_q_min'
		local `var'_min = r(mean)
		replace `var' = `var' - ``var'_min'
	}

	* normalize ranks
	sum rank_q, meanonly
	replace rank_q = rank_q/r(max)

	* save data
	order rank_q log_w_m log_w_f log_pi_m log_pi_f log_x_m log_x_f public_m public_f
	sort rank_q

	* loop through genders
	foreach g in m f {
		if "`g'" == "m" {
			local lc = "blue%50"
			local xtitle = "Men's"
			local subscript = "M"
		}
		else if "`g'" == "f" {
			local lc = "red%50"
			local xtitle = "Women's"
			local subscript = "F"
		}
		tw ///
			(line public_`g' rank_q, lcolor(`lc') lpattern(solid) lwidth(thick)) ///
			, ///
			xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(dot)) ///
			xtitle("`xtitle' employer rank (r{subscript:`subscript'})") ytitle("Share of employment in public sector") ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(off) ///
			name(fig_public_share_ladder_`g', replace)
		graph export "${DIR_RES_FIG}/fig_public_share_ladder_`g'.eps", replace
	}
	
	
	*** model fit across sectors
	* find kappa by gender
	forval g = 1/2 {
		
		* load pre-estimation data
		use ///
			rank_concept gender kappa ///
			if gender == `g' ///
			using "${DIR_TEMP}/lab_params.dta", clear
		drop gender
		
		* keep only size as a rank concept
		keep if rank_concept == 5
		drop rank_concept
		
		* store kappa value in a local macro
		sum kappa, meanonly
		local kappa_g`g' = r(mean)
		
		* save kappa paramter by gender
		prog_comp_desc_sum_save "${DIR_TEMP}/kappa_rank_concept_5_g`g'.dta"
	}
	
	* load data
	use ///
		id_emp ///
		log_w_m log_w_f ///
		log_pi_m log_pi_f ///
		log_x_m log_x_f ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear
		
	* merge in industry codes
	merge 1:1 id_emp ///
		using "${DIR_TEMP}/id_emp_ind.dta" ///
		, ///
		keepusing(ind_2) keep(match) nogen
	rename ind_2 ind

	* generate ranks
	gen double r = runiform()
	foreach var in ///
		log_w_m log_w_f ///
		log_pi_m log_pi_f ///
		log_x_m log_x_f ///
		{
		local var_str = subinstr("`var'", "log_", "", .)
		sort `var' r
		gen float rank_`var_str' = _n/_N
		lab var rank_`var_str' "Employer rank in terms of `var_str'"
	}
	drop r

	* collapse to industry level using gender-specific employment weights, separately by gender
	foreach g in m f {
		preserve
		${gtools}collapse ///
			(mean) rank_*_`g' ///
			(rawsum) size_`g' ///
			[aw=size_`g'] ///
			, ///
			by(ind) fast
		save "${DIR_TEMP}/temp_ind_collapse_`g'.dta", replace
		restore
	}

	* merge files for both genders
	use "${DIR_TEMP}/temp_ind_collapse_m.dta", clear
	merge 1:1 ind ///
		using "${DIR_TEMP}/temp_ind_collapse_f.dta" ///
		, ///
		keepusing(rank_*f size_f) keep(match) nogen

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* save data
	order ind rank_x_m rank_x_f rank_w_m rank_w_f rank_pi_m rank_pi_f weight_m weight_f
	sort ind
	prog_comp_desc_sum_save "${DIR_TEMP}/ind_ranks.dta"
	
	* load post-estimation data
	use "${DIR_TEMP}/post_est.dta", clear
	
	* merge in kappa by gender
	gen float kappa_m = `kappa_g1'
	lab var kappa_m "Effective speed of climbing the job ladder, men"
	gen float kappa_f = `kappa_g2'
	lab var kappa_f "Effective speed of climbing the job ladder, women"
	
	* generate predicted G(x)
	foreach g in m f {
		gen double G_pred_`g' = F_`g'/(1 + kappa_`g'*(1 - F_`g'))
		lab var G_pred_`g' "Predicted cumulative employment distribution, `g'"
	}
	
	* generate predicted g(x)
	foreach g in m f {
		sort rank_`g'
		gen double g_pred_`g' = .
		replace g_pred_`g' = G_pred_`g' if _n == 1
		replace g_pred_`g' = G_pred_`g'[_n] - G_pred_`g'[_n - 1] if _n >= 2
		lab var g_pred_`g' "Predicted employment distribution, `g'"
	}
	
	* convert predicted g(x) to predicted size
	foreach g in m f {
		gen double factor_`g' = size_`g'/g_`g'
		sum factor_`g', meanonly
		local factor_`g' = r(mean)
		drop factor_`g'
		gen double size_pred_`g' = g_pred_`g'*`factor_`g''
		lab var size_pred_`g' "Predicted firm size, `g'"
	}
	
	* merge in industry data
	merge 1:1 id_emp using "${DIR_TEMP}/id_emp_ind.dta", keepusing(ind_2) keep(master match) nogen
	rename ind_2 ind
	
	* collapse to industry level using gender-specific employment weights, separately by gender
	foreach g in m f {
		preserve
		${gtools}collapse ///
			(mean) log_w_`g' ///
			(rawsum) g_`g' size_`g' g_pred_`g' size_pred_`g' ///
			[aw=g_pred_`g'] ///
			, ///
			by(ind) fast
		save "${DIR_TEMP}/temp_ind_collapse_`g'.dta", replace
		restore
	}
	
	* merge files for both genders
	use "${DIR_TEMP}/temp_ind_collapse_m.dta", clear
	merge 1:1 ind ///
		using "${DIR_TEMP}/temp_ind_collapse_f.dta" ///
		, ///
		keepusing(log_w_f g_f size_f g_pred_f size_pred_f) keep(match) nogen
	
	* generate log industry size
	gen float log_size_m = ln(size_m)
	lab var log_size_m "Log industry size, men"
	gen float log_size_f = ln(size_f)
	lab var log_size_f "Log industry size, women"
	
	* merge in files from post-estimation data
	merge 1:1 ind ///
		using "${DIR_TEMP}/ind_ranks.dta" ///
		, ///
		keepusing(rank_x_m rank_x_f) keep(master match) nogen
	
	* produce labels
	foreach g in m f {
		egen clock_`g' = mlabvpos(log_w_`g' log_size_`g')
	}
	replace clock_f = 12 if ind == 24
	
	* employer rank vs. pay rank
	foreach g in m f {
		if "`g'" == "m" {
			local g_str = "men"
			local msymbol = "Oh"
		}
		else if "`g'" == "f" {
			local g_str = "women"
			local msymbol = "Dh"
		}
		tw ///
			(scatter log_w_`g' log_size_`g' [aw=size_`g'], msymbol(`msymbol') mcolor(blue)) ///
			(scatter log_w_`g' log_size_`g' [aw=size_pred_`g'], msymbol(`msymbol') mcolor(red)) ///
			(scatter log_w_`g' log_size_`g' [aw=size_`g'], mlabel(ind) mlabvpos(clock_`g') msymbol(none) mlabcolor(black)) ///
			, ///
			xtitle("Log industry size, `g_str'") ytitle("Mean log pay, `g_str'") ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			xlabel(9(1)16, format(%2.0f) gmin gmax grid gstyle(dot)) ylabel(-.1(.1).6, format(%2.1f) gmin gmax grid gstyle(dot)) ///
			legend(order(2 "Model" 1 "Data") symxsize(*.66) region(color(none)) cols(2) ring(0) pos(1)) ///
			name(model_fit_w_size_`g', replace)
		graph export "${DIR_RES_FIG}/fig_model_fit_w_size_`g'.eps", replace
	}
}


*** final housekeeping
* clean up
if $clean_up {
	rm "${DIR_TEMP}/selection_monthly.dta"
	rm "${DIR_TEMP}/selection_annual.dta"
	rm "${DIR_TEMP}/demographics.dta"
	rm "${DIR_TEMP}/covariates_g1.dta"
	rm "${DIR_TEMP}/covariates_g2.dta"
	rm "${DIR_TEMP}/id_emp_muni_state.dta"
	rm "${DIR_TEMP}/projections_g1.dta"
	rm "${DIR_TEMP}/projections_g2.dta"
	rm "${DIR_TEMP}/akm.dta"
	rm "${DIR_TEMP}/ind_ranks.dta"
}

* turn timer off
timer off 15

* print final banner
di _newline(5)
timer list 15
local t = r(t15)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_14_ANALYSIS_DATA.do
********************************************************************************

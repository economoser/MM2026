fprintf('\n=================================================================')
fprintf('\nFILE NAME:   MM_AKM_KSS.m')
fprintf('\n')
fprintf('\nDESCRIPTION: Estimates KSS correction to AKM variance decomposition')
fprintf('\n')
fprintf('\nINPUTS:      Files in .csv format prepared in Stata:')
fprintf('\n             - a matrix "FILE_TEMP_PARAMS" with 13 columns or variables')
fprintf('\n             - a matrix "FILE_TEMP_INPUT" with 4-10 columns or variables ordered as:')
fprintf('\n               income, person ID, employer ID, year (and possibly')
fprintf('\n               age, education, hours, occupation, tenure, actual experience)')
fprintf('\n')
fprintf('\nOUTPUTS:     KSS correction to AKM variance/covariance components')
fprintf('\n')
fprintf('\nNOTES:       - Due to changes in ichol() command, requires')
fprintf('\n             MATLAB R2011a or later')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n=================================================================')


fprintf('\n==============================================================')
fprintf('\n INITIAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Clear memory\n')
clc
clear

fprintf('\n  --> Verify MATLAB version\n')
v = version;
v_old = (str2double(v(1:3)) < 9.1); % if MATLAB is older than version R2016b
if v_old
    fprintf('\nUSER WARNING: Implicit expansions require MATLAB R2016b or later version. Run slower routine instead.\n')
end
clear v

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Set directories\n')
if exist('paths.txt', 'file')
    READ_REPLICATION = readlines('paths.txt');
    DIR_MAIN = char(READ_REPLICATION(1));
    DIR_DO = fullfile(DIR_MAIN, 'code');
        DIR_DO_DATA = fullfile(DIR_DO, 'data');
        addpath(DIR_DO_DATA);
    DIR_TEMP = char(READ_REPLICATION(2));
else
    fprintf('\nUSER ERROR: Directories not found.\n')
    exit
end
% DIR_MAIN = ''; % note: this directory is automatically defined above
    DIR_DO = fullfile(DIR_MAIN, 'code');
        DIR_DO_DATA = fullfile(DIR_DO, 'data');
            DIR_DO_DATA_MATLAB_PCK = fullfile(DIR_DO_DATA, '_matlab_packages');
                DIR_DO_DATA_MATLAB_PCK_BGL = fullfile(DIR_DO_DATA_MATLAB_PCK, 'matlab_bgl');
                addpath(DIR_DO_DATA_MATLAB_PCK_BGL);
                DIR_DO_DATA_MATLAB_PCK_LOTW = fullfile(DIR_DO_DATA_MATLAB_PCK, 'LeaveOutTwoWay-3.02');
                addpath(DIR_DO_DATA_MATLAB_PCK_LOTW)
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % path to folder where log files should be saved
    FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_MM_AKM_KSS.log']);
% DIR_TEMP = ''; % note: this directory is automatically defined above
    FILE_TEMP_PARAMS = fullfile(DIR_TEMP, 'parameters_akm_kss.csv'); % path to file containing AKM parameters
    DIR_TEMP_PARALLEL = fullfile(DIR_TEMP, 'parallel'); % path where parallel job temp files are stored
    FILE_TEMP_INPUT = fullfile(DIR_TEMP, 'input_akm_kss.csv'); % name of input file with the following columns: income, person_ID, employer_ID, year (, age, etc.) -- note: make sure that this file is sorted by worker id and year (-xtset id year- in Stata)
    FILE_TEMP_OUTPUT = fullfile(DIR_TEMP, 'output_akm_kss.csv'); % name of output file
clear STR_TIME_STAMP READ_REPLICATION DIR_MAIN DIR_DO DIR_DO_DATA DIR_DO_DATA_MATLAB_PCK DIR_DO_DATA_MATLAB_PCK_BGL DIR_TEMP

fprintf('\n  --> Install routines\n')
cd(DIR_DO_DATA_MATLAB_PCK_LOTW)
path(path, 'codes'); % this contains the main LeaveOut routines
path(path, 'CMG'); % CMG package http://www.cs.cmu.edu/~jkoutis/cmg.html
[~, ~] = evalc('installCMG(1)'); % installs CMG routine (silently)
clear DIR_DO_DATA_MATLAB_PCK_LOTW

fprintf('\n  --> Set KSS parameters\n')
leave_out_level = 'matches'; % 'obs' or 'matches'
type_algorithm = 'JLA'; % 'exact' or 'JLA
simulations_JLA = 50; % default = 200
lincom_do = 0; % 0 or 1
Z_lincom = []; % matrix of observables to be used when projecting firm effects onto observables
labels_lincom = []; % vector of dimension rx1 that provides a label for each of the columns in Z_lincom

fprintf('\n  --> Set AKM parameters\n')
FILE_TEMP_PARAMS_OPEN = fopen(FILE_TEMP_PARAMS);
data_params = fscanf(FILE_TEMP_PARAMS_OPEN, '%f %f %f %f %f %f %f %f %f %f %f %f %f', [13 inf])';
fclose(FILE_TEMP_PARAMS_OPEN);
n_params = 1;
gender = data_params(:, n_params); % gender (1 = men; 2 = women)
fprintf('\n')
disp(['gender = ' num2str(gender)])
n_params = n_params + 1;
akm_age_poly_order = data_params(:, n_params); % age polynomial order (0 = no age controls; 1 = restricted profile of age indicators; 2 / 3 / etc. = include 2nd order term / 2nd and 3rd order terms / etc.)
fprintf('\n')
disp(['akm_age_poly_order = ' num2str(akm_age_poly_order)])
n_params = n_params + 1;
akm_age_flat_min = data_params(:, n_params); % minimum age for which income-age profile is restricted to be flat (only relevant if akm_age_poly_order == 1)
fprintf('\n')
disp(['akm_age_flat_min = ' num2str(akm_age_flat_min)])
n_params = n_params + 1;
akm_age_flat_max = data_params(:, n_params); % maximum age for which income-age profile is restricted to be flat (only relevant if akm_age_poly_order == 1)
fprintf('\n')
disp(['akm_age_flat_max = ' num2str(akm_age_flat_max)])
n_params = n_params + 1;
akm_age_norm = data_params(:, n_params); % normalization age
fprintf('\n')
disp(['akm_age_norm = ' num2str(akm_age_norm)])
n_params = n_params + 1;
age_min = data_params(:, n_params); % minimum age
fprintf('\n')
disp(['age_min = ' num2str(age_min)])
n_params = n_params + 1;
age_max = data_params(:, n_params); % maximum age
fprintf('\n')
disp(['age_max = ' num2str(age_max)])
n_params = n_params + 1;
akm_years = data_params(:, n_params); % year controls (0 = no; 1 = yes)
fprintf('\n')
disp(['akm_years = ' num2str(akm_years)])
n_params = n_params + 1;
akm_edu = data_params(:, n_params); % education interactions (0 = no; 1 = yes)
fprintf('\n')
disp(['akm_edu = ' num2str(akm_edu)])
n_params = n_params + 1;
akm_hours = data_params(:, n_params); % hours controls (0 = no; 1 = yes)
fprintf('\n')
disp(['akm_hours = ' num2str(akm_hours)])
n_params = n_params + 1;
akm_occ = data_params(:, n_params); % occupation controls (0 = no; 1 = yes)
fprintf('\n')
disp(['akm_occ = ' num2str(akm_occ)])
n_params = n_params + 1;
akm_tenure = data_params(:, n_params); % tenure controls (0 = no; 1 = yes)
fprintf('\n')
disp(['akm_tenure = ' num2str(akm_tenure)])
n_params = n_params + 1;
akm_exp_act = data_params(:, n_params); % actual experience controls (0 = no; 1 = yes)
fprintf('\n')
disp(['akm_exp_act = ' num2str(akm_exp_act)])
if akm_age_poly_order == 1 && (akm_age_flat_min >= akm_age_flat_max || (akm_age_flat_min >= age_max || akm_age_flat_max <= age_min))
    fprintf('\nUSER ERROR: Requested to estimate age effects (akm_age_poly_order = 1) but restricted-to-be-flat age region is too short or falls outside of selected age range.\n')
    exit
elseif akm_age_poly_order >= 2 && (akm_age_norm < age_min || akm_age_norm > age_max)
    fprintf('\nUSER ERROR: Requested to estimate higher-order age terms (akm_age_poly_order >= 2) but normalization age falls outside of selected age range.\n')
    exit
end
clear FILE_TEMP_PARAMS FILE_TEMP_PARAMS_OPEN age_min age_max data_params n_params

fprintf('\n  --> Set parallel environment\n')
delete(gcp('nocreate'))
c = parcluster('local');
mkdir(DIR_TEMP_PARALLEL)
c.JobStorageLocation = DIR_TEMP_PARALLEL; % recommended to avoid storing conflicting job information (see section "Running Multiple PCT Matlab Jobs" at https://docs.rcc.uchicago.edu/software/apps-and-envs/matlab/#running-multiple-pct-matlab-jobs)
nw = max(min(floor(c.NumWorkers/5), 5), 1); % number of available cores
parpool(c, nw, 'IdleTimeout', Inf); % all cores will be assigned to MATLAB
clear c nw

fprintf('\n  --> Set random-number seeds\n')
seed = 20250828;
rng(seed, 'twister') % set random-number seed on the client (main MATLAB session)
spmd
    s = RandStream('Threefry', 'Seed', seed); % apply the same seed to each worker (parallel MATLAB processes)
    s.Substream = spmdIndex; % assign each worker a different substream, where spmdIndex is the automatically defined worker index
    RandStream.setGlobalStream(s); % set random-number seed on each worker
end
clear seed s

fprintf('\n  --> Start log file\n')
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n LOAD DATA')
fprintf('\n==============================================================')

fprintf('\n  --> Read input data\n')
FILE_TEMP_INPUT_OPEN = fopen(FILE_TEMP_INPUT, 'r');
input_format = '%f %f %f %u'; % always load at least 4 variables: inc, id_pers, id_emp, year
input_n = 4;
if akm_age_poly_order
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if akm_edu
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if akm_hours
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if akm_occ
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if akm_tenure
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
if akm_exp_act
    input_format = [input_format, ' %u'];
    input_n = input_n + 1;
end
fprintf('\n')
disp(['number of variables in input data = ' int2str(input_n) ' (format = ' input_format ')']);
input_data = fscanf(FILE_TEMP_INPUT_OPEN, input_format, [input_n inf])';
fclose(FILE_TEMP_INPUT_OPEN);
inc = input_data(:, 1); % input data column 1: log income
id_pers = input_data(:, 2); % input data column 2: worker ID
id_emp = input_data(:, 3); % input data column 3: employer ID
year = input_data(:, 4); % input data column 4: year ID
any_controls = (akm_years | akm_age_poly_order | akm_edu | akm_hours | akm_occ | akm_tenure | akm_exp_act);
if any_controls
    col_counter = 4;
    if akm_age_poly_order
        col_counter = col_counter + 1;
        age = input_data(:, col_counter); % additional input data: age
    end
    if akm_edu
        col_counter = col_counter + 1;
        edu = input_data(:, col_counter); % additional input data: education
    end
    if akm_hours
        col_counter = col_counter + 1;
        hours = input_data(:, col_counter); % additional input data: hours
    end
    if akm_occ
        col_counter = col_counter + 1;
        occ = input_data(:, col_counter); % additional input data: occupation codes
    end
    if akm_tenure
        col_counter = col_counter + 1;
        tenure = input_data(:, col_counter); % additional input data: tenure length
    end
    if akm_exp_act
        col_counter = col_counter + 1;
        exp_act = input_data(:, col_counter); % additional input data: actual experience (or actual experience interacted with potential experience)
    end
end
clear FILE_TEMP_INPUT FILE_TEMP_INPUT_OPEN input_format input_n input_data col_counter

fprintf('\n  --> Summary statistics for log income\n')
disp(['mean(ln(income)) = ' num2str(mean(inc))])
disp(['sd(ln(income)) = ' num2str(std(inc))])
disp(['var(ln(income)) = ' num2str(var(inc))])

fprintf('\n  --> Descriptive statistics on complete dataset (already restricted to connected set)\n')
n_worker_years = length(inc);
fprintf('\n')
disp(['total number of worker-years = ' int2str(n_worker_years)]);
clear n_worker_years
n_workers_unique = length(unique(id_pers));
fprintf('\n')
disp(['number of unique workers = ' int2str(n_workers_unique)]);
clear n_workers_unique
n_employers_unique = length(unique(id_emp));
fprintf('\n')
disp(['number of unique employers = ' int2str(n_employers_unique)]);
clear n_employers_unique
if any_controls && akm_years
    n_years_unique = length(unique(year));
    fprintf('\n')
    disp(['number of unique years = ' int2str(n_years_unique)]);
    clear n_years_unique
end


fprintf('\n==============================================================')
fprintf('\n ESTIMATE AKM EQUATION')
fprintf('\n==============================================================')

fprintf('\n  --> Create unique indicators for workers, employers, years, ages, hours, occupations, tenure, and actual experience \n')
NT = length(inc); % total number of worker-years
[~, ~, id] = unique(id_pers);
clear id_pers
[~, ~, firmid] = unique(id_emp);
clear id_emp
if any_controls
    if akm_years
        [~, ~, year_unique_index] = unique(year);
        clear year
        T = max(year_unique_index); % number of unique elements in year = number of unique years
    end
    if akm_age_poly_order == 1
        age(age >= akm_age_flat_min & age <= akm_age_flat_max) = akm_age_flat_min; % Restrict income-age profile to be flat between ages akm_age_flat_min and akm_age_flat_max
        clear akm_age_flat_min akm_age_flat_max
        [~, ~, age_unique_index] = unique(age); % note: command -unique()- returns unique values of age -- note: column index (3rd assignment object) maps vector of unique entries (1st assignment object) into the original vector (argument of -unique()-)
        clear age
        N_Age = max(age_unique_index); % number of unique elements in age = number of unique ages
    end
    if akm_edu
        [~, ~, edu_unique_index] = unique(edu);
        clear edu
        N_Edu = max(edu_unique_index); % number of unique elements in edu = number of unique education levels
    end
    if akm_hours
        [~, ~, hours_unique_index] = unique(hours);
        clear hours
    end
    if akm_occ
        [~, ~, occ_unique_index] = unique(occ);
        clear occ
    end
    if akm_tenure
        [~, ~, tenure_unique_index] = unique(tenure);
        clear tenure
    end
    if akm_exp_act
        [~, ~, exp_act_unique_index] = unique(exp_act);
        clear exp_act
    end
end

if any_controls
    fprintf('\n  --> Create (education-specific) year indicators\n')
    if akm_years
        if akm_edu
            Y = sparse(1:NT, T*(edu_unique_index' - 1) + year_unique_index', 1);
            Y(:, T*(edu_unique_index' - 1) + 1) = []; % drop indicator for first year of every education group, or else collinear with worker effects. Dimension: NT x (T - 1)*N_Edu
        else
            Y = sparse(1:NT, year_unique_index', 1);
            Y = Y(:, 2:end); % drop indicator for first year, or else collinear with worker effects. Dimension: NT x (T - 1)
        end
        Y_len = size(Y, 2);
        clear year_unique_index T
    end

    fprintf('\n  --> Create age indicators or higher-order (2nd and up) terms\n')
    if akm_age_poly_order == 1
        if akm_edu
            A = sparse(1:NT, N_Age*(edu_unique_index' - 1) + age_unique_index', 1);
            A(:, N_Age*(edu_unique_index' - 1) + 1) = []; % drop indicator for first age of every education group, or else collinear with worker effects. Dimension: NT x (N_Age - 1)*N_Edu
        else
            A = sparse(1:NT, age_unique_index', 1);
            A = A(:, 2:end); % drop indicator for first age, or else collinear with worker effects. Dimension: NT x (N_Age - 1)
        end
        clear age_unique_index N_Age
        A_len = size(A, 2);
    elseif akm_age_poly_order >= 2
        age = (age - akm_age_norm)/akm_age_norm;  % rescale to avoid big numbers
        if akm_edu
            E = sparse(1:NT, edu_unique_index', 1);
            if v_old
                A = zeros(NT, N_Edu*(akm_age_poly_order - 1));            
                for n = 2:akm_age_poly_order
                    A(:, N_Edu*(n - 2) + 1:N_Edu*(n - 1)) = bsxfun(@times, E, age.^n);
                end
                A = sparse(A); % dimension: NT x (N_Age - 1)*N_Edu
            else
                A = repmat(E, 1, akm_age_poly_order - 1).*repmat(age, 1, N_Edu*(akm_age_poly_order - 1)).^kron((2:akm_age_poly_order), ones(1, N_Edu)); % dimension: NT x (N_Age - 1)*N_Edu
            end
            clear E age
        else
            if v_old
                A = zeros(NT, akm_age_poly_order - 1);
                for n = 2:akm_age_poly_order
                    A(:, n - 1) = age.^n;
                end
                A = sparse(A); % dimension: NT x (N_Age - 1)
            else
                A = sparse(age.^(2:akm_age_poly_order)); % dimension: NT x (N_Age - 1)
            end
            clear age
        end
        A_len = size(A, 2);
    end
    if akm_edu
        clear N_Edu
    end
    clear akm_age_norm v_old

    fprintf('\n  --> Create hours indicators\n')
    if akm_hours
        H = sparse(1:NT, hours_unique_index', 1);
        H = H(:, 2:end); % drop indicator for first hours level, or else collinear with worker effects. Dimension: NT x (N_H - 1)
        H_len = size(H, 2);
        clear hours_unique_index
    end

    fprintf('\n  --> Create occupation indicators\n')
    if akm_occ
        O = sparse(1:NT, occ_unique_index', 1);
        O = O(:, 2:end); % drop indicator for first occupation code, or else collinear with worker effects. Dimension: NT x (N_O - 1)
        O_len = size(O, 2);
        clear occ_unique_index
    end

    fprintf('\n  --> Create (education-specific) tenure indicators\n')
    if akm_tenure
        Ten = sparse(1:NT, tenure_unique_index', 1);
        Ten = Ten(:, 2:end); % drop indicator for first tenure level, or else collinear with worker effects. Dimension: NT x (N_Ten - 1)
        Ten_len = size(Ten, 2);
        clear tenure_unique_index
    end

    fprintf('\n  --> Create (education-specific) actual experience indicators\n')
    if akm_exp_act
        ExpA = sparse(1:NT, exp_act_unique_index', 1);
        ExpA = ExpA(:, 2:end); % drop indicator for first actual experience level, or else collinear with worker effects. Dimension: NT x (N_ExpA - 1)
        ExpA_len = size(ExpA, 2);
        clear exp_act_unique_index
    end

    fprintf('\n  --> Clear education index variable that is no longer needed\n')
    if akm_edu
        clear edu_unique_index
    end
    clear akm_edu
end

fprintf('\n  --> Generate design matrix (X) and Gramian matrix (X_prime*X)\n')
controls = [];
controls_len = 0; % = N + (J - 1)
if any_controls
    if akm_years
        controls = [controls, Y];
        controls_len = controls_len + Y_len;
        clear Y Y_len
    end
    if akm_age_poly_order >= 1
        controls = [controls, A];
        controls_len = controls_len + A_len;
        clear A A_len
    end
    if akm_hours
        controls = [controls, H];
        controls_len = controls_len + H_len;
        clear H H_len
    end
    if akm_occ
        controls = [controls, O];
        controls_len = controls_len + O_len;
        clear O O_len
    end
    if akm_tenure
        controls = [controls, Ten];
        controls_len = controls_len + Ten_len;
        clear Ten Ten_len
    end
    if akm_exp_act
        controls = [controls, ExpA];
        controls_len = controls_len + ExpA_len;
        clear ExpA ExpA_len
    end
    fprintf('\n')
    disp(['dimensions of the controls matrix (controls) = ' num2str(NT) 'x' num2str(controls_len)])
    clear NT
end
clear any_controls controls_len akm_years akm_age_poly_order akm_hours akm_occ akm_tenure akm_exp_act


fprintf('\n==============================================================')
fprintf('\n RUN KSS LEAVE-OUT PROCEDURE')
fprintf('\n==============================================================')

fprintf('\n  --> Produce leave-out estimates\n')
[~, ~, ~] = leave_out_KSS(inc, id, firmid, controls, gender, leave_out_level, type_algorithm, simulations_JLA, lincom_do, Z_lincom, labels_lincom, FILE_TEMP_OUTPUT);
clear inc id firmid controls gender leave_out_level type_algorithm simulations_JLA lincom_do Z_lincom labels_lincom FILE_TEMP_OUTPUT


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Close parallel pool\n')
delete(gcp('nocreate'))

fprintf('\n  --> Delete temporary folder with parallel job files\n')
rmdir(DIR_TEMP_PARALLEL, 's');
clear DIR_TEMP_PARALLEL

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF MM_AKM_KSS.m')
fprintf('\n==============================================================')

fprintf('\n  --> End log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary off

fprintf('\n  --> Exit\n')
exit
********************************************************************************
* FILE NAME:   MM_FUN_CONNECTED.do
*
* DESCRIPTION: Finds (weakly or strongly) (leave-one-out or regular) connected set of employers
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** check global macros and arguments
* make sure that passed arguments are defined
forval i = 1/6 {
	if "``i''" == "" {
		di as error "USER ERROR: Passed argument `i' is not defined."
		error 1
	}
}

* store passed arguments in local macros
local leave_one_out = `1'
local strongly = `2'
local var_date = "`3'"
local var_id_pers = "`4'"
local var_id_emp = "`5'"
local var_gender = "`6'"


*** prepare for connected-set routine
* rename variables
rename `var_date' date
rename `var_id_pers' id_pers
rename `var_id_emp' id_emp
rename `var_gender' gender

* save data
order date id_pers gender id_emp
prog_comp_desc_sum_save "${DIR_TEMP}/temp_fun_connected.dta"


*** find (weakly or strongly) (leave-one-out or regular) connected set in MATLAB
* loop over genders
forval g = 1/2 {
	di "--> gender = `g' (1 = men; 2 = women)" // Note: Could add more categories here -- e.g., parents vs. nonparents of each gender.
	
	di "* load data"
	if `g' == 1 keep if gender == `g'
	else {
		use ///
			if gender == `g' ///
			using "${DIR_TEMP}/temp_fun_connected.dta", clear
	}
	drop gender
	
	di "* create list of current and previous employer IDs"
	if `strongly' bys id_pers (date): gen double lag_id_emp = id_emp[_n - 1] if date[_n - 1] == date[_n] - 1 // for strongly connected set, use only E-to-E transitions.
	else bys id_pers (date): gen double lag_id_emp = id_emp[_n - 1] // for weakly connected set, use E-to-E and E-to-U-to-E transitions.
	lab var lag_id_emp "Lagged employer ID"
	keep if id_emp < . & lag_id_emp < . // i.e., drop observations only ever observed at one employer (when constructing weakly connected set), or observations never transitioning E-to-E (when constructing strongly connected set)
	keep if id_emp != lag_id_emp // i.e., drop stayers -- for constructing connected set, without loss of generality drop self-referrals
	bys id_emp lag_id_emp: keep if _n == 1 // for constructing connected set, always keep only one observation per link
	
	di "* sort by worker ID and date" // Note: Must sort the input data by worker ID and date for MATLAB.
	sort id_pers date
	if `leave_one_out' drop date // i.e., keep id_pers id_emp lag_id_emp
	else drop date id_pers // i.e., keep id_emp lag_id_emp
	
	
	di "* export list of worker IDs and employer IDs for estimation of leave-one-out connected set, or list of current and previous employer IDs for estimation of regular connected set"
	compress
	desc
	if `leave_one_out' {
		format id_pers id_emp %14.0f
		export delim id_pers id_emp using "${DIR_TEMP}/connected_loo_input.csv", novarnames nolabel datafmt delim(tab) replace
	}
	else {
		format id_emp lag_id_emp %14.0f
		export delim id_emp lag_id_emp using "${DIR_TEMP}/connected_input.csv", novarnames nolabel datafmt delim(tab) replace
	}
	clear

	di "* delete earlier output so as to not cause confusion"
	if `leave_one_out' cap rm "${DIR_TEMP}/connected_loo_output.csv"
	else cap rm "${DIR_TEMP}/connected_output.csv"

	di "* export parameter file"
	if !`leave_one_out' { // note: no parameters needed for leave-one-out connected set, since we do not differentiate between weakly and strongly connected sets in that context.
		set obs 1
		gen byte strongly = `strongly'
		lab var strongly "Ind: Strongly connected set?"
		format strongly %1.0f
		cap confirm file "${DIR_TEMP}/connected_params.csv"
		if !_rc di as error "USER WARNING: Parameters file (${DIR_TEMP}/connected_params.csv) already exists -- entering sleep loop."
		while !_rc { // if file already exists
			sleep 1000
			cap confirm file "${DIR_TEMP}/connected_params.csv"
		}
		compress
		export delim ///
			strongly ///
			using "${DIR_TEMP}/connected_params.csv" ///
			, delim(tab) novarnames nolab
		clear
	}
	
	di "* call MATLAB via shell"
	qui cd "${DIR_TEMP}" // set current directory so that MATLAB finds the right folder structure
	if `leave_one_out' {
		!${arch}"${APP_MATLAB}" -nodesktop -nojvm -nodisplay <"${DIR_DO_DATA}/MM_CONNECTED_LOO.m"
	}
	else {
		!${arch}"${APP_MATLAB}" -nodesktop -nojvm -nodisplay <"${DIR_DO_DATA}/MM_CONNECTED.m"
	}
	qui cd // reset the current directory
	
	if `leave_one_out' cap confirm file "${DIR_TEMP}/connected_loo_output.csv"
	else cap confirm file "${DIR_TEMP}/connected_output.csv"
	while _rc { // if file does not exist yet
		sleep 60000
		if `leave_one_out' cap confirm file "${DIR_TEMP}/connected_loo_output.csv"	
		else cap confirm file "${DIR_TEMP}/connected_output.csv"	
	}
	if `leave_one_out' rm "${DIR_TEMP}/connected_loo_input.csv"
	else rm "${DIR_TEMP}/connected_input.csv"

	di "* read MATLAB output"
	if `leave_one_out' {
		import delim using "${DIR_TEMP}/connected_loo_output.csv", varnames(1) asdouble clear
		rm "${DIR_TEMP}/connected_loo_output.csv"
	}
	else {
		import delim using "${DIR_TEMP}/connected_output.csv", varnames(1) asdouble clear
		rm "${DIR_TEMP}/connected_output.csv"
	}
	
	di "* append files"
	gen byte gender = `g'
	if `g' == 1 prog_comp_desc_sum_save "${DIR_TEMP}/temp_fun_connected_gender.dta"
	else {
		append using "${DIR_TEMP}/temp_fun_connected_gender.dta"
		rm "${DIR_TEMP}/temp_fun_connected_gender.dta"
		compress
		desc
		sum, sep(0)
	}
}
rm "${DIR_TEMP}/temp_fun_connected.dta"

* format variables
lab var id_emp "Employer ID (deidentified)"
rename id_emp `var_id_emp'
lab var gender "Gender"
lab define gen_l 1 "Male" 2 "Female", replace
lab val gender gen_l
rename gender `var_gender'


********************************************************************************
* END OF MM_FUN_CONNECTED.do
********************************************************************************

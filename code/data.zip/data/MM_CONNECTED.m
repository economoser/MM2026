fprintf('\n==============================================================')
fprintf('\nFILE NAME:   MM_CONNECTED.m')
fprintf('\n')
fprintf('\nDESCRIPTION: Finds the (weakly or strongly) connected set of')
fprintf('\n             employers')
fprintf('\n')
fprintf('\nAUTHORS:     Iacopo Morchio (University of Bristol)')
fprintf('\n             Christian Moser (Columbia University)')
fprintf('\n')
fprintf('\nINPUTS:      - A .csv file "FILE_TEMP_PARAMS" containing a 1x1')
fprintf('\n               matrix with 1 data column: indicator for')
fprintf('\n               whether the set should be strongly (i.e., not')
fprintf('\n               weakly) connected')
fprintf('\n             - A .csv file "FILE_TEMP_INPUT" containing a Mx2')
fprintf('\n               matrix, where M is the number of observations,')
fprintf('\n               with 2 data columns: employer ID (id_emp),')
fprintf('\n               previous employer ID (id_emp_prev)')
fprintf('\n')
fprintf('\nOUTPUTS:     A .csv file "FILE_TEMP_OUTPUT" containing a Nx1 matrix')
fprintf('\n             with 1 data column: employer ID for employers')
fprintf('\n             in the (weakly or strongly) connected set')
fprintf('\n')
fprintf('\nNOTES:       - MATLAB version R2015b or later is required for')
fprintf('\n               -conncomp()- command')
fprintf('\n             - MATLAB BGL package required for -components()-')
fprintf('\n               command can be obtained from')
fprintf('\n               https://www.mathworks.com/matlabcentral/')
fprintf('\n               fileexchange/10922-matlabbgl')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n==============================================================')


fprintf('\n==============================================================')
fprintf('\n INITIAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Verify MATLAB version\n')
v = version;
v_old = (str2double(v(1:3)) < 8.6); % if MATLAB is older than version R2015b.
if v_old
    fprintf('\nUSER WARNING: MATLAB-native function -conncomp- requires MATLAB R2015b or later version. Using nonnative function -components- from MATLAB BGL package instead.\n')
end
clear v

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Set directories\n')
if exist('paths.txt', 'file')
    READ_REPLICATION = readlines('paths.txt');
    DIR_MAIN = char(READ_REPLICATION(1));
    DIR_TEMP = char(READ_REPLICATION(2));
else
    fprintf('\nUSER ERROR: Directories not found.\n')
    exit
end
% DIR_MAIN = ''; % note: this directory is automatically defined above
    DIR_DO = fullfile(DIR_MAIN, 'code');
        DIR_DO_DATA = fullfile(DIR_DO, 'data');
            DIR_DO_DATA_MATLAB_PCK = fullfile(DIR_DO_DATA, '_matlab_packages');
                DIR_DO_DATA_BGL = fullfile(DIR_DO_DATA_MATLAB_PCK, 'matlab_bgl');
                addpath(DIR_DO_DATA_BGL);
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % path to folder where log files should be saved
    FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_MM_CONNECTED.log']);
% DIR_TEMP = ''; % note: this directory is automatically defined above
    FILE_TEMP_PARAMS = fullfile(DIR_TEMP, 'connected_params.csv'); % path to file containing connected set parameters
    FILE_TEMP_INPUT = fullfile(DIR_TEMP, 'connected_input.csv'); % path to file from which to read Stata input
    FILE_TEMP_OUTPUT = fullfile(DIR_TEMP, 'connected_output.csv'); % path to file to which to write MATLAB output
clear STR_TIME_STAMP READ_REPLICATION DIR_MAIN DIR_DO DIR_DO_DATA DIR_DO_DATA_MATLAB_PCK DIR_DO_DATA_BGL DIR_TEMP

fprintf('\n  --> Read parameters\n')
FILE_TEMP_PARAMS_OPEN = fopen(FILE_TEMP_PARAMS);
eval(['delete ''', FILE_TEMP_PARAMS, ''''])
clear FILE_TEMP_PARAMS
FILE_TEMP_PARAMS_SCAN = fscanf(FILE_TEMP_PARAMS_OPEN, '%f', [1 inf])';
fclose(FILE_TEMP_PARAMS_OPEN);
clear FILE_TEMP_PARAMS_OPEN
strongly = FILE_TEMP_PARAMS_SCAN(:, 1); % indicator for whether employer set should be strongly connected (0 = weakly connected; 1 = strongly connected)
fprintf('\n')
disp(['strongly = ' num2str(strongly)])
clear FILE_TEMP_PARAMS_SCAN

fprintf('\n  --> Set random-number seed\n')
seed = 20250828;
rng(seed, 'twister')
clear seed

fprintf('\n  --> Start log file\n')
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n FIND LARGEST WEAKLY OR STRONGLY CONNECTED SET')
fprintf('\n==============================================================')

fprintf('\n  --> Load data\n')
FILE_TEMP_INPUT_OPEN = fopen(FILE_TEMP_INPUT);
FILE_TEMP_INPUT_SCAN = fscanf(FILE_TEMP_INPUT_OPEN, '%f %f', [2 inf])';
fclose(FILE_TEMP_INPUT_OPEN);
id_emp = FILE_TEMP_INPUT_SCAN(:, 1);
id_emp_prev = FILE_TEMP_INPUT_SCAN(:, 2);
clear FILE_TEMP_INPUT FILE_TEMP_INPUT_OPEN FILE_TEMP_INPUT_SCAN

fprintf('\n  --> Create vectors for employer IDs and previous employer IDs\n')
N_id_emp = length(id_emp);
N_id_emp_prev = length(id_emp_prev);
if N_id_emp ~= N_id_emp_prev
    fprintf('\nUSER ERROR: Not the same number of employer IDs (id_emp) and previous employer IDs (id_emp_prev).\n')
    exit
end
[id_emp_unique, ~, index] = unique([id_emp; id_emp_prev]); % command -unique()- returns unique values of the pooled array of all current and previous employer IDs -- note: column index maps 'id_emp_unique' into the (old) employer IDs: [id_emp; id_emp_prev] = id_emp_unique(index)
N_id_emp_unique = max(index);
id_emp_index = index(1:N_id_emp);
id_emp_prev_index = index(N_id_emp + 1:end);
clear N_id_emp_prev id_emp id_emp_prev index N_id_emp

fprintf('\n  --> Find IDs of employers in largest (weakly or strongly) connected set\n')
if v_old % if MATLAB version is earlier than R2015b, use nonnative function -components- from MATLAB BGL package to compute connected set components
    M = sparse(id_emp_prev_index, id_emp_index, 1); % create sparse square matrix of old employer IDs in rows, new employer IDs in columns
    [N_rows, N_cols] = size(M);
    if N_rows > N_cols % ensure that employer transition matrix is square (it should be by definition)
        M = [M, sparse(N_rows, N_rows - N_cols, 0)];
    elseif N_rows < N_cols
        M = [M; sparse(N_cols - N_rows, N_cols, 0)];
    end
    if ~strongly
        M = max(M, M'); % note: for weakly connected set, it does not matter if move is from employer 1 to employer 2 or from employer 2 to employer 1, since both add the same information for the purpose of constructing the weakly connected set; for strongly connected set, directionality of flows matters
    end
    [connected_index, connected_size] = components(M); % construct (weakly or strongly) connected sets
    idx = find(connected_size == max(connected_size), 1); % select only employer IDs in largest connected set
    id_emp = uint64(id_emp_unique(connected_index == idx));
else % else, if MATLAB version is R2015b or later, use MATLAB-internal function -conncomp- to compute connected set components
    M = digraph(id_emp_prev_index', id_emp_index');
    if strongly
        [connected_index, connected_size] = conncomp(M, 'Type', 'strong'); % construct strongly connected sets
    else
        [connected_index, connected_size] = conncomp(M, 'Type', 'weak'); % construct weakly connected sets
    end
    idx = (connected_index == min(connected_index(connected_size(connected_index) == max(connected_size)))); % vector of indicators for whether employer ID is in the set of employer IDs whose component set has the smallest component ID among all largest component sets
    id_emp = uint64(id_emp_unique(idx)); % select employer IDs in largest connected set
end
clear N_rows N_cols v_old id_emp_unique id_emp_index id_emp_prev_index connected_index idx connected_size M

fprintf('\n  --> Summary statistics\n')
disp(['      ...number of unique firms = ' int2str(N_id_emp_unique)]);
N_id_emp_connected = size(id_emp, 1);
fprintf('\n')
if strongly
    disp(['      ...number of unique firms in strongly connected set = ' int2str(N_id_emp_connected) ' (' num2str(100*N_id_emp_connected/N_id_emp_unique, '%5.2f') '%)']);
else
    disp(['      ...number of unique firms in weakly connected set = ' int2str(N_id_emp_connected) ' (' num2str(100*N_id_emp_connected/N_id_emp_unique, '%5.2f') '%)']);
end
clear N_id_emp_connected N_id_emp_unique strongly

fprintf('\n  --> Write IDs of employers in connected set to tab-delimited file\n')
FILE_TEMP_OUTPUT_OPEN = fopen(FILE_TEMP_OUTPUT, 'w');
fprintf(FILE_TEMP_OUTPUT_OPEN, '%12s\n', 'id_emp');
fprintf(FILE_TEMP_OUTPUT_OPEN, '%12.0f\n', id_emp');
fclose(FILE_TEMP_OUTPUT_OPEN);
clear FILE_TEMP_OUTPUT FILE_TEMP_OUTPUT_OPEN id_emp


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF MM_CONNECTED.m')
fprintf('\n==============================================================')

fprintf('\n  --> End log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> Exit\n')
exit
********************************************************************************
* FILE NAME:   MM_9_COVARIATES.do
*
* DESCRIPTION: Computes employer-level covariates of amenities ($a$), productivities ($p$), and gender wedges ($z$)
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_9_COVARIATES"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 10

* set random-number stream
clear rngstream
set rngstream 9

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** set options
* options
global merge_with_connected = 0 // 0 = do not merge with annual connected set; 1 = merge with annual connected set
global standardize = 1 // 0 = create only one dataset that leaves variables in original scale; 1 = create a second dataset that converts variables to standardized z-scores


*** load and format data
* load data
local vars_load = "year id_pers gender edu id_est muni ind07_5 simples sep_reason occ94_5 earn_mean earn_dec earn_contr hours contract_type abs_reason_1 abs_reason_2 abs_reason_3 abs_dur_1 abs_dur_2 abs_dur_3"
if $merge_with_connected {
	local vars_load = "`vars_load' id_unique"
}
prog_load_data $year_min $year_max "`vars_load'"

* rename variables
rename id_est id_emp
rename earn_mean inc
rename earn_dec inc_dec
rename earn_contr inc_contr


*** sample selection
* keep only observations with nonmissing key variables
foreach var of varlist ///
	year ///
	id_pers ///
	gender ///
	id_emp ///
	{
	keep if `var' < .
}

* keep only workers satisfying the selection criteria
if $merge_with_connected {
	merge m:1 id_unique ///
		using "${DIR_TEMP}/connected_jobs_annual.dta" ///
		, ///
		keep(match) keepusing(id_unique) nogen
	drop id_unique
}

* keep only observations with nonmissing earnings
keep if inc < .

* keep a single observation per worker-year
bys id_pers year (inc): keep if _n == _N


*** create amenity proxies
* skill and task contents
merge m:1 occ94_5 using "${FILE_OCC_BRA_TO_OCC_US}", keep(master match) keepusing(occ90_us) nogen // convert CBO 1994 occupation codes to US Census occupation codes
local vars_skill = "nonrout_cog_pers nonrout_man_phys" // link US Census occupation codes to skill-task contents
merge m:1 occ90_us using "${FILE_OCC_US_TO_SKILL_TASK_CONT}", keep(master match) keepusing(`vars_skill') nogen
drop occ90_us
lab var nonrout_cog_pers "Nonroutine interpersonal skill requirement (z-score)"
rename nonrout_man_phys nonrout_manual
lab var nonrout_manual "Nonroutine manual skill requirement (z-score)"

* variables based on cross-section
lab var inc "Earnings (BRL)"
lab var inc_dec "Earnings in December (BRL)"
lab var inc_contr "Contractual earnings (BRL)"
lab var hours "Work time (hours)"
drop edu
gen byte part_time = (hours < 40) if hours < .
lab var part_time "Ind: Part time (< 40h)?"
drop inc_dec inc_contr
gen byte sep = (sep_reason != 0) if sep_reason < .
lab var sep "Ind: Separated?"
gen byte sep_fired = inlist(sep_reason, 1, 2) if sep == 1 & sep_reason < .
lab var sep_fired "Ind: Fired?"
gen byte sep_death = (sep_reason == 10) if sep == 1 & sep_reason < .
lab var sep_death "Ind: Died?"
drop sep sep_reason
gen byte parental = inlist(5, abs_reason_1, abs_reason_2, abs_reason_3) if abs_reason_1 < . | abs_reason_2 < . | abs_reason_3 < .
lab var parental "Ind: Parental leave?"
gen float parental_dur = 0 if parental == 1
drop parental
replace parental_dur = parental_dur + max(min(abs_dur_1, 365), 1) if abs_reason_1 == 5 & abs_dur_1 < .
replace parental_dur = parental_dur + max(min(abs_dur_2, 365), 1) if abs_reason_2 == 5 & abs_dur_2 < .
replace parental_dur = parental_dur + max(min(abs_dur_3, 365), 1) if abs_reason_3 == 5 & abs_dur_3 < .
replace parental_dur = max(min(parental_dur, 365), 1) if parental_dur < .
lab var parental_dur "Duration of parental leave (days)"
drop abs_dur_1 abs_dur_2 abs_dur_3
gen byte acc_work = inlist(1, abs_reason_1, abs_reason_2, abs_reason_3) if abs_reason_1 < . | abs_reason_2 < . | abs_reason_3 < .
lab var acc_work "Ind: Work-related accident?"
drop abs_reason_1 abs_reason_2 abs_reason_3

* variables based on panel
xtset id_pers year
gen byte hours_change = (abs(hours/L.hours - 1) > ${tol_change}) if hours < . & L.hours < . & id_emp == L.id_emp
lab var hours_change "Ind: Change in work time?"
gen byte inc_change = (abs(inc/L.inc - 1) > ${tol_change}) if inc < . & L.inc < . & id_emp == L.id_emp
lab var inc_change "Ind: Change in earnings?"
drop id_pers

* distribution of workers across genders
bys id_emp year (inc): gen byte gender_own_highest = (gender == gender[_N]) if gender < . & gender[_N] < .
lab var gender_own_highest "Ind: Highest-paid employer of own gender?"

* general (i.e., not gender-specific) employer attributes
drop occ94_5
bys id_emp year: gen float size_est = _N
lab var size_est "Total employment (number of workers)"
drop year


*** convert variables to logs
foreach var of varlist ///
	inc parental_dur size_est /// inc_dec inc_contr
	{
	replace `var' = ln(`var')
	local `var'_l: var lab `var'
	local `var'_l = subinstr("``var'_l'", "(", "(log ", .)
	lab var `var' "``var'_l'"
}


*** create gender-employer statistics
* store original variable labels
foreach var of varlist * {
	local `var'_l: var lab `var'
}

* collapse to gender-employer level
${gtools}collapse ///
	(firstnm) ///
		muni ind07_5 ///
	(mean) ///
		nonrout_cog_pers nonrout_manual ///
		hours part_time hours_change ///
		inc_change ///
		sep_fired sep_death ///
		parental_dur acc_work ///
		gender_own_highest ///
		size_est ///
		simples ///
	(count) ///
		weight=inc ///
	, by(id_emp gender) fast

* apply (original) variable labels
foreach var of varlist * {
	lab var `var' "``var'_l'"
}
lab var muni "Municipality (app. 5565 groups)"
lab var ind07_5 "Industry (5 digits)"
lab var hours "Mean work time (log hours)"
lab var part_time "Share part-time (< 40h) workers"
lab var hours_change "Share with work time change"
lab var inc_change "Share with earnings change"
lab var sep_fired "Share of workers fired"
lab var sep_death "Share of workers died"
lab var parental_dur "Mean duration of parental leave (log days)"
lab var acc_work "Share of workers with work-related accidents"
lab var size_est "Total employment (log number of workers)"
lab var simples "Share participating in Simples Nacional tax program"
lab var weight "Weight (number of workers)"

* save
order ///
	id_emp gender ///
	muni ind07_5 ///
	nonrout_cog_pers nonrout_manual ///
	hours part_time hours_change ///
	inc_change ///
	sep_fired sep_death ///
	parental_dur acc_work ///
	gender_own_highest ///
	size_est ///
	simples ///
	weight
sort id_emp gender
prog_comp_desc_sum_save "${DIR_TEMP}/covariates.dta"

* save single-gender versions
forval g = 1/2 {
	use if gender == `g' using "${DIR_TEMP}/covariates.dta", clear
	drop gender
	sort id_emp
	prog_comp_desc_sum_save "${DIR_TEMP}/covariates_g`g'.dta"
}

* convert to z-scores
if $standardize {
	use "${DIR_TEMP}/covariates.dta", clear
	forval g = 1/2 {
		foreach var of varlist * {
			if !inlist("`var'", "id_emp", "gender", "muni", "ind07_5", "weight") {
				qui sum `var' [aw=weight] if gender == `g'
				replace `var' = (`var' - r(mean))/r(sd) if gender == `g'
			}
		}
	}
	order ///
		id_emp gender ///
		muni ind07_5 ///
		nonrout_cog_pers nonrout_manual ///
		hours part_time hours_change ///
		inc_change ///
		sep_fired sep_death ///
		parental_dur acc_work ///
		gender_own_highest ///
		size_est ///
		simples ///
		weight
	sort id_emp gender
	prog_comp_desc_sum_save "${DIR_TEMP}/covariates_standardized.dta"
	forval g = 1/2 {
		use if gender == `g' using "${DIR_TEMP}/covariates_standardized.dta", clear
		drop gender
		sort id_emp
		prog_comp_desc_sum_save "${DIR_TEMP}/covariates_standardized_g`g'.dta"
	}
	rm "${DIR_TEMP}/covariates_standardized.dta"
}


*** final housekeeping
* clean up
if $clean_up {
	rm "${DIR_TEMP}/covariates.dta"
}

* turn timer off
timer off 10

* print final banner
di _newline(5)
timer list 10
local t = r(t10)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_9_COVARIATES.do
********************************************************************************

fprintf('\n==============================================================')
fprintf('\nFILE NAME:   MM_AKM.m')
fprintf('\n')
fprintf('\nDESCRIPTION: Estimates worker fixed effects, employer fixed')
fprintf('\n             effects, time fixed effects, returns to')
fprintf('\n             demographics, and additional controls based on')
fprintf('\n             AKM (i.e., Abowd, Kramarz, and Margolis, 1999,')
fprintf('\n             Econometrica) using the algorithm by Card,')
fprintf('\n             Heining, and Kline (2013, QJE)')
fprintf('\n')
fprintf('\nAUTHORS:     Iacopo Morchio (University of Bristol)')
fprintf('\n             Christian Moser (Columbia University)')
fprintf('\n')
fprintf('\nINPUTS:      - A .csv file "FILE_TEMP_PARAMS" containing a 14x1')
fprintf('\n               matrix with the following parameters:')
fprintf('\n               akm_age_poly_order, akm_age_flat_min,')
fprintf('\n               akm_age_flat_max, akm_age_norm,')
fprintf('\n               age_min, age_max, akm_years, akm_edu,')
fprintf('\n               akm_hours, akm_occ, akm_tenure, akm_exp_act')
fprintf('\n             - A .csv file "FILE_TEMP_INPUT" containing a KxM')
fprintf('\n               matrix, where K is a number between 4 and 10,')
fprintf('\n               with the following data columns: year,')
fprintf('\n               id_pers, id_emp, inc, age, edu, hours, occ,')
fprintf('\n               tenure, exp_act')
fprintf('\n')
fprintf('\nOUTPUTS:     A .csv file "FILE_TEMP_OUTPUT" containing worker')
fprintf('\n             fixed effects (fe_pers), employer fixed effects')
fprintf('\n             (fe_emp), time fixed effects (fe_year), and')
fprintf('\n             optional returns on other covariates')
fprintf('\n')
fprintf('\nNOTES:       - Due to changes in ichol() command, requires')
fprintf('\n               MATLAB R2011a or later')
fprintf('\n             - Requires MATLAB R2016b or later for implicit')
fprintf('\n               expansion')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n==============================================================')


fprintf('\n==============================================================')
fprintf('\n INITIAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> Verify MATLAB version\n')
v = version;
v_old = (str2double(v(1:3)) < 9.1); % if MATLAB is older than version R2016b
if v_old
    fprintf('\nUSER WARNING: Implicit expansions require MATLAB R2016b or later version. Run slower routine instead.\n')
end
clear v

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Set directories\n')
if exist('paths.txt', 'file')
    READ_REPLICATION = readlines('paths.txt');
    DIR_MAIN = char(READ_REPLICATION(1));
        DIR_DO = fullfile(DIR_MAIN, 'code'); % code directory
            DIR_DO_DATA = fullfile(DIR_DO, 'data'); % data-code directory
            addpath(DIR_DO_DATA);
    DIR_TEMP = char(READ_REPLICATION(2));
else
    fprintf('\nUSER ERROR: Directories not found.\n')
    exit
end
% DIR_MAIN = ''; % note: this directory is automatically defined above
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % directory for log files
    FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_MM_AKM.log']);
% DIR_TEMP = ''; % note: this directory is automatically defined above
    FILE_TEMP_PARAMS = fullfile(DIR_TEMP, 'parameters_akm.csv'); % file containing AKM parameters
    FILE_TEMP_INPUT = fullfile(DIR_TEMP, 'input_akm.csv'); % file containing inputs from Stata for MATLAB
    FILE_TEMP_OUTPUT = fullfile(DIR_TEMP, 'output_akm.csv'); % file containing output from MATLAB for Stata
clear STR_TIME_STAMP READ_REPLICATION DIR_MAIN DIR_DO DIR_DO_DATA DIR_TEMP

fprintf('\n  --> Set parameters\n')
FILE_TEMP_PARAMS_OPEN = fopen(FILE_TEMP_PARAMS);
FILE_TEMP_PARAMS_SCAN = fscanf(FILE_TEMP_PARAMS_OPEN, '%f %f %f %f %f %f %f %f %f %f %f %f', [12 inf])';
fclose(FILE_TEMP_PARAMS_OPEN);
n_params = 1;
akm_age_poly_order = FILE_TEMP_PARAMS_SCAN(:, n_params); % age polynomial order (0 = no age controls; 1 = restricted profile of age indicators; 2 / 3 / etc. = include 2nd order term / 2nd and 3rd order terms / etc.)
fprintf('\n      ...akm_age_poly_order = %1.0f\n', akm_age_poly_order)
n_params = n_params + 1;
akm_age_flat_min = FILE_TEMP_PARAMS_SCAN(:, n_params); % minimum age for which income-age profile is restricted to be flat (only relevant if akm_age_poly_order == 1)
fprintf('\n      ...akm_age_flat_min = %2.0f\n', akm_age_flat_min)
n_params = n_params + 1;
akm_age_flat_max = FILE_TEMP_PARAMS_SCAN(:, n_params); % maximum age for which income-age profile is restricted to be flat (only relevant if akm_age_poly_order == 1)
fprintf('\n      ...akm_age_flat_max = %2.0f\n', akm_age_flat_max)
n_params = n_params + 1;
akm_age_norm = FILE_TEMP_PARAMS_SCAN(:, n_params); % normalization age
fprintf('\n      ...akm_age_norm = %2.0f\n', akm_age_norm)
n_params = n_params + 1;
age_min = FILE_TEMP_PARAMS_SCAN(:, n_params); % minimum age
fprintf('\n      ...age_min = %2.0f\n', age_min)
n_params = n_params + 1;
age_max = FILE_TEMP_PARAMS_SCAN(:, n_params); % maximum age
fprintf('\n      ...age_max = %2.0f\n', age_max)
n_params = n_params + 1;
akm_years = FILE_TEMP_PARAMS_SCAN(:, n_params); % year controls (0 = no; 1 = yes)
fprintf('\n      ...akm_years = %1.0f\n', akm_years)
n_params = n_params + 1;
akm_edu = FILE_TEMP_PARAMS_SCAN(:, n_params); % education interactions (0 = no; 1 = yes)
fprintf('\n      ...akm_edu = %1.0f\n', akm_edu)
n_params = n_params + 1;
akm_hours = FILE_TEMP_PARAMS_SCAN(:, n_params); % hours controls (0 = no; 1 = yes)
fprintf('\n      ...akm_hours = %1.0f\n', akm_hours)
n_params = n_params + 1;
akm_occ = FILE_TEMP_PARAMS_SCAN(:, n_params); % occupation controls (0 = no; 1 = yes)
fprintf('\n      ...akm_occ = %1.0f\n', akm_occ)
n_params = n_params + 1;
akm_tenure = FILE_TEMP_PARAMS_SCAN(:, n_params); % tenure controls (0 = no; 1 = yes)
fprintf('\n      ...akm_tenure = %1.0f\n', akm_tenure)
n_params = n_params + 1;
akm_exp_act = FILE_TEMP_PARAMS_SCAN(:, n_params); % actual experience controls (0 = no; 1 = yes)
fprintf('\n      ...akm_exp_act = %1.0f\n', akm_exp_act)
if akm_age_poly_order == 1 && (akm_age_flat_min >= akm_age_flat_max || (akm_age_flat_min >= age_max || akm_age_flat_max <= age_min))
    fprintf('\nUSER ERROR: Requested to estimate age effects (akm_age_poly_order = 1) but restricted-to-be-flat age region is too short or falls outside of selected age range.\n')
    exit
elseif akm_age_poly_order >= 2 && (akm_age_norm < age_min || akm_age_norm > age_max)
    fprintf('\nUSER ERROR: Requested to estimate higher-order age terms (akm_age_poly_order >= 2) but normalization age falls outside of selected age range.\n')
    exit
end
eval(['delete ''', FILE_TEMP_PARAMS, ''''])
clear FILE_TEMP_PARAMS FILE_TEMP_PARAMS_OPEN FILE_TEMP_PARAMS_SCAN age_min age_max n_params

fprintf('\n  --> Set random-number seed\n')
seed = 20250828;
rng(seed, 'twister')
clear seed

fprintf('\n  --> Start log file\n')
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n LOAD DATA')
fprintf('\n==============================================================')

fprintf('\n  --> Read input data\n')
FILE_TEMP_INPUT_OPEN = fopen(FILE_TEMP_INPUT, 'r');
FORMAT_INPUT = '%u %f %f %f'; % always load at least 4 variables: year id_pers id_emp inc
N_INPUT = 4;
if akm_age_poly_order
    FORMAT_INPUT = [FORMAT_INPUT, ' %u'];
    N_INPUT = N_INPUT + 1;
end
if akm_edu
    FORMAT_INPUT = [FORMAT_INPUT, ' %u'];
    N_INPUT = N_INPUT + 1;
end
if akm_hours
    FORMAT_INPUT = [FORMAT_INPUT, ' %u'];
    N_INPUT = N_INPUT + 1;
end
if akm_occ
    FORMAT_INPUT = [FORMAT_INPUT, ' %u'];
    N_INPUT = N_INPUT + 1;
end
if akm_tenure
    FORMAT_INPUT = [FORMAT_INPUT, ' %u'];
    N_INPUT = N_INPUT + 1;
end
if akm_exp_act
    FORMAT_INPUT = [FORMAT_INPUT, ' %u'];
    N_INPUT = N_INPUT + 1;
end
fprintf('\n')
disp(['      ...number of variables in input data = ' int2str(N_INPUT) ' (format = ' FORMAT_INPUT ')']);
FILE_TEMP_INPUT_SCAN = fscanf(FILE_TEMP_INPUT_OPEN, FORMAT_INPUT, [N_INPUT inf])';
fclose(FILE_TEMP_INPUT_OPEN);
year = FILE_TEMP_INPUT_SCAN(:, 1); % input data column 1: year
id_pers = FILE_TEMP_INPUT_SCAN(:, 2); % input data column 2: worker ID
id_emp = FILE_TEMP_INPUT_SCAN(:, 3); % input data column 3: employer ID
inc = FILE_TEMP_INPUT_SCAN(:, 4); % input data column 4: log income
col_counter = 4;
if akm_age_poly_order
    col_counter = col_counter + 1;
    age = FILE_TEMP_INPUT_SCAN(:, col_counter); % additional input data: age
end
if akm_edu
    col_counter = col_counter + 1;
    edu = FILE_TEMP_INPUT_SCAN(:, col_counter); % additional input data: education
end
if akm_hours
    col_counter = col_counter + 1;
    hours = FILE_TEMP_INPUT_SCAN(:, col_counter); % additional input data: hours
end
if akm_occ
    col_counter = col_counter + 1;
    occ = FILE_TEMP_INPUT_SCAN(:, col_counter); % additional input data: occupation codes
end
if akm_tenure
    col_counter = col_counter + 1;
    tenure = FILE_TEMP_INPUT_SCAN(:, col_counter); % additional input data: tenure length
end
if akm_exp_act
    col_counter = col_counter + 1;
    exp_act = FILE_TEMP_INPUT_SCAN(:, col_counter); % additional input data: actual experience (or actual experience interacted with potential experience)
end
clear FILE_TEMP_INPUT FILE_TEMP_INPUT_OPEN FORMAT_INPUT N_INPUT FILE_TEMP_INPUT_SCAN col_counter

fprintf('\n  --> Summary statistics for complete dataset (already restricted to connected set)\n')
n_years_unique = length(unique(year));
fprintf('\n      ...total number of unique years = %2.0f\n', n_years_unique)
n_worker_years = length(inc);
fprintf('\n      ...total number of worker-years = %10.0f\n', n_worker_years)
n_workers_unique = length(unique(id_pers));
fprintf('\n      ...total number of unique workers = %10.0f\n', n_workers_unique)
n_employers_unique = length(unique(id_emp));
fprintf('\n      ...total number of unique employers = %10.0f\n', n_employers_unique)
fprintf('\n      ...mean(ln(income)) = %5.3f\n', mean(inc))
fprintf('\n      ...std. dev.(ln(income)) = %5.3f\n', std(inc))
fprintf('\n      ...var(ln(income)) = %5.3f\n', var(inc))
clear n_years_unique n_worker_years n_workers_unique n_employers_unique


fprintf('\n==============================================================')
fprintf('\n ESTIMATE AKM EQUATION')
fprintf('\n==============================================================')

fprintf('\n  --> Create unique indicators for workers, employers, years, ages, hours, occupations, tenure, and actual experience \n')
NT = length(inc); % total number of worker-years.
[~, ~, id_pers_unique_index] = unique(id_pers);
[~, ~, id_emp_unique_index] = unique(id_emp);
clear id_emp
if akm_years
    [~, ~, year_unique_index] = unique(year);
    T = max(year_unique_index); % number of unique elements in year = number of unique years
end
if akm_age_poly_order == 1
    age(age >= akm_age_flat_min & age <= akm_age_flat_max) = akm_age_flat_min; % restrict income-age profile to be flat between ages akm_age_flat_min and akm_age_flat_max
    clear akm_age_flat_min akm_age_flat_max
    [~, ~, age_unique_index] = unique(age); % note: command -unique()- returns unique values of age -- note: column index (3rd assignment object) maps vector of unique entries (1st assignment object) into the original vector (argument of -unique()-)
    clear age
    N_Age = max(age_unique_index); % number of unique elements in age = number of unique ages
end
if akm_edu
    [~, ~, edu_unique_index] = unique(edu);
    clear edu
    if akm_age_poly_order >= 2
        N_Edu = max(edu_unique_index); % number of unique elements in edu = number of unique education levels
    end
end
if akm_hours
    [~, ~, hours_unique_index] = unique(hours);
    clear hours
end
if akm_occ
    [~, ~, occ_unique_index] = unique(occ);
    clear occ
end
if akm_tenure
    [~, ~, tenure_unique_index] = unique(tenure);
    clear tenure
end
if akm_exp_act
    [~, ~, exp_act_unique_index] = unique(exp_act);
    clear exp_act
end

fprintf('\n  --> Create worker indicators\n')
W = sparse(1:NT, id_pers_unique_index', 1); % dimension: NT x N -- note: this is the only independent variable for which no category is dropped
W_len = size(W, 2);
clear id_pers_unique_index

fprintf('\n  --> Create employer indicators\n')
F = sparse(1:NT, id_emp_unique_index', 1);
F = F(:, 2:end); % drop indicator for first firm, or else collinear with worker effects. Dimension: NT x (J - 1)
F_len = size(F, 2);
clear id_emp_unique_index

if akm_years
    fprintf('\n  --> Create (education-specific) year indicators\n')
    if akm_edu
        Y = sparse(1:NT, T*(edu_unique_index' - 1) + year_unique_index', 1);
        Y(:, T*(edu_unique_index' - 1) + 1) = []; % drop indicator for first year of every education group, or else collinear with worker effects. Dimension: NT x (T - 1)*N_Edu
    else
        Y = sparse(1:NT, year_unique_index', 1);
        Y = Y(:, 2:end); % drop indicator for first year, or else collinear with worker effects. Dimension: NT x (T - 1).
    end
    Y_len = size(Y, 2);
    clear year_unique_index T
end

if akm_age_poly_order == 1
    fprintf('\n  --> Create age indicators or higher-order (i.e., excluding linear) terms\n')
    if akm_edu
        A = sparse(1:NT, N_Age*(edu_unique_index' - 1) + age_unique_index', 1);
        A(:, N_Age*(edu_unique_index' - 1) + 1) = []; % drop indicator for first age of every education group, or else collinear with worker effects. Dimension: NT x (N_Age - 1)*N_Edu
    else
        A = sparse(1:NT, age_unique_index', 1);
        A = A(:, 2:end); % drop indicator for first age, or else collinear with worker effects. Dimension: NT x (N_Age - 1)
    end
    clear age_unique_index N_Age
    A_len = size(A, 2);
elseif akm_age_poly_order >= 2
    age = (age - akm_age_norm)/akm_age_norm;  % rescale to avoid big numbers
    if akm_edu
        E = sparse(1:NT, edu_unique_index', 1);
        if v_old
            A = zeros(NT, N_Edu*(akm_age_poly_order - 1));            
            for n = 2:akm_age_poly_order
                A(:, N_Edu*(n - 2) + 1:N_Edu*(n - 1)) = bsxfun(@times, E, age.^n);
            end
            A = sparse(A); % dimension: NT x (N_Age - 1)*N_Edu
        else
            A = repmat(E, 1, akm_age_poly_order - 1).*repmat(age, 1, N_Edu*(akm_age_poly_order - 1)).^kron((2:akm_age_poly_order), ones(1, N_Edu)); % Dimension: NT x (N_Age - 1)*N_Edu
        end
        clear E age N_Edu
    else
        if v_old
            A = zeros(NT, akm_age_poly_order - 1);
            for n = 2:akm_age_poly_order
                A(:, n - 1) = age.^n;
            end
            A = sparse(A); % dimension: NT x (N_Age - 1)
        else
            A = sparse(age.^(2:akm_age_poly_order)); % dimension: NT x (N_Age - 1)
        end
        clear age
    end
    A_len = size(A, 2);
end
clear akm_age_norm v_old

if akm_hours
    fprintf('\n  --> Create hours indicators\n')
    H = sparse(1:NT, hours_unique_index', 1);
    H = H(:, 2:end); % drop indicator for first hours level, or else collinear with worker effects. Dimension: NT x (N_H - 1)
    H_len = size(H, 2);
    clear hours_unique_index
end

if akm_occ
    fprintf('\n  --> Create occupation indicators\n')
    O = sparse(1:NT, occ_unique_index', 1);
    O = O(:, 2:end); % drop indicator for first occupation code, or else collinear with worker effects. Dimension: NT x (N_O - 1)
    O_len = size(O, 2);
    clear occ_unique_index
end

if akm_tenure
    fprintf('\n  --> Create (education-specific) tenure indicators\n')
    Ten = sparse(1:NT, tenure_unique_index', 1);
    Ten = Ten(:, 2:end); % drop indicator for first tenure level, or else collinear with worker effects. Dimension: NT x (N_Ten - 1)
    Ten_len = size(Ten, 2);
    clear tenure_unique_index
end

if akm_exp_act
    fprintf('\n  --> Create (education-specific) actual experience indicators\n')
    ExpA = sparse(1:NT, exp_act_unique_index', 1);
    ExpA = ExpA(:, 2:end); % drop indicator for first actual experience level, or else collinear with worker effects. Dimension: NT x (N_ExpA - 1)
    ExpA_len = size(ExpA, 2);
    clear exp_act_unique_index
end

if akm_edu
    fprintf('\n  --> Clear education index variable that is no longer needed\n')
    clear edu_unique_index
end

fprintf('\n  --> Generate design matrix (X) and Gramian matrix (X_prime*X)\n')
X = [W, F];
X_len = W_len + F_len; % = N + (J - 1)
if akm_years
    X = [X, Y];
    X_len = X_len + Y_len;
end
if akm_age_poly_order
    X = [X, A];
    X_len = X_len + A_len;
end
if akm_hours
    X = [X, H];
    X_len = X_len + H_len;
end
if akm_occ
    X = [X, O];
    X_len = X_len + O_len;
end
if akm_tenure
    X = [X, Ten];
    X_len = X_len + Ten_len;
end
if akm_exp_act
    X = [X, ExpA];
    X_len = X_len + ExpA_len;
end
fprintf('\n      ...dimensions of the design matrix (X) = %10.0f x %10.0f\n', NT, X_len)
fprintf('\n      ...dimensions of the Gramian matrix (X_prime*X) = %10.0f x %10.0f\n', X_len, X_len)
fprintf('\n      ...dimensions of the moment matrix (X_prime*y) = %10.0f x %1.0f\n', X_len, 1)
clear NT

fprintf('\n  --> Perform incomplete Cholesky factorization of Gramian matrix (X_prime*X) as preconditioner for matrix inversion\n')
L = ichol(X'*X, struct('type', 'ict', 'droptol', 1e-2, 'diagcomp', 1e-1)); % note: command -ichol()- uses iterative approximation algorithm

fprintf('\n  --> Create coefficient vector\n')
b = pcg(X'*X, X'*inc, 1e-10, 1e3, L, L'); % note: command -pcg()- uses preconditioned conjugate gradients method to compute b = (X'*X)^-1*X'*inc. Dimension: N + (J - 1) + (T - 1)*N_Edu + ... if akm_edu, or else N + (J - 1) + (T - 1) + ...
fprintf('\n      ...dimensions of the coefficient vector (b) = %10.0f x %1.0f\n', X_len, 1)
clear L X X_len

fprintf('\n  --> Extract estimated parameters\n')
index_start = 1; % beginning of index for worker fixed effects
index_end = W_len; % end of index for worker fixed effects
fe_pers = full(W*b(index_start:index_end)); % Worker fixed effects = N worker indicators * estimated worker returns vector. Dimension: NT x 1
clear W W_len
index_start = index_end + 1; % beginning of index for employer fixed effects.
index_end = index_end + F_len; % end of index for employer fixed effects.
fe_emp = full(F*b(index_start:index_end)); % Employer fixed effects (first one dropped) = J - 1 employer indicators (first one dropped) * estimated employer returns vector. Dimension: NT x 1
clear F F_len
if akm_years
    index_start = index_end + 1; % beginning of index for (education-specific) year fixed effects
    index_end = index_end + Y_len; % end of index for (education-specific) year fixed effects
    xb_y = full(Y*b(index_start:index_end)); % year fixed effects = T - 1 year indicators (first one dropped) * estimated year returns vector. Dimension: NT x 1
    clear Y Y_len
end
if akm_age_poly_order
    index_start = index_end + 1; % beginning of index for (education-specific) age fixed effects
    index_end = index_end + A_len; % end of index for (education-specific) age fixed effects
    xb_a = full(A*b(index_start:index_end)); % age fixed effects or higher-order age terms = N_Age - 1 age indicators or higher-order age terms * estimated age returns vector. Dimension: NT x 1
    clear A A_len
end
if akm_hours
    index_start = index_end + 1; % beginning of index for hours fixed effects
    index_end = index_end + H_len; % end of index for hours fixed effects
    xb_h = full(H*b(index_start:index_end)); % hours fixed effects
    clear H H_len
end
if akm_occ
    index_start = index_end + 1; % beginning of index for occupation fixed effects
    index_end = index_end + O_len; % end of index for occupation fixed effects
    xb_o = full(O*b(index_start:index_end)); % occupation fixed effects
    clear O O_len
end
if akm_tenure
    index_start = index_end + 1; % beginning of index for tenure fixed effects
    index_end = index_end + Ten_len; % end of index for tenure fixed effects
    xb_t = full(Ten*b(index_start:index_end)); % tenure fixed effects
    clear Ten Ten_len
end
if akm_exp_act
    index_start = index_end + 1; % beginning of index for actual experience fixed effects
    index_end = index_end + ExpA_len; % end of index for actual experience fixed effects
    xb_e = full(ExpA*b(index_start:index_end)); % actual experience fixed effects
    clear ExpA ExpA_len
end
clear b index_start index_end


fprintf('\n==============================================================')
fprintf('\n ANALYZE ESTIMATION RESULTS')
fprintf('\n==============================================================')

fprintf('\n  --> Normalize worker and employer fixed effect distributions such that worker fixed effects are mean zero\n')
m_pe = mean(fe_pers);
fe_pers = fe_pers - m_pe;
fe_emp = fe_emp + m_pe;
clear m_pe

fprintf('\n  --> Means of worker and employer fixed effects\n')
m = mean([fe_pers, fe_emp]);
disp(m)
clear m

fprintf('\n  --> Create AKM residual\n')
resid = inc - fe_pers - fe_emp;
if akm_years
    resid = resid - xb_y;
end
if akm_age_poly_order
    resid = resid - xb_a;
end
if akm_hours
    resid = resid - xb_h;
end
if akm_occ
    resid = resid - xb_o;
end
if akm_tenure
    resid = resid - xb_t;
end
if akm_exp_act
    resid = resid - xb_e;
end

fprintf('\n  --> Full covariance matrix of estimated AKM wage components\n')
cov_mat = [inc, fe_pers, fe_emp];
clear inc
if akm_years
    cov_mat = [cov_mat, xb_y];
end
if akm_age_poly_order
    cov_mat = [cov_mat, xb_a];
end
if akm_hours
    cov_mat = [cov_mat, xb_h];
end
if akm_occ
    cov_mat = [cov_mat, xb_o];
end
if akm_tenure
    cov_mat = [cov_mat, xb_t];
end
if akm_exp_act
    cov_mat = [cov_mat, xb_e];
end
cov_mat = [cov_mat, resid];
C = full(cov(cov_mat));
clear cov_mat resid
cov_str = ' income    person    employer';
if akm_years
    if akm_edu
        cov_str = [cov_str '  edu-year'];
    else
        cov_str = [cov_str '  year    '];
    end
end
if akm_age_poly_order
    if akm_edu
        cov_str = [cov_str '  edu-age'];
    else
        cov_str = [cov_str '  age    '];
    end
end
if akm_hours
    cov_str = [cov_str '   hours'];
end
if akm_occ
    cov_str = [cov_str '     occup'];
end
if akm_tenure
    cov_str = [cov_str '    tenure'];
end
if akm_exp_act
    cov_str = [cov_str '    exp_act'];
end
cov_str = [cov_str '       residual'];
fprintf('\n')
disp(cov_str)
disp(C)
var_y = C(1, 1);
var_y_share = 100*var_y/var_y;
var_pe = C(2, 2);
var_pe_share = 100*var_pe/var_y;
var_fe = C(3, 3);
var_fe_share = 100*var_fe/var_y;
cov_index = 3;
cov_sum_2 = var_y - var_pe - var_fe;
if akm_years
    cov_index = cov_index + 1;
    var_year = C(cov_index, cov_index);
    var_year_share = 100*var_year/var_y;
    cov_sum_2 = cov_sum_2 - var_year;
end
if akm_age_poly_order
    cov_index = cov_index + 1;
    var_age = C(cov_index, cov_index);
    var_age_share = 100*var_age/var_y;
    cov_sum_2 = cov_sum_2 - var_age;
end
if akm_hours
    cov_index = cov_index + 1;
    var_hours = C(cov_index, cov_index);
    var_hours_share = 100*var_hours/var_y;
    cov_sum_2 = cov_sum_2 - var_hours;
end
if akm_occ
    cov_index = cov_index + 1;
    var_occ = C(cov_index, cov_index);
    var_occ_share = 100*var_occ/var_y;
    cov_sum_2 = cov_sum_2 - var_occ;
end
if akm_tenure
    cov_index = cov_index + 1;
    var_tenure = C(cov_index, cov_index);
    var_tenure_share = 100*var_tenure/var_y;
    cov_sum_2 = cov_sum_2 - var_tenure;
end
if akm_exp_act
    cov_index = cov_index + 1;
    var_exp_act = C(cov_index, cov_index);
    var_exp_act_share = 100*var_exp_act/var_y;
    cov_sum_2 = cov_sum_2 - var_exp_act;
end
cov_index = cov_index + 1;
var_resid = C(cov_index, cov_index);
var_resid_share = 100*var_resid/var_y;
cov_sum_2 = cov_sum_2 - var_resid;
cov_sum_2_share = 100*cov_sum_2/var_y;
clear cov_str C cov_index

fprintf('\n  --> Plug-in variance decomposition\n')
disp(['      ...var(income) = ' num2str(var_y) ' (' num2str(var_y_share) '%)'])
disp(['      ...var(worker FE) = ' num2str(var_pe) ' (' num2str(var_pe_share) '%)'])
disp(['      ...var(employer FE) = ' num2str(var_fe) ' (' num2str(var_fe_share) '%)'])
if akm_years
    if akm_edu
        disp(['      ...var(edu-year FE) = ' num2str(var_year) ' (' num2str(var_year_share) '%)'])
    else
        disp(['      ...var(year FE) = ' num2str(var_year) ' (' num2str(var_year_share) '%)'])
    end
    clear var_year var_year_share 
end
if akm_age_poly_order
    if akm_edu
        disp(['      ...var(edu-age FE) = ' num2str(var_age) ' (' num2str(var_age_share) '%)'])
    else
        disp(['      ...var(age FE) = ' num2str(var_age) ' (' num2str(var_age_share) '%)'])
    end
    clear var_age var_age_share
end
if akm_hours
    disp(['      ...var(hours FE) = ' num2str(var_hours) ' (' num2str(var_hours_share) '%)'])
    clear var_hours var_hours_share
end
if akm_occ
    disp(['      ...var(occ FE) = ' num2str(var_occ) ' (' num2str(var_occ_share) '%)'])
    clear var_occ var_occ_share
end
if akm_tenure
    disp(['      ...var(tenure FE) = ' num2str(var_tenure) ' (' num2str(var_tenure_share) '%)'])
    clear var_tenure var_tenure_share
end
if akm_exp_act
    disp(['      ...var(actual exp FE) = ' num2str(var_exp_act) ' (' num2str(var_exp_act_share) '%)'])
    clear var_exp_act var_exp_act_share
end
disp(['      ...2*sum(Cov(.)) = ' num2str(cov_sum_2) ' (' num2str(cov_sum_2_share) '%)'])
disp(['      ...var(resid) = ' num2str(var_resid) ' (' num2str(var_resid_share) '%)'])
clear var_y var_y_share var_pe var_pe_share var_fe var_fe_share akm_edu cov_sum_2 cov_sum_2_share var_resid var_resid_share

fprintf('\n  --> Plug-in correlation between AKM worker and employer fixed effects\n');
rho = corr(fe_pers, fe_emp);
disp(rho)
fprintf('\n')
clear rho

fprintf('\n  --> Write estimation results to tab-delimited output file\n')
eval(['delete ''', FILE_TEMP_OUTPUT, ''''])
FILE_TEMP_OUTPUT_OPEN = fopen(FILE_TEMP_OUTPUT, 'w');
if FILE_TEMP_OUTPUT_OPEN == -1
    fprintf('\nUSER ERROR: Could not open file %s (FILE_TEMP_OUTPUT_OPEN = -1).', FILE_TEMP_OUTPUT)
    exit
end
HEADER_OUTPUT_FORMAT = '%2s\t %10s\t %6s\t %6s';
HEADER_OUTPUT = {'y', 'id_p', 'pe', 'fe'};
DATA_OUTPUT_FORMAT = '%2.0f\t %10.0f\t %6.4f\t %6.4f';
DATA_OUTPUT = [year'; id_pers'; fe_pers'; fe_emp'];
clear FILE_TEMP_OUTPUT year id_pers fe_pers fe_emp
if akm_years
    HEADER_OUTPUT_FORMAT = [HEADER_OUTPUT_FORMAT, '\t %6s'];
    HEADER_OUTPUT{end + 1} = 'xb_y';
    DATA_OUTPUT_FORMAT = [DATA_OUTPUT_FORMAT, '\t %6.4f'];
    DATA_OUTPUT = [DATA_OUTPUT; xb_y'];
    clear xb_y
end
if akm_age_poly_order
    HEADER_OUTPUT_FORMAT = [HEADER_OUTPUT_FORMAT, '\t %6s'];
    HEADER_OUTPUT{end + 1} = 'xb_a';
    DATA_OUTPUT_FORMAT = [DATA_OUTPUT_FORMAT, '\t %6.4f'];
    DATA_OUTPUT = [DATA_OUTPUT; xb_a'];
    clear xb_a
end
if akm_hours
    HEADER_OUTPUT_FORMAT = [HEADER_OUTPUT_FORMAT, '\t %6s'];
    HEADER_OUTPUT{end + 1} = 'xb_h';
    DATA_OUTPUT_FORMAT = [DATA_OUTPUT_FORMAT, '\t %6.4f'];
    DATA_OUTPUT = [DATA_OUTPUT; xb_h'];
    clear xb_h
end
if akm_occ
    HEADER_OUTPUT_FORMAT = [HEADER_OUTPUT_FORMAT, '\t %6s'];
    HEADER_OUTPUT{end + 1} = 'xb_o';
    DATA_OUTPUT_FORMAT = [DATA_OUTPUT_FORMAT, '\t %6.4f'];
    DATA_OUTPUT = [DATA_OUTPUT; xb_o'];
    clear xb_o
end
if akm_tenure
    HEADER_OUTPUT_FORMAT = [HEADER_OUTPUT_FORMAT, '\t %6s'];
    HEADER_OUTPUT{end + 1} = 'xb_t';
    DATA_OUTPUT_FORMAT = [DATA_OUTPUT_FORMAT, '\t %6.4f'];
    DATA_OUTPUT = [DATA_OUTPUT; xb_t'];
    clear xb_t
end
if akm_exp_act
    HEADER_OUTPUT_FORMAT = [HEADER_OUTPUT_FORMAT, '\t %6s'];
    HEADER_OUTPUT{end + 1} = 'xb_e';
    DATA_OUTPUT_FORMAT = [DATA_OUTPUT_FORMAT, '\t %6.4f'];
    DATA_OUTPUT = [DATA_OUTPUT; xb_e'];
    clear xb_e
end
HEADER_OUTPUT_FORMAT = [HEADER_OUTPUT_FORMAT, '\n'];
DATA_OUTPUT_FORMAT = [DATA_OUTPUT_FORMAT, '\n'];
fprintf(FILE_TEMP_OUTPUT_OPEN, HEADER_OUTPUT_FORMAT, HEADER_OUTPUT{:});
fprintf(FILE_TEMP_OUTPUT_OPEN, DATA_OUTPUT_FORMAT, DATA_OUTPUT);
fclose(FILE_TEMP_OUTPUT_OPEN);
clear HEADER_OUTPUT_FORMAT HEADER_OUTPUT DATA_OUTPUT_FORMAT DATA_OUTPUT FILE_TEMP_OUTPUT_OPEN akm_age_poly_order akm_years akm_hours akm_occ akm_tenure akm_exp_act


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF MM_AKM.m')
fprintf('\n==============================================================')

fprintf('\n  --> Close log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> Exit\n')
exit
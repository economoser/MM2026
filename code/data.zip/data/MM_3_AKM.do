********************************************************************************
* FILE NAME:   MM_3_AKM.do
*
* DESCRIPTION: Estimates AKM model to find gender-specific firm pay components
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_3_AKM"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 4

* set random-number stream
clear rngstream
set rngstream 3

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** load and clean data
* call user-defined function to load data
prog_load_data $year_min $year_max "${vars_list} month_hire month_sep id_unique" // i.e., "year id_pers gender edu age id_est ind07_5 muni hours hours_year occ02_6 tenure exp_act earn_mean_mw month_hire month_sep id_unique"

* rename variables
rename id_est id_emp
rename earn_mean_mw inc
if $akm_occ rename occ02_6 occ

* drop variables that are no longer needed
if !$akm_hours drop hours
if !$akm_occ drop occ
if !$akm_tenure drop tenure
if !$akm_exp_act drop exp_act
drop hours_year ind07_5 muni month_hire month_sep

* make sure all variables have nonmissing values
foreach var of varlist * {
	assert `var' < .
}


*** combine with connected set
* restrict to unique job IDs in annual connected set
merge m:1 id_unique ///
	using "${DIR_TEMP}/connected_jobs_annual.dta" ///
	, ///
	keepusing(id_unique) keep(match) nogen
drop id_unique


*** prepare data for estimation of AKM model
* apply uniform upper-income winsorizing
if $year_min < 2001 & $year_max >= 2001 replace inc = min(inc, 120) if inc < .

* convert income to natural logarithm
gen float inc_ln = ln(inc)
drop inc
rename inc_ln inc
lab var inc "Earnings (log multiples of MW)"

* create potential experience (= years of age - years of education - 6)
if $akm_exp_act | $akm_tenure {
	recode edu ///
		(1 = 0) ///
		(2 = 3) ///
		(3 = 5) ///
		(4 = 8) ///
		(5 = 9) ///
		(6 = 11) ///
		(7 = 12) ///
		(8 = 14) ///
		(9 = 16) ///
		(nonmissing = .) ///
		, ///
		generate(edu_y) // codes: 1 "Illiterate (0 years)" 2 "Some primary school (1-5 years)" 3 "Primary school degree (5 years)" 4 "Some middle school (6-9 years)" 5 "Middle school degree (9 years)" 6 "Some high school (10-12 years)" 7 "High school degree (12 years)" 8 "Some college (13-15 years)" 9 "Bachelor's or higher degree (16+ years)"
	lab var edu_y "Years of education"
	gen byte exp_pot = max(age - edu_y - 6, 0)
	lab var exp_pot "Potential experience (age - years of education - 6)"
	drop edu_y
}

* transform actual experience
if $akm_exp_act {
	replace exp_act = min(floor(exp_act/12), exp_pot)
	lab var exp_act "Actual experience in formal sector (years)"
}

* transform tenure
if $akm_tenure {
	if $akm_exp_act replace tenure = min(floor(tenure/12), exp_pot, exp_act)
	else replace tenure = min(floor(tenure/12), exp_pot)
	lab var tenure "Tenure in current job (years)"
}

* drop potential experience, since collinear with year FE and person FE
if $akm_exp_act | $akm_tenure drop exp_pot

* convert year to MATLAB format
replace year = year - ${year_min} + 1 // generate numerical year starting from 1
rename year year_akm
lab var year_akm "Year (AKM format)"

* prepare to export age variable if higher-order age terms or restricted set of dummies are to be included, and education variable if experience is to be interacted with education
if $akm_age_poly_order local var_age = "age" // if AKM estimation includes higher-order age terms
else local var_age = ""
if $akm_edu local var_edu = "edu" // if AKM estimation includes year effects and age effects (or higher-order age terms) interacted with education
else local var_edu = ""

* coarsen variables
if $akm_N_coarsen > 1 {
	if $akm_hours prog_coarsen "hours" ${akm_N_coarsen}
	if $akm_occ prog_coarsen "occ" ${akm_N_coarsen}
	if $akm_tenure prog_coarsen "tenure" ${akm_N_coarsen}
	if $akm_exp_act prog_coarsen "exp_act" ${akm_N_coarsen}
}

* check that all variables are nonmissing
foreach var of varlist * {
	assert `var' < .
}

* save
if $akm_hours local var_hours = "hours"
else local var_hours = ""
if $akm_occ local var_occ = "occ"
else local var_occ = ""
if $akm_tenure local var_tenure = "tenure"
else local var_tenure = ""
if $akm_exp_act local var_exp_act = "exp_act"
else local var_exp_act = ""
order year_akm id_pers id_emp gender inc `var_age' `var_edu' `var_hours' `var_occ' `var_tenure' `var_exp_act' // list of variables currently used: year id_pers gender edu age id_emp inc; list of variables currently not used: hours occ tenure exp_act
sort id_pers year_akm
prog_comp_desc_sum_save "${DIR_TEMP}/temp_akm.dta"


*** estimate AKM model in MATLAB
* loop over genders
forval g = 1/2 {
	di "--> gender = `g' (1 = male; 2 = female)" // Note: Could add more categories here -- e.g., parents vs. nonparents of each gender.
	local first = (`g' == 1)
	local last = (`g' == 2)
	
	di "* load data"
	use ///
		if gender == `g' ///
		using "${DIR_TEMP}/temp_akm.dta", clear
	drop gender
	
	di "* format variables"
	local var_list = "year_akm id_pers id_emp inc"
	if $akm_age_poly_order local var_list = "`var_list' age"
	if $akm_edu local var_list = "`var_list' edu"
	if $akm_hours local var_list = "`var_list' hours"
	if $akm_occ local var_list = "`var_list' occ"
	if $akm_tenure local var_list = "`var_list' tenure"
	if $akm_exp_act local var_list = "`var_list' exp_act"
	foreach var of local var_list {
		sum `var', meanonly
		if "`var'" == "inc" format `var' %`= ceil(max(log10(abs(r(min))),log10(abs(r(max))))) + 6'.6f
		else format `var' %`= ceil(max(log10(abs(r(min))),log10(abs(r(max)))))'.0f
	}
	
	di "* sort by worker ID and year" // Note: Must sort the input data by worker ID and year for MATLAB.
	sort id_pers year_akm
	
	di "* export AKM inputs: year IDs, worker IDs, employer IDs, wages, and possibly other covariates"
	compress
	desc
	sum, sep(0)
	export delim ///
		year_akm id_pers id_emp inc `var_age' `var_edu' `var_hours' `var_occ' `var_tenure' `var_exp_act' ///
		using "${DIR_TEMP}/input_akm.csv" ///
		, ///
		delim(tab) novarnames nolab replace

	di "* export parameters"
	clear
	set obs 1
	gen byte akm_age_poly_order = ${akm_age_poly_order}
	gen int akm_age_flat_min = ${akm_age_flat_min}
	gen int akm_age_flat_max = ${akm_age_flat_max}
	gen int akm_age_norm = ${akm_age_norm}
	gen int age_min = ${age_min}
	gen int age_max = ${age_max}
	gen byte akm_years = ${akm_years}
	gen byte akm_edu = ${akm_edu}
	gen byte akm_hours = ${akm_hours}
	gen byte akm_occ = ${akm_occ}
	gen byte akm_tenure = ${akm_tenure}
	gen byte akm_exp_act = ${akm_exp_act}
	format akm_age_poly_order akm_edu akm_hours akm_occ akm_tenure akm_exp_act %1.0f
	format akm_age_flat_min akm_age_flat_max akm_age_norm age_min age_max %3.0f
	compress
	desc
	sum, sep(0)
	export delim ///
		akm_age_poly_order akm_age_flat_min akm_age_flat_max akm_age_norm age_min age_max akm_years akm_edu akm_hours akm_occ akm_tenure akm_exp_act ///
		using "${DIR_TEMP}/parameters_akm.csv" ///
		, ///
		delim(tab) novarnames nolab replace
	
	di "* estimate AKM wage components"
	clear
	cap rm "${DIR_TEMP}/output_akm.csv"
	qui cd "${DIR_TEMP}" // set current directory so that MATLAB finds the right folder structure
	!${arch}"${APP_MATLAB}" -nodesktop -nojvm -nodisplay <"${DIR_DO_DATA}/MM_AKM.m"
	cap confirm file "${DIR_TEMP}/output_akm.csv"
	while _rc { // if file does not exist yet
		sleep 60000
		cap confirm file "${DIR_TEMP}/output_akm.csv"
	}
	qui cd // reset current directory

	di "* read MATLAB output"
	import delim ///
		using "${DIR_TEMP}/output_akm.csv" ///
		, asdouble varnames(1) delim(tab) clear
	rm "${DIR_TEMP}/output_akm.csv"
	rename y year_akm
	lab var year_akm "Year (AKM format)"
	rename id_p id_pers
	lab var id_pers "Worker ID (deidentified)"
	rename pe fe_pers
	lab var fe_pers "Predicted AKM worker fixed effect"
	rename fe fe_emp
	lab var fe_emp "Predicted AKM employer FE"
	rename xb_y xb_year
	if $akm_edu lab var xb_year "Predicted AKM education-year FE"
	else lab var xb_year "Predicted AKM year FE"
	if $akm_age_poly_order {
		rename xb_a xb_age
		if $akm_age_poly_order == 1 {
			if $akm_edu lab var xb_age "Predicted AKM education-age FE"
			else lab var xb_age "Predicted AKM age FE"
		}
		else if $akm_age_poly_order >= 2 {
			if $akm_edu lab var xb_age "Predicted AKM higher-order education-age terms"
			else lab var xb_age "Predicted AKM higher-order age terms"
		}
	}
	if $akm_hours {
		rename xb_h xb_hours
		lab var xb_hours "Predicted AKM hours FE"
	}
	if $akm_occ {
		rename xb_o xb_occ
		lab var xb_occ "Predicted AKM occupation FE"
	}
	if $akm_tenure {
		rename xb_t xb_tenure
		lab var xb_tenure "Predicted AKM tenure FE"
	}
	if $akm_exp_act {
		rename xb_e xb_exp_act
		lab var xb_exp_act "Predicted AKM actual-experience FE"
	}
	
	di "* recast AKM estimates to float data types"
	foreach var in fe_pers fe_emp xb_year xb_age xb_hours xb_occ xb_tenure xb_exp_act {
		cap confirm var `var'
		if !_rc recast float `var', force
	}
	
	di "* append files"
	if !`first' append using "${DIR_TEMP}/temp_akm_gender.dta"
	if !`last' prog_comp_desc_sum_save "${DIR_TEMP}/temp_akm_gender.dta"
}

* get other variables for each worker-year
merge 1:1 year_akm id_pers ///
	using "${DIR_TEMP}/temp_akm.dta" ///
	, ///
	keepusing(year_akm id_pers id_emp gender inc `var_age' `var_edu' `var_hours' `var_occ' `var_tenure' `var_exp_act') keep(master match) nogen
rm "${DIR_TEMP}/temp_akm.dta"
cap rm "${DIR_TEMP}/temp_akm_gender.dta"

* convert year back to standard format
replace year_akm = year_akm + ${year_min} - 1
rename year_akm year
lab var year "Year"

* save AKM estimates
local var_list = "year id_pers id_emp gender inc `var_age' `var_edu' `var_hours' `var_occ' `var_tenure' `var_exp_act'"
if $akm_age_poly_order local var_list = "`var_list' age"
if $akm_edu local var_list = "`var_list' edu"
if $akm_hours local var_list = "`var_list' hours"
if $akm_occ local var_list = "`var_list' occ"
if $akm_tenure local var_list = "`var_list' tenure"
if $akm_exp_act local var_list = "`var_list' exp_act"
order `var_list'
sort id_pers year
prog_comp_desc_sum_save "${DIR_TEMP}/akm.dta"


*** save AKM estimates separately
* save file with predicted AKM employer FEs only
use ///
	id_emp gender fe_emp ///
	if id_emp < . & fe_emp < . ///
	using "${DIR_TEMP}/akm.dta", clear
bys id_emp gender: keep if _n == 1
order id_emp gender fe_emp
sort id_emp gender
prog_comp_desc_sum_save "${DIR_TEMP}/akm_fe_emp.dta"

* save file with predicted AKM year FEs only
use ///
	gender `var_edu' year xb_year ///
	if year < . & xb_year < . ///
	using "${DIR_TEMP}/akm.dta", clear
bys gender `var_edu' year: keep if _n == 1
order gender `var_edu' year xb_year
sort gender `var_edu' year
prog_comp_desc_sum_save "${DIR_TEMP}/akm_xb_year.dta"

* save file with only predicted AKM age FEs or higher-order age terms
if $akm_age_poly_order {
	use ///
		gender `var_edu' age xb_age ///
		if age < . & xb_age < . ///
		using "${DIR_TEMP}/akm.dta", clear
	bys gender `var_edu' age: keep if _n == 1
	order gender `var_edu' age xb_age
	sort gender `var_edu' age
	prog_comp_desc_sum_save "${DIR_TEMP}/akm_xb_age.dta"
}

* save file with predicted AKM hours FEs only
if $akm_hours {
	use ///
		gender hours xb_hours ///
		if hours < . & xb_hours < . ///
		using "${DIR_TEMP}/akm.dta", clear
	bys gender hours: keep if _n == 1
	order gender hours xb_hours
	sort gender hours
	prog_comp_desc_sum_save "${DIR_TEMP}/akm_xb_hours.dta"
}

* save file with predicted AKM occupation FEs only
if $akm_occ {
	use ///
		gender occ xb_occ ///
		if occ < . & xb_occ < . ///
		using "${DIR_TEMP}/akm.dta", clear
	bys gender occ: keep if _n == 1
	order gender occ xb_occ
	sort gender occ
	prog_comp_desc_sum_save "${DIR_TEMP}/akm_xb_occ.dta"
}

* save file with predicted AKM tenure FEs only
if $akm_tenure {
	use ///
		gender tenure xb_tenure ///
		if tenure < . & xb_tenure < . ///
		using "${DIR_TEMP}/akm.dta", clear
	bys gender tenure: keep if _n == 1
	order gender tenure xb_tenure
	sort gender tenure
	prog_comp_desc_sum_save "${DIR_TEMP}/akm_xb_tenure.dta"
}

* save file with predicted AKM actual-experience FEs only
if $akm_exp_act {
	use ///
		gender exp_act xb_exp_act ///
		if exp_act < . & xb_exp_act < . ///
		using "${DIR_TEMP}/akm.dta", clear
	bys gender exp_act: keep if _n == 1
	order gender exp_act xb_exp_act
	sort gender exp_act
	prog_comp_desc_sum_save "${DIR_TEMP}/akm_xb_exp_act.dta"
}


*** KSS bias correction
forval g = 1/2 {
	di "--> gender = `g'"

	* define list of variables to load
	local use_vars = "inc"
	if (${akm_edu} & (${akm_years} | ${akm_age_poly_order})) | ${akm_tenure} | ${akm_exp_act} local use_vars = "`use_vars' edu"
	if ${akm_age_poly_order} local use_vars = "`use_vars' age"
	if ${akm_hours} local use_vars = "`use_vars' hours"
	if ${akm_occ} local use_vars = "`use_vars' occ"
	if ${akm_tenure} local use_vars = "`use_vars' tenure"
	if ${akm_exp_act} local use_vars = "`use_vars' exp_act"

	* load data
	use ///
		id_pers year id_emp gender id_unique ///
		if gender == `g' ///
		using "${DIR_TEMP}/selection_annual.dta", clear
	drop gender

	* merge in relevant covariates
	merge 1:1 id_unique using "${DIR_TEMP}/load_${year_min}_${year_max}.dta", keepusing(`use_vars') keep(match) nogen

	* convert earnings to natural logarithm
	gen float inc_ln = ln(inc)
	label var inc_ln "Mean monthly earnings (log multiples of MW)"
	rename inc inc_lvl
	label var inc_lvl "Mean monthly earnings (multiples of MW)"

	* create potential experience (= years of age - years of education - 6)
	if ($akm_tenure | $akm_exp_act) {
		recode edu (1=0) (2=3) (3=5) (4=7) (5=9) (6=11) (7=12) (8=14) (9=16) (nonmissing=.), generate(edu_y) // codes: 1 "Illiterate (0 years)" 2 "Some primary school (1-5 years)" 3 "Primary school degree (5 years)" 4 "Some middle school (6-9 years)" 5 "Middle school degree (9 years)" 6 "Some high school (10-12 years)" 7 "High school degree (12 years)" 8 "Some college (13-15 years)" 9 "Bachelor's or higher degree (16+ years)"
		label var edu_y "Years of education"
		gen byte exp_pot = age - edu_y - 6
		drop edu_y
		label var exp_pot "Potential experience (years of age - years of education - 6)"
		replace exp_pot = max(min(exp_pot, age - 6), 0)
	}

	* transform actual experience
	if $akm_exp_act {
		replace exp_act = min(floor(exp_act/12), exp_pot)
		label var exp_act "Actual experience (years in formal sector)"
	}

	* transform tenure
	if $akm_tenure {
		if $akm_exp_act replace tenure = min(floor(tenure/12), exp_pot, exp_act)
		else replace tenure = min(floor(tenure/12), exp_pot)
		label var tenure "Tenure (years at current employer)"
	}

	* drop potential experience, since collinear with year FE and person FE
	if ($akm_tenure | $akm_exp_act) drop exp_pot

	* format year so it can be read by MATLAB
	replace year = year - ${year_min} + 1 // generate numerical year starting from 1
	rename year year_akm
	label var year_akm "Year (AKM format)"

	* prepare to outsheet age variable if higher-order age terms are to be included
	if $akm_age_poly_order global age_outsheet = "age" // if AKM estimation includes higher-order age terms
	else global age_outsheet = ""
	if $akm_edu global edu_outsheet = "edu" // if AKM estimation includes year effects and age effects (or higher-order age terms) interacted with education
	else global edu_outsheet = ""

	* check that all variables are nonmissing
	sum, sep(0)
	foreach var of varlist * {
		assert `var' < .
	}

	* coarsen variables
	if $akm_coarsen {
		if $akm_hours prog_coarsen "hours" ${akm_N_coarsen}
		if $akm_occ prog_coarsen "occ" ${akm_N_coarsen}
		if $akm_tenure prog_coarsen "tenure" ${akm_N_coarsen}
		if $akm_exp_act prog_coarsen "exp_act" ${akm_N_coarsen}
	}

	* format variables for file export
	if $akm_hours global hours_outsheet = "hours"
	else global hours_outsheet = ""
	if $akm_occ global occ_outsheet = "occ"
	else global occ_outsheet = ""
	if $akm_tenure global tenure_outsheet = "tenure"
	else global tenure_outsheet = ""
	if $akm_exp_act global exp_act_outsheet = "exp_act"
	else global exp_act_outsheet = ""
	local vars_format = "inc_ln id_pers id_emp year_akm"
	if $akm_age_poly_order local vars_format = "`vars_format' age"
	if $akm_edu local vars_format = "`vars_format' edu"
	if $akm_hours local vars_format = "`vars_format' hours"
	if $akm_occ local vars_format = "`vars_format' occ"
	if $akm_tenure local vars_format = "`vars_format' tenure"
	if $akm_exp_act local vars_format = "`vars_format' exp_act"
	foreach var of local vars_format {
		sum `var', meanonly
		if "`var'" == "inc_ln" format `var' %`=ceil(max(log10(abs(r(min))),log10(abs(r(max))))) + 6'.6f
		else format `var' %`=ceil(max(log10(abs(r(min))),log10(abs(r(max)))))'.0f
	}

	* outsheet list of wages, worker IDs, employer IDs, year IDs (and possibly covariates)
	local vars = "inc_ln id_pers id_emp year_akm ${age_outsheet} ${edu_outsheet} ${hours_outsheet} ${occ_outsheet} ${tenure_outsheet} ${exp_act_outsheet}"
	order `vars'
	sort id_pers year_akm
	compress
	desc
	sum `vars', sep(0)
	export delim `vars' using "${DIR_TEMP}/input_akm_kss.csv", delim(tab) novarnames nolabel replace

	* prepare file with parameters
	clear
	set obs 1
	gen byte gender = `g'
	gen byte akm_age_poly_order = ${akm_age_poly_order}
	gen int akm_age_flat_min = ${akm_age_flat_min}
	gen int akm_age_flat_max = ${akm_age_flat_max}
	gen int akm_age_norm = ${akm_age_norm}
	gen int age_min = ${age_min}
	gen int age_max = ${age_max}
	gen byte akm_years = ${akm_years}
	gen byte akm_edu = ${akm_edu}
	gen byte akm_hours = ${akm_hours}
	gen byte akm_occ = ${akm_occ}
	gen byte akm_tenure = ${akm_tenure}
	gen byte akm_exp_act = ${akm_exp_act}
	format gender akm_age_poly_order akm_edu akm_hours akm_occ akm_tenure akm_exp_act %1.0f
	format akm_age_flat_min akm_age_flat_max akm_age_norm age_min age_max %3.0f
	compress
	export delim ///
		gender akm_age_poly_order akm_age_flat_min akm_age_flat_max akm_age_norm age_min age_max akm_years akm_edu akm_hours akm_occ akm_tenure akm_exp_act ///
		using "${DIR_TEMP}/parameters_akm_kss.csv", delim(tab) novarnames nolabel replace
	clear

	di "* estimate KSS correction to AKM wage decomposition"
	qui cd "${DIR_TEMP}" // set current directory so that MATLAB finds the right folder structure
	!${arch}"${APP_MATLAB}" -nodesktop -nodisplay <"${DIR_DO_DATA}/MM_AKM_KSS.m"
	qui cd // reset current directory
	
	* delete old data files used in AKM estimation
	cap rm "${DIR_TEMP}/input_akm_kss.csv"
}


*** summarize AKM wage components and compute variance decomposition
* load AKM estimates
use ///
	year id_emp gender inc fe_pers fe_emp xb_year xb_age xb_hours xb_occ xb_tenure xb_exp_act ///
	using "${DIR_TEMP}/akm.dta", clear

* generate gender-specific employer sizes
bys id_emp gender year: gen byte unique_emp_gender_year = 1 if _n == 1
lab var unique_emp_gender_year "Ind: Unique employer-gender-year?"
if _N < 2147483647 local gtools = "${gtools}"
else local gtools = ""
if "`gtools'" == "g" gegen byte N_years = total(unique_emp_gender_year), by(id_emp gender)
else bys id_emp gender: egen byte N_years = total(unique_emp_gender_year)
drop unique_emp_gender_year
bys id_emp gender: gen double size_g = _N
replace size_g = size_g/N_years
lab var size_g "Mean number of workers by gender"
drop id_emp N_years

* generate residual
gen float resid = inc - fe_pers - fe_emp - xb_year - xb_age
if $akm_hours replace resid = resid - xb_hours
if $akm_occ replace resid = resid - xb_occ
if $akm_tenure replace resid = resid - xb_tenure
if $akm_exp_act replace resid = resid - xb_exp_act
lab var resid "Predicted AKM gender-specific residual"

* open postfile
cap postclose postfile_akm
postfile postfile_akm ///
	gender ///
	size_g_min ///
	var_inc ///
	var_fe_pers var_fe_emp ///
	var_xb_year var_xb_age var_xb_hours var_xb_occ var_xb_tenure var_xb_exp_act ///
	var_resid ///
	cov_sum ///
	share_inc ///
	share_fe_pers share_fe_emp ///
	share_xb_year share_xb_age share_xb_hours share_xb_occ share_xb_tenure share_xb_exp_act ///
	share_resid ///
	share_cov_sum ///
	cov_inc_inc cov_inc_fe_pers cov_inc_fe_emp cov_inc_xb_year cov_inc_xb_age cov_inc_xb_hours cov_inc_xb_occ cov_inc_xb_tenure cov_inc_xb_exp_act cov_inc_resid ///
	share_cov_inc_inc share_cov_inc_fe_pers share_cov_inc_fe_emp share_cov_inc_xb_year share_cov_inc_xb_age share_cov_inc_xb_hours share_cov_inc_xb_occ share_cov_inc_xb_tenure share_cov_inc_xb_exp_act share_cov_inc_resid ///
	corr_pers_emp r2 N ///
	using "${DIR_TEMP}/postfile_akm.dta", replace

* compute variance decomposition
prog_comp_desc_sum_save "${DIR_TEMP}/temp_akm_decomp.dta"
forval g = 1/2 {
	di _newline(5) "  --> gender = `g' (1 = male; 2 = female)" // Note: Could add more categories here -- e.g., parents vs. nonparents of each gender.
	local first = (`g' == 1)
	
	di "* load data"
	if `first' keep if gender == `g'
	else {
		use ///
			if gender == `g' ///
			using "${DIR_TEMP}/temp_akm_decomp.dta", clear
	}
	
	di "* compute variance decomposition"
	local cov_list = "inc fe_pers fe_emp xb_year xb_age"
	if $akm_hours local cov_list = "`cov_list' xb_hours"
	if $akm_occ local cov_list = "`cov_list' xb_occ"
	if $akm_tenure local cov_list = "`cov_list' xb_tenure"
	if $akm_exp_act local cov_list = "`cov_list' xb_exp_act"
	local cov_list = "`cov_list' resid"
	foreach size_g_min in 0 {
		di _newline(2) "    ...variance decomposition for gender = `g' and employer size >= `size_g_min'"
		count if size_g >= `size_g_min' & size_g < .
		local N = r(N)
		local N_disp: di %12.0fc `N'
		if r(N) > 0 {
			corr `cov_list' if size_g >= `size_g_min' & size_g < ., cov
			matrix C = r(C)
			corr fe_pers fe_emp if size_g >= `size_g_min' & size_g < .
			local rho_pers_emp = r(rho)
			local corr_pers_emp: di %4.3f `rho_pers_emp'
			local cov_counter = 1
			foreach var of local cov_list {
				local var_`var' = C[`cov_counter', `cov_counter']
				local var_`var'_disp: di %4.3f `var_`var''
				if "`var'" == "inc" local cov_sum = `var_inc'
				else local cov_sum = `cov_sum' - `var_`var''
				local cov_inc_`var' = C[1, `cov_counter']
				local ++cov_counter
			}
			foreach var of local cov_list {
				local share_`var' = 100*`var_`var''/`var_inc'
				local share_`var'_disp: di %3.1f `share_`var''
				local share_cov_inc_`var' = 100*`cov_inc_`var''/`cov_inc_inc'
				local share_cov_inc_`var'_disp: di %3.1f `share_cov_`var''
			}
			local cov_sum_disp: di %4.3f `cov_sum'
			local share_cov_sum = 100*`cov_sum'/`var_inc'
			local share_cov_sum_disp: di %3.1f `share_cov_sum'
			local r2 = 1 - `share_resid'/100
			local r2_disp: di %4.3f `r2'
			foreach var of local cov_list {
				if "`var'" != "resid" di "Var(`var') = `var_`var'_disp' (`share_`var'_disp'%)"
			}
			di "2*sum(Cov(.)) = `cov_sum_disp' (`share_cov_sum_disp'%)"
			di "Var(resid) = `var_resid_disp' (`share_resid_disp'%)"
			di "Corr(fe_pers, fe_emp) = `corr_pers_emp'"
			di "Observations = `N_disp'"
			di "R^2 = `r2_disp'"
		}
		
		* ensure that all local macros exist
		foreach l in ///
			var_xb_hours var_xb_occ var_xb_tenure var_xb_exp_act ///
			share_xb_hours share_xb_occ share_xb_tenure share_xb_exp_act ///
			cov_inc_inc cov_inc_fe_pers cov_inc_fe_emp cov_inc_xb_year cov_inc_xb_age cov_inc_xb_hours cov_inc_xb_occ cov_inc_xb_tenure cov_inc_xb_exp_act cov_inc_resid ///
			share_cov_inc_inc share_cov_inc_fe_pers share_cov_inc_fe_emp share_cov_inc_xb_year share_cov_inc_xb_age share_cov_inc_xb_hours share_cov_inc_xb_occ share_cov_inc_xb_tenure share_cov_inc_xb_exp_act share_cov_inc_resid ///
			{
			if "`l'" == "" local `l' = .
		}

		* write to postfile
		post postfile_akm ///
			(`g') ///
			(`size_g_min') ///
			(`var_inc') ///
			(`var_fe_pers') (`var_fe_emp') ///
			(`var_xb_year') (`var_xb_age') (`var_xb_hours') (`var_xb_occ') (`var_xb_tenure') (`var_xb_exp_act') ///
			(`var_resid') ///
			(`cov_sum') ///
			(`share_inc') ///
			(`share_fe_pers') (`share_fe_emp') ///
			(`share_xb_year') (`share_xb_age') (`share_xb_hours') (`share_xb_occ') (`share_xb_tenure') (`share_xb_exp_act') ///
			(`share_resid') ///
			(`share_cov_sum') ///
			(`cov_inc_inc') (`cov_inc_fe_pers') (`cov_inc_fe_emp') (`cov_inc_xb_year') (`cov_inc_xb_age') (`cov_inc_xb_hours') (`cov_inc_xb_occ') (`cov_inc_xb_tenure') (`cov_inc_xb_exp_act') (`cov_inc_resid') ///
			(`share_cov_inc_inc') (`share_cov_inc_fe_pers') (`share_cov_inc_fe_emp') (`share_cov_inc_xb_year') (`share_cov_inc_xb_age') (`share_cov_inc_xb_hours') (`share_cov_inc_xb_occ') (`share_cov_inc_xb_tenure') (`share_cov_inc_xb_exp_act') (`share_cov_inc_resid') ///
			(`corr_pers_emp') (`r2') (`N')
	}
}
rm "${DIR_TEMP}/temp_akm_decomp.dta"

* close postfile
postclose postfile_akm

* format postfile
use "${DIR_TEMP}/postfile_akm.dta", clear
lab var gender "Gender"
lab def gen_l 1 "1: Male" 2 "2: Female", replace
lab val gender gen_l
lab var size_g_min "Minimum gender-specific employer size"
lab var var_inc "Variance of log earnings"
lab var var_fe_pers "Variance of person FEs"
lab var var_fe_emp "Variance of employer FEs"
lab var var_xb_year "Variance of education-specific year FEs"
lab var var_xb_age "Variance of education-specific age FEs"
lab var var_xb_hours "Variance of hour FEs"
lab var var_xb_occ "Variance of occupation FEs"
lab var var_xb_tenure "Variance of tenure FEs"
lab var var_xb_exp_act "Variance of actual-experience FEs"
lab var var_resid "Variance of residual"
lab var cov_sum "2 times sum of covariances"
lab var share_inc "Share of variance of log earnings"
lab var share_fe_pers "Share of variance of person FEs"
lab var share_fe_emp "Share of variance of employer FEs"
lab var share_xb_year "Share of variance of education-specific year FEs"
lab var share_xb_age "Share of variance of education-specific age FEs"
lab var share_xb_hours "Share of variance of hour FEs"
lab var share_xb_occ "Share of variance of occupation FEs"
lab var share_xb_tenure "Share of variance of tenure FEs"
lab var share_xb_exp_act "Share of variance of actual-experience FEs"
lab var share_resid "Share of variance of residual"
lab var share_cov_sum "Share of 2 times sum of covariances"
lab var cov_inc_inc "Covariance between log earnings and itself"
lab var cov_inc_fe_pers "Covariance between log earnings and person FEs"
lab var cov_inc_fe_emp "Covariance between log earnings and employer FEs"
lab var cov_inc_xb_year "Covariance between log earnings and education-specific year FEs"
lab var cov_inc_xb_age "Covariance between log earnings and education-specific age FEs"
lab var cov_inc_xb_hours "Covariance between log earnings and hour FEs"
lab var cov_inc_xb_occ "Covariance between log earnings and occupation FEs"
lab var cov_inc_xb_tenure "Covariance between log earnings and tenure FEs"
lab var cov_inc_xb_exp_act "Covariance between log earnings and actual-experience FEs"
lab var cov_inc_resid "Covariance between log earnings and residual"
lab var share_cov_inc_inc "Share of covariance between log earnings and itself"
lab var share_cov_inc_fe_pers "Share of covariance between log earnings and person FEs"
lab var share_cov_inc_fe_emp "Share of covariance between log earnings and employer FEs"
lab var share_cov_inc_xb_year "Share of covariance between log earnings and education-specific year FEs"
lab var share_cov_inc_xb_age "Share of covariance between log earnings and education-specific age FEs"
lab var share_cov_inc_xb_hours "Share of covariance between log earnings and hour FEs"
lab var share_cov_inc_xb_occ "Share of covariance between log earnings and occupation FEs"
lab var share_cov_inc_xb_tenure "Share of covariance between log earnings and tenure FEs"
lab var share_cov_inc_xb_exp_act "Share of covariance between log earnings and actual-experience FEs"
lab var share_cov_inc_resid "Share of covariance between log earnings and residual"
lab var corr_pers_emp "Correlation between person FEs and employer FEs"
lab var r2 "Coefficient of determination (R^2)"
recast long N, force
lab var N "Number of observations"

* save formatted postfile for AKM decomposition
keep if size_g_min == 0
drop size_g_min
prog_comp_desc_sum_save "${DIR_TEMP}/akm_decomp.dta"


*** final housekeeping
* clean up
if $clean_up {
	cap rm "${DIR_TEMP}/parameters_akm.csv"
	cap rm "${DIR_TEMP}/parameters_akm_kss.csv"
	cap rm "${DIR_TEMP}/input_akm.csv"
	cap rm "${DIR_TEMP}/input_akm_kss.csv"
	cap rm "${DIR_TEMP}/output_akm.csv"
	cap rm "${DIR_TEMP}/output_akm_kss.csv"
}

* turn timer off
timer off 4

* print final banner
di _newline(5)
timer list 4
local t = r(t4)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_3_AKM.do
********************************************************************************

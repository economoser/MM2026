********************************************************************************
* FILE NAME:   MM_8_POST_EST.do
*
* DESCRIPTION: Creates files for post-estimation analysis
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_8_POST_EST"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 9

* set random-number stream
clear rngstream
set rngstream 8

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** create file for post-estimation analysis
* load data
use "${DIR_TEMP}/firm_parameters_merged_match${match_F_or_G}_${baseline_rank}_p_pi_z.dta", clear // note: this file also contains the economy-wide parameters eta_v and eta_pi as well as the gender-firm specific parameters c_pi_m and c_pi_f -- ignore c_m and c_f because they are placeholders!

* drop variables that are no longer needed
drop fe_rank_m fe_rank_f eta_v p c_m c_f

* replace variables
foreach g in m f {
	gen double ptilde_`g' = p_${baseline_rank}_`g' + pi_`g'
	if "`g'" == "m" lab var ptilde_`g' "Composite productivity (p^tilde)"
	else if "`g'" == "f" lab var ptilde_`g' "Composite productivity (p^tilde, incl. gender wedge)"
	drop p_${baseline_rank}_`g'
}

* rename variables
local baseline_rank = ${baseline_rank}
foreach var of varlist *_`baseline_rank'_* {
	local n = subinstr("`var'", "_${baseline_rank}_", "_", .)
	rename `var' `n'
}
foreach g in m f {
	rename fe_`g' log_w_`g'
	lab var log_w_`g' "Log pay (`g')"
	rename phys_p_`g' p_`g'
	if "`g'" == "m" lab var p_m "Physical productivity (p)"
	else if "`g'" == "f" {
		lab var p_f "Physical productivity net of gender wedge ((1 - \tau)p)"
	}
}

* relabel variables
lab var size_m "Employer size (m)"
lab var size_f "Employer size (f)"

* create variables in levels
foreach g in m f {
	gen double w_`g' = exp(log_w_`g')
	lab var w_`g' "Level pay (`g')"
}

* generate flow utility
foreach g in m f {
	gen double x_`g' = w_`g' + pi_`g'
	lab var x_`g' "Level flow utility (`g')"
}

* generate total employment
egen double size = rowtotal(size_m size_f)
lab var size "Total employmer size (m + f)"

* create variables in logs
foreach g in m f {
	gen double log_pi_`g' = ln(pi_`g')
	lab var log_pi_`g' "Log amenity (`g')"
	gen double log_x_`g' = ln(x_`g')
	lab var log_x_`g' "Log flow utility (`g')"
	gen double log_size_`g' = ln(size_`g')
	lab var log_size_`g' "Log employer size (`g')"
}
gen double log_size = ln(size)
lab var log_size "Log employer size (m + f)"

* generate total employment shares
egen double g = rowtotal(g_m g_f)
sum g, meanonly
replace g = g/r(sum)
lab var g "Total employment PMF (m + f)"

* generate gender wedge
gen double tau = 1 - p_f/p_m // i.e., p_f = (1 - tau)*p_m <==> tau = 1 - p_f/p_m
lab var tau "Gender wedge at dual-gender firms (tau = 1 - p_f/p_m)"
gen double log_1_minus_tau = ln(p_f/p_m) // note: log(p_f) = log((1 - tau)*p_m) <==> log(1 - tau) = log(p_f/p_m)
lab var log_1_minus_tau "Log(1 - gender wedge) at dual-gender firms (log(1 - tau) = log(p_f/p_m))"

* generate log productivity
foreach g in m f {
	gen log_p_`g' = ln(p_`g')
	if "`g'" == "m" lab var log_p_m "Log physical productivity (p)"
	else if "`g'" == "f" {
		lab var log_p_f "Log physical productivity net of gender wedge ((1 - \tau)p)"
	}
}

* generate log composite productivity
foreach g in m f {
	gen log_ptilde_`g' = ln(ptilde_`g')
	if "`g'" == "m" lab var log_ptilde_m "Log composite productivity (p^tilde)"
	else if "`g'" == "f" lab var log_ptilde_f "Log composite productivity (p^tilde, incl. gender wedge)"
}

* save data
order ///
	id_emp /// employer ID
	f_m f_f f_smooth_m f_smooth_f F_m F_f /// offer distributions
	g_m g_f g G_m G_f /// employment distributions
	size_m size_f size log_size_m log_size_f log_size /// empirical employer sizes
	cardinality_m cardinality_f /// (implied) employer size -- i.e., size if rank_concept = 5 or PageRank if rank_concept = 7
	model_size_m model_size_f /// model-implied employer sizes
	rank_m rank_f /// ranks
	x_m x_f log_x_m log_x_f /// flow utilities
	w_m w_f log_w_m log_w_f /// pay
	pi_m pi_f log_pi_m log_pi_f /// amenities
	c_pi_m c_pi_f /// amenity cost parameters
	p_m p_f log_p_m log_p_f /// productivity (net of gender wedge for women)
	ptilde_m ptilde_f log_ptilde_m log_ptilde_f /// composite productivity (net of gender wedge for women)
	tau log_1_minus_tau /// gender wedge
	public /// public-sector indicator
	eta_pi // elasticity of the amenity cost function
sort id_emp
prog_comp_desc_sum_save "${DIR_TEMP}/post_est.dta"


*** labor market parameters and moments
* load flow values of nonemployment by gender
import delim using "${DIR_TEMP}/lab_params_flow_values_${baseline_rank}.txt", delim(tab) clear // note: this file is produced in the model estimation routines!
local b_1 = b_m[1]
local b_2 = b_f[1]

* load labor market parameters
use "${DIR_TEMP}/lab_params_rank_concept_${baseline_rank}.dta", clear

* create flow values of nonemployment by gender
gen double b = .
replace b = `b_1' if gender == 1
replace b = `b_2' if gender == 2
lab var b "Flow value of nonemployment by gender"

* save data
keep gender delta lambda_u s_e s_g b
order gender delta lambda_u s_e s_g b
sort gender
prog_comp_desc_sum_save "${DIR_TEMP}/lab_params_summary.dta"


*** final housekeeping
* turn timer off
timer off 9

* print final banner
di _newline(5)
timer list 9
local t = r(t9)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_8_POST_EST.do
********************************************************************************

********************************************************************************
* FILE NAME:   MM_0_MASTER.do
*
* DESCRIPTION: Master file for "The Gender Pay Gap: Micro Sources and Macro Consequences" (2025)
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        February 12, 2026
********************************************************************************


*** initial housekeeping
* set Stata interpreter version
version 18.0

* clean up
clear all
log close _all

* settings
set excelxlsxlargefile on
set graphics off
set linesize 128
set maxvar 120000
set segmentsize 1.5g
set niceness 1
set more off
set rmsg on
set trace off
set type float
set varabbrev off
pause off

* turn timer on
timer on 1


*** directories
* drop previously used macros
macro drop DIR_*
macro drop FILE_*
macro drop APP_*

* user-defined directories
global DIR_MAIN = "/root/MM2025_replication" // main directory of the replication package
global DIR_TEMP = "/root/temp_MM2025_replication" // temporary directory
global APP_MATLAB = "matlab" // system handle for calling MATLAB
global APP_PDFLATEX = "/usr/bin/pdflatex" // system handle for calling PDFLaTeX
global APP_BIBTEX = "/usr/bin/bibtex" // system handle for calling BibTeX
global APP_LATEX = "/usr/bin/latex" // system handle for calling LaTeX
global APP_DVIPS = "/usr/bin/dvips" // system handle for calling Dvips
global APP_PS2PDF = "/usr/bin/ps2pdf" // system handle for calling ps2pdf

* automatically set directories
global DIR_DATA = "${DIR_MAIN}/inputs"
	global DIR_DATA_CPI = "${DIR_DATA}/cpi"
		global FILE_CPI_RAW = "${DIR_DATA_CPI}/IPCA_IPEA_13February2019.xls"
		global FILE_CPI = "${DIR_DATA_CPI}/cpi_bra.dta"
	global DIR_DATA_MATLAB_INPUTS = "${DIR_DATA}/matlab"
	global DIR_DATA_MW = "${DIR_DATA}/mw"
		global FILE_MW_RAW = "${DIR_DATA_MW}/minwage_nominal_IPEA_13February2019.xls"
		global FILE_MW = "${DIR_DATA_MW}/mw_bra.dta"
	global DIR_DATA_OCC = "${DIR_DATA}/occ"
		global FILE_OCC_BRA_TO_OCC_US = "${DIR_DATA_OCC}/occ_bra_to_occ_us.dta"
		global FILE_OCC_US_TO_SKILL_TASK_CONT = "${DIR_DATA_OCC}/occ_us_to_skill_tasks_contents.dta"
	global DIR_DATA_ORBIS = "${DIR_DATA}/orbis"
		global FILE_ORBIS = "${DIR_DATA_ORBIS}/bvd_orbis_historical_bra.dta"
		global FILE_ORBIS_SIM = "${DIR_DATA_ORBIS}/bvd_orbis_historical_bra_sim.dta"
	global DIR_DATA_RAIS = "${DIR_DATA}/rais"
global DIR_DO = "${DIR_MAIN}/code"
	global DIR_DO_DATA = "${DIR_DO}/data"
		global DIR_DO_DATA_MATLAB_PCK = "${DIR_DO_DATA}/_matlab_packages"
			global DIR_DO_DATA_MATLAB_BGL = "${DIR_DO_DATA_MATLAB_PCK}/matlab_bgl"
			global DIR_DO_DATA_MATLAB_LOTW = "${DIR_DO_DATA_MATLAB_PCK}/LeaveOutTwoWay-3.02"
		global DIR_DO_DATA_STATA_PCK = "${DIR_DO_DATA}/_stata_packages"
	global DIR_DO_MODEL = "${DIR_DO}/model"
		global DIR_DO_MODEL_ESTIMATION = "${DIR_DO_MODEL}/estimation"
		global DIR_DO_MODEL_SOLUTION = "${DIR_DO_MODEL}/solution"
global DIR_LOG = "${DIR_MAIN}/logs"
global DIR_RES = "${DIR_MAIN}/results"
	global DIR_RES_FIG = "${DIR_RES}/figures"
	global DIR_RES_TAB = "${DIR_RES}/tables"
	global DIR_RES_TXT = "${DIR_RES}/text"
global DIR_PAPER = "${DIR_MAIN}/paper"
	global DIR_PAPER_FIG = "${DIR_PAPER}/figures"
	global DIR_PAPER_TAB = "${DIR_PAPER}/tables"
	global DIR_PAPER_TXT = "${DIR_PAPER}/text"
sysdir set PLUS "${DIR_DO_DATA_STATA_PCK}"

* generate time stamp
global STR_TIME_STAMP = subinstr(string(clock("`c(current_date)' `c(current_time)'", "DMYhms"), "%tcCCYY-NN-DD-HH-MM-SS"), "-", "_", .) // current date-time in milliseconds since January 1, 1960, converted to string in 24-hour format: YYYY-MM-DD-HH-MM-SS

* generate date and time strings
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"


*** section switches
global MM_1_SELECTION = 1 // imposes selection criteria
global MM_2_CONNECTED = 1 // finds connected set
global MM_3_AKM = 1 // estimates AKM model
global MM_4_RANKS = 1 // computes firm-level revealed-preference ranks
global MM_5_LAB_PARAMS = 1 // computes labor market "parameters"
global MM_6_ESTIMATION = 1 // prepares data for the estimation of the structural model
global MM_7_FIRM_PARAMETERS = 1 // estimates firm-level parameters
global MM_8_POST_EST = 1 // processes results of model estimation
global MM_9_COVARIATES = 1 // generates covariates at the employer-gender level
global MM_10_PROJECTIONS = 1 // projects model estimates onto observables at the employer-gender level
global MM_11_SUM_STATS = 1 // produces summary statistics
global MM_12_GAPS = 1 // computes gender gaps in pay and other outcomes within and between employers
global MM_13_ANALYSIS_MODEL = 1 // conducts additional analyses related to the model
global MM_14_ANALYSIS_DATA = 1 // conducts additional analyses related to the data
global MM_15_FIGURES = 1 // produces results figures
global MM_16_TABLES = 1 // produces results tables
global MM_17_TEXT = 1 // produces results text snippets
global MM_18_SIMULATIONS = 1 // conducts Monte Carlo and counterfactual simulations
global MM_19_COMPILE = 1 // compiles the paper


*** parameters
* list of key variables
global vars_list = "year id_pers gender edu age id_est ind07_5 muni hours hours_year occ02_6 tenure exp_act earn_mean_mw"

* selection criteria relating to worker and job characteristics
global year_min = 2007 // year
global year_max = 2014
global gender_min = 1 // gender: 1 = male; 2 = female; . = missing
global gender_max = 2
global edu_min = 1 // education: 1 = illiterate; 2 = some primary; 3 = primary; 4 = some middle; 5 = middle; 6 = some high; 7 = high; 8 = some college; 9 = Bachelor's or higher; . = missing
global edu_max = 9
global age_min = 18 // age: 1-99 = age in years; . = missing
global age_max = 54
global ind07_5_min = 0 // 5-digit industry code
global ind07_5_max = 999999
global occ02_6_min = 0 // 6-digit occupation code
global occ02_6_max = 999999
global hours_min = 1 // contractual work hours
global hours_max = 7*24
global hours_year_min = 1 // hours worked in a year
global hours_year_max = 365*24
global muni_min = 1 // municipality code
global muni_max = 999999
global earn_mean_mw_min = 1 // earnings in multiples of the current minimum wage
global earn_mean_mw_max = 150

* selection criteria relating to firm characteristics
global selection_iter = 0 // 0 = apply selection criteria once; 1 = apply selection criteria iteratively so as to ensure that they are all satisfied in the final sample
global drop_singletons = 1 // 0 = keep all observations; 1 = recursively drop singletons by employer ID and worker ID
global min_size_emp = 10 // minimum employment threshold (>= 1)
global min_size_emp_years = 2 // 0 = impose minimum employer threshold (${min_size_emp}) across pooled years; 1 = impose minimum employer threshold (${min_size_emp}) on average in each year across total timespan; 2 = impose minimum employer threshold (${min_size_emp}) on average in each year across years that a given firm exists; 3 = impose minimum employer threshold (${min_size_emp}) in each year
global min_size_emp_nonsingletons = 1 // 0 = apply minimum employer threshold w.r.t. all workers; 1 = apply minimum employer threshold w.r.t. nonsingleton workers (i.e., workers that are observed at least one more time at a future date -- see Sorkin ('18 QJE)
global min_emp_years = (${year_max} - ${year_min} + 1)/4 // minimum number of employer-years per employer across all years (>= 1)
global n_batches = 5 // number of batches to split panel data into (higher numbers take more CPU time but less RAM) for connected set, employer ranks, and labor market parameters
global min_hire_NE = 1 // minimum number of hires from nonemployment (>=0) -- Bagger & Lentz (REStud '19) and Sorkin (QJE '18) set = 1
global min_hire_tot = 10 // minimum number of total hires, either from nonemployment or from another employer (>=0) -- Bagger & Lentz (REStud '19) set = 15, Sorkin (QJE '18) sets = 0
global min_sep_EN = 1 // minimum number of separations into nonemployment (>=0)
global min_sep_tot = 1 // minimum number of total separations, either to nonemployment or to another employer (>=0)
global dual_gender = 0 // restrict attention to dual-gender firms? 0 = no; 1 = yes

* AKM regressions
global akm_coarsen = 1 // 0 = do not coarsen covariates; 1 = coarsen covariates
global akm_N_coarsen = 15 // minimum number of observations used for coarsening categories of each independent variable in AKM estimation
global akm_age_poly_order = 1 // 0 = do not include age terms in AKM regression; 1 = age dummies with income-age profile restricted to be flat from age ${age_flat_min}-${age_flat_max}; 2 / 3 / etc. = include 2nd order term / 2nd and 3rd order terms / etc.
global akm_age_flat_min = 45 // minimum age for which income-age profile is restricted to be flat (only relevant if akm_age_poly_order == 1)
global akm_age_flat_max = 49 // maximum age for which income-age profile is restricted to be flat (only relevant if akm_age_poly_order == 1)
global akm_age_norm = 49 // age around which to normalize higher-order age polynomial terms in AKM estimation (relevant only if ${akm_age_poly_order} >= 2; coincides with where the age profile is assumed to be flat for interpretation of worker FEs and year FEs)
global akm_years = 1 // 0 = do not include year controls in AKM estimation; 1 = include year controls in AKM estimation
global akm_edu = 1 // 0 = no education interactions; 1 = interact education with time trends and age profiles
global akm_hours = 1 // 0 = do not include hours controls in AKM estimation; 1 = include hours controls in AKM estimation
global akm_occ = 1 // 0 = do not include occupation controls in AKM estimation; 1 = include occupation controls in AKM estimation
global akm_tenure = 1 // 0 = do not include tenure controls in AKM estimation; 1 = include tenure controls in AKM estimation
global akm_exp_act = 1 // 0 = do not include actual experience controls in AKM estimation; 1 = include actual experience controls in AKM estimation

* employer ranks
global size_measure = 2 // gender-employer size measure: 1 = average number of workers per month that a firm exists in the monthly panel; 2 = average number of workers per year that a firm exists in the annual panel
global n_iter_max = 10 // maximum number of iterations during which noise is injected into employer rank measures
global pagerank_unemployed = 1 // 0 = exclude the nonemployed from PageRank calculation; 1 = include nonemployment in PageRank calculation

* labor market parameters
global sample_share = 1.0 // share of data to keep for computation of job finding rate from nonemployment and separation rate into nonemployment
global duration_max = 36 // maximum duration of a nonemployment spell
global rank_concept = 0 // employer rank concept: 0 = loop through all rank concepts; 1 = rank_hires_NE; 2 = rank_poaching; 3 = rank_retention; 4 = rank_net; 5 = rank_size; 6 = rank_fe_emp; 7 = PageRank
global n_rank_q = 100 // number of quantiles of employer ranks to collapse the data to for estimation of labor market transition "parameters"

* structural model estimation
global akm_norm_ind_list = "56112" // comma-separated list of industries where firm FEs are normalized to zero (e.g., "56112" or "56112, 56121, 56201")
global var_lambda_e = 1 // 1 = use estimate of lambda^E obtained from composite of lambda^G in EE transition counts; 2 = use estimate of lambda^E obtained from combining kappa, lambda^G, and delta

* amenities and productivity estimation
global empid_var = "id_emp"
global min_pi = 0.01 // floor for amenities
global endogenous_amenities = 0 // 0 = exogenous amenities; 1 = endogenous amenities
global amenities_sample = 1 // 0 = include all firms in the data; 1 = include only firms with both men and women
global rank_measures_list = "5 7" // ranks with which estimation is done. 2 = poaching ranks, 4 = net poaching ranks, 5 = size, 6 = firm pay FEs, 7 = PageRanks
global rank_measures_list_robustness = "5" // rank list for robustness checks
global baseline_rank = 5 // rank used for model simulation and baseline results (5 = size, the default; 7 = PageRanks)
global size_threshold_estimation = 10 // Threshold for firm size, default = 10
global distribution_tails_cut = 0 // Percentiles of offer distribution that are trimmed.
global trim_percent = 1 // Percentiles of firm-pay fixed effects that are trimmed in estimation of amenities and productivity
global match_F_or_G = "G" // match F, the offer CDF, or G, the worker CDF. default = "F"
global slope_logpay_logvalueadded = 0.179 //Target for eta_v: Slope of log pay on log value added, source: Alvarez et al., 2018, AEJ: Macro (balanced, no controls, 2004-2008)
global amenities_cost_share = 0.08 //Target for eta_a: amenities cost share

* structural model
global model_rho = ln(1 + 0.053) // discount rate
global model_alpha = 0.5 // elasticity of the matching function with respect to vacancies
global model_chi = 1 // efficiency of the matching function
global model_cfs_to_run = 0 // 1 = just read pre-calculated moments (default), 0 = do everything (takes up to 1 full day), 2 = do everything but skip equal pay policy, 3 = do everything but skip equal pay and equal hiring policies, 4 = do everything except policies (fast)

* empirical gaps
global n_q_plot = 25

* postestimation projections
global projections_cluster = "vce(cluster id_emp)" // clustering of standard errors in projection exercises: "vce(cluster id_emp)", "vce(robust)", or ""
global projections_absorb = 3 // 1 = control for industry; 2 = control for municipality; 3 = control for industry and municipality; 4 = control for industry x municipality interaction
global projections_scale = 2 // scale of covariates: 1 = logs; 2 = z-scores
global projections_postfile = 1 // whether to save projection results in postfile: 0 = do not save projection results; 1 = save projection results in postfile
global projections_n_var_min = 3 // minimum number of variables to use in projections
global projections_n_var_max = 6 // maximum number of variables to use in projections

* amenity covariates
global tol_change = 1e-3

* significance
global show_stars = 0 // 0 = do not show stars indicating levels of significance in regression tables; 1 = show stars indicating levels of significance in regression tables
global sig_level_010 = 1.645
global sig_level_005 = 1.960
global sig_level_001 = 2.576

* model analysis
global SD_fe_US_1 = 0.283 // constant to shift distributions from Brazil to US: men
global SD_fe_US_2 = 0.265 // constant to shift distributions from Brazil to US: women
global mean_diff_log_size_US = 1.3 // difference in mean log firm size going from Brazil to US
global difference_SD_log_size_US = 0.1254 // difference in standard deviation of log firm size going from Brazil to US

* package options
global packages_install = 0 // 0 = do not install packages; 1 = install packages
global gtools = "g" // "" = to use Stata-native functions; "g" = use (faster) gtools package

* rebuild replication folders from scratch?
global rebuild = 1 // 0 = keep old directories and files; 1 = delete old directories (i.e., ${DIR_TEMP}, ${DIR_RES}, ${DIR_PAPER_FIG}, ${DIR_PAPER_TAB}, ${DIR_PAPER_TXT}) and paper file (i.e., MM2025.pdf); 2 = delete old directories (i.e., ${DIR_TEMP}, ${DIR_RES}, ${DIR_PAPER_FIG}, ${DIR_PAPER_TAB}, ${DIR_PAPER_TXT}), paper file (i.e., MM2025.pdf), and log files (i.e., those without prefix "stata-mp" or older than 1 minute)

* simulate data?
global sim_orbis = 1 // 0 = use proprietary Orbis Historical data; 1 = use simulated Orbis Historical data

* compile with separate references for the supplemental appendix?
global app_refs = 0 // 0 = include all citations in the main paper's references section; 1 = create a separate references section for the supplemental appendix

* clean up large files?
global clean_up = 1 // 0 = do not delete any large files; 1 = delete large files after use


*** load programs
do "${DIR_DO_DATA}/MM_FUN_PROGRAMS.do"


*** automated steps
* detect machine architecture
detect_arch
if substr("`r(arch)'", 1, 3) == "arm" {
    global arch = ""
}
else if substr("`r(arch)'", 1, 3) == "x86" {
    if inlist("`=c(os)'", "MacOSX") global arch = "arch -arm64 " // note: forcing the shell to use Apple silicon architecture
	else global arch = ""
}
else {
	di as error "USER WARNING: Could not detect machine architecture!"
	global arch = ""
}

* set random-number seed
set rng mt64s
global seed = 20250828
set seed ${seed}

* set sort seed
global sortseed = "1001XZA112210f4b16c1cb10507a1f38cb440c40003c9a83566fa1201b69ab0aff2f2401e18"
set sortseed ${sortseed}

* set processors
global n_cpus = 1 // number of cores to use
set processors `=min(${n_cpus}, `c(processors_max)')'

* install packages
if $packages_install {
	cap n ssc install binscatter
	cap n ssc install confirmdir
	cap n ssc install egenmore
	cap ssc uninstall ftools
	cap ado uninstall ftools
	cap n ssc install ftools // alternatively: cap n net install ftools, from("https://github.com/sergiocorreia/ftools/raw/master/src/")
	cap n ssc install gtools // alternatively: cap n net install gtools, from("https://raw.githubusercontent.com/mcaceresb/stata-gtools/master/build/")
	cap n gtools, upgrade
	cap n ssc install reghdfe
}

* extracting compressed packages
foreach file in ///
	"LeaveOutTwoWay-3.02" ///
	"matlab_bgl" ///
	{
	!cd "${DIR_DO_DATA_MATLAB_PCK}"; unzip -o "`file'.zip"
}

* delete old directories, log files, and paper file, if prompted
if $rebuild {
	foreach dir in "DIR_TEMP" "DIR_RES" "DIR_PAPER_FIG" "DIR_PAPER_TAB" "DIR_PAPER_TXT" {
		if inlist("`=c(os)'", "MacOSX", "Unix") {
			!rm -rf "${`dir'}"
		}
		else if "`=c(os)'" == "Windows" {
			shell rmdir /s /q "${`dir'}"
		}
		cap mkdir "${`dir'}"
	}
	cap n rm "${DIR_PAPER}/MM2025.pdf"
	if $rebuild == 2 {
		if inlist("`=c(os)'", "MacOSX", "Unix") {
			!find "${DIR_LOG}" -maxdepth 1 -type f \( ! -name "stata-mp*" -o -mmin +1 \) -delete // note: this deletes server log files older than 1 minute---i.e., it keeps the current server log files
		}
		else if "`=c(os)'" == "Windows" {
			shell forfiles /p "${DIR_LOG}" /m * /c "cmd /c if /I @file NEQ stata-mp* del @path"
			shell forfiles /p "${DIR_LOG}" /m * /d -0:01 /c "cmd /c del @path"
		}
	}
}

* create directories
local dirs: all globals "DIR_*"
local dirs_sorted = ""
foreach dir of local dirs {
	local dirs_sorted = "`dir' `dirs_sorted'"
}
foreach dir of local dirs_sorted {
	cap confirmdir "${`dir'}/"
	if `=r(confirmdir)' { // if this directory does not exist
		di as error "USER WARNING: Creating nonexistent directory ${`dir'}."
		cap mkdir "${`dir'}"
	}
}

* copy over initial guesses and previous results for model solution
cap confirmdir "${DIR_TEMP}/temp_matlab/"
if !`=r(confirmdir)' { // if this directory exists, delete it
	if inlist("`=c(os)'", "MacOSX", "Unix") {
		!rm -rf "${DIR_TEMP}/temp_matlab"
	}
	else if "`=c(os)'" == "Windows" {
		shell rmdir /s /q "${DIR_TEMP}/temp_matlab"
	}
}
if inlist("`=c(os)'", "MacOSX", "Unix") {
	!cp -r "${DIR_DATA_MATLAB_INPUTS}" "${DIR_TEMP}/temp_matlab"
}
else if "`=c(os)'" == "Windows" {
	shell xcopy /s /e /i "${DIR_DATA_MATLAB_INPUTS}" "${DIR_TEMP}/temp_matlab"
}

* write .txt files with time stamp for MATLAB
forval k = 1/4 {
	cap file close FILE_TIME_STAMP
	if `k' == 1 file open FILE_TIME_STAMP using "${DIR_TEMP}/time_stamp.txt", write replace
	else if `k' == 2 file open FILE_TIME_STAMP using "${DIR_DO_DATA}/time_stamp.txt", write replace
	else if `k' == 3 file open FILE_TIME_STAMP using "${DIR_DO_MODEL_ESTIMATION}/time_stamp.txt", write replace
	else if `k' == 4 file open FILE_TIME_STAMP using "${DIR_DO_MODEL_SOLUTION}/time_stamp.txt", write replace
	file write FILE_TIME_STAMP "${STR_TIME_STAMP}"
	file close FILE_TIME_STAMP
}

* write .txt files with paths for MATLAB
forval k = 1/4 {
	cap file close FILE_PATHS
	if `k' == 1 file open FILE_PATHS using "${DIR_TEMP}/paths.txt", write replace
	else if `k' == 2 file open FILE_PATHS using "${DIR_DO_DATA}/paths.txt", write replace
	else if `k' == 3 file open FILE_PATHS using "${DIR_DO_MODEL_ESTIMATION}/paths.txt", write replace
	else if `k' == 4 file open FILE_PATHS using "${DIR_DO_MODEL_SOLUTION}/paths.txt", write replace
	file write FILE_PATHS "${DIR_MAIN}" _n "${DIR_TEMP}"
	file close FILE_PATHS
}


*** execute codes
* open log file
local log_name = "MM_0_MASTER"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* print initial banner
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(15)

* run code files
foreach section in ///
	"MM_1_SELECTION" ///
	"MM_2_CONNECTED" ///
	"MM_3_AKM" ///
	"MM_4_RANKS" ///
	"MM_5_LAB_PARAMS" ///
	"MM_6_ESTIMATION" ///
	"MM_7_FIRM_PARAMETERS" ///
	"MM_8_POST_EST" ///
	"MM_9_COVARIATES" ///
	"MM_10_PROJECTIONS" ///
	"MM_11_SUM_STATS" ///
	"MM_12_GAPS" ///
	"MM_13_ANALYSIS_MODEL" ///
	"MM_14_ANALYSIS_DATA" ///
	"MM_15_FIGURES" ///
	"MM_16_TABLES" ///
	"MM_17_TEXT" ///
	"MM_18_SIMULATIONS" ///
	"MM_19_COMPILE" ///
	{
	if ${`section'} do "${DIR_DO_DATA}/`section'.do"
}


*** final housekeeping
* clean up
forval k = 1/4 {
	if `k' == 1 {
		cap rm "${DIR_TEMP}/time_stamp.txt"
		cap rm "${DIR_TEMP}/paths.txt"
	}
	else if `k' == 2 {
		cap rm "${DIR_DO_DATA}/time_stamp.txt"
		cap rm "${DIR_DO_DATA}/paths.txt"
	}
	else if `k' == 3 {
		cap rm "${DIR_DO_MODEL_ESTIMATION}/time_stamp.txt"
		cap rm "${DIR_DO_MODEL_ESTIMATION}/paths.txt"
	}
	else if `k' == 4 {
		cap rm "${DIR_DO_MODEL_SOLUTION}/time_stamp.txt"
		cap rm "${DIR_DO_MODEL_SOLUTION}/paths.txt"
	}
}
!rm -r "${DIR_DO_DATA_MATLAB_BGL}"
!rm -r "${DIR_DO_DATA_MATLAB_LOTW}"

* print final banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di _newline(15)
timer off 1
timer list 1
local t = r(t1)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"
log close _all
clear all


********************************************************************************
* END OF MM_0_MASTER.do
********************************************************************************

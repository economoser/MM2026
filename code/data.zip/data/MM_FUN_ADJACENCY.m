function A = MM_FUN_ADJACENCY(id_pers, id_emp)
    
    %======================================================================
    % FILE NAME:   MM_FUN_ADJACENCY.m
    %
    % DESCRIPTION: Builds the adjacancy matrix of a bipartite graph based
    %              on worker IDs and employer IDs
    %
    % ORIGINAL AUTHOR: Raffaele Saggio (University of British Columbia)
    %
    % EDITS BY:    Iacopo Morchio (University of Bristol)
    %              Christian Moser (Columbia University)
    %     
    % INPUTS:      Vectors of person IDs (id_pers) numbered from 1, 2, ...
    %              and employer IDs (id_emp) numbered from 1, 2, ...
    %     
    % OUTPUTS:     Adjacency matrix of the bipartite graph (A)
    %
    % DATE:        November 4, 2025
    %======================================================================
    
    % build the adjacency matrix
    gcs = [NaN; id_pers(1:end-1)];
    gcs = (id_pers ~= gcs);
    id_emp_prev = [NaN; id_emp(1:end - 1)];
    id_emp_prev(gcs == 1) = NaN; % first obs for each worker
    stayer = (id_emp == id_emp_prev);
    stayer(gcs == 1) = 1;
    stayer = accumarray(id_pers, stayer);
    T = accumarray(id_pers, 1);
    stayer = (T == stayer);
    mover = ~stayer;
    mover = mover(id_pers);
    id_emp_movers = id_emp(mover);
    gcs_movers = gcs(mover);
    id_emp_movers_prev = [NaN; id_emp_movers(1:end - 1)];
    id_emp_movers_prev(gcs_movers == 1) = NaN; % first obs for each worker
    list = [id_emp_movers_prev id_emp_movers]; % all the moves observed from one period to the next, this time only for movers -- note: removed third column vector id_pers_movers = id_pers(mover);
    sel = ~isnan(list(:, 1));
    list = list(sel, :);
    sel = (list(:, 1) ~= list(:, 2));
    list = list(sel, :);
    [e, jj, kk] = unique(list(:, 1:2), 'rows');
    weight = histc(kk, 1:numel(jj)); % frequencies -- note: could be replaced with MATLAB's newer -histcounts- function
    J = max(id_emp);
    A = sparse([e(:, 1); e(:, 2)], [e(:, 2); e(:, 1)], [weight; weight], J, J); % adjacency matrix
end
fprintf('\n==============================================================')
fprintf('\nFILE NAME:   MM_CONNECTED_LOO.m')
fprintf('\n')
fprintf('\nDESCRIPTION: Find the largest leave-one-out connected set---i.e.,')
fprintf('\n             a connected set for which removal of one')
fprintf('\n             individual work history at a time leaves the set')
fprintf('\n             connected---see Appendix B of Kline, Saggio, and')
fprintf('\n             Sølvsten (2020, Econometrica) for details')
fprintf('\n')
fprintf('\nORIGINAL AUTHOR: Raffaele Saggio (University of British Columbia)')
fprintf('\n')
fprintf('\nEDITED BY:   Iacopo Morchio (University of Bristol)')
fprintf('\n             Christian Moser (Columbia University)')
fprintf('\n')
fprintf('\nINPUTS:      A .csv file "FILE_TEMP_INPUT" containing a Nx2 matrix')
fprintf('\n             with 2 data columns: employer IDs (id_emp) and')
fprintf('\n             worker IDs (id_pers) sorted by worker ID and')
fprintf('\n             date')
fprintf('\n')
fprintf('\nOUTPUTS:     A .csv file "FILE_TEMP_OUTPUT" containing a Nx1 matrix')
fprintf('\n             with 1 data column: employer ID (id_emp) for')
fprintf('\n             employers in the leave-one-out connected set')
fprintf('\n')
fprintf('\nNOTES:       - Data must be sorted by worker ID and date')
fprintf('\n               (i.e., by worker IDs first and then by date')
fprintf('\n               within worker IDs)')
fprintf('\n             - A is the J x J adjacency matrix associated with')
fprintf('\n               leave-one-out sample, where J is the number of')
fprintf('\n               firms in the leave-one-out sample')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n==============================================================')


fprintf('\n==============================================================')
fprintf('\n INITIAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Verify MATLAB version\n')
v = version;
v_old = (str2double(v(1:3)) < 8.6); % if MATLAB is older than version R2015b
if v_old
    fprintf('\nUSER ERROR: This code relies on the MATLAB-native function -conncomp-, which requires MATLAB R2015b or later version.\n')
    exit
end
clear v v_old

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Set directories\n')
if exist('paths.txt', 'file')
    READ_REPLICATION = readlines('paths.txt');
    DIR_MAIN = char(READ_REPLICATION(1));
    DIR_TEMP = char(READ_REPLICATION(2));
else
    fprintf('\nUSER ERROR: Directories not found.\n')
    exit
end
% DIR_MAIN = ''; % note: this directory is automatically defined above
    DIR_DO = fullfile(DIR_MAIN, 'code'); % path to folder where empirical code files are stored
        DIR_DO_DATA = fullfile(DIR_DO, 'data'); % path to folder where empirical code files are stored
        addpath(DIR_DO_DATA);
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % path to folder where log files should be saved
    FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_MM_CONNECTED_LOO.log']);
% DIR_TEMP = ''; % note: this directory is automatically defined above
    FILE_TEMP_INPUT = fullfile(DIR_TEMP, 'connected_loo_input.csv'); % path to file from which to read Stata input
    FILE_TEMP_OUTPUT = fullfile(DIR_TEMP, 'connected_loo_output.csv'); % path to file to which to write MATLAB output
clear STR_TIME_STAMP READ_REPLICATION DIR_MAIN DIR_TEMP DIR_DO DIR_DO_DATA

fprintf('\n  --> Set random-number seed\n')
seed = 20250828;
rng(seed, 'twister')
clear seed

fprintf('\n  --> Start log file\n')
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n FIND LEAVE-ONE-OUT CONNECTED SET')
fprintf('\n==============================================================')

fprintf('\n  --> Load data\n')
FILE_TEMP_INPUT_OPEN = fopen(FILE_TEMP_INPUT);
FILE_TEMP_INPUT_SCAN = fscanf(FILE_TEMP_INPUT_OPEN, '%f %f', [2 inf])';
fclose(FILE_TEMP_INPUT_OPEN);
id_pers = FILE_TEMP_INPUT_SCAN(:, 1);
id_emp = FILE_TEMP_INPUT_SCAN(:, 2);
clear FILE_TEMP_INPUT FILE_TEMP_INPUT_OPEN FILE_TEMP_INPUT_SCAN

fprintf('\n  --> Prepare for while-loop\n')
n_artic_point_workers = 1; % initiate while-loop
id_emp_old = id_emp; % save original employer IDs
[~, ~, id_emp] = unique(id_emp); % relabel employer IDs (id_emp) so they are numbered 1, 2, ...

fprintf('\n  --> While-loop that iteratively removes articulation point workers\n')
n_iter = 1;
while n_artic_point_workers >= 1

    % Find movers
    J = max(id_emp);
    gcs = [NaN; id_pers(1:end - 1)];
    gcs = (id_pers ~= gcs); % indicator for whether current and previous worker IDs are different -- i.e., for whether a set of observations for a new person ID starts
    id_emp_prev = [NaN; id_emp(1:end - 1)];
    id_emp_prev(gcs == 1) = NaN; % previous employer ID (after replacing each worker's first observation of previous employer ID with missing since previous employer ID is unknown then)
    mover = (id_emp ~= id_emp_prev);
    mover(gcs == 1) = 0;
    mover = accumarray(id_pers, mover);
    mover = (mover > 0);
    mover = mover(id_pers); % indicator for whether worker ever moves between employers during sample period
    clear gcs id_emp_prev
        
    % Subset of entries of id_pers and id_emp associated with movers only
    id_pers_movers = id_pers(mover);
    id_emp_movers = id_emp(mover);
    clear mover

    % Normalize id_pers_movers and keep a dictionary
    id_pers_movers_old = id_pers_movers; % save original values of id_pers_movers
    [~, ~, id_pers_movers] = unique(id_pers_movers); % relabel worker IDs of movers (id_pers_movers) so they are numbered 1, 2, ...
    n_movers = max(id_pers_movers); % number of unique workers who move between employers during sample period
    
    % Unique worker-firm pairs
    list = [id_pers_movers id_emp_movers];
    list = unique(list, 'rows');
    clear id_emp_movers
        
    % Construct adjacency matrix of bipartite graph linking workers to firms
    B = sparse(list(:, 1), list(:, 2), 1, n_movers, J);
    G = [sparse(n_movers, n_movers), B; B.', sparse(J, J)];
    clear J list B
        
    % In resulting graph, find articulation point workers
    [~, artic_points] = biconncomp(graph(G));
    bad_workers = artic_points(artic_points <= n_movers);
    clear n_movers G artic_points
        
    % Find indices for and count articulation point workers
    sel = ismember(id_pers_movers, bad_workers);
    bad_workers = id_pers_movers_old(sel);
    bad_workers = unique(bad_workers);
    n_artic_point_workers = size(bad_workers, 1);
    clear id_pers_movers id_pers_movers_old sel
        
    % Drop articulation point workers
    sel = ~ismember(id_pers, bad_workers);
    id_emp = id_emp(sel);
    id_pers = id_pers(sel);
    id_emp_old = id_emp_old(sel);
    clear bad_workers sel
        
    % Reset employer and worker IDs
    [~, ~, id_emp] = unique(id_emp);
    [~, ~, id_pers] = unique(id_pers);
        
    % Find adjacency matrix of the bipartite graph
    A = MM_FUN_ADJACENCY(id_pers, id_emp);
    
    % Find the largest connected set after removing articulation point workers
    [sindex, sz] = conncomp(graph(A)); % construct (strongly) connected sets -- note: it does not make sense to form a directed graph and find weakly vs. strongly connected components based on the adjacency matrix of a bipartite graph
    sz = sz';
    sindex = sindex';
    idx = find(sz == max(sz), 1); % find largest set among all the connected sets -- note: as a tiebreaker, use the largest set with the smallest index
    id_emp_list = find(sindex == idx); % firms in connected set
    sel = ismember(id_emp, id_emp_list);
    id_emp = id_emp(sel);
    id_pers = id_pers(sel);
    id_emp_old = id_emp_old(sel);
    clear A sindex sz idx id_emp_list sel

    % Reset employer and worker IDs one last time
    [~, ~, id_emp] = unique(id_emp);
    [~, ~, id_pers] = unique(id_pers);
    
    % Print status message before moving to next iteration
    fprintf('\n      ...iteration number %2.0f has %6.0f articulation point workers\n', n_iter, n_artic_point_workers)
    n_iter = n_iter + 1;
end
clear n_artic_point_workers n_iter

fprintf('\n  --> Final output\n')
id_emp = unique(id_emp_old);
clear id_pers id_emp_old

fprintf('\n  --> Write IDs of employers in connected set to tab-delimited file\n')
FILE_TEMP_OUTPUT_OPEN = fopen(FILE_TEMP_OUTPUT, 'w');
fprintf(FILE_TEMP_OUTPUT_OPEN, '%12s\n', 'id_emp');
fprintf(FILE_TEMP_OUTPUT_OPEN, '%12.0f\n', id_emp');
fclose(FILE_TEMP_OUTPUT_OPEN);
clear FILE_TEMP_OUTPUT FILE_TEMP_OUTPUT_OPEN id_emp


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF MM_CONNECTED_LOO.m')
fprintf('\n==============================================================')

fprintf('\n  --> End log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> Exit\n')
exit
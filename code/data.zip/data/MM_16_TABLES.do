********************************************************************************
* FILE NAME:   MM_16_TABLES.do
*
* DESCRIPTION: Produces tables to be included in the paper
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_16_TABLES"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 17

* set random-number stream
clear rngstream
set rngstream 16

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** result tables
* switches for which tables to produce
global tab_sum_stats 				= 1 	// summary statistics
global tab_akm_decomp 				= 1		// AKM variance decomposition based on plug-in estimates
global tab_akm_kss_decomp 			= 1		// AKM variance decomposition with KSS bias correction
global tab_akm_combined_decomp 		= 1		// AKM variance decomposition combining plug-in estimates with KSS bias correction
global tab_kob 						= 1 	// Kitagawa-Oaxaca-Blinder decomposition of total gender-firm pay gap into between vs. within components
global tab_lab_params 				= 1 	// labor market parameters
global tab_model_fit 				= 1 	// model-fit statistics
global tab_corr 					= 1 	// correlations between model parameters
global tab_sum_stats_app_a1_a5		= 1 	// Appendix A1-A5 (see relative section below for short description of each table) 
global tab_mincer_app				= 1		// Appendix B1-B2: Mincer regressions
global tab_reg_amenities			= 1		// Regression tables (amenities)
global tab_reg_amenities_long		= 1		// Regression tables (amenities) -- long version
global tab_reg_wedges				= 1 	// Regression tables (wedges)
global tab_reg_wedges_long			= 1 	// Regression tables (wedges) -- long version
global tab_pay_var_decomp 			= 1		// Variance decomposition of wages
global tab_reg_workplace_chars 		= 1		// Workplace characteristics by gender
global tab_mincer			 		= 1		// Mincer regressions for reply to R2
global tab_corr_dem			 		= 1		// correlations between firm ranks (size) across demographic subgroups
global tab_ranks			 		= 1 	// correlations between alternative firm rank measures

* names of the output files
global f_tab_sum_stats 				= "tab_sum_stats.tex"
global f_tab_akm_decomp 			= "tab_akm_decomp.tex"
global f_tab_akm_kss_decomp			= "tab_akm_kss_decomp.tex"
global f_tab_akm_combined_decomp	= "tab_akm_combined_decomp.tex"
global f_tab_kob_log_w				= "tab_kob_log_w.tex"
global f_tab_kob_log_w_pri			= "tab_kob_log_w_pri.tex"
global f_tab_kob_log_w_pub			= "tab_kob_log_w_pub.tex"
global f_tab_kob_log_w_us_size		= "tab_kob_log_w_us_size.tex"
global f_tab_kob_log_w_eta_a_h		= "tab_kob_log_w_eta_a_h.tex"
global f_tab_kob_log_w_eta_a_d		= "tab_kob_log_w_eta_a_d.tex"
global f_tab_kob_log_w_delta		= "tab_kob_log_w_delta.tex"
global f_tab_kob_log_w_pageranks	= "tab_kob_log_w_pageranks.tex"
global f_tab_kob_log_w_short 		= "tab_kob_log_w_short.tex"
global f_tab_kob_log_w_short_pri 	= "tab_kob_log_w_short_pri.tex"
global f_tab_kob_log_w_short_pub 	= "tab_kob_log_w_short_pub.tex"
global f_tab_kob_log_w_short_us_size = "tab_kob_log_w_short_us_size.tex"
global f_tab_kob_log_w_short_eta_a_h = "tab_kob_log_w_short_eta_a_h.tex"
global f_tab_kob_log_w_short_eta_a_d = "tab_kob_log_w_short_eta_a_d.tex"
global f_tab_kob_log_w_short_delta = "tab_kob_log_w_short_delta.tex"
global f_tab_kob_log_w_short_pageranks = "tab_kob_log_w_short_pageranks.tex"
global f_tab_kob_log_pi				= "tab_kob_log_pi.tex"
global f_tab_kob_log_pi_pri			= "tab_kob_log_pi_pri.tex"
global f_tab_kob_log_pi_pub			= "tab_kob_log_pi_pub.tex"
global f_tab_kob_log_pi_us_size		= "tab_kob_log_pi_us_size.tex"
global f_tab_kob_log_pi_eta_a_h		= "tab_kob_log_pi_eta_a_h.tex"
global f_tab_kob_log_pi_eta_a_d		= "tab_kob_log_pi_eta_a_d.tex"
global f_tab_kob_log_pi_delta		= "tab_kob_log_pi_delta.tex"
global f_tab_kob_log_pi_pageranks	= "tab_kob_log_pi_pageranks.tex"
global f_tab_kob_log_pi_tilde		= "tab_kob_log_pi_tilde.tex"
global f_tab_kob_log_pi_tilde_pri 	= "tab_kob_log_pi_tilde_pri.tex"
global f_tab_kob_log_pi_tilde_pub 	= "tab_kob_log_pi_tilde_pub.tex"
global f_tab_kob_log_pi_tilde_us_size = "tab_kob_log_pi_tilde_us_size.tex"
global f_tab_kob_log_pi_tilde_eta_a_h = "tab_kob_log_pi_tilde_eta_a_h.tex"
global f_tab_kob_log_pi_tilde_eta_a_d = "tab_kob_log_pi_tilde_eta_a_d.tex"
global f_tab_kob_log_pi_tilde_delta = "tab_kob_log_pi_tilde_delta.tex"
global f_tab_kob_log_pi_tilde_pageranks = "tab_kob_log_pi_tilde_pageranks.tex"
global f_tab_kob_log_x				= "tab_kob_log_x.tex"
global f_tab_kob_log_x_pri			= "tab_kob_log_x_pri.tex"
global f_tab_kob_log_x_pub			= "tab_kob_log_x_pub.tex"
global f_tab_kob_log_x_us_size		= "tab_kob_log_x_us_size.tex"
global f_tab_kob_log_x_eta_a_h		= "tab_kob_log_x_eta_a_h.tex"
global f_tab_kob_log_x_eta_a_d		= "tab_kob_log_x_eta_a_d.tex"
global f_tab_kob_log_x_delta		= "tab_kob_log_x_delta.tex"
global f_tab_kob_log_x_pageranks	= "tab_kob_log_x_pageranks.tex"
global f_tab_kob_log_w_pi_x			= "tab_kob_log_w_pi_x.tex"
global f_tab_kob_log_w_pi_x_pri 	= "tab_kob_log_w_pi_x_pri.tex" // note: only private firms
global f_tab_kob_log_w_pi_x_pub 	= "tab_kob_log_w_pi_x_pub.tex" // note: only public firms
global f_tab_kob_log_w_pi_x_us_size = "tab_kob_log_w_pi_x_us_size.tex" // note: U.S. employer size distribution
global f_tab_kob_log_w_pi_x_eta_a_h = "tab_kob_log_w_pi_x_eta_a_h.tex" // note: half the baseline value of the amenity cost elasticity, eta_a
global f_tab_kob_log_w_pi_x_eta_a_d = "tab_kob_log_w_pi_x_eta_a_d.tex" // note: double the baseline value of the amenity cost elasticity, eta_a
global f_tab_kob_log_w_pi_x_delta 	= "tab_kob_log_w_pi_x_delta.tex" // note: heterogeneous firm-level separation rates
global f_tab_kob_log_w_pi_x_pageranks = "tab_kob_log_w_pi_x_pageranks.tex" // note: PageRanks as employer ranks
global f_tab_lab_params 			= "tab_lab_params.tex"
global f_tab_corr_m 				= "tab_corr_m.tex"
global f_tab_corr_f					= "tab_corr_f.tex"
global f_tab_corr_cross				= "tab_corr_cross.tex"
global f_tab_appendix_a1			= "tab_appendix_a1.tex"
global f_tab_appendix_a2			= "tab_appendix_a2.tex"
global f_tab_appendix_a3			= "tab_appendix_a3.tex"
global f_tab_appendix_a4			= "tab_appendix_a4.tex"
global f_tab_appendix_a5			= "tab_appendix_a5.tex"
global f_tab_appendix_b1_b2			= "tab_appendix_b" // Note: there is no number and no ".tex" at the end, because the corresponding year will be appended at the end of the file name
global f_tab_reg_amenities			= "tab_reg_amenities.tex"
global f_tab_reg_amenities_long		= "tab_reg_amenities_long.tex"
global f_tab_reg_wedges				= "tab_reg_wedges.tex"
global f_tab_reg_wedges_long		= "tab_reg_wedges_long.tex"
global f_tab_pay_var_decomp 		= "tab_var_pay_decomp.tex"
global f_tab_reg_workplace_chars 	= "tab_reg_workplace_chars.tex"
global f_tab_mincer 				= "tab_mincer.tex"
global f_tab_corr_dem				= "tab_corr_dem.tex"
global f_tab_ranks					= "tab_ranks.tex"


*** summary statistics
if $tab_sum_stats {
	
	* load data (CONNECTED)
	use "${DIR_TEMP}/sum_stats_connected.dta", clear
	
	* renaming some columns
	replace var_label = "Mean years of age" if var_label == "Mean age"
	replace var_label = "Mean years of tenure" if var_label == "Mean tenure (years)"
	replace var_label = "Number of unique employers" if var_label == "Number of unique establishments"
	replace var_label = "Mean employer size" if var_label == "Mean establishment size"
	replace var_label = "Share Nonwhite" if var_label == "Share nonwhite"
	
	* setting a group of locals containing the index that extracts that specific value (indices are organized as the rows of the table!)
	local i_1	= 25 	// Mean log real monthly earnings			
	local i_2	= 27	// Mean log real hourly wage
	local i_3	= 3		// Share Nonwhite
	local i_4	= 9		// Mean years of education
	local i_5	= 11	// Mean age
	local i_6	= 13	// Mean establishment size
	local i_7	= 21	// Mean contractual work hours
	local i_8	= 23	// Mean years of tenure
	local i_9	= 33	// Mean log gender earnings gap
	local i_10	= 34	// Mean log gender wage gap
	local i_11	= 29	// Number of worker-years
	local i_12	= 30	// Number of unique workers
	local i_13	= 31	// Number of unique establishments
	local i_14	= 32	// Share female
	
	* Writing the table on a .tex file	
	cap macro drop file_sum_stats
	cap file close file_sum_stats
	file open file_sum_stats using "${DIR_RES_TAB}/${f_tab_sum_stats}", write replace
	file write file_sum_stats ///
		"{}%" _n ///
		"\begin{tabular}{lcccc}" _n ///
		"&  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"&  & {Overall}  & {Men}  & {Women}\tabularnewline" _n ///
		"\hline" _n ///
		"{" (var_label[`i_1']) "} {(std. dev.)}  &  & {" (OverallPooled[`i_1']) "} {" (OverallPooled[`i_1'+1]) "}  & {" (MenPooled[`i_1']) "} {" (MenPooled[`i_1'+1]) "}  & {" (WomenPooled[`i_1']) " {}" (WomenPooled[`i_1'+1]) "}\tabularnewline" _n ///
/// 	"{" (var_label[`i_2']) "} {(std. dev.)}  &  & {" (OverallPooled[`i_2']) "} {" (OverallPooled[`i_2'+1]) "}  & {" (MenPooled[`i_2']) "} {" (MenPooled[`i_2'+1]) "}  & {" (WomenPooled[`i_2']) " {}" (WomenPooled[`i_2'+1]) "}\tabularnewline" _n ///
		"{" (var_label[`i_4']) "} {(std. dev.)}  &  & {" (OverallPooled[`i_4']) "} {" (OverallPooled[`i_4'+1]) "}  & {" (MenPooled[`i_4']) "} {" (MenPooled[`i_4'+1]) "}  & {" (WomenPooled[`i_4']) " {}" (WomenPooled[`i_4'+1]) "}\tabularnewline" _n ///
		"{" (var_label[`i_5']) "} {(std. dev.)}  &  & {" (OverallPooled[`i_5']) "} {" (OverallPooled[`i_5'+1]) "}  & {" (MenPooled[`i_5']) "} {" (MenPooled[`i_5'+1]) "}  & {" (WomenPooled[`i_5']) " {}" (WomenPooled[`i_5'+1]) "}\tabularnewline" _n ///
		"{" (var_label[`i_6']) "} {(std. dev.)}  &  & {" (OverallPooled[`i_6']) "} {" (OverallPooled[`i_6'+1]) "}  & {" (MenPooled[`i_6']) "} {" (MenPooled[`i_6'+1]) "}  & {" (WomenPooled[`i_6']) " {}" (WomenPooled[`i_6'+1]) "}\tabularnewline" _n ///
		"{" (var_label[`i_7']) "} {(std. dev.)}  &  & {" (OverallPooled[`i_7']) "} {" (OverallPooled[`i_7'+1]) "}  & {" (MenPooled[`i_7']) "} {" (MenPooled[`i_7'+1]) "}  & {" (WomenPooled[`i_7']) " {}" (WomenPooled[`i_7'+1]) "}\tabularnewline" _n ///
		"{" (var_label[`i_8']) "} {(std. dev.)}  &  & {" (OverallPooled[`i_8']) "} {" (OverallPooled[`i_8'+1]) "}  & {" (MenPooled[`i_8']) "} {" (MenPooled[`i_8'+1]) "}  & {" (WomenPooled[`i_8']) " {}" (WomenPooled[`i_8'+1]) "}\tabularnewline" _n ///
		"{" (var_label[`i_3']) "}  &  & {" (OverallPooled[`i_3']) "}  & {" (MenPooled[`i_3']) "}  & {" (WomenPooled[`i_3']) "}\tabularnewline" _n ///
		"{" (var_label[`i_14']) "}  &  & {" (OverallPooled[`i_14']) "}  &  & \tabularnewline" _n ///
		"{" (var_label[`i_9']) "}  &  & {" (OverallPooled[`i_9']) "}  &  & \tabularnewline" _n ///
/// 	"{" (var_label[`i_10']) "}  &  & {" (OverallPooled[`i_10']) "}  &  & \tabularnewline" _n ///
		"{" (var_label[`i_11']) "}  &  & {" (OverallPooled[`i_11']) "}  & {" (MenPooled[`i_11']) "}  & {" (WomenPooled[`i_11']) "}\tabularnewline" _n ///
		"{" (var_label[`i_12']) "}  &  & {" (OverallPooled[`i_12']) "}  & {" (MenPooled[`i_12']) "}  & {" (WomenPooled[`i_12']) "}\tabularnewline" _n ///
		"{" (var_label[`i_13']) "}  &  & {" (OverallPooled[`i_13']) "}  & {" (MenPooled[`i_13']) "}  & {" (WomenPooled[`i_13']) "}\tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_sum_stats	
	
}


*** AKM variance decomposition
if $tab_akm_decomp {
	
	* load post-estimation dataset to get mean employer FEs by gender
	use ///
		log_w_* size* ///
		using "${DIR_TEMP}/post_est.dta", clear
	
	* compute gender-specific mean employer FEs
	foreach g in m f {
		sum log_w_`g' [aw=size_`g']
		local log_w_`g'_mean: di %4.3f `=r(mean)'
	}
	
	* load data
	use "${DIR_TEMP}/akm_decomp.dta", clear
	
	* formatting variables
	foreach var of varlist var_* cov_sum cov_inc_* corr_pers_emp r2 {
		format `var' %4.3f
	}
	foreach var of varlist share_* {
		format `var' %4.1f
	}
	format N %9.0f
	
	* converting to string (all but gender)
	ds gender share_*, not 
	tostring `r(varlist)', format(%18.3f) replace force
	ds share_*
	tostring `r(varlist)', format(%18.1f) replace force
	
	* adding commas to N observations
	prog_comma_thousands N 1
	prog_comma_thousands N 2
	
	* writing the table on a .tex file	
	cap macro drop file_akm_decomp
	cap file close file_akm_decomp
	file open file_akm_decomp using "${DIR_RES_TAB}/${f_tab_akm_decomp}", write replace
	file write file_akm_decomp ///
		"\begin{tabular}{lcclcc}" _n ///
		"&  &  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"& \multicolumn{2}{c}{Men} &  & \multicolumn{2}{c}{Women}\tabularnewline" _n ///
		"\cline{2-3} \cline{3-3} \cline{5-6} \cline{6-6}" _n ///
		"& Level & Share (\%) &  & Level & Share (\%)\tabularnewline" _n ///
		"\hline" _n ///
		"Variance of log earnings & " (var_inc[1]) " &  &  & " (var_inc[2]) " & \tabularnewline" _n ///
		"Variance components: &  &  &  &  & \tabularnewline" _n ///
		"$\quad$ Employer FEs (\%) &" 			(var_fe_emp[1]) 	"&" (share_fe_emp[1]) 		"&  &" (var_fe_emp[2]) 		"& " (share_fe_emp[2]) "\tabularnewline" _n ///
		"$\quad$ Person FEs (\%) &" 				(var_fe_pers[1]) 	"&" (share_fe_pers[1]) 		"&  &" (var_fe_pers[2]) 	"& " (share_fe_pers[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Education-year FEs (\%) &" 		(var_xb_year[1]) 	"&" (share_xb_year[1]) 		"&  &" (var_xb_year[2]) 	"& " (share_xb_year[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Education-age FEs (\%) &" 		(var_xb_age[1]) 	"&" (share_xb_age[1]) 		"&  &" (var_xb_age[2]) 		"& " (share_xb_age[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Hours FEs (\%) &" 				(var_xb_hours[1]) 	"&" (share_xb_hours[1])		"&  &" (var_xb_hours[2]) 	"& " (share_xb_hours[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Occupation FEs (\%) &" 			(var_xb_occ[1])		"&" (share_xb_occ[1])		"&  &" (var_xb_occ[2]) 		"& " (share_xb_occ[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Tenure FEs (\%) &" 				(var_xb_tenure[1])	"&" (share_xb_tenure[1])	"&  &" (var_xb_tenure[2]) 	"& " (share_xb_tenure[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Actual experience FEs (\%) &"	(var_xb_exp_act[1])	"&" (share_xb_exp_act[1])	"&  &" (var_xb_exp_act[2])	"& " (share_xb_exp_act[2]) "\tabularnewline" _n ///
///  		"$\quad$ Covariances (\%) &" 			(cov_sum[1]) 			"&" (share_cov_sum[1]) 			"&  &" (cov_sum[2]) 			"& " (share_cov_sum[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Residual (\%) &" 				(var_resid[1]) 		"&" (share_resid[1])		"&  &" (var_resid[2]) 		"& " (share_resid[2]) "\tabularnewline" _n ///
/// 		"Covariance components: &  &  &  &  & \tabularnewline" _n ///
/// 		"$\quad$ Employer FEs (\%) &" 			(cov_inc_fe_emp[1]) 	"&" (share_cov_inc_fe_emp[1]) 		"&  &" (cov_inc_fe_emp[2]) 		"& " (share_cov_inc_fe_emp[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Person FEs (\%) &" 				(cov_inc_fe_pers[1]) 	"&" (share_cov_inc_fe_pers[1]) 		"&  &" (cov_inc_fe_pers[2]) 	"& " (share_cov_inc_fe_pers[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Education-year FEs (\%) &" 		(cov_inc_xb_year[1]) 	"&" (share_cov_inc_xb_year[1]) 		"&  &" (cov_inc_xb_year[2]) 	"& " (share_cov_inc_xb_year[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Education-age FEs (\%) &" 		(cov_inc_xb_age[1]) 	"&" (share_cov_inc_xb_age[1]) 		"&  &" (cov_inc_xb_age[2]) 		"& " (share_cov_inc_xb_age[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Hours FEs (\%) &" 				(cov_inc_xb_hours[1]) 	"&" (share_cov_inc_xb_hours[1])		"&  &" (cov_inc_xb_hours[2]) 	"& " (share_cov_inc_xb_hours[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Occupation FEs (\%) &" 			(cov_inc_xb_occ[1])		"&" (share_cov_inc_xb_occ[1])		"&  &" (cov_inc_xb_occ[2]) 		"& " (share_cov_inc_xb_occ[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Tenure FEs (\%) &" 				(cov_inc_xb_tenure[1])	"&" (share_cov_inc_xb_tenure[1])	"&  &" (cov_inc_xb_tenure[2]) 	"& " (share_cov_inc_xb_tenure[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Actual experience FEs (\%) &"	(cov_inc_xb_exp_act[1])	"&" (share_cov_inc_xb_exp_act[1])	"&  &" (cov_inc_xb_exp_act[2])	"& " (share_cov_inc_xb_exp_act[2]) "\tabularnewline" _n ///
/// 		"$\quad$ Residual &" 				(cov_inc_resid[1]) 		"&" (share_cov_inc_resid[1])		"&  &" (cov_inc_resid[2]) 		"& " (share_cov_inc_resid[2]) "\tabularnewline" _n ///
		"Correlation & \multicolumn{2}{l}{" (corr_pers_emp[1]) "} &  & \multicolumn{2}{l}{" (corr_pers_emp[2]) "}\tabularnewline" _n ///
/// 		"Observations & \multicolumn{2}{l}{" (N[1]) "} &  & \multicolumn{2}{l}{" (N[2]) "}\tabularnewline" _n ///
		"$ R^{2}$ & \multicolumn{2}{l}{" (r2[1]) "} &  & \multicolumn{2}{l}{" (r2[2]) "}\tabularnewline" _n ///
		"Mean employer FE & \multicolumn{2}{l}{" %4.3f (`log_w_m_mean') "} &  & \multicolumn{2}{l}{" %4.3f (`log_w_f_mean') "}\tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_akm_decomp
	
}


*** AKM variance decomposition with KSS bias correction
if $tab_akm_kss_decomp {
	
	* load KSS estimates
	foreach stat in var_y var_fe var_pe cov_fe_pe corr_fe_pe r_2 {
		foreach method in plugin leaveout {
			forval g = 1/2 {
				if "`stat'" == "var_y" {
					qui import delim using "${DIR_TEMP}/output_akm_kss_`stat'_`g'.csv", clear
					sum v1, meanonly
					if "`stat'" == "cov_fe_pe" local `stat'_`g' = 2*r(mean)
					else local `stat'_`g' = r(mean)
					local `stat'_`g'_disp: di %4.3f ``stat'_`g''
				}
				else {
					qui import delim using "${DIR_TEMP}/output_akm_kss_`stat'_`method'_`g'.csv", clear
					sum v1, meanonly
					if "`stat'" == "cov_fe_pe" local `stat'_`method'_`g' = 2*r(mean)
					else local `stat'_`method'_`g' = r(mean)
					local `stat'_`method'_`g'_disp: di %4.3f ``stat'_`method'_`g''
				}
				
			}
		}
	}
	
	* compute variance shares
	foreach stat in var_fe var_pe cov_fe_pe {
		foreach method in plugin leaveout {
			forval g = 1/2 {
				qui import delim using "${DIR_TEMP}/output_akm_kss_`stat'_`method'_`g'.csv", clear
				sum v1, meanonly
				local share_`stat'_`method'_`g' = ``stat'_`method'_`g''/`var_y_`g''*100
				local share_`stat'_`method'_`g'_disp: di %4.1f `share_`stat'_`method'_`g''
			}
		}
	}
	
	* writing the table on a .tex file	
	cap macro drop file_akm_kss_decomp
	cap file close file_akm_kss_decomp
	file open file_akm_kss_decomp using "${DIR_RES_TAB}/${f_tab_akm_kss_decomp}", write replace
	file write file_akm_kss_decomp ///
		"\begin{tabular}{lccccccccc}" _n ///
		"&  &  &  &  &  &  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"& \multicolumn{4}{c}{Men} &  & \multicolumn{4}{c}{Women}\tabularnewline" _n ///
		"\cline{2-5} \cline{7-10}" _n ///
		"& \multicolumn{2}{c}{Plug-in} & \multicolumn{2}{c}{Leave-out} &  & \multicolumn{2}{c}{Plug-in} & \multicolumn{2}{c}{Leave-out}\tabularnewline" _n ///
		"\cline{2-3} \cline{4-5} \cline{7-8} \cline{9-10}" _n ///
		"Variances & Level & Share (\%) & Level & Share (\%) &  & Level & Share (\%) & Level & Share (\%)\tabularnewline" _n ///
		"\hline" _n ///
		"Variance & `var_y_1_disp' & & `var_y_1_disp' & & & `var_y_2_disp' & & `var_y_2_disp' & \tabularnewline" _n ///
		"Components: &  &  &  &  &  &  &  &  & \tabularnewline" _n ///
		"$\quad$ Employer FEs (\%) & `var_fe_plugin_1_disp' & `share_var_fe_plugin_1_disp' & `var_fe_leaveout_1_disp' & `share_var_fe_leaveout_1_disp' & & `var_fe_plugin_2_disp' & `share_var_fe_plugin_2_disp' & `var_fe_leaveout_2_disp' & `share_var_fe_leaveout_2_disp' \tabularnewline" _n ///
		"$\quad$ Person FEs (\%) & `var_pe_plugin_1_disp' & `share_var_pe_plugin_1_disp' & `var_pe_leaveout_1_disp' & `share_var_pe_leaveout_1_disp' & & `var_pe_plugin_2_disp' & `share_var_pe_plugin_2_disp' & `var_pe_leaveout_2_disp' & `share_var_pe_leaveout_2_disp' \tabularnewline" _n ///
		"Correlation & `corr_fe_pe_plugin_1_disp' & & `corr_fe_pe_leaveout_1_disp' & & & `corr_fe_pe_plugin_2_disp' & & `corr_fe_pe_leaveout_2_disp' & \tabularnewline" _n ///
		"$ R^{2}$ & `r_2_plugin_1_disp' & & `r_2_leaveout_1_disp' & & & `r_2_plugin_2_disp' & & `r_2_leaveout_2_disp' & \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_akm_kss_decomp
// 	"$\quad$ $2 \times$Covariance & `cov_fe_pe_plugin_1_disp' & & `cov_fe_pe_leaveout_1_disp' & & & `cov_fe_pe_plugin_2_disp' & & `cov_fe_pe_leaveout_2_disp' & \tabularnewline" _n ///
}


*** AKM variance decomposition combining plug-in estimates with KSS bias correction
if $tab_akm_combined_decomp {
	
	* load KSS estimates
	foreach stat in var_y var_fe var_pe cov_fe_pe corr_fe_pe r_2 {
		foreach method in plugin leaveout {
			forval g = 1/2 {
				if "`stat'" == "var_y" {
					qui import delim using "${DIR_TEMP}/output_akm_kss_`stat'_`g'.csv", clear
					sum v1, meanonly
					if "`stat'" == "cov_fe_pe" local `stat'_`g' = 2*r(mean)
					else local `stat'_`g' = r(mean)
					local `stat'_`g'_disp: di %4.3f ``stat'_`g''
				}
				else {
					qui import delim using "${DIR_TEMP}/output_akm_kss_`stat'_`method'_`g'.csv", clear
					sum v1, meanonly
					if "`stat'" == "cov_fe_pe" local `stat'_`method'_`g' = 2*r(mean)
					else local `stat'_`method'_`g' = r(mean)
					local `stat'_`method'_`g'_disp: di %4.3f ``stat'_`method'_`g''
				}
				
			}
		}
	}
	
	* compute variance shares
	foreach stat in var_fe var_pe cov_fe_pe {
		foreach method in plugin leaveout {
			forval g = 1/2 {
				qui import delim using "${DIR_TEMP}/output_akm_kss_`stat'_`method'_`g'.csv", clear
				sum v1, meanonly
				local share_`stat'_`method'_`g' = ``stat'_`method'_`g''/`var_y_`g''*100
				local share_`stat'_`method'_`g'_disp: di %4.1f `share_`stat'_`method'_`g''
			}
		}
	}
	
	* load post-estimation dataset to get mean employer FEs by gender
	use ///
		log_w_* size* ///
		using "${DIR_TEMP}/post_est.dta", clear
	
	* compute gender-specific mean employer FEs
	foreach g in m f {
		sum log_w_`g' [aw=size_`g']
		local log_w_`g'_mean: di %4.3f `=r(mean)'
	}
	
	* load data containing plug-in estimates
	use "${DIR_TEMP}/akm_decomp.dta", clear
	
	* create formatted local macros based on variable contents
	foreach var of varlist var_inc var_fe_emp var_fe_pers corr_pers_emp r2 {
		forval g = 1/2 {
			sum `var' if _n == `g', meanonly
			local `var'_`g'_disp: di %4.3f `=r(mean)'
		}
	}
	foreach var of varlist share_fe_emp share_fe_pers {
		forval g = 1/2 {
			sum `var' if _n == `g', meanonly
			local `var'_`g'_disp: di %3.1f `=r(mean)'
		}
	}
	
	* writing the table on a .tex file
	cap macro drop file_akm_combined_decomp
	cap file close file_akm_combined_decomp
	file open file_akm_combined_decomp using "${DIR_RES_TAB}/${f_tab_akm_combined_decomp}", write replace
	file write file_akm_combined_decomp ///
		"\begin{tabular}{lcclcc}" _n ///
		"&  &  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"& \multicolumn{2}{c}{Men} &  & \multicolumn{2}{c}{Women}\tabularnewline" _n ///
		"\cline{2-3} \cline{3-3} \cline{5-6} \cline{6-6}" _n ///
		"& Plug-in & Leave-out &  & Plug-in & Leave-out\tabularnewline" _n ///
		"\hline" _n ///
		"Variance of log earnings & `var_inc_1_disp' & `var_y_1_disp' &  & `var_inc_2_disp' & `var_y_2_disp' \tabularnewline" _n ///
		"Variance components: &  &  &  &  & \tabularnewline" _n ///
		"$\quad$ Employer FEs (\%) & `var_fe_emp_1_disp' (`share_fe_emp_1_disp'\%) & `var_fe_leaveout_1_disp' (`share_var_fe_leaveout_1_disp'\%) &  & `var_fe_emp_2_disp' (`share_fe_emp_2_disp'\%) & `var_fe_leaveout_2_disp' (`share_var_fe_leaveout_2_disp'\%) \tabularnewline" _n ///
		"$\quad$ Person FEs (\%) & `var_fe_pers_1_disp' (`share_fe_pers_1_disp'\%) & `var_pe_leaveout_1_disp' (`share_var_pe_leaveout_1_disp'\%) &  & `var_fe_pers_2_disp' (`share_fe_pers_2_disp'\%) & `var_pe_leaveout_2_disp' (`share_var_pe_leaveout_2_disp'\%) \tabularnewline" _n ///
		"Correlation & `corr_pers_emp_1_disp' & `corr_fe_pe_leaveout_1_disp' &  & `corr_pers_emp_2_disp' & `corr_fe_pe_leaveout_2_disp' \tabularnewline" _n ///
		"$ R^{2}$ & `r2_1_disp' & `r_2_leaveout_1_disp' &  & `r2_2_disp' & `r_2_leaveout_2_disp' \tabularnewline" _n ///
		"Mean employer FE & `log_w_m_mean' & `log_w_m_mean' &  & `log_w_f_mean' & `log_w_f_mean' \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_akm_combined_decomp
	
}


*** Kitagawa-Oaxaca-Blinder decomposition of total gender-firm pay gap into between vs. within components
if $tab_kob {
	
	* loop through whole economy / private sector only / public sector only
	foreach robustness in "" "private" "public" "us_size" "eta_a_h" "eta_a_d" "delta" "pageranks" {
		
		* define data input file
		if inlist("`robustness'", "", "private", "public") local file_data = "${DIR_TEMP}/firm_parameters_merged_match${match_F_or_G}_${baseline_rank}_p_pi_z.dta" // note: old file is "${DIR_TEMP}/firm_parameters_merged_match${match_F_or_G}_${baseline_rank}_p_pi_z - Copy of OLD results.dta"
		else if "`robustness'" == "us_size" local file_data = "${DIR_TEMP}/firm_parameters_UScase_match${match_F_or_G}_${baseline_rank}_p_pi_z.dta"
		else if "`robustness'" == "eta_a_h" local file_data = "${DIR_TEMP}/firm_parameters_rob_amenity_share_004_match${match_F_or_G}_${baseline_rank}_p_pi_z.dta"
		else if "`robustness'" == "eta_a_d" local file_data = "${DIR_TEMP}/firm_parameters_rob_amenity_share_016_match${match_F_or_G}_${baseline_rank}_p_pi_z.dta"		
		else if "`robustness'" == "delta" local file_data = "${DIR_TEMP}/firm_parameters_hetdelta_match${match_F_or_G}_${baseline_rank}_p_pi_z.dta"		
		else if "`robustness'" == "pageranks" local file_data = "${DIR_TEMP}/firm_parameters_merged_match${match_F_or_G}_7_p_pi_z.dta"
		
		* define file extension
		if "`robustness'" == "" local robustness_str = ""
		else if "`robustness'" == "private" local robustness_str = "_pri"
		else if "`robustness'" == "public" local robustness_str = "_pub"
		else if "`robustness'" == "us_size" local robustness_str = "_us_size"
		else if "`robustness'" == "eta_a_h" local robustness_str = "_eta_a_h"
		else if "`robustness'" == "eta_a_d" local robustness_str = "_eta_a_d"
		else if "`robustness'" == "delta" local robustness_str = "_delta"
		else if "`robustness'" == "pageranks" local robustness_str = "_pageranks"
		
		* load data
		use ///
			id_emp g_m g_f fe_m fe_f pi_m pi_f ///
			using "`file_data'", clear

		* rename variables
		foreach g in m f {
			rename fe_`g' log_w_`g'
			lab var log_w_`g' "Log pay (`g')"
		}

		* create variables in levels
		foreach g in m f {
			qui gen double w_`g' = exp(log_w_`g')
			lab var w_`g' "Level pay (`g')"
		}

		* generate flow utility
		foreach g in m f {
			qui gen double x_`g' = w_`g' + pi_`g'
			lab var x_`g' "Level flow utility (`g')"
		}

		* create variables in logs
		foreach g in m f {
			qui gen double log_pi_`g' = ln(pi_`g')
			lab var log_pi_`g' "Log amenity (`g')"
			qui gen double log_x_`g' = ln(x_`g')
			lab var log_x_`g' "Log flow utility (`g')"
		}
		
		* merge in indicator for public sector
		if inlist("`robustness'", "private", "public") qui merge m:1 id_emp using "${DIR_TEMP}/id_emp_public.dta", keepusing(public) keep(master match) nogen
		
		* create multiplicative amenities term
		foreach g in m f {
			qui gen float pi_tilde_`g' = x_`g'/w_`g'
			lab var pi_tilde_`g' "Multiplicative amenities term (\tilde{a} = x/w), gender `g'"
			qui gen float log_pi_tilde_`g' = ln(pi_tilde_`g')
			lab var log_pi_tilde_`g' "Log of multiplicative amenities term (ln(\tilde{a}) = ln(x) - ln(w)), gender `g'"
		}
		
		* keep whole economy / private sector only / public sector only
		di _newline(1)
		if "`robustness'" == "" {
			di as result "--> KOB for whole economy"
		}
		else if "`robustness'" == "private" {
			di as result "--> KOB for private sector only"
			qui keep if public == 0
		}
		else if "`robustness'" == "public" {
			di as result "--> KOB for public sector only"
			qui keep if public == 1
		}
		else if "`robustness'" == "us_size" {
			di as result "--> KOB for US employer size distribution"
		}
		else if "`robustness'" == "eta_a_h" {
			di as result "--> KOB for half the amenity-cost elasticity"
		}
		else if "`robustness'" == "eta_a_d" {
			di as result "--> KOB for double the amenity-cost elasticity"
		}
		else if "`robustness'" == "delta" {
			di as result "--> KOB for heterogeneous firm-level separation rates"
		}
		else if "`robustness'" == "pageranks" {
			di as result "--> KOB for PageRanks as employer ranks"
		}
		else {
			di as error "USER ERROR: Cannot find subgroup `robustness' in code!"
			error 1
		}
		if inlist("`robustness'", "private", "public") drop public
		
		* [RECAP TABLE] writing the table summarizing all three files ...
		cap file close file_kob_2
		file open file_kob_2 using "${DIR_RES_TAB}/${f_tab_kob_log_w_pi_x`robustness_str'}", write replace
		file write file_kob_2 ///
			"\begin{tabular}{lccccccc}" _n ///
			"&  &  &  &  &  &  & \tabularnewline" _n ///
			"\hline" _n ///
			"\hline" _n ///
			"& \multicolumn{1}{c}{} &  & \multicolumn{2}{c}{Between-employer gap} &  & \multicolumn{2}{c}{Within-employer gap}\tabularnewline" _n ///
			"\cline{4-5} \cline{5-5} \cline{7-8} \cline{8-8}" _n ///
			"& Gender gap &  & Level & Share (\%) &  & Level & Share (\%)\tabularnewline" _n ///
			"\hline" _n ///
		
		* loop through compensation components
		foreach comp in log_w log_pi_tilde log_x { // i.e., use the multiplicative amenities term (\tilde{a} = x/w)
			
			* define compensation component
			if "`comp'" == "log_w" {
				local comp_str = "log pay"
				local str_recap_table = "Pay"
			}
			else if inlist("`comp'", "log_pi", "log_pi_tilde") {
				local comp_str = "log amenities"
				local str_recap_table = "Amenity-valuation"
			}
			else if "`comp'" == "log_x" {
				local comp_str = "log total compensation"
				local str_recap_table = "Total compensation"
			}
			
			* preserve
			preserve
			
			* Kitagawa-Oaxaca-Blinder decomposition
			prog_kob "`comp'"
			
			* load .dta with decompositions
			use "${DIR_TEMP}/postfile_kob_`comp'.dta", clear
			compress
			
			* adding hphantom
			forval i = 1/2 {
				foreach var in gender_pay_gap level_sorting share_sorting level_pay share_pay {
					if real(`var'[`i']) >= 0 local hphantom_`var'_`i' = "\hphantom{$-$}"
					else local hphantom_`var'_`i' = ""
				}
			}
			
			* [INDIVIDUAL TABLES] writing the table to a .tex file
			cap macro drop file_kob
			cap file close file_kob
			file open file_kob using "${DIR_RES_TAB}/${f_tab_kob_`comp'`robustness_str'}", write replace
			file write file_kob ///
				"\begin{tabular}{lccccccc}" _n ///
				"&  &  &  &  &  &  & \tabularnewline" _n ///
				"\hline" _n ///
				"\hline" _n ///
				"& \multicolumn{1}{c}{} &  & \multicolumn{2}{c}{Between-employer gap} &  & \multicolumn{2}{c}{Within-employer gap}\tabularnewline" _n ///
				"\cline{4-5} \cline{5-5} \cline{7-8} \cline{8-8}" _n ///
				"& Gender `comp_str' gap &  & Level & Share (\%) &  & Level & Share (\%)\tabularnewline" _n ///
				"\hline" _n ///
				"Decomposition 1 & `hphantom_gender_pay_gap_1'$" (gender_pay_gap[1]) "$ &  & `hphantom_level_sorting_1'$" (level_sorting[1]) "$ & `hphantom_share_sorting_1'$" (share_sorting[1]) "$ &  & `hphantom_level_pay_1'$" (level_pay[1]) "$ & `hphantom_share_pay_1'$" (share_pay[1]) "$ \tabularnewline" _n ///
				"Decomposition 2 & `hphantom_gender_pay_gap_2'$" (gender_pay_gap[2]) "$ &  & `hphantom_level_sorting_2'$" (level_sorting[2]) "$ & `hphantom_share_sorting_2'$" (share_sorting[2]) "$ &  & `hphantom_level_pay_2'$" (level_pay[2]) "$ & `hphantom_share_pay_2'$" (share_pay[2]) "$ \tabularnewline" _n ///
				"\hline" _n ///
				"\end{tabular}"
			file close file_kob
			
			* short-form table for log pay
			if "`comp'" == "log_w" {
				cap macro drop file_kob_short
				cap file close file_kob_short
				file open file_kob_short using "${DIR_RES_TAB}/${f_tab_kob_`comp'_short`robustness_str'}", write replace
				file write file_kob_short ///
					"\begin{tabular}{cccccccc}" _n ///
					"&  &  &  &  &  & \tabularnewline" _n ///
					"\hline" _n ///
					"\hline" _n ///
					"\multicolumn{1}{c}{} &  & \multicolumn{2}{c}{Between-employer gap} &  & \multicolumn{2}{c}{Within-employer gap}\tabularnewline" _n ///
					"\cline{3-4} \cline{4-4} \cline{6-7} \cline{7-7}" _n ///
					"Gender gap in employer FEs &  & Level & Share (\%) &  & Level & Share (\%)\tabularnewline" _n ///
					"\hline" _n ///
					"$" (gender_pay_gap[1]) "$ &  & $" (level_sorting[1]) "$ & $" (share_sorting[1]) "$ &  & $" (level_pay[1]) "$ & $" (share_pay[1]) "$ \tabularnewline" _n ///
					"\hline" _n ///
					"\end{tabular}"
				file close file_kob_short
			}
			
			* [RECAP TABLE] writing the table that recaps all three files for Decomposition 2
			file write file_kob_2 "`str_recap_table' & `hphantom_gender_pay_gap_1'$" (gender_pay_gap[1]) "$ &  & `hphantom_level_sorting_1'$" (level_sorting[1]) "$ & `hphantom_share_sorting_1'$" (share_sorting[1]) "$ &  & `hphantom_level_pay_1'$" (level_pay[1]) "$ & `hphantom_share_pay_1'$" (share_pay[1]) "$ \tabularnewline" _n ///
			
			* restore
			restore
		}
		
		* [RECAP TABLE] closing the recap table of Decomposition 2
		file write file_kob_2 "\hline" _n ///
			"\end{tabular}" 
		qui file close file_kob_2
	}
	
}


*** labor market parameters
if $tab_lab_params {
	
	* load population shares
	use "${DIR_TEMP}/pop_shares.dta", clear
	keep if rank_concept == ${baseline_rank}
	drop rank_concept
	save "${DIR_TEMP}/temp_pop_shares.dta", replace
	
	* load labor market parameters data
	use "${DIR_TEMP}/lab_params_summary.dta", clear
	
	* merge in population shares
	merge 1:1 gender using "${DIR_TEMP}/temp_pop_shares.dta", keep(master match) keepusing(pop_share) nogen
	
	* formatting variables + converting to string (all but gender)
	ds gender, not 
	format `r(varlist)' %4.3f
	tostring `r(varlist)', format(%18.3f) replace force
	
	* writing the table on a .tex file	
	cap macro drop file_lab_params
	cap file close file_lab_params
	file open file_lab_params using "${DIR_RES_TAB}/${f_tab_lab_params}", write replace
	file write file_lab_params ///
		"\begin{tabular}{clccc}" _n ///
		"&  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"Parameter & Description & Men & & Women \tabularnewline" _n ///
		"\hline" _n ///
		"$\quad \mu_{g}$ & Population shares &" 			(pop_share[1]) 	"&  &" (pop_share[2]) 	 "" "\tabularnewline" _n ///
		"$\quad \lambda_{g}^{U}$ & Offer arrival rate from nonemployment &" 			(lambda_u[1]) 	"&  &" (lambda_u[2]) 	 "" "\tabularnewline" _n ///
		"$\quad \delta_{g}$ & Job destruction rate &" 									(delta[1]) 		"& 	&" (delta[2]) 		 "" "\tabularnewline" _n ///
		"$\quad s_{g}^{E}$ & Relative arrival rate of voluntary on-the-job offers &" 	(s_e[1]) 		"&  &" (s_e[2]) 		 "" "\tabularnewline" _n ///
		"$\quad s_{g}^{G}$ & Relative arrival rate of involuntary on-the-job offers &" 	(s_g[1]) 		"&  &" (s_g[2]) 		 "" "\tabularnewline" _n ///
		"$\quad b_{g}$ & Flow value of nonemployment &" 								(b[1]) 			"&  &" (b[2]) 			 "" "\tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_lab_params
	
}


*** model-fit statistics
if $tab_model_fit {

	* load data
	use ///
		id_emp gender EE pay_decline ///
		using "${DIR_TEMP}/temp_lab_params.dta", clear

	* merge with estimation data
	merge m:1 id_emp using "${DIR_TEMP}/post_est.dta", keep(match) keepusing(id_emp) nogen
	drop id_emp
	
	* compute probability of pay cut upon E-to-E transition
	forval g = 1/2 {
		foreach var of varlist EE pay_decline {
			sum `var' if gender == `g', meanonly
			local `var'_mean_`g' = r(mean)
		}
	}
	
	* create mini-dataset
	clear
	set obs 1
	forval g = 1/2 {
		foreach var in EE pay_decline {
			gen float `var'_mean_`g' = ``var'_mean_`g''
		}
	}
	
	* export statistics
	export delim using "${DIR_TEMP}/model_fit_data.csv", delim(tab) novarnames replace // note: this will be read in MATLAB to create model-fit table

}


*** correlations between model parameters
if $tab_corr {
	
	* load data
	use "${DIR_TEMP}/post_est.dta", clear
	
	* within-gender correlations using gender-specific employment weights
	local var_list = "w pi x p size rank"
	foreach g in m f {
		local var_list_`g' = ""
		foreach var of local var_list {
			local var_list_`g' = "`var_list_`g'' `var'_`g'"
		}
		pwcorr `var_list_`g'' [aw=g_`g']
		matrix C_`g' = r(C)
	}
	foreach g in m f {
		local N_var: word count `var_list_`g''
		forval i = 1/`N_var' {
			forval j = 1/`i' {
				if `i' != `j' {
					local corr_`i'_`j': di %4.3f C_`g'[`i',`j']
				}
				
				* hphantom needed?
				if C_`g'[`i', `j'] > 0 local hphantom_`g'_`i'_`j' = "\hphantom{$-$}"
				if C_`g'[`i', `j'] < 0 local hphantom_`g'_`i'_`j' = ""
			}
		}
	}
	
	foreach g in m f {
		
		* for the headers
		if "`g'" == "m" {
			local G = "M"
			local p_g = "p"
		}
		if "`g'" == "f" {
			local G = "F"
			local p_g = "(1 - \tau)p"
		}
		
		* writing the table on a .tex file (two separate tables by gender)
		cap macro drop file_corr_`g'
		cap file close file_corr_`g'
		file open file_corr_`g' using "${DIR_RES_TAB}/${f_tab_corr_`g'}", write replace
		file write file_corr_`g'	"\begin{tabular}{ccccccc}" _n ///
									"\hline" _n ///
									"\hline" _n ///
									"& $ w_{`G'}$  &  $ a_{`G'}$  &  $ x_{`G'}$  &  $ `p_g' $ &  $ l_{`G'}$ &  $ r_{`G'}$ \tabularnewline" _n ///
									"\hline" _n ///
									"$ w_{`G'}$ & `hphantom_`g'_1_1'$" %4.3f (C_`g'[1,1]) "$ & & & & & \tabularnewline" _n ///
									"$ a_{`G'}$ & `hphantom_`g'_2_1'$" %4.3f (C_`g'[2,1]) "$ & `hphantom_`g'_2_2'$" %4.3f (C_`g'[2,2]) "$ & & & & \tabularnewline" _n ///
									"$ x_{`G'}$ & `hphantom_`g'_3_1'$" %4.3f (C_`g'[3,1]) "$ & `hphantom_`g'_3_2'$" %4.3f (C_`g'[3,2]) "$ & `hphantom_`g'_3_3'$" %4.3f (C_`g'[3,3]) "$ & & & \tabularnewline" _n ///
									"$ `p_g'$ & `hphantom_`g'_4_1'$" %4.3f (C_`g'[4,1]) "$ & `hphantom_`g'_4_2'$" %4.3f (C_`g'[4,2]) "$ & `hphantom_`g'_4_3'$" %4.3f (C_`g'[4,3]) "$ & `hphantom_`g'_4_4'$" %4.3f (C_`g'[4,4]) "$ & & \tabularnewline" _n ///
									"$ l_{`G'}$ & `hphantom_`g'_5_1'$" %4.3f (C_`g'[5,1]) "$ & `hphantom_`g'_5_2'$" %4.3f (C_`g'[5,2]) "$ & `hphantom_`g'_5_3'$" %4.3f (C_`g'[5,3]) "$ & `hphantom_`g'_5_4'$" %4.3f (C_`g'[5,4]) "$ & `hphantom_`g'_5_5'$" %4.3f (C_`g'[5,5]) "$ & \tabularnewline" _n ///
									"$ r_{`G'}$ & `hphantom_`g'_6_1'$" %4.3f (C_`g'[6,1]) "$ & `hphantom_`g'_6_2'$" %4.3f (C_`g'[6,2]) "$ & `hphantom_`g'_6_3'$" %4.3f (C_`g'[6,3]) "$ & `hphantom_`g'_6_4'$" %4.3f (C_`g'[6,4]) "$ & `hphantom_`g'_6_5'$" %4.3f (C_`g'[6,5]) "$ & `hphantom_`g'_6_6'$" %4.3f (C_`g'[6,6]) "$ \tabularnewline" _n ///
									"\hline" _n ///
									"\end{tabular}"
		file close file_corr_`g'
	}
	
	
	* cross-gender correlations using sum of gender-specific employment weights
	local var_list = "w pi x p size rank"
	local var_list_combined = ""
	foreach var of local var_list {
		local var_list_combined = "`var_list_combined' `var'_m `var'_f"
	}
	pwcorr `var_list_combined' [aw=g]
	matrix C_combined = r(C)
	local N_var: word count `var_list'
	forval i = 1/`N_var' {
		local corr_`i': di %4.3f C_combined[2*`i', 2*`i' - 1]
	}
	
	* writing the table on a .tex file (two separate tables by gender)
	cap macro drop file_corr_cross
	cap file close file_corr_cross
	file open file_corr_cross using "${DIR_RES_TAB}/${f_tab_corr_cross}", write replace
	file write file_corr_cross	"\begin{tabular}{ccccccc}" _n ///
								"\hline" _n ///
								"\hline" _n ///
								"& $ w_{g}$  &  $ a_{g}$  &  $ x_{g}$  &  $ (1 - \tau_{g})p_{g}$ &  $ l_{g}$ &  $ r_{g}$ \tabularnewline" _n ///
								"\hline" _n ///
								"Cross-gender correlation & $" %4.3f (`corr_1') "$ & $" %4.3f (`corr_2') "$ & $" %4.3f (`corr_3') "$ & $" %4.3f (`corr_4') "$ & $" %4.3f (`corr_5') "$ & $" %4.3f (`corr_6') "$ \tabularnewline" _n ///
								"\hline" _n ///
								"\end{tabular}"
	file close file_corr_cross
	
}


*** Appendix A1-A5
if $tab_sum_stats_app_a1_a5 {
	
	*** Appendix A1, A2, A3: respectively: 2007-2014-Pooled for (A1) all (A2) selection and (A3) connected
	foreach t in all selection connected {
		
		* set locals to save based on whether Table A1, A2 or A3 is being produced
		if "`t'" == "all" 		local one_two_three = 1
		if "`t'" == "selection"	local one_two_three = 2
		if "`t'" == "connected"	local one_two_three = 3
		
		* load data
		use "${DIR_TEMP}/sum_stats_`t'.dta", clear
		
		* dropping the rows we do not need
		drop if var_label == "Share nonnative"
		drop if var_label == "Year"
		drop if var_label == "Subgroup"
		drop if var_label == "Mean log gender wage gap"
		* drop the "Mean log real hourly wage" and standard dev. in an automatic way
		gen obsno = _n
		${gtools}levelsof obsno if var_label == "Mean log real hourly wage", local(to_be_dropped)
		drop if obsno == `to_be_dropped' | obsno == `to_be_dropped' + 1
		drop obsno
		
		* renaming some columns
		replace var_label = "Mean years of age" if var_label == "Mean age"
		replace var_label = "Mean years of tenure" if var_label == "Mean tenure (years)"
		replace var_label = "Number of unique employers" if var_label == "Number of unique establishments"
		replace var_label = "Mean employer size" if var_label == "Mean establishment size"
		replace var_label = "Mean gender-employer size" if var_label == "Mean gender-establishment size"
		replace var_label = "Mean employer age" if var_label == "Mean establishment age"
		replace var_label = "Share Nonwhite" if var_label == "Share nonwhite"
		
		* replicating the structure of the current table
		foreach i in 2007 2014 Pooled {
			replace Men`i' = "" if var_label == "Mean log gender earnings gap"
			replace Women`i' = "" if var_label == "Mean log gender earnings gap"
		}

		* Writing the table on a .tex file	
		cap macro drop file_appendix_a`one_two_three'
		cap file close file_appendix_a`one_two_three'
		file open file_appendix_a`one_two_three' using "${DIR_RES_TAB}/${f_tab_appendix_a`one_two_three'}", write replace
		file write file_appendix_a`one_two_three' ///
			"{\footnotesize{}}%" _n ///
			"\begin{tabular}{lccccccccccc}" _n ///
			"&  &  &  &  &  &  &  &  &  &  & \tabularnewline" _n ///
			"\hline" _n ///
			"\hline" _n ///
			"& \multicolumn{3}{c}{{\footnotesize{}2007}} &  & \multicolumn{3}{c}{{\footnotesize{}2014}} &  & \multicolumn{3}{c}{{\footnotesize{}Pooled 2007--2014}}\tabularnewline" _n ///
			"\cline{2-4} \cline{3-4} \cline{4-4} \cline{6-8} \cline{7-8} \cline{8-8} \cline{10-12} \cline{11-12} \cline{12-12}" _n ///
			"& {\footnotesize{}Overall} & {\footnotesize{}Men} & {\footnotesize{}Women} &  & {\footnotesize{}Overall} & {\footnotesize{}Men} & {\footnotesize{}Women} &  & {\footnotesize{}Overall} & {\footnotesize{}Men} & {\footnotesize{}Women}\tabularnewline" _n ///
			"\hline" _n
		
		* Looping through the dataset, as the .dta is basically identical to the final table
		count
		forval i = 1/`=r(N)' {
			
			* The LaTeX code is slightly different if the std. dev. is being included
			if var_label[`i'] == "(std. dev.)" {
				file write file_appendix_a`one_two_three' "{\footnotesize{}$\quad$ " (var_label[`i']) "} & {\footnotesize{}" (Overall2007[`i']) "} & {\footnotesize{}" (Men2007[`i']) "} & {\footnotesize{}" (Women2007[`i']) "} &  & {\footnotesize{}" (Overall2014[`i']) "} & {\footnotesize{}" (Men2014[`i']) "} & {\footnotesize{}" (Women2014[`i']) "} &  & {\footnotesize{}" (OverallPooled[`i']) "} & {\footnotesize{}" (MenPooled[`i']) "} & {\footnotesize{}" (WomenPooled[`i']) "}\tabularnewline"
			}
			else {
				file write file_appendix_a`one_two_three'	"{\footnotesize{}" (var_label[`i']) "} & {\footnotesize{}" (Overall2007[`i']) "} & {\footnotesize{}" (Men2007[`i']) "} & {\footnotesize{}" (Women2007[`i']) "} &  & {\footnotesize{}" (Overall2014[`i']) "} & {\footnotesize{}" (Men2014[`i']) "} & {\footnotesize{}" (Women2014[`i']) "} &  & {\footnotesize{}" (OverallPooled[`i']) "} & {\footnotesize{}" (MenPooled[`i']) "} & {\footnotesize{}" (WomenPooled[`i']) "}\tabularnewline" _n
			}
			
		}
		file write file_appendix_a`one_two_three' ///
			"\hline" _n ///
			"\end{tabular}"
		file close file_appendix_a`one_two_three'
	}
	

	*** Appendix A4-A5:
	*	A4: comparison between selection and all (pooled)	
	*	A5: comparison between connected and selection (pooled)	
	foreach t in selection connected {
		
		* set locals to show correct columnns based on whether Table A4 or A5 is being produced
		if "`t'" == "selection" {
			local four_five 		= 4
			
			local column_title_1 	= "selection set"
			local column_title_2	= "all"
			local column_title_3 	= "selection set to all"
			
			local column_2 			= "all"
			
		}
		if "`t'" == "connected" {
			local four_five 		= 5
			
			local column_title_1 	= "connected set" 
			local column_title_2 	= "selection set"
			local column_title_3 	= "connected set to selection set"
			
			local column_2 			= "selection"
		}
		
		* load data
		use "${DIR_TEMP}/sum_stats_comparison_`t'.dta", clear
		
		* dropping the rows we do not need
		drop if var_label == "Year"
		drop if var_label == "Subgroup"
		drop if var_label == "Sample"
		drop if var_label == "Share nonnative"
		drop if var_label == "Mean log gender wage gap"
		
		* drop the "Mean log real hourly wage" and standard dev. in an automatic way
		gen obsno = _n
		${gtools}levelsof obsno if var_label == "Mean log real hourly wage", local(to_be_dropped)
		drop if obsno == `to_be_dropped' | obsno == `to_be_dropped' + 1
		drop obsno
		
		* renaming some columns
		replace var_label = "Mean years of age" if var_label == "Mean age"
		replace var_label = "Mean years of tenure" if var_label == "Mean tenure (years)"
		replace var_label = "Number of unique employers" if var_label == "Number of unique establishments"
		replace var_label = "Mean employer size" if var_label == "Mean establishment size"
		replace var_label = "Mean gender-employer size" if var_label == "Mean gender-establishment size"
		replace var_label = "Mean employer age" if var_label == "Mean establishment age"
		replace var_label = "Share Nonwhite" if var_label == "Share nonwhite"
		
		* replicating the structure of the current table
		foreach i in `t' `column_2' `t'_perc {
			replace MenPooled_`i' 	= "" if var_label == "Mean log gender earnings gap"
			replace WomenPooled_`i' = "" if var_label == "Mean log gender earnings gap"
		}
		
		* removing the "%" symbol from the string
		replace OverallPooled_`t'_perc	= substr(OverallPooled_`t'_perc, 1, length(OverallPooled_`t'_perc) - 1)
		replace MenPooled_`t'_perc 		= substr(MenPooled_`t'_perc, 1, length(MenPooled_`t'_perc) - 1)
		replace WomenPooled_`t'_perc 	= substr(WomenPooled_`t'_perc, 1, length(WomenPooled_`t'_perc) - 1)
		
		* Writing the table on a .tex file
		cap macro drop file_appendix_a`four_five'
		cap file close file_appendix_a`four_five'
		file open file_appendix_a`four_five' using "${DIR_RES_TAB}/${f_tab_appendix_a`four_five'}", write replace
		file write file_appendix_a`four_five' ///
			"\begin{tabular}{lccccccccccc}" _n ///
			"&  &  &  &  &  &  &  &  &  &  & \tabularnewline" _n ///
			"\hline" _n ///
			"\hline" _n ///
			"& \multicolumn{3}{c}{{\footnotesize{}Pooled 2007--2014, `column_title_1'}} &  & \multicolumn{3}{c}{{\footnotesize{}Pooled 2007--2014, `column_title_2'}} &  & \multicolumn{3}{c}{{\footnotesize{}Ratio: `column_title_3'}}\tabularnewline" _n ///
			"\cline{2-4} \cline{3-4} \cline{4-4} \cline{6-8} \cline{7-8} \cline{8-8} \cline{10-12} \cline{11-12} \cline{12-12}" _n ///
			"& {\footnotesize{}Overall} & {\footnotesize{}Men} & {\footnotesize{}Women} &  & {\footnotesize{}Overall} & {\footnotesize{}Men} & {\footnotesize{}Women} &  & {\footnotesize{}Overall} & {\footnotesize{}Men} & {\footnotesize{}Women}\tabularnewline" _n ///
			"\hline" _n
		
		* Looping through the dataset, as the .dta is basically identical to the final table
		count
		forval i = 1/`=r(N)' {
			
			* The LaTeX code is slightly different if the std. dev. is being included
			if var_label[`i'] == "(std. dev.)" {
				file write file_appendix_a`four_five' "{\footnotesize{}$\quad$ " (var_label[`i']) "} & {\footnotesize{}" (OverallPooled_`t'[`i']) "} & {\footnotesize{}" (MenPooled_`t'[`i']) "} & {\footnotesize{}" (WomenPooled_`t'[`i']) "} &  & {\footnotesize{}" (OverallPooled_`column_2'[`i']) "} & {\footnotesize{}" (MenPooled_`column_2'[`i']) "} & {\footnotesize{}" (WomenPooled_`column_2'[`i']) "} &  & {\footnotesize{}" (OverallPooled_`t'_perc[`i']) "} & {\footnotesize{}" (MenPooled_`t'_perc[`i']) "} & {\footnotesize{}" (WomenPooled_`t'_perc[`i']) "}\tabularnewline"
			}
			else {
				file write file_appendix_a`four_five' "{\footnotesize{}" (var_label[`i']) "} & {\footnotesize{}" (OverallPooled_`t'[`i']) "} & {\footnotesize{}" (MenPooled_`t'[`i']) "} & {\footnotesize{}" (WomenPooled_`t'[`i']) "} &  & {\footnotesize{}" (OverallPooled_`column_2'[`i']) "} & {\footnotesize{}" (MenPooled_`column_2'[`i']) "} & {\footnotesize{}" (WomenPooled_`column_2'[`i']) "} &  & {\footnotesize{}" (OverallPooled_`t'_perc[`i']) "} & {\footnotesize{}" (MenPooled_`t'_perc[`i']) "} & {\footnotesize{}" (WomenPooled_`t'_perc[`i']) "}\tabularnewline" _n
			}
			
		}
		file write file_appendix_a`four_five' ///
			"\hline" _n ///
			"\end{tabular}"
		file close file_appendix_a`four_five'
	}
	
}


*** Appendix B1-B2: Mincer regressions
if $tab_mincer_app {
	
	*** Produce here Appendix Tables B1-B2
	* open postfile
	cap postclose postfile_mincer_specs
	postfile postfile_mincer_specs ///
		year ///
		str4 inc_concept ///
		str8 spec ///
		gap ///
		N ///
		r2 ///
		control_c_edu_y ///
		control_p_exp_pot ///
		control_i_g_tenure ///
		control_i_g_exp_act ///
		control_i_g_edu_x_age ///
		control_i_occ02_6 ///
		control_i_hours ///
		control_i_id_est ///
		using "${DIR_TEMP}/postfile_mincer_specs.dta", replace

	* loop over years
	foreach y in $year_min $year_max {

		* local macros
		local vars_list = "id_pers year id_est earn_mean_mw gender race edu age ind07_5 occ02_6 hours hours_year tenure exp_act" // when run on Chris' other machines incl. the CBS server
		// local vars_list = "persid year empid_est earn_mean_mw gender race edu age ind07_5 occ02_6 hours hours_year tenure exp_act" // when run on Chris' work laptop (MacBook Pro)

		* load data
		prog_load_data `y' `y' "`vars_list' month_hire month_sep id_unique" // i.e.,  "year id_pers gender edu age id_est ind07_5 muni hours hours_year occ02_6 tenure exp_act earn_mean_mw month_hire month_sep id_unique"
			
		* rename variables
		cap rename persid id_pers
		cap rename empid_est id_est

		* combine with connected set
		merge m:1 id_unique ///
			using "${DIR_TEMP}/connected_jobs_annual.dta" ///
			, ///
			keepusing(id_unique) keep(match) nogen

		* generate log earnings
		gen float earnings_log = ln(earn_mean_mw)
		lab var earnings_log "Earnings (log multiples of MW)"
		drop earn_mean_mw
		
		* generate log wage
		gen float wage_log = earnings_log - ln(hours)
		lab var wage_log "Wage (log multiples of MW)"

		* generate years of education
		gen byte edu_y = .
		replace edu_y = 0 if edu == 1
		replace edu_y = 5 if edu == 2
		replace edu_y = 5 if edu == 3
		replace edu_y = 9 if edu == 4
		replace edu_y = 9 if edu == 5
		replace edu_y = 12 if edu == 6
		replace edu_y = 12 if edu == 7
		replace edu_y = 15 if edu == 8
		replace edu_y = 16 if edu == 9
		lab var edu_y "Years of education"
		drop edu
		
		* create potential experience
		gen byte exp_pot = max(age - edu_y - 6, 0)
		lab var exp_pot "Potential experience (age - years of education - 6)"
		
		* replace actual experience
		replace exp_act = min(floor(exp_act/12), exp_pot)
		
		* replace tenure
		replace tenure = min(floor(tenure/12), exp_pot, exp_act)
		
		* generate higher-order terms
		foreach var of varlist ///
			age ///
			tenure ///
			exp_act ///
			exp_pot ///
			{
			forval i = 2/3 {
				gen float `var'_`i' = `var'^`i'
				local l: var lab `var'
				lab var `var'_`i' "`l', polynomial term `i'"
			}
		}
		
		* generate education x age interactions
		${gtools}egen long edu_x_age = group(edu_y age)
		lab var edu_x_age "Education x age interactions"
		
		* loop over income concepts
		foreach inc in ///
			earnings ///
			wage ///
			{
			
			* raw gender pay gap
			reghdfe ///
				`inc'_log ///
				ib2.gender ///
				, ///
				noabsorb keepsingletons
			local gap_`inc'_raw = _b[1.gender]
			local gap_`inc'_raw_disp: di %4.3f `gap_`inc'_raw'
			di "--> Raw data in `y': gender `inc' gap = `gap_`inc'_raw_disp'" _newline(10)
			local N = e(N)
			local r2 = e(r2)
			post postfile_mincer_specs ///
				(`y') ///
				("`inc'") ///
				("raw") ///
				(`gap_`inc'_raw') ///
				(`N') ///
				(`r2') ///
				(0) /// Continuous years of education?
				(0) /// Polynomial in potential experience?
				(0) /// Indicator for tenure?
				(0) /// Indicator for actual experience?
				(0) /// Indicator for education-specific age?
				(0) /// Indicator for occupation?
				(0) /// Indicator for contractual work hours?
				(0) // Indicator for employer?
			
			* Mincer 1: gender pay gap conditional on standard Mincerian controls
			reghdfe ///
				`inc'_log ///
				ib2.gender c.edu_y c.exp_pot c.exp_pot_2 c.exp_pot_3 ///
				, ///
				noabsorb keepsingletons
			local gap_`inc'_1 = _b[1.gender]
			local gap_`inc'_1_disp: di %4.3f `gap_`inc'_1'
			di "--> Mincer 1 (standard controls) in `y': gender `inc' gap = `gap_`inc'_1_disp'" _newline(10)
			local N = e(N)
			local r2 = e(r2)
			post postfile_mincer_specs ///
				(`y') ///
				("`inc'") ///
				("Mincer 1") ///
				(`gap_`inc'_1') ///
				(`N') ///
				(`r2') ///
				(1) /// Continuous years of education?
				(1) /// Polynomial in potential experience?
				(0) /// Indicator for tenure?
				(0) /// Indicator for actual experience?
				(0) /// Indicator for education-specific age?
				(0) /// Indicator for occupation?
				(0) /// Indicator for contractual work hours?
				(0) // Indicator for employer?
			
			* Mincer 2: gender pay gap conditional on most flexible controls
			local vars_cat = "tenure exp_act edu_x_age"
			reghdfe ///
				`inc'_log ///
				ib2.gender ///
				, ///
				a(occ02_6 hours `vars_cat') keepsingletons
			local gap_`inc'_2 = _b[1.gender]
			local gap_`inc'_2_disp: di %4.3f `gap_`inc'_2'
			di "--> Mincer 2 (flexible controls) in `y': gender `inc' gap = `gap_`inc'_2_disp'" _newline(10)
			local N = e(N)
			local r2 = e(r2)
			post postfile_mincer_specs ///
				(`y') ///
				("`inc'") ///
				("Mincer 2") ///
				(`gap_`inc'_2') ///
				(`N') ///
				(`r2') ///
				(0) /// Continuous years of education?
				(0) /// Polynomial in potential experience?
				(1) /// Indicator for tenure?
				(1) /// Indicator for actual experience?
				(1) /// Indicator for education-specific age?
				(1) /// Indicator for occupation?
				(1) /// Indicator for contractual work hours?
				(0) // Indicator for employer?
			
			* Mincer 3: gender pay gap conditional on most flexible controls and employer FEs
			local vars_cat = "tenure exp_act edu_x_age"
			reghdfe ///
				`inc'_log ///
				ib2.gender ///
				, ///
				a(occ02_6 hours id_est `vars_cat') keepsingletons
			local gap_`inc'_3 = _b[1.gender]
			local gap_`inc'_3_disp: di %4.3f `gap_`inc'_3'
			di "--> Mincer 3 (incl. employer FEs) in `y': gender `inc' gap = `gap_`inc'_3_disp'" _newline(10)
			local N = e(N)
			local r2 = e(r2)
			post postfile_mincer_specs ///
				(`y') ///
				("`inc'") ///
				("Mincer 3") ///
				(`gap_`inc'_3') ///
				(`N') ///
				(`r2') ///
				(0) /// Continuous years of education?
				(0) /// Polynomial in potential experience?
				(1) /// Indicator for tenure?
				(1) /// Indicator for actual experience?
				(1) /// Indicator for education-specific age?
				(1) /// Indicator for occupation?
				(1) /// Indicator for contractual work hours?
				(1) // Indicator for employer?
		}
	}

	* close postfile
	postclose postfile_mincer_specs

	* format postfile
	use "${DIR_TEMP}/postfile_mincer_specs.dta", clear
	lab var year "Year"
	format %4.0f year
	lab var inc_concept "Income concept"
	lab var spec "Specification"
	lab var gap "Gender pay gap"
	format %4.3f gap
	lab var N "Number of observations"
	format %12.0fc N
	lab var r2 "Coefficient of determination (R^2)"
	format %4.3f r2
	lab var control_c_edu_y "Control: Continuous years of education?"
	lab var control_p_exp_pot "Control: Polynomial in potential experience?"
	lab var control_i_g_tenure "Control: Indicator for tenure?"
	lab var control_i_g_exp_act "Control: Indicator for actual experience?"
	lab var control_i_g_edu_x_age "Control: Indicator for education-specific age?"
	lab var control_i_occ02_6 "Control: Indicator for occupation?"
	lab var control_i_hours "Control: Indicator for contractual work hours?"
	lab var control_i_id_est "Control: Indicator for employer?"
	format %1.0f ///
		control_c_edu_y ///
		control_p_exp_pot ///
		control_i_g_tenure ///
		control_i_g_exp_act ///
		control_i_g_edu_x_age ///
		control_i_occ02_6 ///
		control_i_hours ///
		control_i_id_est
	lab def con_l ///
		0 "0: No" ///
		1 "1: Yes" ///
		, replace
	lab val ///
		control_c_edu_y ///
		control_p_exp_pot ///
		control_i_g_tenure ///
		control_i_g_exp_act ///
		control_i_g_edu_x_age ///
		control_i_occ02_6 ///
		control_i_hours ///
		control_i_id_est ///
		con_l
	lab data "Gender pay gap in Mincer regressions."
	
	* counter to save tables as B1, B2, etc.
	local one_two = 1
	
	* list through years
	${gtools}levelsof year, local(years_list)
	foreach y in `years_list' {
		
		preserve
	
		keep if year == `y'
		
		* Replace the dummies to string, to have 0=nothing and 1=checkmark
		foreach var of varlist control_* {
			decode `var', gen(`var'_string)
			drop `var'
			rename `var'_string `var'
			replace `var' = "" if `var' == "0: No"
			replace `var' = "$ \checkmark$ " if `var' == "1: Yes"
		}
		
		replace inc_concept = "Earnings" if inc_concept == "earn"
		replace inc_concept = "Wage" if inc_concept == "wage"
		
		* Writing the table on a .tex file
		cap macro drop file_appendix_b`one_two'
		cap file close file_appendix_b`one_two'
		file open file_appendix_b`one_two' using "${DIR_RES_TAB}/${f_tab_appendix_b1_b2}`one_two'_`y'.tex", write replace
		file write file_appendix_b`one_two' "\begin{tabular}{lcccccccc}" _n ///
			"&  &  &  &  &  &  &  &\tabularnewline" _n ///
			"\hline" _n ///
			"\hline" _n ///
			"& (1) & (2) & (3) & (4) & (5) & (6) & (7) & (8) \tabularnewline" _n ///
			"\hline" _n ///
			"Gender gap & " %4.3f (gap[1]) "&" %4.3f (gap[2]) "&" %4.3f (gap[3]) "&" %4.3f (gap[4]) "&" %4.3f (gap[5]) "&" %4.3f (gap[6]) "&" %4.3f (gap[7]) "&" %4.3f (gap[8]) "\tabularnewline" _n ///
			"&  &  &  &  &  &  &  &\tabularnewline" _n ///
			"Income concept & " (inc_concept[1]) "&" (inc_concept[2]) "&" (inc_concept[3]) "&" (inc_concept[4]) "&" (inc_concept[5]) "&" (inc_concept[6]) "&" (inc_concept[7]) "&" (inc_concept[8]) "\tabularnewline" _n ///
			"Education & " (control_c_edu_y[1]) "&" (control_c_edu_y[2]) "&" (control_c_edu_y[3]) "&" (control_c_edu_y[4]) "&" (control_c_edu_y[5]) "&" (control_c_edu_y[6]) "&" (control_c_edu_y[7]) "&" (control_c_edu_y[8]) "\tabularnewline" _n ///
			"Potential experience (polynomial) & " (control_p_exp_pot[1]) "&" (control_p_exp_pot[2]) "&" (control_p_exp_pot[3]) "&" (control_p_exp_pot[4]) "&" (control_p_exp_pot[5]) "&" (control_p_exp_pot[6]) "&" (control_p_exp_pot[7]) "&" (control_p_exp_pot[8]) "\tabularnewline" _n ///
			"Gender-specific tenure FEs & " (control_i_g_tenure[1]) "&" (control_i_g_tenure[2]) "&" (control_i_g_tenure[3]) "&" (control_i_g_tenure[4]) "&" (control_i_g_tenure[5]) "&" (control_i_g_tenure[6]) "&" (control_i_g_tenure[7]) "&" (control_i_g_tenure[8]) "\tabularnewline" _n ///
			"Gender-specific actual experience FEs & " (control_i_g_exp_act[1]) "&" (control_i_g_exp_act[2]) "&" (control_i_g_exp_act[3]) "&" (control_i_g_exp_act[4]) "&" (control_i_g_exp_act[5]) "&" (control_i_g_exp_act[6]) "&" (control_i_g_exp_act[7]) "&" (control_i_g_exp_act[8]) "\tabularnewline" _n ///
			"Gender-education-specific age FEs & " (control_i_g_edu_x_age[1]) "&" (control_i_g_edu_x_age[2]) "&" (control_i_g_edu_x_age[3]) "&" (control_i_g_edu_x_age[4]) "&" (control_i_g_edu_x_age[5]) "&" (control_i_g_edu_x_age[6]) "&" (control_i_g_edu_x_age[7]) "&" (control_i_g_edu_x_age[8]) "\tabularnewline" _n ///
			"Occupation FEs & " (control_i_occ02_6[1]) "&" (control_i_occ02_6[2]) "&" (control_i_occ02_6[3]) "&" (control_i_occ02_6[4]) "&" (control_i_occ02_6[5]) "&" (control_i_occ02_6[6]) "&" (control_i_occ02_6[7]) "&" (control_i_occ02_6[8]) "\tabularnewline" _n ///
			"Contractual work hours FEs& " (control_i_hours[1]) "&" (control_i_hours[2]) "&" (control_i_hours[3]) "&" (control_i_hours[4]) "&" (control_i_hours[5]) "&" (control_i_hours[6]) "&" (control_i_hours[7]) "&" (control_i_hours[8]) "\tabularnewline" _n ///
			"Employer FEs & " (control_i_id_est[1]) "&" (control_i_id_est[2]) "&" (control_i_id_est[3]) "&" (control_i_id_est[4]) "&" (control_i_id_est[5]) "&" (control_i_id_est[6]) "&" (control_i_id_est[7]) "&" (control_i_id_est[8]) "\tabularnewline" _n ///
			"&  &  &  &  &  &  &  &\tabularnewline" _n ///
			"Observations & " %12.0fc (N[1]) "&" %12.0fc (N[2]) "&" %12.0fc (N[3]) "&" %12.0fc (N[4]) "&" %12.0fc (N[5]) "&" %12.0fc (N[6]) "&" %12.0fc (N[7]) "&" %12.0fc (N[8]) "\tabularnewline" _n ///
			"$ R^{2}$ & " %4.3f (r2[1]) "&" %4.3f (r2[2]) "&" %4.3f (r2[3]) "&" %4.3f (r2[4]) "&" %4.3f (r2[5]) "&" %4.3f (r2[6]) "&" %4.3f (r2[7]) "&" %4.3f (r2[8]) "\tabularnewline" _n

		file write file_appendix_b`one_two' ///
			"\hline" _n ///
			"\end{tabular}"
		file close file_appendix_b`one_two'
		
		restore
	
		local one_two = `one_two' + 1
	
	}
	
}


*** Regression tables (amenities)
if $tab_reg_amenities {
	
	* load data for female workers, saving an ID to merge
	use "${DIR_TEMP}/postfile_projections_amenities_2.dta", clear
	keep if absorb_vars == "ind muni"
	cap gen id = _n
	save "${DIR_TEMP}/temp_postfile_projections_amenities_2.dta", replace
	
	* load data for male workers, then merge
	use "${DIR_TEMP}/postfile_projections_amenities_1.dta", clear
	keep if absorb_vars == "ind muni"
	gen id = _n
	
	* rename variables
	ds var id, not // All variables but var
	foreach var of varlist `r(varlist)' {
		rename `var' `var'_m
	}
	
	* merge files
	merge 1:1 id using "${DIR_TEMP}/temp_postfile_projections_amenities_2.dta"
	drop _merge id
	
	* rename variables
	foreach var in absorb_vars covariates coefficient std_err obs_employers obs_workers r2 r2_within {
		rename `var' `var'_f
	}
	
	* creating stars for significance
	foreach g in m f {
		if $show_stars {
			gen stars_`g' = "\hphantom{***}"
			replace stars_`g' = "*\hphantom{**}" if abs(coefficient_`g'/std_err_`g') >= ${sig_level_010}
			replace stars_`g' = "**\hphantom{*}" if abs(coefficient_`g'/std_err_`g') >= ${sig_level_005}
			replace stars_`g' = "***" if abs(coefficient_`g'/std_err_`g') >= ${sig_level_001}
		}
		else gen stars_`g' = ""
	}
	
	* hphantom
	foreach g in m f {
		forval i = 1/8 {
			if coefficient_`g'[`i'] >= 0 local hphantom_`g'_`i' = "\hphantom{$-$}"
			else local hphantom_`g'_`i' = ""
		}
	}
	
	* renaming variables
	rename var var_label
	replace var_label = "Part-time work incidence" if var_label == "part_time"
	replace var_label = "Working hours flexibility" if var_label == "hours_change"
	replace var_label = "Parental leave generosity" if var_label == "parental_gen"
	replace var_label = "Income fluctuations" if var_label == "inc_change"
	replace var_label = "Workplace hazards" if var_label == "acc_work"
	replace var_label = "Incidence of unjust firings" if var_label == "sep_fired"
	replace var_label = "Incidence of workplace deaths" if var_label == "sep_death"
	replace var_label = "Log size" if var_label == "size_est"
	
	cap macro drop file_reg_amenities
	cap file close file_reg_amenities
	file open file_reg_amenities using "${DIR_RES_TAB}/${f_tab_reg_amenities}", write replace
	file write file_reg_amenities ///
		"\begin{tabular}{lcccccc}" _n ///
		"&  &  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"&  \multicolumn{2}{c}{Men} & & \multicolumn{2}{c}{Women}\tabularnewline" _n ///
		"\cline{2-3} \cline{5-6}" _n ///
		"& Coefficient  & (std. err.) & & Coefficient  & (std. err.) \tabularnewline" _n ///
		"\hline" _n
		forval i = 1/8 {
			file write file_reg_amenities ///
				(var_label[`i']) "& `hphantom_m_`i''$" %4.3f (coefficient_m[`i']) "$" (stars_m[`i']) " & (" %4.3f (std_err_m[`i']) ") & & `hphantom_f_`i''$" %4.3f (coefficient_f[`i']) "$" (stars_f[`i']) " & (" %4.3f (std_err_f[`i']) ") \tabularnewline" _n
		}	
	file write file_reg_amenities ///
		"$ R^{2}$ & $\hphantom{-}" %4.3f (r2_m[1]) "\hphantom{***}$ & & & $\hphantom{-}" %4.3f (r2_f[1]) "\hphantom{***}$ \tabularnewline" _n ///
		"Within-$ R^{2}$ & $\hphantom{-}" %4.3f (r2_within_m[1]) "\hphantom{***}$ & & & $\hphantom{-}" %4.3f (r2_within_f[1]) "\hphantom{***}$ \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_reg_amenities
	
}


*** Regression tables (amenities) -- long version
if $tab_reg_amenities_long {
	
	* load data for female workers, saving an ID to merge
	use "${DIR_TEMP}/postfile_projections_amenities_2.dta", clear
	cap gen id = _n
	save "${DIR_TEMP}/temp_postfile_projections_amenities_2.dta", replace
	
	* load data for male workers, then merge
	use "${DIR_TEMP}/postfile_projections_amenities_1.dta", clear
	cap gen id = _n
	
	* rename variables
	ds var id, not // All variables but id
	foreach var of varlist `r(varlist)' {
		rename `var' `var'_m
	}
	
	* merge files
	merge 1:1 id using "${DIR_TEMP}/temp_postfile_projections_amenities_2.dta"
	drop _merge id
	
	* rename variables
	foreach var in absorb_vars covariates coefficient std_err obs_employers obs_workers r2 r2_within {
		rename `var' `var'_f
	}
	
	* set number of covariates
	local n_covariates = 8
	
	* creating stars for significance
	foreach g in m f {
		if $show_stars {
			gen stars_`g' = "\hphantom{***}"
			replace stars_`g' = "*\hphantom{**}" if abs(coefficient_`g'/std_err_`g') >= ${sig_level_010}
			replace stars_`g' = "**\hphantom{*}" if abs(coefficient_`g'/std_err_`g') >= ${sig_level_005}
			replace stars_`g' = "***" if abs(coefficient_`g'/std_err_`g') >= ${sig_level_001}
		}
		else gen stars_`g' = ""
	}
	
	* hphantom
	foreach g in m f {
		forval i = 1/`n_covariates' {
			local i_absorb = `i'
			local i_noabsorb = `i' + `n_covariates'
			if coefficient_`g'[`i_absorb'] >= 0 local hphantom_`g'_`i_absorb' = "\hphantom{$-$}"
			else local hphantom_`g'_`i_absorb' = ""
			if coefficient_`g'[`i_noabsorb'] >= 0 local hphantom_`g'_`i_noabsorb' = "\hphantom{$-$}"
			else local hphantom_`g'_`i_noabsorb' = ""
		}
	}
	
	* renaming variables
	rename var var_label
	replace var_label = "Part-time work incidence" if var_label == "part_time"
	replace var_label = "Working hours flexibility" if var_label == "hours_change"
	replace var_label = "Parental leave generosity" if var_label == "parental_gen"
	replace var_label = "Income fluctuations" if var_label == "inc_change"
	replace var_label = "Workplace hazards" if var_label == "acc_work"
	replace var_label = "Incidence of unjust firings" if var_label == "sep_fired"
	replace var_label = "Incidence of workplace deaths" if var_label == "sep_death"
	replace var_label = "Log size" if var_label == "size_est"
	
	cap macro drop file_reg_amenities_long
	cap file close file_reg_amenities_long
	file open file_reg_amenities_long using "${DIR_RES_TAB}/${f_tab_reg_amenities_long}", write replace
	file write file_reg_amenities_long ///
		"\begin{tabular}{lccccccccc}" _n ///
		"& & & & & & & & & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"& \multicolumn{4}{c}{Men} & & \multicolumn{4}{c}{Women} \tabularnewline" _n ///
		"\cline{2-5} \cline{7-10}" _n ///
		"& Coefficient & (std. err.) & Coefficient & (std. err.) & & Coefficient & (std. err.) & Coefficient & (std. err.) \tabularnewline" _n ///
		"\hline" _n

	forval i = 1/`n_covariates' {
		local i_absorb = `i'
		local i_noabsorb = `i' + `n_covariates'
		file write file_reg_amenities_long ///
			"`= var_label[`i']' & `hphantom_m_`i_absorb''$" %4.3f (coefficient_m[`i_absorb']) "$" (stars_m[`i_absorb']) " & (" %4.3f (std_err_m[`i_absorb']) ") & `hphantom_m_`i_noabsorb''$" %4.3f (coefficient_m[`i_noabsorb']) "$" (stars_m[`i_noabsorb']) " & (" %4.3f (std_err_m[`i_noabsorb']) ") & & `hphantom_f_`i_absorb''$" %4.3f (coefficient_f[`i_absorb']) "$" (stars_f[`i_absorb']) " & (" %4.3f (std_err_f[`i_absorb']) ") & `hphantom_f_`i_noabsorb''$" %4.3f (coefficient_f[`i_noabsorb']) "$" (stars_f[`i_noabsorb']) " & (" %4.3f (std_err_f[`i_noabsorb']) ") \tabularnewline" _n
	}

	file write file_reg_amenities_long ///
		"Industry and municipality FEs & \hphantom{$-$}Yes\hphantom{$***$} & & \hphantom{$-$}No\hphantom{$***$} & & & \hphantom{$-$}Yes\hphantom{$***$} & & \hphantom{$-$}No\hphantom{$***$} & \tabularnewline" _n ///
		"$ R^{2}$ & $\hphantom{-}" %4.3f (r2_m[1]) "\hphantom{***}$ & & $\hphantom{-}" %4.3f (r2_m[_N]) "\hphantom{***}$ & & & $\hphantom{-}" %4.3f (r2_f[1]) "\hphantom{***}$ & & $\hphantom{-}" %4.3f (r2_f[_N]) "\hphantom{***}$ \tabularnewline" _n ///
		"Within-$ R^{2}$ & $\hphantom{-}" %4.3f (r2_within_m[1]) "\hphantom{***}$ & & & & & $\hphantom{-}" %4.3f (r2_within_f[1]) "\hphantom{***}$ & & & \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_reg_amenities_long
	
}


*** Regression tables (wedges)
if $tab_reg_wedges {
	
	* load data
	use "${DIR_TEMP}/postfile_projections_wedges.dta", clear
	
	* creating stars for significance	
	if $show_stars {
		gen stars = "\hphantom{***}"
		replace stars = "*\hphantom{**}" if abs(coefficient/std_err) >= ${sig_level_010}
		replace stars = "**\hphantom{*}" if abs(coefficient/std_err) >= ${sig_level_005}
		replace stars = "***" if abs(coefficient/std_err) >= ${sig_level_001}
	}
	else gen stars = ""
	
	* hphantom
	forval i = 1/6 {
		if coefficient[`i'] >= 0 local hphantom_`i' = "\hphantom{$-$}"
		else local hphantom_`i' = ""
	}
	
	* renaming variables
	rename var var_label
	replace var_label = "Female manager" if var_label == "woman_highest"
	replace var_label = "Nonroutine manual task intensity" if var_label == "nonrout_manual"
	replace var_label = "Nonroutine interpersonal task intensity" if var_label == "nonrout_cog_pers"
	replace var_label = "Mean working hours" if var_label == "hours"
	replace var_label = "No major financial stakeholders" if var_label == "simples"
	replace var_label = "Log size" if var_label == "size_est"
		
	cap macro drop file_reg_wedges
	cap file close file_reg_wedges
	file open file_reg_wedges using "${DIR_RES_TAB}/${f_tab_reg_wedges}", write replace
	file write file_reg_wedges ///
		"\begin{tabular}{lcc}" _n ///
		"&  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"& Coefficient  & (std. err.) \tabularnewline" _n ///
		"\hline" _n
		forval i = 1/6 {
			file write file_reg_wedges ///
				(var_label[`i']) "& `hphantom_`i''$" %4.3f (coefficient[`i']) "$" (stars[`i']) " & (" %4.3f (std_err[`i']) ") \tabularnewline" _n
		}	
	file write file_reg_wedges ///
		"$ R^{2}$ & $\hphantom{-}" %4.3f (r2[1]) "\hphantom{***}$ & \tabularnewline" _n ///
		"Within-$ R^{2}$ & $\hphantom{-}" %4.3f (r2_within[1]) "\hphantom{***}$ & \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_reg_wedges
	
}


*** Regression tables (wedges) -- long version
if $tab_reg_wedges_long {
	
	* load data
	use "${DIR_TEMP}/postfile_projections_wedges.dta", clear
	
	* set number of covariates
	local n_covariates = 6
	
	* creating stars for significance
	if $show_stars {
		gen stars = "\hphantom{***}"
		replace stars = "*\hphantom{**}" if abs(coefficient/std_err) >= ${sig_level_010}
		replace stars = "**\hphantom{*}" if abs(coefficient/std_err) >= ${sig_level_005}
		replace stars = "***" if abs(coefficient/std_err) >= ${sig_level_001}
	}
	else gen stars = ""
	
	* hphantom
	forval i = 1/`n_covariates' {
		local i_absorb = `i'
		local i_noabsorb = `i' + `n_covariates'
		if coefficient[`i_absorb'] >= 0 local hphantom_`i_absorb' = "\hphantom{$-$}"
		else local hphantom_`i_absorb' = ""
		if coefficient[`i_noabsorb'] >= 0 local hphantom_`i_noabsorb' = "\hphantom{$-$}"
		else local hphantom_`i_noabsorb' = ""
	}
	
	* renaming variables
	rename var var_label
	replace var_label = "Female manager" if var_label == "woman_highest"
	replace var_label = "Nonroutine manual task intensity" if var_label == "nonrout_manual"
	replace var_label = "Nonroutine interpersonal task intensity" if var_label == "nonrout_cog_pers"
	replace var_label = "Mean working hours" if var_label == "hours"
	replace var_label = "No major financial stakeholders" if var_label == "simples"
	replace var_label = "Log size" if var_label == "size_est"
		
	cap macro drop file_reg_wedges_long
	cap file close file_reg_wedges_long
	file open file_reg_wedges_long using "${DIR_RES_TAB}/${f_tab_reg_wedges_long}", write replace
	file write file_reg_wedges_long ///
		"\begin{tabular}{lcccc}" _n ///
		"&  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"& Coefficient  & (std. err.)  & Coefficient  & (std. err.) \tabularnewline" _n ///
		"\hline" _n
		forval i = 1/`n_covariates' {
			local i_absorb = `i'
			local i_noabsorb = `i' + `n_covariates'
			file write file_reg_wedges_long ///
				(var_label[`i']) "& `hphantom_`i_absorb''$" %4.3f (coefficient[`i_absorb']) "$" (stars[`i_absorb']) " & (" %4.3f (std_err[`i_absorb']) ")  & `hphantom_`i_noabsorb''$" %4.3f (coefficient[`i_noabsorb']) "$" (stars[`i_noabsorb']) " & (" %4.3f (std_err[`i_noabsorb']) ") \tabularnewline" _n
		}	
	file write file_reg_wedges_long ///
		"$ R^{2}$ & $\hphantom{-}" %4.3f (r2[1]) "\hphantom{***}$ & & $\hphantom{-}" %4.3f (r2[_N]) "\hphantom{***}$  \tabularnewline" _n ///
		"Industry and municipality FEs & \hphantom{$-$}Yes\hphantom{$***$} & & \hphantom{$-$}No\hphantom{$***$}  \tabularnewline" _n ///
		"Within-$ R^{2}$ & $\hphantom{-}" %4.3f (r2_within[1]) "\hphantom{***}$ & & $\hphantom{-}" %4.3f (r2_within[_N]) "\hphantom{***}$  \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_reg_wedges_long
	
}


*** wage variance decomposition
if $tab_pay_var_decomp {
	
	* open postfiles
	cap postclose post_var_w_decomp
	postfile post_var_w_decomp ///
		str5 gender ///
		N_emp_unique N_obs ///
		var_log_w var_log_x var_log_pi cov ///
		var_log_w_share var_log_x_share var_log_pi_share cov_share ///
		cov_log_w_log_w cov_log_w_log_x cov_log_w_log_pi_multi ///
		cov_log_w_log_w_share cov_log_w_log_x_share cov_log_w_log_pi_multi_share ///
		using "${DIR_TEMP}/var_w_decomp.dta", replace
		
	* load data
	use ///
		w_* log_w_* pi_* log_pi_* x_* log_x_* ///
		size_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* create multiplicative amenities term
	foreach g in m f {
		gen float log_pi_`g'_multi = log_x_`g' - log_w_`g'
		lab var log_pi_`g'_multi "Multiplicative amenities term, `g'"
	}

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* variance and covariance decompositions of pay into utility, amenities, and their covariance (all in logs)
	foreach g in m f {
		if "`g'" == "m" local g_str = "Men"
		else if "`g'" == "f" local g_str = "Women"
		
		* number of observations and number of unique employers
		local N_emp_unique = _N
		sum weight_`g', meanonly
		sum weight_`g'
		local N_obs = r(sum)
		
		* total variance oflog  wages
		qui sum log_w_`g' [aw=weight_`g']
		local var_log_w = r(Var)
		local var_log_w_share = 100
		local var_log_w_disp: di %4.3f `var_log_w'
		local var_log_w_share_disp: di %4.1f `var_log_w_share'
		
		* variance decomposition
		qui sum log_x_`g' [aw=weight_`g']
		local var_log_x = r(Var)
		local var_log_x_share = `var_log_x'/`var_log_w'*100
		local var_log_x_disp: di %4.3f `var_log_x'
		local var_log_x_share_disp: di %4.1f `var_log_x_share'
		qui sum log_pi_`g'_multi [aw=weight_`g']
		local var_log_pi_multi = r(Var)
		local var_log_pi_multi_share = `var_log_pi_multi'/`var_log_w'*100
		local var_log_pi_multi_disp: di %4.3f `var_log_pi_multi'
		local var_log_pi_multi_share_disp: di %4.1f `var_log_pi_multi_share'
		qui corr log_x_`g' log_pi_`g'_multi [aw=weight_`g'], cov
		local cov = -2*r(cov_12)
		local cov_share = `cov'/`var_log_w'*100
		local cov_disp: di %4.3f `cov'
		local cov_share_disp: di %4.1f `cov_share'
		di _newline(2)
		di "--> gender `g' var of log wages:    `var_log_w_disp' (`var_log_w_share_disp'%)"
		di "  = variance of log utility:        `var_log_x_disp' (`var_log_x_share_disp'%)"
		di "  + variance of log amenities:      `var_log_pi_multi_disp' (`var_log_pi_multi_share_disp'%)"
		di "  - 2*cov b/w log u, log multi a:   `cov_disp' (`cov_share_disp'%)"
		local check = `var_log_w' - (`var_log_x' + `var_log_pi_multi' + `cov')
		assert abs(`check') < 10^-6
		
		* covariance decomposition
		qui corr log_w_`g' log_x_`g' [aw=weight_`g'], cov
		local cov_log_w_log_x = r(cov_12)
		local cov_log_w_log_x_share = `cov_log_w_log_x'/`var_log_w'*100
		local cov_log_w_log_x_disp: di %4.3f `cov_log_w_log_x'
		local cov_log_w_log_x_share_disp: di %4.1f `cov_log_w_log_x_share'
		qui corr log_w_`g' log_pi_`g'_multi [aw=weight_`g'], cov
		local cov_log_w_log_pi_multi = -r(cov_12)
		local cov_log_w_log_pi_multi_share = `cov_log_w_log_pi_multi'/`var_log_w'*100
		local cov_log_w_log_pi_multi_disp: di %4.3f `cov_log_w_log_pi_multi'
		local cov_log_w_log_pi_multi_share_d: di %4.1f `cov_log_w_log_pi_multi_share'
		di _newline(2)
		di "--> gender `g' var of log wages:    `var_log_w_disp' (`var_log_w_share_disp'%)"
		di "  = cov b/w log w, log u:           `cov_log_w_log_x_disp' (`cov_log_w_log_x_share_disp'%)"
		di "  - cov b/w log w, log a:           `cov_log_w_log_pi_multi_disp' (`cov_log_w_log_pi_multi_share_d'%)"
		local check = `var_log_w' - (`cov_log_w_log_x' + `cov_log_w_log_pi_multi')
		assert abs(`check') < 10^-6
		
		* write to postfile
		post post_var_w_decomp ///
			("`g_str'") ///
			(`N_emp_unique') (`N_obs') ///
			(`var_log_w') (`var_log_x') (`var_log_pi_multi') (`cov') ///
			(`var_log_w_share') (`var_log_x_share') (`var_log_pi_multi_share') (`cov_share') ///
			(`var_log_w') (`cov_log_w_log_x') (`cov_log_w_log_pi_multi') ///
			(`var_log_w_share') (`cov_log_w_log_x_share') (`cov_log_w_log_pi_multi_share')
	}

	* close postfiles
	postclose post_var_w_decomp

	* format postfile
	use "${DIR_TEMP}/var_w_decomp.dta", clear
	lab var gender "Gender"
	lab var N_emp_unique "Number of unique employers"
	lab var N_obs "Number of observations"
	lab var var_log_w "Var log wages (ln w)"
	lab var var_log_x "Var log utility (ln x)"
	lab var var_log_pi "Var amenities (ln a)"
	lab var cov "2*Cov b/w log wages (ln w) and log amenities (ln a)"
	lab var var_log_w_share "Share of var log wages (ln w) due to var log wages (ln w)"
	lab var var_log_x_share "Share of var log wages (ln w) due to var log utility (ln x)"
	lab var var_log_pi_share "Share of var log wages (ln w) due to var log amenities (ln a)"
	lab var cov_share "Share of var log wages (ln w) due to 2*cov b/w log utility (ln x), log amenities (ln a)"
	lab var cov_log_w_log_w "Var log wages (ln w)"
	lab var cov_log_w_log_x "Cov(log w, log x)"
	lab var cov_log_w_log_pi_multi "Cov(log w, log a^tilde)"
	lab var cov_log_w_log_w_share "Share of var log wages (ln w) due to var log wages (ln w)"
	lab var cov_log_w_log_x_share "Share of var log wages (ln w) due to cov(log w, log x)"
	lab var cov_log_w_log_pi_multi_share "Share of var log wages (ln w) due to cov(log w, log a)"
	order ///
		gender ///
		N_emp_unique N_obs ///
		var_log_w var_log_x var_log_pi cov var_log_w_share var_log_x_share var_log_pi_share cov_share ///
		cov_log_w_log_w cov_log_w_log_x cov_log_w_log_pi_multi cov_log_w_log_w_share cov_log_w_log_x_share cov_log_w_log_pi_multi_share
	sort gender
	
	* formatting
	local format_var  = "%4.3f"
	local format_share = "%4.1f"
	
	* hphantom
	ds gender *_share, not
	foreach var of varlist `r(varlist)' {
		if `var'[1] >= 0 local h_`var'1 = "\hphantom{$-$}"
		else local h_`var'1 = ""
		
		if `var'[2] >= 0 local h_`var'2 = "\hphantom{$-$}"
		else local h_`var'2 = ""
	}

	* writing the table on a .tex file	
	cap macro drop file_pay_var_decomp
	cap file close file_pay_var_decomp
	file open file_pay_var_decomp using "${DIR_RES_TAB}/${f_tab_pay_var_decomp}", write replace
	file write file_pay_var_decomp ///
		"\begin{tabular}{lcclcc}" _n ///
		"&  &  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		"& \multicolumn{2}{c}{Men} &  & \multicolumn{2}{c}{Women}\tabularnewline" _n ///
		"\cline{2-3} \cline{3-3} \cline{5-6} \cline{6-6}" _n ///
		"Variances & Level & Share (\%) &  & Level & Share (\%)\tabularnewline" _n ///
		"\hline" _n ///
		"Variance of log pay & `h_var_log_w1'$" `format_var' (var_log_w[1]) "$ &  &  & `h_var_log_w2'$" `format_var' (var_log_w[2]) "$ & \tabularnewline" _n ///
		"Variance components: &  &  &  &  & \tabularnewline" _n ///
		"$\quad$ Log utility & `h_var_log_x1'$" `format_var' (var_log_x[1]) "$ & `h_var_log_x_share1'$" `format_share' (var_log_x_share[1]) "$ &  & `h_var_log_x2'$" `format_var' (var_log_x[2]) "$ & `h_var_log_x_share2'$" `format_share' (var_log_x_share[2]) "$ \tabularnewline" _n ///
		"$\quad$ Log amenities & `h_var_log_pi1'$" `format_var' (var_log_pi[1]) "$ & `h_var_log_pi_share1'$" `format_share' (var_log_pi_share[1]) "$ &  & `h_var_log_pi2'$" `format_var' (var_log_pi[2]) "$ & `h_var_log_pi_share2'$" `format_share' (var_log_pi_share[2]) "$ \tabularnewline" _n ///
		"$\quad$ Covariance between log utility and log amenities  & `h_cov1'$" `format_var' (cov[1]) "$ & `h_cov_share1'$" `format_share' (cov_share[1]) "$ &  & `h_cov2'$" `format_var' (cov[2]) "$ & `h_cov_share2'$" `format_share' (cov_share[2]) "$ \tabularnewline" _n ///
		"Covariance components: &  &  &  &  & \tabularnewline" _n ///
		"$\quad$ Covariance between log utility and log pay & `h_cov_log_w_log_x1'$" `format_var' (cov_log_w_log_x[1]) "$ & `h_cov_log_w_log_x_share1'$" `format_share' (cov_log_w_log_x_share[1]) "$ &  & `h_cov_log_w_log_x2'$" `format_var' (cov_log_w_log_x[2]) "$ & `h_cov_log_w_log_x_share2'$" `format_share' (cov_log_w_log_x_share[2]) "$\tabularnewline" _n ///
		"$\quad$ Covariance between log amenities and log pay & `h_cov_log_w_log_pi_multi1'$" `format_var' (cov_log_w_log_pi_multi[1]) "$ & `h_cov_log_w_log_pi_multi_share1'$" `format_share' (cov_log_w_log_pi_multi_share[1]) "$ &  & `h_cov_log_w_log_pi_multi2'$" `format_var' (cov_log_w_log_pi_multi[2]) "$ & `h_cov_log_w_log_pi_multi_share2'$" `format_share' (cov_log_w_log_pi_multi_share[2]) "$ \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_pay_var_decomp
	
}


*** workplace characteristics by gender
if $tab_reg_workplace_chars {
	
	*** load data
	use "${DIR_TEMP}/postfile_reg_workplace_chars.dta", clear
	
	* for clarity, recoding the variable var
	lab define var_label ///
		1 "1: Gender" ///
		2 "2: Log employer size" ///
		3 "3: Gender # log employer size" ///
		, replace
	lab value var var_label
	
	* formatting variables
	format beta se r2 %4.3f
	local format_obs = "%9.0fc"
	
	* creating stars for significance
	if $show_stars {
		gen stars = ""
		replace stars = "*" if abs(beta/se) >= ${sig_level_010}
		replace stars = "**" if abs(beta/se) >= ${sig_level_005}
		replace stars = "***" if abs(beta/se) >= ${sig_level_001}
	}
	else gen stars = ""
	
	* converting to string (all but gender)
	tostring beta se r2 mean_*, format(%18.3f) replace force
	replace se = "(" + se + ")"
	
	* writing the table on a .tex file	
	cap macro drop file_reg_workplace_chars
	cap file close file_reg_workplace_chars
	file open file_reg_workplace_chars using "${DIR_RES_TAB}/${f_tab_reg_workplace_chars}", write replace
	file write file_reg_workplace_chars ///
		"\begin{tabular}{lcccccc}" _n ///
		"&  &  &  &  &  & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		" & (1) & (2)  & (3)  & (4)  & (5) & (6) \tabularnewline" _n ///
		" & Part-time & Flexibility & Parental & Hazards & Firings & Deaths \tabularnewline" _n ///
		"\hline" _n 
	
	forval i = 1/3 {
		if `i' == 1 local var_name = "Female"
		if `i' == 2 local var_name = "Log size"
		if `i' == 3 local var_name = "Female $\times$ log size"
		
		preserve
			keep if var == `i'
			sort counter
			
			* hphantom
			forval j = 1 / 6 {
			
				* minus
				if real(beta[`j']) >= 0 local hphantom_`j' = "\hphantom{$-$}"
				else local hphantom_`j' = ""
				
				* stars
				if $show_stars {
					if stars[`j'] == "" local hphantom_stars_`j' = "\hphantom{***}"
					else if stars[`j'] == "*" local hphantom_stars_`j' = "\hphantom{**}"
					else if stars[`j'] == "**" local hphantom_stars_`j' = "\hphantom{*}"
					else if stars[`j'] == "***" local hphantom_stars_`j' = ""
				}
				else local hphantom_stars_`j' = ""
			}
			
			file write file_reg_workplace_chars ///
				"`var_name' & `hphantom_1'$" (beta[1]) "$" (stars[1]) "`hphantom_stars_1' & `hphantom_2'$" (beta[2]) "$" (stars[2]) "`hphantom_stars_2' & `hphantom_3'$" (beta[3]) "$" (stars[3]) "`hphantom_stars_3' & `hphantom_4'$" (beta[4]) "$" (stars[4]) "`hphantom_stars_4' & `hphantom_5'$" (beta[5]) "$" (stars[5]) "`hphantom_stars_5' & `hphantom_6'$" (beta[6]) "$" (stars[6]) "`hphantom_stars_6' \tabularnewline" _n ///
				"$\quad$ (std. err.) & $" (se[1]) "$ & $" (se[2]) "$ & $" (se[3]) "$ & $" (se[4]) "$ & $" (se[5]) "$ & $" (se[6]) "$ \tabularnewline" _n
		restore
	}
	
	* Keeping one (does not make any difference which) to save N and r2
	keep if var == 1
	
	file write file_reg_workplace_chars ///
/// 	"Observations & $" `format_obs' (N[1]) "$ & $" `format_obs' (N[2]) "$ & $" `format_obs' (N[3]) "$ & $" `format_obs' (N[4]) "$ & $" `format_obs' (N[5]) "$ & $" `format_obs' (N[6]) "$ \tabularnewline" _n ///
		"$ R^{2} $ & $" (r2[1]) "\hphantom{***}$ & $" (r2[2]) "\hphantom{***}$ & $" (r2[3]) "\hphantom{***}$ & $" (r2[4]) "\hphantom{***}$ & $" (r2[5]) "\hphantom{***}$ & $" (r2[6]) "\hphantom{***}$ \tabularnewline" _n ///
		"Mean for men & $" (mean_m[1]) "$ & $" (mean_m[2]) "$ & $" (mean_m[3]) "$ & $" (mean_m[4]) "$ & $" (mean_m[5]) "$ & $" (mean_m[6]) "$ \tabularnewline" _n ///
		"Mean for women & $" (mean_f[1]) "$ & $" (mean_f[2]) "$ & $" (mean_f[3]) "$ & $" (mean_f[4]) "$ & $" (mean_f[5]) "$ & $" (mean_f[6]) "$ \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_reg_workplace_chars
	
}


*** labor market parameters
if $tab_mincer {
	
	* load data
	use "${DIR_TEMP}/postfile_mincer.dta", clear
	
	* convert numerical variable to string
	tostring gap, format(%4.3f) replace force
	
	* writing the table on a .tex file	
	cap macro drop file_tab_mincer
	cap file close file_tab_mincer
	file open file_tab_mincer using "${DIR_RES_TAB}/${f_tab_mincer}", write replace
	file write file_tab_mincer ///
		"\begin{tabular}{lc}" _n ///
		" & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		" Controls & Mincerian gender pay gap \tabularnewline" _n ///
		"\hline" _n ///
		" None & `=gap[1]' \tabularnewline" _n ///
		" Age & `=gap[2]' \tabularnewline" _n ///
		" Age, education & `=gap[3]' \tabularnewline" _n ///
		" Age, education, hours & `=gap[4]' \tabularnewline" _n ///
		" Age, education, hours, occupation & `=gap[5]' \tabularnewline" _n ///
		" Age, education, hours, occupation, tenure & `=gap[6]' \tabularnewline" _n ///
		" Age, education, hours, occupation, tenure, actual experience & `=gap[7]' \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_tab_mincer
	
}


*** firm rank (size) correlations across demographic groups
if $tab_corr_dem {
	
	* load data
	use "${DIR_TEMP}/postfile_corr_dem.dta", clear
	
	* keep only relevant observations
	keep if balance == "unbalanced" & corr == "corr" & dem != "gender rand"
	drop balance corr
	
	* convert numerical variable to string
	tostring rho*, format(%4.3f) replace force
	
	* writing the table on a .tex file	
	cap macro drop file_tab_corr_dem
	cap file close file_tab_corr_dem
	file open file_tab_corr_dem using "${DIR_RES_TAB}/${f_tab_corr_dem}", write replace
	file write file_tab_corr_dem ///
		"\begin{tabular}{lcc}" _n ///
		" & & \tabularnewline" _n ///
		"\hline" _n ///
		"\hline" _n ///
		" & Men & Women \tabularnewline" _n ///
		"\hline" _n ///
		"Low education vs. high education & `=rho_m[2]' & `=rho_f[2]' \tabularnewline" _n ///
		"Parents vs. nonparents & `=rho_m[3]' & `=rho_f[3]' \tabularnewline" _n ///
		"Young cohorts vs. old cohorts & `=rho_m[5]' & `=rho_f[5]' \tabularnewline" _n ///
		"\hline" _n ///
		"\end{tabular}"
	file close file_tab_corr_dem
	
}


*** comparison of alternative firm rank measures
if $tab_ranks {
	
	* load data
	use "${DIR_TEMP}/ranks.dta", clear

	* select subset of firms in estimation
	// merge m:1 id_emp using "${DIR_TEMP}/post_est.dta", nogen keep(match)

	* compute weighted Pearson correlations or Spearman's rank correlations between various employer rank measures
	local var_list = "size pagerank poaching" // hires_NE poaching retention net size fe_emp pagerank
	foreach corr_type in pearson spearman {
		forval g = 1/2 {
			if `g' == 1 local g_str = "men"
			else if `g' == 2 local g_str = "women"
			di _newline(1) "--> `corr_type' correlation for `g_str':"
			foreach var1 of local var_list {
				foreach var2 of local var_list {
					if "`var1'" == "`var2'" continue, break
					else {
						if "`corr_type'" == "pearson" qui corr `var1' `var2' [aw = size] if gender == `g'
						else if "`corr_type'" == "spearman" qui corr rank_`var1' rank_`var2' [aw = size] if gender == `g'
						local `corr_type'_`var1'_`var2'_`g' = r(rho)
						local `corr_type'_`var1'_`var2'_`g'_di: di %4.3f ``corr_type'_`var1'_`var2'_`g''
						di "corr(`var1', `var2') = ``corr_type'_`var1'_`var2'_`g'_di'"
					}
				}
			}
		}
	}
	
	* writing the table on a .tex file	
	cap macro drop file_tab_ranks
	cap file close file_tab_ranks
	file open file_tab_ranks using "${DIR_RES_TAB}/${f_tab_ranks}", write replace
	file write file_tab_ranks ///
		"\begin{tabular}{lccccccc}" _n ///
			"\hline" _n ///
			"\hline" _n ///
			"& \multicolumn{3}{c}{Men} & & \multicolumn{3}{c}{Women} \tabularnewline" _n ///
			"\cline{2-4} \cline{6-8} \tabularnewline" _n ///
			"& Size & PageRank & Poaching rank & & Size & PageRank & Poaching rank \tabularnewline" _n ///
			"\hline" _n ///
			"Size             & 1.000 & & & & 1.000 & & \tabularnewline" _n ///
			"PageRank        &" ("`spearman_pagerank_size_1_di'") "& 1.000 & & &" ("`spearman_pagerank_size_2_di'") "& 1.000 & \tabularnewline" _n ///
			"Poaching rank    &" ("`spearman_poaching_size_1_di'") "&" ("`spearman_poaching_pagerank_1_di'") "& 1.000 & &" ("`spearman_poaching_size_2_di'") "&" ("`spearman_poaching_pagerank_2_di'") "& 1.000 \tabularnewline" _n ///
			"\hline" _n ///
		"\end{tabular}"
	file close file_tab_ranks
	
}


*** final housekeeping
* clean up
if $clean_up {
	foreach comp in log_w log_pi_tilde log_x {
		rm "${DIR_TEMP}/postfile_kob_`comp'.dta"
	}
	rm "${DIR_TEMP}/temp_lab_params.dta"
	rm "${DIR_TEMP}/connected_jobs_annual.dta"
}

* turn timer off
timer off 17

* print final banner
di _newline(5)
timer list 17
local t = r(t17)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_16_TABLES.do
********************************************************************************

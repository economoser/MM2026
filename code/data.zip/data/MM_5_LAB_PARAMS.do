********************************************************************************
* FILE NAME:   MM_5_LAB_PARAMS.do
*
* DESCRIPTION: Computes labor market objects (i.e., parameters and moments with a direct mapping to parameters) based on monthly panel data incl. employer ranks
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_5_LAB_PARAMS"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 6

* set random-number stream
clear rngstream
set rngstream 5

* set sort seed
// set sortseed ${sortseed}

* open postfile
cap postclose post_lab_params
postfile post_lab_params ///
	rank_concept ///
	gender ///
	delta ///
	lambda_u ///
	u_rate ///
	lambda_e lambda_e_alt ///
	s_e s_e_alt ///
	lambda_g ///
	s_g ///
	kappa kappa_alt ///
	using "${DIR_TEMP}/lab_params.dta", replace

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** compute shares of workers of each gender among the employed
* load raw data
use ///
	gender ///
	using "${DIR_TEMP}/load_${year_min}_${year_max}.dta", clear

* compute employment shares
forval g = 1/2 {
	if `g' == 1 local g_str = "m"
	else if `g' == 2 local g_str = "f"
	count if gender == `g'
	local emp_share_`g_str' = r(N)/_N
}

* save
clear
set obs 1
gen float emp_share_m = `emp_share_m'
lab var emp_share_m "Share of men among the employed"
gen float emp_share_f = `emp_share_f'
lab var emp_share_f "Share of women among the employed"
prog_comp_desc_sum_save "${DIR_TEMP}/emp_shares.dta"
export delim "${DIR_TEMP}/emp_shares.txt", nolabel replace


*** prepare data
* load monthly data
use "${DIR_TEMP}/selection_monthly.dta", clear // note: could contemplate using an even larger file here (e.g., including all firms), but would need rank measures for them!

* take a sample of ${sample_share}*100 percent
keep if mod(id_pers, round(1/${sample_share})) == 0

* merge in AKM gender-firm FEs
merge m:1 id_emp gender using "${DIR_TEMP}/akm_fe_emp.dta", keep(master match) keepusing(fe_emp) nogen

* identify start and end dates
sum date, meanonly
local date_min = r(min)
local date_max = r(max)

* set panel
xtset id_pers date

* identify hires from nonemployment -- note: this count includes a small number of workers who cross the minimum age threshold while employed during the sample period.
gen byte NE = (L.id_emp == .) if date > `date_min'
lab var NE "Ind: Hire from nonemployment?"

* identify hires from employment -- note: this indicator includes a small number of workers who cross the minimum age threshold while employed during the sample period.
gen byte EE = (L.id_emp < . & L.id_emp != id_emp) if date > `date_min'
lab var EE "Ind: Hire from employment?"

* identify separations into nonemployment -- note: this indicator includes a small number of workers who cross the maximum age threshold while employed during the sample period.
gen byte EN = (F.id_emp == .) if date < `date_max'
lab var EN "Ind: Separation into nonemployment?"

* identify pay cuts upon job-to-job transition
gen byte pay_decline = (L.fe_emp > fe_emp) if EE & L.fe_emp < . & fe_emp < .
lab var pay_decline "Ind: Pay cut upon job-to-job transition?"

* save temporary file
prog_comp_desc_sum_save "${DIR_TEMP}/temp_lab_params.dta"


*** estimate hazard of separation into nonemployment (delta)
* compute delta = mean of indicator for separation into nonemployment
forval g = 1/2 {
	sum EN if gender == `g', meanonly
	local delta_g`g' = r(mean)
}


*** estimate hazard of job offer from nonemployment (lambda^U)
* ignore nonemployment spells without subsequent NE transition
bys id_pers (date): replace EN = 0 if EN & _n == _N

* ignore employment spells without prior EN transition
bys id_pers (date): replace NE = 0 if NE & _n == 1

* keep only individuals who ever went into nonemployment and ever came back from nonemployment after that -- note: this methods accounts for missing observations, which is better than to sort by EN and then keep data based on last observation per individual
gen int EN_date = date if EN
gen int NE_date = date if NE
if _N < 2147483647 local gtools = "${gtools}"
else local gtools = ""
if "`gtools'" == "g" {
	gegen int EN_date_max = max(EN_date), by(id_pers)
	gegen int NE_date_min = min(NE_date), by(id_pers)
}
else {
	bys id_pers: egen int EN_date_max = max(EN_date)
	bys id_pers: egen int NE_date_min = min(NE_date)
}
keep if NE_date_min < EN_date_max
drop EN_date NE_date EN_date_max NE_date_min

* generate nonemployment duration
bys id_pers (date): gen int duration = date[_n] - date[_n - 1] if NE[_n] == 1 & EN[_n - 1] == 1
compress duration
drop id_pers date NE EN

* keep only observations with nonmissing nonemployment duration (i.e., one observation per ENE transition)
keep if duration < .

* compute survivor function
forval i = 1/$duration_max {
	gen byte duration`i' = (duration > `i')
}
drop duration
if _N < 2147483647 local gtools = "${gtools}"
else local gtools = ""
`gtools'collapse ///
	(mean) duration* ///
	, ///
	by(gender) fast
	
* reshape to long format
if _N*12 < 2147483647 local gtools = "${gtools}"
else local gtools = ""
`gtools'reshape long duration, i(gender) j(month)
	
* compute lambda^U = regression coefficient when projecting log survival function onto nonemployment spell duration
replace duration = ln(duration)
forval g = 1/2 {
	reg duration month if gender == `g', noconstant
	local lambda_u_g`g' = 1 - exp(_b[month])
}


*** compute employer rank concept-dependent hazard rates (lambda^G and lambda^E)
* loop through rank concepts
foreach r in 5 7 { // i.e., size (5) and PageRanks (7)
	
	* choose rank concept
	if `r' == 5 local var_rank = "rank_size"
	else if `r' == 7 local var_rank = "rank_pagerank"
	
	
	*** compute offer distribution (F) and cross-sectional distribution (G)
	* load employer ranks data
	if `r' == 7 {
		use ///
			id_emp gender `var_rank' hires_NE pagerank ///
			using "${DIR_TEMP}/ranks.dta", clear
		rename pagerank cardinality
	}
	else {
		use ///
			id_emp gender `var_rank' hires_NE size ///
			using "${DIR_TEMP}/ranks.dta", clear
		rename size cardinality
	}
	lab var cardinality "Cardinality of a firm in the employment distribution"
	
	* generate key variables
	rename `var_rank' rank
	lab var rank "Employer rank (`r': `var_rank')"
	
	* make sure that rank variable is nonmissing
	assert rank < .
	
	* compute offer distribution
	bys gender (rank): gen double F = sum(hires_NE)
	forval g = 1/2 {
		sum F if gender == `g', meanonly
		replace F = F/r(max) if gender == `g'
	}
	lab var F "Cumulative offer distribution (F)"
	drop hires_NE
	
	* compute employment
	bys gender (rank): gen double G = sum(cardinality)
	forval g = 1/2 {
		sum G if gender == `g', meanonly
		replace G = G/r(max) if gender == `g'
	}
	lab var G "Cumulative employment distribution (G)"
	drop rank cardinality
	
	* save F and G
	order id_emp gender F G
	sort id_emp gender
	prog_comp_desc_sum_save "${DIR_TEMP}/F_G_rank_concept_`r'.dta"
	
	
	*** prepare computation of labor market parameters
	* load monthly panel data
	use ///
		date id_pers id_emp gender EE ///
		using "${DIR_TEMP}/temp_lab_params.dta", clear

	* get employer ranks
	merge m:1 id_emp gender ///
		using "${DIR_TEMP}/ranks.dta" ///
		, ///
		keep(match) keepusing(`var_rank') nogen
	rename `var_rank' rank
	lab var rank "Employer rank (`r': `var_rank')"
	
	* make sure that rank variable is nonmissing
	assert rank < .

	* set panel
	xtset id_pers date

	* generate indicators for upward EE transition
	gen byte EE_up = (EE == 1 & rank > L.rank) if EE < . & L.rank < . // baseline population: everyone who either made an EE transition or verifiably did not between period t - 1 and period t
	drop id_pers date
	
	* compute rank quantiles
	if _N < 2147483647 local gtools = "${gtools}"
	else local gtools = ""
	if "`gtools'" == "g" gquantiles rank_q = rank, xtile n(${n_rank_q}) by(gender)
	else {
		forval g = 1/2 {
			xtile rank_q_g`g' = rank if gender == `g', n(${n_rank_q})
		}
		egen byte rank_q = rowtotal(rank_q_g*)
		drop rank_q_g*
	}
	lab var rank_q "Firm rank quantile"
	
	* get F and G
	merge m:1 id_emp gender ///
		using "${DIR_TEMP}/F_G_rank_concept_`r'.dta" ///
		, ///
		keep(match) keepusing(F G) nogen
	drop id_emp
	
	* summarize key objects
	bys gender: sum EE EE_up
	
	* collapse to rank percentiles
	if _N < 2147483647 local gtools = "${gtools}"
	else local gtools = ""
	`gtools'collapse ///
		(mean) EE_mean=EE EE_up_mean=EE_up F_mean=F G_mean=G ///
		, ///
		by(gender rank_q) fast
	drop rank_q

	* save dataset to check estimation results
	prog_comp_desc_sum_save "${DIR_TEMP}/lab_params_collapsed_rank_concept_`r'.dta"
	

	*** compute hazard of involuntary job transition (lambda^G)
	* compute lambda^G across rank percentiles
	assert F_mean >= 0 & F_mean <= 1
	gen float lambda_g = (EE_mean - EE_up_mean)/F_mean
	lab var lambda_g "Involuntary hazard of job transitions (lambda^G)"
	forval g = 1/2 {
		sum lambda_g if gender == `g', d
		local lambda_g_g`g' = r(p50) // note: the median is a more robust estimator than the mean
		local s_g_g`g' = `lambda_g_g`g''/`lambda_u_g`g''
	}
	drop EE_up_mean


	*** compute hazard of voluntary job offer from employment (lambda^E)
	* compute lambda^E across rank percentiles
	gen float lambda_e = (EE_mean - lambda_g)/(1 - F_mean)
	lab var lambda_e "Voluntary hazard of job transitions (lambda^E)"
	forval g = 1/2 {
		sum lambda_e if gender == `g', d
		local lambda_e_g`g' = r(p50) // note: the median is a more robust estimator than the mean
		local s_e_g`g' = `lambda_e_g`g''/`lambda_u_g`g''
	}
	drop EE_mean lambda_g lambda_e
	
	* compute effective speed of climbing the job ladder, kappa
	gen float kappa = .
	forval g = 1/2 {
		replace kappa = `lambda_e_g`g''/(`delta_g`g'' + `lambda_g_g`g'') if gender == `g'
	}
	lab var kappa "Effective speed of climbing the job ladder (kappa)"
	forval g = 1/2 {
		sum kappa if gender == `g', d
		local kappa_g`g' = r(p50) // note: this is a constant, so does not matter which moment we summarize here
	}
	drop kappa
	
	* alternative way of computing effective speed of climbing the job ladder, kappa
	gen float kappa_alt = (F_mean - G_mean)/(G_mean*(1 - F_mean))
	lab var kappa_alt "Eff speed of climbing job ladder, alt (kappa_alt)"
	
	* alternative way of computing lambda^E
	forval g = 1/2 {
		sum kappa_alt if gender == `g', d
		local kappa_alt_g`g' = r(p50) // note: the median is a more robust estimator than the mean
		local lambda_e_alt_g`g' = `kappa_alt_g`g''*(`delta_g`g'' + `lambda_g_g`g'')
		local s_e_alt_g`g' = `lambda_e_alt_g`g''/`lambda_u_g`g''
	}
	drop kappa_alt
	
	
	*** compute steady-state nonemployment rate
	* loop through genders
	forval g = 1/2 {
		local u_rate_g`g' = `delta_g`g''/(`delta_g`g'' + `lambda_u_g`g'' + `lambda_g_g`g'')
	}
	
	* collect results
	forval g = 1/2 {
		di _newline(3)
		di "*** gender `g':"
		di "  --> delta = `delta_g`g''"
		di "  --> lambda_u = `lambda_u_g`g''"
		di "  --> lambda_e = `lambda_e_g`g''"
		di "  --> lambda_e_alt = `lambda_e_alt_g`g''"
		di "  --> s_e = `s_e_g`g''"
		di "  --> s_e_alt = `s_e_alt_g`g''"
		di "  --> lambda_g = `lambda_g_g`g''"
		di "  --> s_g = `s_g_g`g''"
		di "  --> kappa = `kappa_g`g''"
		di "  --> kappa_alt = `kappa_alt_g`g''"
		di "  --> nonemployment rate = `u_rate_g`g''"
	}
	
	* post to postfile
	forval g = 1/2 {
		post post_lab_params ///
			(`r') ///
			(`g') ///
			(`delta_g`g'') ///
			(`lambda_u_g`g'') ///
			(`u_rate_g`g'') ///
			(`lambda_e_g`g'') (`lambda_e_alt_g`g'') ///
			(`s_e_g`g'') (`s_e_alt_g`g'') ///
			(`lambda_g_g`g'') ///
			(`s_g_g`g'') ///
			(`kappa_g`g'') (`kappa_alt_g`g'')
	}
}

* close postfile
postclose post_lab_params

* format posfile
use "${DIR_TEMP}/lab_params.dta", clear
lab var rank_concept "Rank concept"
lab def ran_l ///
	1 "rank_hires_NE" ///
	2 "rank_poaching" ///
	3 "rank_retention" ///
	4 "rank_net" ///
	5 "rank_size" ///
	6 "rank_fe_emp" ///
	7 "rank_pagerank" ///
	, replace // note: could add other categories here
lab val rank_concept ran_l
lab var gender "Gender"
lab def gen_l ///
	1 "1: Male" ///
	2 "2: Female" ///
	, replace // note: could add other categories here
lab val gender gen_l
lab var delta "Hazard of job offer from N (delta)"
lab var lambda_u "Hazard of job offer from N (lambda^U)"
lab var u_rate "Nonemployment rate, u = delta/(delta + lambda^U + lambda^G)"
lab var lambda_e "Hazard of voluntary job offer from E (lambda^E)"
lab var lambda_e_alt "Hazard of vol job offer from E, alt (lambda^E)"
lab var s_e "Relative hazard of voluntary job-to-job offers (s^E)"
lab var s_e_alt "Relative hazard of voluntary job-to-job offers, alt (s^E)"
lab var lambda_g "Hazard of involuntary job transition (lambda^G)"
lab var s_g "Relative hazard of involuntary job-to-job offers (s^G)"
lab var kappa "Effective speed of climbing the job ladder (kappa)"
lab var kappa_alt "Eff speed of climbing job ladder, alt (kappa)"

* save labor market "parameters" for each rank concept and gender
order ///
	rank_concept ///
	gender ///
	delta ///
	lambda_u ///
	u_rate ///
	lambda_e lambda_e_alt ///
	s_e s_e_alt ///
	lambda_g ///
	s_g ///
	kappa kappa_alt
sort rank_concept gender
compress
prog_comp_desc_sum_save "${DIR_TEMP}/lab_params.dta"


*** compute population shares
* load labor market parameter data
use "${DIR_TEMP}/lab_params.dta", clear

* merge in shares of workers of each gender among the employed
merge 1:1 _n using "${DIR_TEMP}/emp_shares.dta", keepusing(emp_share_m emp_share_f) keep(master match) nogen
gen float emp_share = .
replace emp_share = emp_share_m[1] if gender == 1
replace emp_share = emp_share_f[1] if gender == 2
lab var emp_share "Share of workers among the employed"
drop emp_share_m emp_share_f

* compute population shares
gen float pop_share = emp_share/(1 - u_rate)
bys rank_concept: egen float pop_share_sum = total(pop_share)
lab var pop_share_sum "Sum of population shares"
replace pop_share = pop_share/pop_share_sum
lab var pop_share "Population share"
drop pop_share_sum

* save
keep rank_concept gender pop_share
prog_comp_desc_sum_save "${DIR_TEMP}/pop_shares.dta"
export delim "${DIR_TEMP}/pop_shares.txt", nolabel replace


*** final housekeeping
* clean up
if $clean_up {
	rm "${DIR_TEMP}/load_${year_min}_${year_max}.dta"
}

* turn timer off
timer off 6

* print final banner
di _newline(5)
timer list 6
local t = r(t6)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_5_LAB_PARAMS.do
********************************************************************************

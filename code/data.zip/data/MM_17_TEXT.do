********************************************************************************
* FILE NAME:   MM_17_TEXT.do
*
* DESCRIPTION: Produces text snippets to be included in the paper
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_17_TEXT"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 18

* set random-number stream
clear rngstream
set rngstream 17

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** result text snippets
* switches for which text snippets to produce
global txt_categories 		= 1 	// number of categories for key variables
global txt_exog_params 		= 1 	// exogenous model parameters
global txt_lab_params 		= 1 	// labor market parameters and moments
global txt_wedges 			= 1 	// wedges
global txt_corr 			= 1 	// correlations between model parameters
global txt_ladders 			= 1 	// gender-specific job ladders
global txt_parent_share 	= 1 	// share of parents
global txt_akm_decomp 		= 1		// AKM decomposition
global txt_akm_kss_decomp	= 1		// AKM decomposition with KSS bias correction
global txt_kob_decomp 		= 1		// KOB decomposition
global txt_sum_stats 		= 1		// summary statistics
global txt_means 			= 1		// gender-specific mean employer ranks, pay, amenities, and productivity
global txt_recruiting_dens 	= 1		// density estimates of recruiting intensities
global txt_amenity_shares 	= 1		// amenity shares
global txt_gaps 			= 1 	// total gender gaps in employer pay and utility, and their dispersion
global txt_elast 			= 1		// gender-specific elasticities of pay with respect to productivity
global txt_counterfactual 	= 1		// counterfactual
global txt_reg_amenities 	= 1		// saving R^2 from regressions (amenities)
global txt_reg_wedges 		= 1		// saving R^2 from regressions (wedges)
global txt_reg_pay_size_r2	= 1 	// saving R^2 from regressions (pay on size, by gender)
global txt_mincer			= 1 	// Mincer regressions for reply to R2
global txt_ranks			= 1 	// comparison of different rank concepts


*** number of categories for key variables
if $txt_categories {
	
	* loop through key variables
	foreach var in ///
		ind85_2 ///
		ind07_5 ///
		muni ///
		occ02_6 ///
		{
		prog_load_data $year_min $year_max "`var'"
		keep if `var' < .
		bys `var': keep if _n == 1
		qui count
		local N_`var': di %5.0fc `=r(N)'
		file open N_`var' using "${DIR_RES_TXT}/txt_N_`var'.tex", write replace
		file write N_`var' "`N_`var''"
		file close N_`var'
	}
	
}


*** exogenous model parameters
if $txt_exog_params {
	
	* continuous-time discount rate
	local model_rho_disp: di %4.3f ${model_rho}
	di "  --> rho = `model_rho_disp'"
	file open model_rho using "${DIR_RES_TXT}/txt_model_rho.tex", write replace
	file write model_rho "`model_rho_disp'%"
	file close model_rho
	
	* annual discount rate
	local model_discount_rate = (exp(${model_rho}) - 1)*100
	local model_discount_rate_disp: di %2.1f `model_discount_rate'
	di "  --> discount rate = `model_discount_rate_disp'"
	file open model_discount_rate using "${DIR_RES_TXT}/txt_model_discount_rate.tex", write replace
	file write model_discount_rate "`model_discount_rate_disp'%"
	file close model_discount_rate
	
	* elasticity of the matching function with respect to vacancies
	local model_alpha_disp: di %4.3f ${model_alpha}
	di "  --> alpha = `model_alpha_disp'"
	file open model_alpha using "${DIR_RES_TXT}/txt_model_alpha.tex", write replace
	file write model_alpha "`model_alpha_disp'%"
	file close model_alpha
	
	* efficiency of the matching function
	local model_chi_disp: di %4.3f ${model_chi}
	di "  --> chi = `model_chi_disp'"
	file open model_chi using "${DIR_RES_TXT}/txt_model_chi.tex", write replace
	file write model_chi "`model_chi_disp'%"
	file close model_chi
	
}


*** labor market parameters
if $txt_lab_params {
	
	* population shares
	use "${DIR_TEMP}/temp_pop_shares.dta", clear
	foreach g in 1 2 {
		sum pop_share if gender == `g'
		local pop_share_`g': di %2.1f `=r(mean)*100'
	}
	di "  --> pop_share_m = `pop_share_1'%"
	file open pop_share_m using "${DIR_RES_TXT}/txt_pop_share_m.tex", write replace
	file write pop_share_m "`pop_share_1'\%"
	file close pop_share_m
	di "  --> pop_share_f = `pop_share_2'%"
	file open pop_share_f using "${DIR_RES_TXT}/txt_pop_share_f.tex", write replace
	file write pop_share_f "`pop_share_2'\%"
	file close pop_share_f
	
	* rates of job separation by gender
	use "${DIR_TEMP}/lab_params_rank_concept_${baseline_rank}.dta", clear
	foreach g in 1 2 {
		sum delta if gender == `g'
		local delta_`g': di %2.1f `=r(mean)*100'
	}
	di "  --> delta_m = `delta_1'%"
	file open delta_m using "${DIR_RES_TXT}/txt_delta_m.tex", write replace
	file write delta_m "`delta_1'\%"
	file close delta_m
	di "  --> delta_f = `delta_2'%"
	file open delta_f using "${DIR_RES_TXT}/txt_delta_f.tex", write replace
	file write delta_f "`delta_2'\%"
	file close delta_f
	
	* rates of job offers from nonemployment by gender
	use "${DIR_TEMP}/lab_params_rank_concept_${baseline_rank}.dta", clear
	foreach g in 1 2 {
		sum lambda_u if gender == `g'
		local lambda_u_`g': di %2.1f `=r(mean)*100'
	}
	di "  --> lambda_u_m = `lambda_u_1'%"
	file open lambda_u_m using "${DIR_RES_TXT}/txt_lambda_u_m.tex", write replace
	file write lambda_u_m "`lambda_u_1'\%"
	file close lambda_u_m
	di "  --> lambda_u_f = `lambda_u_2'%"
	file open lambda_u_f using "${DIR_RES_TXT}/txt_lambda_u_f.tex", write replace
	file write lambda_u_f "`lambda_u_2'\%"
	file close lambda_u_f
	
	* implied rates of voluntary job offers by gender
	use "${DIR_TEMP}/lab_params_rank_concept_${baseline_rank}.dta", clear
	foreach g in 1 2 {
		sum lambda_e if gender == `g'
		local lambda_e_`g': di %2.1f `=r(mean)*100'
	}
	di "  --> lambda_e_m = `lambda_e_1'%"
	file open lambda_e_m using "${DIR_RES_TXT}/txt_lambda_e_m.tex", write replace
	file write lambda_e_m "`lambda_e_1'\%"
	file close lambda_e_m
	di "  --> lambda_e_f = `lambda_e_2'%"
	file open lambda_e_f using "${DIR_RES_TXT}/txt_lambda_e_f.tex", write replace
	file write lambda_e_f "`lambda_e_2'\%"
	file close lambda_e_f

	* implied rates of mandatory job offers by gender
	use "${DIR_TEMP}/lab_params_rank_concept_${baseline_rank}.dta", clear
	foreach g in 1 2 {
		sum lambda_g if gender == `g'
		local lambda_g_`g': di %2.1f `=r(mean)*100'
	}
	di "  --> lambda_g_m = `lambda_g_1'%"
	file open lambda_g_m using "${DIR_RES_TXT}/txt_lambda_g_m.tex", write replace
	file write lambda_g_m "`lambda_g_1'\%"
	file close lambda_g_m
	di "  --> lambda_g_f = `lambda_g_2'%"
	file open lambda_g_f using "${DIR_RES_TXT}/txt_lambda_g_f.tex", write replace
	file write lambda_g_f "`lambda_g_2'\%"
	file close lambda_g_f

	* flow values of nonemployment by gender
	use "${DIR_TEMP}/lab_params_summary.dta", clear
	foreach g in 1 2 {
		sum b if gender == `g'
		local b_`g': di %4.3f `=r(mean)'
	}
	di "  --> b_m = `b_1'"
	file open b_m using "${DIR_RES_TXT}/txt_b_m.tex", write replace
	file write b_m "`b_1'"
	file close b_m
	di "  --> b_f = `b_2'"
	file open b_f using "${DIR_RES_TXT}/txt_b_f.tex", write replace
	file write b_f "`b_2'"
	file close b_f

	* reservation wages by gender
	use "${DIR_TEMP}/post_est.dta", clear
	sum x_m, meanonly
	local phi_1: di %4.3f `=r(min)'
	sum x_f, meanonly
	local phi_2: di %4.3f `=r(min)'
	di "  --> phi_m = `phi_1'"
	file open phi_m using "${DIR_RES_TXT}/txt_phi_m.tex", write replace
	file write phi_m "`phi_1'"
	file close phi_m
	di "  --> phi_f = `phi_2'"
	file open phi_f using "${DIR_RES_TXT}/txt_phi_f.tex", write replace
	file write phi_f "`phi_2'"
	file close phi_f
	local phi_m_rel: di %3.1f `=(`phi_1'/`phi_2' - 1)*100'
	di "  --> phi_m_rel = `phi_m_rel'"
	file open phi_m_rel using "${DIR_RES_TXT}/txt_phi_m_rel.tex", write replace
	file write phi_m_rel "`phi_m_rel'"
	file close phi_m_rel
	local phi_f_rel: di %3.1f `=(`phi_2'/`phi_1' - 1)*100'
	di "  --> phi_f_rel = `phi_f_rel'"
	file open phi_f_rel using "${DIR_RES_TXT}/txt_phi_f_rel.tex", write replace
	file write phi_f_rel "`phi_f_rel'"
	file close phi_f_rel

	* unemployment rates by gender
	use "${DIR_TEMP}/lab_params_rank_concept_${baseline_rank}.dta", clear
	gen float u = delta/(delta + lambda_u + lambda_g)
	lab var u "Nonemployment rate"
	foreach g in 1 2 {
		sum u if gender == `g', meanonly
		local u_`g': di %3.1f `=r(mean)*100'
	}
	drop u
	di "  --> u_m = `u_1'%"
	file open u_m using "${DIR_RES_TXT}/txt_u_m.tex", write replace
	file write u_m "`u_1'\%"
	file close u_m
	di "  --> u_f = `u_2'%"
	file open u_f using "${DIR_RES_TXT}/txt_u_f.tex", write replace
	file write u_f "`u_2'\%"
	file close u_f
	
}


*** wedges
if $txt_wedges {
	
	* load data
	use "${DIR_TEMP}/post_est.dta", clear
	
	* correlations between model parameters
	foreach g in m f {
		sum tau [aw=size_`g'], meanonly
		local tau_`g'_mean: di %4.3f `=r(mean)'
		file open tau_`g'_mean using "${DIR_RES_TXT}/txt_tau_`g'_mean.tex", write replace
		file write tau_`g'_mean "`tau_`g'_mean'"
		file close tau_`g'_mean
	}
	
}


*** correlations between model parameters
if $txt_corr {
	
	* load data
	use "${DIR_TEMP}/post_est.dta", clear
	
	* correlation between productivity and wedges
	pwcorr p_m tau [aw=g]
	local corr_p_tau: di %4.3f `=r(rho)'
	di "  --> corr(p, tau) = `corr_p_tau'"
	file open corr_p_tau using "${DIR_RES_TXT}/txt_corr_p_tau.tex", write replace
	file write corr_p_tau "`corr_p_tau'"
	file close corr_p_tau
	
	* correlations across genders within firm
	foreach var in log_w log_pi rank {
		corr `var'_m `var'_f [aw=g]
		local corr_`var': di %4.3f `=r(rho)'
		file open corr_`var' using "${DIR_RES_TXT}/txt_corr_`var'.tex", write replace
		file write corr_`var' "`corr_`var''"
		file close corr_`var'
	}
	
}

*** gender-specific job ladders
if $txt_ladders {
	
	* load data
	use ///
		id_emp ///
		log_pi* log_w_* log_x_* ///
		rank_* ///
		size_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* merge in industry codes
	merge m:1 id_emp using "${DIR_TEMP}/id_emp_public.dta", keepusing(public) keep(master match) nogen

	* collapse to rank quantiles using gender-specific employment weights, separately by gender
	foreach g in m f {
		preserve
		gquantiles rank_q = rank_`g' [aw=weight_`g'], xtile n(50)
		lab var rank_q "Gender-specific employer rank quantile"
		rename public public_`g'
		${gtools}collapse ///
			(mean) log_w_*`g' log_pi_*`g' log_x_*`g' public_`g' ///
			[aw=weight_`g'] ///
			, ///
			by(rank_q) fast
		save "${DIR_TEMP}/temp_rank_collapse_`g'.dta", replace
		restore
	}

	* merge files for both genders
	use "${DIR_TEMP}/temp_rank_collapse_m.dta", clear
	merge 1:1 rank_q ///
		using "${DIR_TEMP}/temp_rank_collapse_f.dta" ///
		, ///
		keepusing(*w_* *pi_* *x_* *public_*) keep(match) nogen

	* normalize variables in logs
	foreach var of varlist log* {
		sum rank_q, meanonly
		local rank_q_min = r(min)
		sum `var' if rank_q == `rank_q_min'
		local `var'_min = r(mean)
		replace `var' = `var' - ``var'_min'
	}

	* normalize ranks
	sum rank_q, meanonly
	replace rank_q = rank_q/r(max)
	
	* min and max along the ladder
	sort rank_q
	foreach g in m f {
		sum log_x_`g' if _n == 1
		local log_x_`g'_min = r(mean)
		sum log_x_`g' if _n == _N
		local log_x_`g'_max = r(mean)
	}
	
	* range along the ladder
	foreach g in m f {
		local log_x_`g'_range = (`log_x_`g'_max' - `log_x_`g'_min')*100
		local log_x_`g'_range_disp: di %3.1f `log_x_`g'_range'
		file open log_x_`g'_range using "${DIR_RES_TXT}/txt_log_x_`g'_range.tex", write replace
		file write log_x_`g'_range "`log_x_`g'_range_disp'"
		file close log_x_`g'_range
	}
	
}


*** share of parents
if $txt_parent_share {
	
	* load data
	use "${DIR_TEMP}/parent_share.dta", clear
	
	* create macros
	sum N_parent, meanonly
	local N_parent = r(mean)
	sum N_nonparent, meanonly
	local N_nonparent = r(mean)
	
	* create parent shares
	local parent_share: di %3.1f `=`N_parent'/(`N_parent' + `N_nonparent')*1000'
	local parent_share_rel: di %3.1f `=`parent_share'/12.9*100'
	
	* write to files
	file open parent_share using "${DIR_RES_TXT}/txt_parent_share.tex", write replace
	file write parent_share "`parent_share'" "%"
	file close parent_share
	file open parent_share_rel using "${DIR_RES_TXT}/txt_parent_share_rel.tex", write replace
	file write parent_share_rel "`parent_share_rel'" "%"
	file close parent_share_rel
	
}


*** AKM decomposition
if $txt_akm_decomp {
	
	* load data
	use "${DIR_TEMP}/akm_decomp.dta", clear
	
	local format_1d = "%4.1f"
	
	* obtaining log points from shares -- note: shares already are already with 1 decimal
	foreach var of varlist var_* cov_sum cov_inc_* corr_pers_emp r2 {
		replace `var' = `var'*100
	}
	
	cap macro drop akm*
	cap file close akm*
	
	* male: variance of log earnings
	file open akm_var_m using "${DIR_RES_TXT}/txt_akm_var_m.tex", write replace
	file write akm_var_m `format_1d' (var_inc[1]) "%"
	file close akm_var_m
	
	* female: variance of log earnings
	file open akm_var_f using "${DIR_RES_TXT}/txt_akm_var_f.tex", write replace
	file write akm_var_f `format_1d' (var_inc[2]) "%"
	file close akm_var_f
	
	* male: variance person FEs share
	file open akm_var_pers_fe_sh_m using "${DIR_RES_TXT}/txt_akm_var_pers_fe_sh_m.tex", write replace
	file write akm_var_pers_fe_sh_m `format_1d' (share_fe_pers[1]) "%"
	file close akm_var_pers_fe_sh_m
	
	* female: variance person FEs share
	file open akm_var_pers_fe_sh_f using "${DIR_RES_TXT}/txt_akm_var_pers_fe_sh_f.tex", write replace
	file write akm_var_pers_fe_sh_f `format_1d' (share_fe_pers[2]) "%"
	file close akm_var_pers_fe_sh_f
	
	* male: variance employer FEs share
	file open akm_var_emp_fe_sh_m using "${DIR_RES_TXT}/txt_akm_var_emp_fe_sh_m.tex", write replace
	file write akm_var_emp_fe_sh_m `format_1d' (share_fe_emp[1]) "%"
	file close akm_var_emp_fe_sh_m
	
	* female: variance employer FEs share
	file open akm_var_emp_fe_sh_f using "${DIR_RES_TXT}/txt_akm_var_emp_fe_sh_f.tex", write replace
	file write akm_var_emp_fe_sh_f `format_1d' (share_fe_emp[2]) "%"
	file close akm_var_emp_fe_sh_f
	
	* male: covariance employer FEs share
	file open akm_cov_emp_fe_sh_m using "${DIR_RES_TXT}/txt_akm_cov_emp_fe_sh_m.tex", write replace
	file write akm_cov_emp_fe_sh_m `format_1d' (share_cov_inc_fe_emp[1]) "%"
	file close akm_cov_emp_fe_sh_m
	
	* female: covariance employer FEs share
	file open akm_cov_emp_fe_sh_f using "${DIR_RES_TXT}/txt_akm_cov_emp_fe_sh_f.tex", write replace
	file write akm_cov_emp_fe_sh_f `format_1d' (share_cov_inc_fe_emp[2]) "%"
	file close akm_cov_emp_fe_sh_f
	
	* male: correlation person employer FEs
	file open akm_corr_pers_emp_m using "${DIR_RES_TXT}/txt_akm_corr_pers_emp_m.tex", write replace
	file write akm_corr_pers_emp_m `format_1d' (corr_pers_emp[1]) "%"
	file close akm_corr_pers_emp_m
	
	* female: correlation person employer FEs
	file open akm_corr_pers_emp_f using "${DIR_RES_TXT}/txt_akm_corr_pers_emp_f.tex", write replace
	file write akm_corr_pers_emp_f `format_1d' (corr_pers_emp[2]) "%"
	file close akm_corr_pers_emp_f
	
	* R^2: "upward of" smaller number
	file open akm_r2 using "${DIR_RES_TXT}/txt_akm_r2.tex", write replace
	file write akm_r2 `format_1d' (r2[1]) "%"
	file close akm_r2
	
	* mean employer FE for men
	use ///
		log_w_m size_m ///
		using "${DIR_TEMP}/post_est.dta", clear
	sum log_w_m [aw=size_m]
	local log_w_m_mean: di %4.1f `=r(mean)*100'
	file open akm_mean_fe_m using "${DIR_RES_TXT}/txt_akm_mean_fe_m.tex", write replace
	file write akm_mean_fe_m `format_1d' (`log_w_m_mean') "%"
	file close akm_mean_fe_m
	
}


*** AKM decomposition with KSS bias correction
if $txt_akm_kss_decomp {
	
	* load KSS estimates
	foreach stat in var_y var_fe var_pe cov_fe_pe corr_fe_pe r_2 {
		foreach method in plugin leaveout {
			forval g = 1/2 {
				if "`stat'" == "var_y" {
					qui import delim using "${DIR_TEMP}/output_akm_kss_`stat'_`g'.csv", clear
					replace v1 = v1*100
					sum v1, meanonly
					if "`stat'" == "cov_fe_pe" local `stat'_`g' = 2*r(mean)
					else local `stat'_`g' = r(mean)
					local `stat'_`g'_disp: di %3.1f ``stat'_`g''
				}
				else {
					qui import delim using "${DIR_TEMP}/output_akm_kss_`stat'_`method'_`g'.csv", clear
					replace v1 = v1*100
					sum v1, meanonly
					if "`stat'" == "cov_fe_pe" local `stat'_`method'_`g' = 2*r(mean)
					else local `stat'_`method'_`g' = r(mean)
					local `stat'_`method'_`g'_disp: di %3.1f ``stat'_`method'_`g''
				}
				if "`stat'" == "var_y" {
					file open kss_`stat'_`g' using "${DIR_RES_TXT}/txt_akm_kss_`stat'_`g'.tex", write replace
					file write kss_`stat'_`g' %3.1f (``stat'_`g'_disp') "%"
					file close kss_`stat'_`g'
				}
				else {
					file open kss_`stat'_`method'_`g' using "${DIR_RES_TXT}/txt_akm_kss_`stat'_`method'_`g'.tex", write replace
					file write kss_`stat'_`method'_`g' %3.1f (``stat'_`method'_`g'_disp') "%"
					file close kss_`stat'_`method'_`g'
				}
			}
		}
	}
	
	* compute and save variance shares
	foreach stat in var_fe var_pe cov_fe_pe {
		foreach method in plugin leaveout {
			forval g = 1/2 {
				qui import delim using "${DIR_TEMP}/output_akm_kss_`stat'_`method'_`g'.csv", clear
				sum v1, meanonly
				local share_`stat'_`method'_`g' = ``stat'_`method'_`g''/`var_y_`g''*100
				local share_`stat'_`method'_`g'_disp: di %4.1f `share_`stat'_`method'_`g''
				if inlist("`stat'", "var_fe", "var_pe") {
					file open kss_share_`stat'_`method'_`g' using "${DIR_RES_TXT}/txt_akm_kss_share_`stat'_`method'_`g'.tex", write replace
					file write kss_share_`stat'_`method'_`g' %4.1f (`share_`stat'_`method'_`g'_disp') "%"
					file close kss_share_`stat'_`method'_`g'
				}
			}
		}
	}
}


*** KOB decomposition
if $txt_kob_decomp {

	foreach comp in log_w log_pi log_pi_tilde {
		
		* load data
		use ///
			id_emp ///
			w_m w_f ///
			log_w_m log_w_f ///
			log_pi_m log_pi_f ///
			x_m x_f ///
			log_x_m log_x_f ///
			g_m g_f ///
			using "${DIR_TEMP}/post_est.dta", clear
		
		* create multiplicative amenities term
		foreach g in m f {
			gen float pi_tilde_`g' = x_`g'/w_`g'
			lab var pi_tilde_`g' "Multiplicative amenities term (\tilde{a} = x/w), gender `g'"
			gen float log_pi_tilde_`g' = ln(pi_tilde_`g')
			lab var log_pi_tilde_`g' "Log of multiplicative amenities term (ln(\tilde{a}) = ln(x) - ln(w)), gender `g'"
		}
		
		* Kitagawa-Oaxaca-Blinder decomposition
		prog_kob "`comp'"
		
		* load .dta with decompositions
		use "${DIR_TEMP}/postfile_kob_`comp'.dta", clear
		sleep 100
		compress

		local format_1d = "%4.1f"
		
		* formatting numbers
		foreach var of varlist * {
			destring `var', gen(`var'_n)
			drop `var'
			rename `var'_n `var'
		}
		replace gender_pay_gap = gender_pay_gap*100
		replace level_pay = level_pay*100
		replace level_sorting = level_sorting*100

		cap macro drop kob*
		cap file close kob*
		
		* gender pay gap
		if "`comp'" == "log_w" local gap_fe = gender_pay_gap[1]
		file open kob_gender_pay_gap using "${DIR_RES_TXT}/txt_kob_gender_gap_`comp'.tex", write replace
		file write kob_gender_pay_gap `format_1d' (gender_pay_gap[1]) "%" 
		file close kob_gender_pay_gap
		
		* decomp1: share within
		file open kob_share_within_1 using "${DIR_RES_TXT}/txt_kob_share_within_1_`comp'.tex", write replace
		file write kob_share_within_1 `format_1d' (share_pay[1]) "%" 
		file close kob_share_within_1
		
		* decomp2: share within
		file open kob_share_within_2 using "${DIR_RES_TXT}/txt_kob_share_within_2_`comp'.tex", write replace
		file write kob_share_within_2 `format_1d' (share_pay[2]) "%" 
		file close kob_share_within_2
		
		* decomp1: share between (lower bound because we say "upward of")
		file open kob_share_between_1 using "${DIR_RES_TXT}/txt_kob_share_between_1_`comp'.tex", write replace
		file write kob_share_between_1 `format_1d' (share_sorting[1]) "%" 
		file close kob_share_between_1
		
		* decomp2: share between (lower bound because we say "upward of")
		file open kob_share_between_2 using "${DIR_RES_TXT}/txt_kob_share_between_2_`comp'.tex", write replace
		file write kob_share_between_2 `format_1d' (share_sorting[2]) "%" 
		file close kob_share_between_2
		
		* decomp1: level between
		file open kob_level_between_1 using "${DIR_RES_TXT}/txt_kob_level_between_1_`comp'.tex", write replace
		file write kob_level_between_1 `format_1d' (level_sorting[1]) "%"
		file close kob_level_between_1
		
		* decomp1: level within
		file open kob_level_within_1 using "${DIR_RES_TXT}/txt_kob_level_within_1_`comp'.tex", write replace
		file write kob_level_within_1 `format_1d' (level_pay[1]) "%"
		file close kob_level_within_1
		
		* ratio of within to men's mean employer FE (i.e., women's implied bargaining disadvantage)
		if "`comp'" == "log_w" {
			sum level_pay if _n == 1
			local gap_within = `=r(mean)/100'
			use ///
				log_w_m size_m ///
				using "${DIR_TEMP}/post_est.dta", clear
			sum log_w_m [aw=size_m]
			local log_w_m_mean = r(mean)
			local bargaining_disadvantage: di %4.1f `=`gap_within'/`log_w_m_mean'*100'
			file open kob_bargaining_disadvantage using "${DIR_RES_TXT}/txt_kob_bargaining_disadvantage.tex", write replace
			file write kob_bargaining_disadvantage `format_1d' (`bargaining_disadvantage') "%"
			file close kob_bargaining_disadvantage
		}
	}
	
}


*** summary statistics
if $txt_sum_stats {
	
	* load data (CONNECTED)
	use "${DIR_TEMP}/sum_stats_connected.dta", clear
	
	keep var_label OverallPooled
	
	local format_1d = "%4.1f"
	
	cap macro drop sum_stats*
	cap file close sum_stats*
	
	* deleting commas and destring to obtain numbers
	replace OverallPooled = subinstr(OverallPooled, ",", "", .)
	destring OverallPooled, gen(OverallPooled_numbers) force
	drop OverallPooled
	rename OverallPooled_numbers OverallPooled
	
	* overall pooled: number of observations
	preserve
		keep if var_label == "Number of worker-years"
		replace OverallPooled = OverallPooled / 1000000 // millions
		file open sum_stats_n_worker_years using "${DIR_RES_TXT}/txt_sum_stats_n_worker_years.tex", write replace
		file write sum_stats_n_worker_years `format_1d' (OverallPooled[1]) "%"
		file close sum_stats_n_worker_years
	restore
	
	* overall pooled: unique workers
	preserve
		keep if var_label == "Number of unique workers"
		replace OverallPooled = OverallPooled / 10^6 // millions
		file open sum_stats_n_workers using "${DIR_RES_TXT}/txt_sum_stats_n_workers.tex", write replace
		file write sum_stats_n_workers `format_1d' (OverallPooled[1]) "%"
		file close sum_stats_n_workers
	restore
	
	* overall pooled: unique establishments
	preserve
		keep if var_label == "Number of unique establishments"
		replace OverallPooled = OverallPooled / 10^3 // thousands
		file open sum_stats_n_estab using "${DIR_RES_TXT}/txt_sum_stats_n_estab.tex", write replace
		file write sum_stats_n_estab `format_1d' (OverallPooled[1]) "%"
		file close sum_stats_n_estab
	restore
	
	* shares of females
	preserve
		keep if var_label == "Share female"
		replace OverallPooled = OverallPooled*100
		file open sum_stats_sh_f using "${DIR_RES_TXT}/txt_sum_stats_sh_f.tex", write replace
		file write sum_stats_sh_f `format_1d' (OverallPooled[1]) "%"
		file close sum_stats_sh_f
	restore
	
	* load gender gap in employer FEs
	preserve
		use "${DIR_TEMP}/postfile_kob_log_w.dta", clear
		foreach var of varlist * {
			destring `var', gen(`var'_n)
			drop `var'
			rename `var'_n `var'
		}
		replace gender_pay_gap = gender_pay_gap*100
		local gap_fe = gender_pay_gap[1]
	restore
	
	* overall pooled: mean log gender earnings gap
	preserve
		keep if var_label == "Mean log gender earnings gap"
		replace OverallPooled = OverallPooled*100
		local gap_raw_earn = OverallPooled[1]
		local gap_share_fe_earn = `gap_fe'/`gap_raw_earn'*100
		file open sum_stats_gap_share_fe_earn using "${DIR_RES_TXT}/txt_sum_stats_gap_share_fe_earn.tex", write replace
		file write sum_stats_gap_share_fe_earn `format_1d' (`gap_share_fe_earn') "%"
		file close sum_stats_gap_share_fe_earn
		file open sum_stats_earn_gap using "${DIR_RES_TXT}/txt_sum_stats_earn_gap.tex", write replace
		file write sum_stats_earn_gap `format_1d' (OverallPooled[1]) "%"
		file close sum_stats_earn_gap
	restore
	
	* overall pooled: mean log gender wage gap
	preserve
		keep if var_label == "Mean log gender wage gap"
		replace OverallPooled = OverallPooled*100
		local gap_raw_wage = OverallPooled[1]
		local gap_share_fe_wage = `gap_fe'/`gap_raw_wage'*100
		file open sum_stats_gap_share_fe_wage using "${DIR_RES_TXT}/txt_sum_stats_gap_share_fe_wage.tex", write replace
		file write sum_stats_gap_share_fe_wage `format_1d' (`gap_share_fe_wage') "%"
		file close sum_stats_gap_share_fe_wage
		file open sum_stats_wage_gap using "${DIR_RES_TXT}/txt_sum_stats_wage_gap.tex", write replace
		file write sum_stats_wage_gap `format_1d' (OverallPooled[1]) "%"
		file close sum_stats_wage_gap
	restore
	
}


*** gender-specific mean employer ranks, pay, amenities, and productivity
if $txt_means {
	
	* load data
	use ///
		rank_m rank_f ///
		log_w_m log_w_f ///
		log_pi_m log_pi_f ///
		log_p_m ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear
	
	* compute gender-specific means
	foreach g in m f {
		foreach var in rank log_w log_pi {
			sum `var'_`g' [aw=size_`g'], meanonly
			local mean_`var'_`g' = r(mean)
			local mean_`var'_`g'_disp: di %4.3f `mean_`var'_`g''
		}
	}
	
	* write means to files
	foreach g in m f {
		foreach var in rank log_w log_pi {
			file open mean_`var'_`g' using "${DIR_RES_TXT}/txt_mean_`var'_`g'.tex", write replace
			file write mean_`var'_`g' "`mean_`var'_`g'_disp'%"
			file close mean_`var'_`g'
		}
	}
	
	* productivity
	foreach g in m f {
		sum log_p_m [aw=size_`g']
		local mean_log_prod_`g' = r(mean)
		local mean_log_prod_`g'_disp: di %4.3f `mean_log_prod_`g''
		file open mean_log_prod_`g' using "${DIR_RES_TXT}/txt_mean_log_prod_`g'.tex", write replace
		file write mean_log_prod_`g' "`mean_log_prod_`g'_disp'%"
		file close mean_log_prod_`g'
	}
	local mean_log_prod_gap = (`mean_log_prod_m' - `mean_log_prod_f')*100
	local mean_log_prod_gap_disp: di %2.1f `mean_log_prod_gap'
	file open mean_log_prod_gap using "${DIR_RES_TXT}/txt_mean_log_prod_gap.tex", write replace
	file write mean_log_prod_gap "`mean_log_prod_gap_disp'%"
	file close mean_log_prod_gap
	
}


*** density estimates of recruiting intensities
if $txt_recruiting_dens {
	
	* open postfile
	cap postclose post_recruiting
	postfile post_recruiting ///
		log_f_m_sd log_f_m_skew log_f_m_kurt ///
		log_f_f_sd log_f_f_skew log_f_f_kurt ///
		using "${DIR_TEMP}/recruiting_stats.dta", replace

	* load data
	use ///
		f_m f_f ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear

	* generate log recruiting intensities
	foreach g in m f {
		gen float log_f_`g' = ln(f_`g')
		lab var log_f_`g' "Log recruiting intensity for gender `g'"
	}
	drop f_m f_f

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* summarize log recruiting intensities
	foreach g in m f {
		sum log_f_`g' [aw=weight_`g'], d
		local log_f_`g'_sd = r(sd)
		local log_f_`g'_skew = r(skewness)
		local log_f_`g'_kurt = r(kurtosis)
		di "gender `g': sd = `log_f_`g'_sd', skewness = `log_f_`g'_skew', kurtosis = `log_f_`g'_kurt'"
	}

	* write to postfile
	post post_recruiting ///
		(`log_f_m_sd') (`log_f_m_skew') (`log_f_m_kurt') ///
		(`log_f_f_sd') (`log_f_f_skew') (`log_f_f_kurt')

	* close postfile
	postclose post_recruiting

	* format postfile
	use "${DIR_TEMP}/recruiting_stats.dta", clear
	lab var log_f_m_sd "Standard deviation of log recruiting intensity, men"
	lab var log_f_m_skew "Skewness of log recruiting intensity, men"
	lab var log_f_m_kurt "Kurtosis of log recruiting intensity, men"
	lab var log_f_f_sd "Standard deviation of log recruiting intensity, women"
	lab var log_f_f_skew "Skewness of log recruiting intensity, women"
	lab var log_f_f_kurt "Kurtosis of log recruiting intensity, women"
	order log_f_m_sd log_f_m_skew log_f_m_kurt log_f_f_sd log_f_f_skew log_f_f_kurt
	compress
	
	* prepare recruiting statistics
	cap macro drop recruiting*
	cap file close recruiting*
	local format_sd = "%4.3f"
	local format_skew = "%4.3f"
	local format_kurt = "%4.3f"
	
	* Sd. men
	file open recruiting_sd_m using "${DIR_RES_TXT}/txt_recr_sd_m.tex", write replace
	file write recruiting_sd_m `format_sd' (log_f_m_sd[1]) "%"
	file close recruiting_sd_m
	
	* Skew men
	file open recruiting_sk_m using "${DIR_RES_TXT}/txt_recr_skew_m.tex", write replace
	file write recruiting_sk_m `format_skew' (log_f_m_skew[1]) "%"
	file close recruiting_sk_m
	
	* Kurt men
	file open recruiting_ku_m using "${DIR_RES_TXT}/txt_recr_kurt_m.tex", write replace
	file write recruiting_ku_m `format_kurt' (log_f_m_kurt[1]) "%"
	file close recruiting_ku_m
	
	* Sd. women
	file open recruiting_sd_f using "${DIR_RES_TXT}/txt_recr_sd_f.tex", write replace
	file write recruiting_sd_f `format_sd' (log_f_f_sd[1]) "%"
	file close recruiting_sd_f
	
	* Skew women
	file open recruiting_sk_f using "${DIR_RES_TXT}/txt_recr_skew_f.tex", write replace
	file write recruiting_sk_f `format_skew' (log_f_f_skew[1]) "%"
	file close recruiting_sk_f
	
	* Kurt women
	file open recruiting_ku_f using "${DIR_RES_TXT}/txt_recr_kurt_f.tex", write replace
	file write recruiting_ku_f `format_kurt' (log_f_f_kurt[1]) "%"
	file close recruiting_ku_f
	
}


*** amenity shares
if $txt_amenity_shares {
	
	* load data
	use ///
		id_emp ///
		pi_* x_* ///
		size_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* shares of utility due to wages vs. amenities
	foreach g in m f {
		gen float pi_share_`g' = pi_`g'/x_`g'
		lab var pi_share_`g' "Share of flow utility due to amenities, `g'"
		sum pi_share_`g' [aw=weight_`g']
		drop pi_`g' x_`g'
	}

	* save data
	order id_emp pi_share_m pi_share_f weight_m weight_f
	sort id_emp
	
	* compute amenity shares
	foreach g in m f {
		sum pi_share_`g' [aw=weight_`g']
		local pi_share_`g'_mean = r(mean)
		local pi_share_`g'_mean_disp: di %4.1f `pi_share_`g'_mean'*100
		di "gender `g': `pi_share_`g'_mean_disp'%"
	}
	
	* write output files
	foreach g in m f {
		file open pi_share_`g'_mean using "${DIR_RES_TXT}/txt_pi_share_`g'_mean.tex", write replace
		file write pi_share_`g'_mean "`pi_share_`g'_mean_disp'%"
		file close pi_share_`g'_mean
	}
	
}


*** total gender gaps in employer pay and utility, and their dispersion
if $txt_gaps {
	
	* load data
	use ///
		w_* log_w_* log_pi_* x_* log_x_* g_* ///
		using "${DIR_TEMP}/post_est.dta", clear
	
	* create multiplicative amenities term
	foreach g in m f {
		gen float pi_tilde_`g' = x_`g'/w_`g'
		lab var pi_tilde_`g' "Multiplicative amenities term (\tilde{a} = x/w), gender `g'"
		gen float log_pi_tilde_`g' = ln(pi_tilde_`g')
		lab var log_pi_tilde_`g' "Log of multiplicative amenities term (ln(\tilde{a}) = ln(x) - ln(w)), gender `g'"
	}

	* compute weighted mean pay by gender
	foreach var in log_w log_pi log_pi_tilde log_x {
		foreach g in m f {
			sum `var'_`g' [aw=g_`g']
			local `var'_`g'_mean = r(mean)
			local `var'_`g'_std = r(sd)
			local `var'_`g'_var = r(Var)
		}
	}
	
	* compute gaps
	local gap_log_w = `log_w_m_mean' - `log_w_f_mean'
	local gap_log_w_disp: di %4.1f `gap_log_w'*100
	di "overall gender gap in pay = `gap_w_disp' log points"
	local gap_log_pi = `log_pi_m_mean' - `log_pi_f_mean'
	local gap_log_pi_disp: di %4.1f `gap_log_pi'*100
	di "overall gender gap in amenities = `gap_pi_disp' log points"
	local gap_log_pi_tilde = `log_pi_tilde_m_mean' - `log_pi_tilde_f_mean'
	local gap_log_pi_tilde_disp: di %4.1f `gap_log_pi_tilde'*100
	di "overall gender gap in multiplicative amenities = `gap_pi_disp' log points"
	local gap_log_x = `log_x_m_mean' - `log_x_f_mean'
	local gap_log_x_disp: di %4.1f `gap_log_x'*100
	di "overall gender gap in utility = `gap_x_disp' log points"
	
	* compute share of pay gap that is utility gap
	local gap_log_x_share = `gap_log_x'/`gap_log_w'
	local gap_log_x_share_disp: di %4.1f `gap_log_x_share'*100
	
	* format standard deviations and variances
	foreach var in log_w log_x {
		foreach g in m f {
			local `var'_`g'_std_disp: di %4.3f ``var'_`g'_std'
			local `var'_`g'_var_disp: di %4.3f ``var'_`g'_var'
		}
	}
	
	* compute standard deviation / variance of utility's share in the standard deviation / variance of wages
	foreach g in m f {
		local std_x_share_`g' = `log_x_`g'_std'/`log_w_`g'_std'*100
		local std_x_share_`g'_disp: di %4.1f `std_x_share_`g''
		local var_x_share_`g' = `log_x_`g'_var'/`log_w_`g'_var'*100
		local var_x_share_`g'_disp: di %4.1f `var_x_share_`g''
	}
	
	* write output files
	foreach var in log_w log_pi log_pi_tilde log_x {
		file open gap_`var' using "${DIR_RES_TXT}/txt_gap_`var'.tex", write replace
		file write gap_`var' "`gap_`var'_disp'%"
		file close gap_`var'
	}
	foreach var in log_w log_x {
		foreach g in m f {
			file open std_`var'_`g' using "${DIR_RES_TXT}/txt_std_`var'_`g'.tex", write replace
			file write std_`var'_`g' "``var'_`g'_std_disp'%"
			file close std_`var'_`g'
			file open var_`var'_`g' using "${DIR_RES_TXT}/txt_var_`var'_`g'.tex", write replace
			file write var_`var'_`g' "``var'_`g'_var_disp'%"
			file close var_`var'_`g'
		}
	}
	file open gap_log_x_share using "${DIR_RES_TXT}/txt_gap_log_x_share.tex", write replace
	file write gap_log_x_share "`gap_log_x_share_disp'%"
	file close gap_log_x_share
	foreach g in m f {
		file open std_x_share_`g' using "${DIR_RES_TXT}/txt_std_x_share_`g'.tex", write replace
		file write std_x_share_`g' "`std_x_share_`g'_disp'%"
		file close std_x_share_`g'
		file open var_x_share_`g' using "${DIR_RES_TXT}/txt_var_x_share_`g'.tex", write replace
		file write var_x_share_`g' "`var_x_share_`g'_disp'%"
		file close var_x_share_`g'
	}
	
}


*** gender-specific elasticities of pay with respect to productivity
if $txt_elast {
	
	* load data
	use ///
		log_w_m log_w_f log_p_m size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear
		
	* regress gender-specific pay on productivity
	foreach g in m f {
		reghdfe log_w_`g' log_p_m [aw=size_`g'], noabsorb
		local elast_`g' = _b[log_p_m]
	}

	* create dataset with estimates
	clear
	set obs 1
	foreach g in m f {
		gen float elast_`g' = `elast_`g''
	}

	* save data
	order elast_m elast_f
	compress
	
	* format elasticities
	foreach g in m f {
		local elast_`g'_disp: di %4.3f elast_`g'[1]
	}
	
	* write output files
	foreach g in m f {
		file open elast_`g' using "${DIR_RES_TXT}/txt_elast_`g'.tex", write replace
		file write elast_`g' "`elast_`g'_disp'%"
		file close elast_`g'
	}
}


*** counterfactual
if $txt_counterfactual {
		
	cap macro drop cf2_* cf1_*
	cap file close cf2_* cf1_*
	
	*** COUNTERFACTUAL 1A)
	*Load data
	use ///
		log_x_* log_w_* log_pi* g_* ///
		using "${DIR_TEMP}/post_est.dta", clear
	
	* compute changes in utility, amenities, and wages
	sum log_x_m [aw=g_m], meanonly
	local mean_log_x_m_gm = r(mean)
	sum log_x_f [aw=g_f], meanonly
	local mean_log_x_f_gf = r(mean)
	local gap_log_x_m =  `mean_log_x_m_gm'-`mean_log_x_f_gf'
	
	sum log_x_f [aw=g_m], meanonly
	local mean_log_x_f_gm = r(mean)
	local cf1_change_log_x_f_minus_m = `mean_log_x_f_gf' - `mean_log_x_f_gm'	// INVERTED BECAUSE NEGATIVE
	
	sum log_pi_f [aw=g_f], meanonly
	local mean_log_pi_f_gf = r(mean)
	sum log_pi_f [aw=g_m], meanonly
	local mean_log_pi_f_gm = r(mean)
	local cf1_change_log_pi_f_minus_m = `mean_log_pi_f_gf' - `mean_log_pi_f_gm'	// INVERTED BECAUSE NEGATIVE
	
	sum log_w_f [aw=g_f], meanonly
	local mean_log_w_f_gf = r(mean)
	sum log_w_f [aw=g_m], meanonly
	local mean_log_w_f_gm = r(mean)
	local cf1_change_log_w_f = `mean_log_w_f_gm' - `mean_log_w_f_gf'
	di ///
		"Counterfactual 1A) fixing job characteristics, move women into men's employers:" _newline(1) ///
		"     Change in log wages:            `cf1_change_log_w_f'" _newline(1) ///
		"     Change in log amenities:        `cf1_change_log_pi_f_minus_m'" _newline(1) ///
		"     Change in log utility:      	  `cf1_change_log_x_f_minus_m'"
	
	* save text
	foreach var in ///
					cf1_change_log_w_f ///
					cf1_change_log_pi_f_minus_m ///
					cf1_change_log_x_f_minus_m ///
					{
						
		local `var'_di: di %4.1f ``var''*100
		
		file open f_`var' using "${DIR_RES_TXT}/txt_`var'.tex", write replace
		file write f_`var' "``var'_di'%"
		file close f_`var'
	}
	
	
	*** COUNTERFACTUAL 1B)
	*Load data
	use ///
		log_x_* log_w_* log_pi* g_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* compute changes in utility, amenities, and wages
	sum log_x_f [aw=g_f], meanonly
	local mean_log_x_f_gf = r(mean)
	sum log_x_m [aw=g_m], meanonly
	local mean_log_x_m_gm = r(mean)
	local gap_log_x_mm =  `mean_log_x_f_gf'-`mean_log_x_m_gm'
	
	sum log_x_m [aw=g_f], meanonly
	local mean_log_x_m_gf = r(mean)
	local cf1_change_log_x_m_minus_f = `mean_log_x_m_gm' - `mean_log_x_m_gf'	// INVERTED BECAUSE NEGATIVE
	
	sum log_pi_m [aw=g_m], meanonly
	local mean_log_pi_m_gm = r(mean)
	sum log_pi_m [aw=g_f], meanonly
	local mean_log_pi_m_gf = r(mean)
	local cf1_change_log_pi_m = `mean_log_pi_m_gf' - `mean_log_pi_m_gm'
	
	sum log_w_m [aw=g_m], meanonly
	local mean_log_w_m_gm = r(mean)
	sum log_w_m [aw=g_f], meanonly
	local mean_log_w_m_gf = r(mean)
	local cf1_change_log_w_m_minus_f = `mean_log_w_m_gm' - `mean_log_w_m_gf'	// INVERTED BECAUSE NEGATIVE
	di ///
		"Counterfactual 1B) fixing job characteristics, move men into women's employers:" _newline(1) ///
		"     Change in log wages:            `cf1_change_log_w_m_minus_f'" _newline(1) ///
		"     Change in log amenities:        `cf1_change_log_pi_m'" _newline(1) ///
		"     Change in log utility:      	  `cf1_change_log_x_m_minus_f'"

	* save text
	foreach var in ///
					cf1_change_log_w_m_minus_f ///
					cf1_change_log_pi_m ///
					cf1_change_log_x_m_minus_f ///
					{
		
		local `var'_di: di %4.1f ``var''*100
		
		file open f_`var' using "${DIR_RES_TXT}/txt_`var'.tex", write replace
		file write f_`var' "``var'_di'%"
		file close f_`var'
	}
	
	
	*** COUNTERFACTUAL 2A) CHANGE WOMEN'S JOB CHARACTERISTICS TO MEN'S (WAGES, AMENITIES, UTILITIES)
	*Load data
	use ///
		log_x_* log_w_* log_pi* g_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* compute counterfactual pay, amenities, and total compensation
	sum log_x_m [aw=g_f], meanonly
	local mean_log_x_m_gf = r(mean)
	local cf2_change_log_x_f = `mean_log_x_m_gf' - `mean_log_x_f_gf'
	sum log_pi_m [aw=g_f], meanonly
	local mean_log_pi_m_gf = r(mean)
	local cf2_change_log_pi_f = `mean_log_pi_m_gf' - `mean_log_pi_f_gf'
	sum log_w_m [aw=g_f], meanonly
	local mean_log_w_m_gf = r(mean)
	local cf2_change_log_w_f = `mean_log_w_m_gf' - `mean_log_w_f_gf'
	di ///
		"Counterfactual 2A) fixing employment, change women's job characteristics to men's characteristics:" _newline(1) ///
		"     Change in log wages:            `cf2_change_log_w_f'" _newline(1) ///
		"     Change in log amenities:        `cf2_change_log_pi_f'" _newline(1) ///
		"     Change in log utility:      	  `cf2_change_log_x_f'"

	* save text
	foreach var in w pi x {
		
		local cf2_change_log_`var'_f_di: di %4.1f `cf2_change_log_`var'_f'*100
		
		file open f_`var' using "${DIR_RES_TXT}/txt_cf2_change_log_`var'_f.tex", write replace
		file write f_`var' "`cf2_change_log_`var'_f_di'%"
		file close f_`var'
	}
	
	*** COUNTERFACTUAL 2B) CHANGE MEN'S JOB CHARACTERISTICS TO WOMEN'S (WAGES, AMENITIES, UTILITIES)
	*Load data
	use ///
		log_x_* log_w_* log_pi* g_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* compute counterfactual pay, amenities, and total compensation
	sum log_x_f [aw=g_m], meanonly
	local mean_log_x_f_gm = r(mean)
	local cf2b_change_log_x_m_minus_f = `mean_log_x_m_gm' - `mean_log_x_f_gm'		// INVERTED BECAUSE NEGATIVE
	sum log_pi_f [aw=g_m], meanonly
	local mean_log_pi_f_gm = r(mean)
	local cf2b_change_log_pi_m_minus_f = `mean_log_pi_m_gm' - `mean_log_pi_f_gm'	// INVERTED BECAUSE NEGATIVE
	sum log_w_f [aw=g_m], meanonly
	local mean_log_w_f_gm = r(mean)
	local cf2b_change_log_w_m_minus_f = `mean_log_w_m_gm' - `mean_log_w_f_gm'		// INVERTED BECAUSE NEGATIVE
	di ///
		"Counterfactual 2B) fixing employment, change men's job characteristics to women's characteristics:" _newline(1) ///
		"     Change in log wages:            `cf2b_change_log_w_m_minus_f'" _newline(1) ///
		"     Change in log amenities:        `cf2b_change_log_pi_m_minus_f'" _newline(1) ///
		"     Change in log utility:      	  `cf2b_change_log_x_m_minus_f'"

	* save text
	foreach var in ///
					cf2b_change_log_w_m_minus_f ///
					cf2b_change_log_pi_m_minus_f ///
					cf2b_change_log_x_m_minus_f ///
					{
		
		local `var'_di: di %4.1f ``var''*100
		
		file open f_`var' using "${DIR_RES_TXT}/txt_`var'.tex", write replace
		file write f_`var' "``var'_di'%"
		file close f_`var'
	}
	
}


*** saving R^2 from regressions (amenities)
if $txt_reg_amenities {
	
	cap macro drop file_r2*
	cap file close file_r2*
	
	* load data (men)
	use "${DIR_TEMP}/postfile_projections_amenities_1.dta", clear
	keep if absorb_vars == "ind muni"
	replace r2 = r2*100
	
	* R^2 for men
	file open file_r2_men using "${DIR_RES_TXT}/txt_reg_amenities_r2_men.tex", write replace
	file write file_r2_men %4.1f (r2[1]) "%"
	file close file_r2_men
	
	* load data (women)
	use "${DIR_TEMP}/postfile_projections_amenities_2.dta", clear
	keep if absorb_vars == "ind muni"
	replace r2 = r2*100
	
	* R^2 for women
	file open file_r2_women using "${DIR_RES_TXT}/txt_reg_amenities_r2_women.tex", write replace
	file write file_r2_women %4.1f (r2[1]) "%"
	file close file_r2_women
	
}


*** saving R^2 from regressions (wedges)
if $txt_reg_wedges {
	
	cap macro drop file_r2*
	cap file close file_r2*
	
	* load data
	use "${DIR_TEMP}/postfile_projections_wedges.dta", clear
	keep if absorb_vars == "ind muni"
	replace r2 = r2*100
	
	* save R^2 coefficient
	file open file_r2 using "${DIR_RES_TXT}/txt_reg_wedges_r2.tex", write replace
	file write file_r2 %4.1f (r2[1]) "%"
	file close file_r2
}


*** saving R^2 from regressions (pay on size, by gender)
if $txt_reg_pay_size_r2 {
	
	cap macro drop file_r2*
	cap file close file_r2*
	
	* load data
	use "${DIR_TEMP}/postfile_reg_pay_size_r2.dta", clear
	replace r2 = r2*100
	
	* save R^2 coefficients
	forvalues i = 1/2 {		
		local gender = gender[`i']
		file open file_r2 using "${DIR_RES_TXT}/txt_reg_pay_size_r2_`gender'.tex", write replace
		file write file_r2 %4.1f (r2[`i']) "%"
		file close file_r2
	}

}


*** compute correlations between employer-gender rank measures
if $txt_ranks {
	
	* load data
	use "${DIR_TEMP}/ranks.dta", clear

	* compute weighted Pearson correlations or Spearman's rank correlations between various employer rank measures
	local var_list = "size pagerank poaching" // hires_NE poaching retention net size fe_emp pagerank
	foreach restriction in "" { // "& rank_size >= 0.5"
		foreach corr_type in pearson spearman {
			forval g = 1/2 {
				if `g' == 1 local g_str = "men"
				else if `g' == 2 local g_str = "women"
				if "`restriction'" == "" di _newline(1) "--> `corr_type' correlation for `g_str':"
				else if "`restriction'" == "& rank_size >= 0.5" di _newline(1) "--> `corr_type' correlation for `g_str' (top 50% of firm sizes):"
				foreach var1 of local var_list {
					foreach var2 of local var_list {
						if "`var1'" == "`var2'" continue, break
						else {
							if "`corr_type'" == "pearson" qui corr `var1' `var2' [aw = size] if gender == `g' `restriction'
							else if "`corr_type'" == "spearman" qui corr rank_`var1' rank_`var2' [aw = size] if gender == `g' `restriction'
							local `corr_type'_`var1'_`var2'_`g' = r(rho)
							local `corr_type'_`var1'_`var2'_`g'_di: di %4.3f ``corr_type'_`var1'_`var2'_`g''
							di "corr(`var1', `var2') = ``corr_type'_`var1'_`var2'_`g'_di'"
							if "`corr_type'" == "spearman" | (inlist("size", "`var1'", "`var2'") & inlist("pagerank", "`var1'", "`var2'")) {
								file open file_corr_`var1'_`var2' using "${DIR_RES_TXT}/txt_corr_`corr_type'_`var1'_`var2'_`g'.tex", write replace
								file write file_corr_`var1'_`var2' %4.3f (``corr_type'_`var1'_`var2'_`g'_di') "%"
								file close file_corr_`var1'_`var2'
							}
						}
					}
				}
			}
		}
	}
	
}


*** final housekeeping
* clean up
if $clean_up {
	rm "${DIR_TEMP}/id_emp_public.dta"
	rm "${DIR_TEMP}/ranks.dta"
	rm "${DIR_TEMP}/post_est.dta"
}

* turn timer off
timer off 18

* print final banner
di _newline(5)
timer list 18
local t = r(t18)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_17_TEXT.do
********************************************************************************

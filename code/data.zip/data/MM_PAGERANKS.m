fprintf('\n==============================================================')
fprintf('\nFILE NAME:   MM_PAGERANKS.m')
fprintf('\n')
fprintf('\nDESCRIPTION: Computes PageRanks based on the adjacency or transition matrix')
fprintf('\n')
fprintf('\nAUTHORS:     Iacopo Morchio (University of Bristol)')
fprintf('\n             Christian Moser (Columbia University)')
fprintf('\n')
fprintf('\nINPUTS:      Two files:')
fprintf('\n             - FILE_TEMP_INPUT: a matrix with three columns (old employer IDs, new employer IDs, frequency of observations)')
fprintf('\n             - FILE_TEMP_GENDER: a scalar indicating the gender of individuals in the sample')
fprintf('\n')
fprintf('\nOUTPUTS:     One file:')
fprintf('\n             - FILE_TEMP_OUTPUT: a matrix with two columns (unique employer ID, PageRank)')
fprintf('\n')
fprintf('\nDATE:        November 4, 2025')
fprintf('\n==============================================================')


fprintf('\n==============================================================')
fprintf('\n INITIAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Start timer\n')
tic

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Set options\n')
self_referrals = 1; % whether to use self-referrals in computation of largest strongly connected set and PageRank: 0 = drop self-referrals; 1 = keep self-referrals

fprintf('\n  --> Set time stamp\n')
if exist('time_stamp.txt', 'file')
    READ_TIME_STAMP = readlines('time_stamp.txt');
    STR_TIME_STAMP = char(READ_TIME_STAMP(1));
    clear READ_TIME_STAMP
else
    fprintf('\nUSER ERROR: Time stamp not found.\n')
    exit
end

fprintf('\n  --> Set directories\n')
if exist('paths.txt', 'file')
    READ_REPLICATION = readlines('paths.txt');
    DIR_MAIN = char(READ_REPLICATION(1));
    DIR_TEMP = char(READ_REPLICATION(2));
else
    fprintf('\nUSER ERROR: Directories not found.\n')
    exit
end
% DIR_MAIN = ''; % note: this directory is automatically defined above
    DIR_LOG = fullfile(DIR_MAIN, 'logs'); % path to folder where log files should be saved
    FILE_LOG = fullfile(DIR_LOG, ['log_', STR_TIME_STAMP, '_MM_PAGERANKS.log']);
% DIR_TEMP = ''; % note: this directory is automatically defined above
    FILE_TEMP_INPUT = fullfile(DIR_TEMP, 'input_pagerank.csv');
    FILE_TEMP_GENDER = fullfile(DIR_TEMP, 'input_pagerank_gender.csv');
    FILE_TEMP_OUTPUT = fullfile(DIR_TEMP, 'output_pagerank.csv');
clear STR_TIME_STAMP READ_REPLICATION DIR_MAIN DIR_TEMP

fprintf('\n  --> Set random-number seed\n')
seed = 20250828;
rng(seed, 'twister')
clear seed

fprintf('\n  --> Start log file\n')
diary(FILE_LOG)
clear DIR_LOG FILE_LOG


fprintf('\n==============================================================')
fprintf('\n MAIN CODE')
fprintf('\n==============================================================')
fprintf('\n  --> Read data\n')
id_emp_old_new = readmatrix(FILE_TEMP_INPUT);
gender = readmatrix(FILE_TEMP_GENDER);
clear FILE_TEMP_INPUT FILE_TEMP_GENDER

fprintf('\n  --> Drop self-referrals, if requested\n')
if ~self_referrals
    id_emp_old_new = id_emp_old_new(id_emp_old_new(:, 1) ~= id_emp_old_new(:, 2), 1:2);
end
clear self_referrals

fprintf('\n  --> Create vectors for employer IDs and previous employer IDs\n')
id_emp_old = id_emp_old_new(:, 1); % old employer IDs
id_emp_new = id_emp_old_new(:, 2); % new employer IDs
N_obs = size(id_emp_old_new, 1); % number of observations

fprintf('\n  --> Create vectors of unique employer IDs\n')
[id_emp_unique, ~, index] = unique([id_emp_old; id_emp_new]); % command -unique()- returns unique values of the pooled array of all current and previous employer IDs -- note: column index maps 'id_emp_unique' into the (old) employer IDs: [id_emp_new; id_emp_old] = id_emp_unique(index)
id_emp_old_index = index(1:N_obs);
id_emp_new_index = index(N_obs + 1:end);
clear index

fprintf('\n  --> Find IDs of employers in largest strongly connected set\n')
M = digraph(id_emp_old_index', id_emp_new_index');
[connected_index, connected_size] = conncomp(M, 'Type', 'strong'); % construct strongly connected sets
idx = (connected_index == min(connected_index(connected_size(connected_index) == max(connected_size)))); % vector of indicators for whether employer ID is in the set of employer IDs whose component set has the smallest component ID among all largest component sets
id_emp_connected = uint64(id_emp_unique(idx)); % select employer IDs in largest connected set
clear id_emp_old_index id_emp_new_index M connected_index connected_size id_emp_unique idx

fprintf('\n  --> Restrict attention to employers in largest strongly connected set\n')
is_connected_old = ismember(id_emp_old, id_emp_connected);
is_connected_new = ismember(id_emp_new, id_emp_connected);
id_emp_old_new = id_emp_old_new(is_connected_old & is_connected_new, :);
id_emp_old = id_emp_old_new(:, 1); % old employer IDs
id_emp_new = id_emp_old_new(:, 2); % new employer IDs
freq = id_emp_old_new(:, 3); % frequency of transitions between old employer ID and new employer ID
N_obs = size(id_emp_old_new, 1);
clear is_connected_old is_connected_new id_emp_connected id_emp_old_new

fprintf('\n  --> Create vectors of unique employer IDs again\n')
[id_emp_unique, ~, index] = unique([id_emp_old; id_emp_new]); % command -unique()- returns unique values of the pooled array of all current and previous employer IDs -- note: column index maps 'id_emp_unique' into the (old) employer IDs: [id_emp_new; id_emp_old] = id_emp_unique(index)
id_emp_old_index = index(1:N_obs);
id_emp_new_index = index(N_obs + 1:end);
N_id_emp = max(index);
clear index id_emp_old id_emp_new N_obs

fprintf('\n  --> Construct transition (i.e., rescaled adjacency) matrix for employers in largest strongly connected set\n')
A = sparse(id_emp_old_index, id_emp_new_index, freq, N_id_emp, N_id_emp);
A_row_sums = sum(A, 2);
A_row_sums_inv = spdiags(1./A_row_sums, 0, N_id_emp, N_id_emp);
A = A_row_sums_inv*A; % memory-efficient way of normalizing the adjacency matrix to create the transition matrix---i.e., same effect as A = A./sum(A, 2)
A_row_sums = sum(A, 2);
tol_error = 1.0*1e-12; % error tolerance in constructing the transition matrix
assert(all(abs(A_row_sums - 1) < tol_error));
clear id_emp_old_index id_emp_new_index freq A_row_sums A_row_sums_inv tol_error

fprintf('\n  --> Compute PageRanks\n')
d = 1.00; % damping factor (typically set to 0.85 but set to 1.00 for our purposes)
pagerank = ones(N_id_emp, 1)/N_id_emp; % use uniform distribution as initial guess for PageRank vector
iter_max = 1.0*1e7; % maximum number of iterations
tol_conv = 1.0*1e-14; % convergence tolerance
update = 1; % initialize update
for iter = 1:iter_max % PageRank algorithm iteration
    pagerank_new = (1 - d)/N_id_emp + d*(A'*pagerank);
    update = max(abs(pagerank_new - pagerank));
    if update <= tol_conv
        fprintf('      ...successfully converged after %1.1e iterations with an update of %1.3e and a tolerance of %1.1e!\n', iter, update, tol_conv)
        break;
    end
    pagerank = pagerank_new;
end
if iter == iter_max && update > tol_conv
    fprintf('      ...failed to converge within %1.1e iterations with an update of %1.3e and a tolerance of %1.1e!\n', iter, update, tol_conv)
end
clear d iter_max tol_conv iter pagerank_new update A N_id_emp

fprintf('\n  --> Write results\n')
FILE_TEMP_OUTPUT = strrep(FILE_TEMP_OUTPUT, '.csv', ['_' num2str(gender) '.csv']);
writematrix([id_emp_unique pagerank], FILE_TEMP_OUTPUT, 'Delimiter', '\t');
clear id_emp_unique pagerank FILE_TEMP_OUTPUT gender


fprintf('\n==============================================================')
fprintf('\n FINAL HOUSEKEEPING')
fprintf('\n==============================================================')

fprintf('\n  --> Summarize objects stored in memory\n')
whos

fprintf('\n  --> Clear memory\n')
clear

fprintf('\n  --> End timer\n')
toc


fprintf('\n==============================================================')
fprintf('\n END OF MM_PAGERANKS.m')
fprintf('\n==============================================================')

fprintf('\n  --> End log file\n')
fprintf('\n\n\n\n\n\n\n\n\n\n\n\n')
diary close

fprintf('\n  --> Exit\n')
exit
********************************************************************************
* FILE NAME:   MM_11_SUM_STATS.do
*
* DESCRIPTION: Produces summary statistics by gender
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_11_SUM_STATS"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 12

* set random-number stream
clear rngstream
set rngstream 11

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** loop through all data or only connected set
foreach sel in ///
	"all" ///
	"selection" ///
	"connected" ///
	{
	di _newline(5)
	di "--> SEL = `sel'"
		
	*** loop through years
	local first_loop = 1
	local y_n = 0
	foreach y of numlist $year_min $year_max 0 { // `y' = $year_min, ..., $year_max: summary statistics for single year; `y' = 0: summary statistics for all years pooled
		di _newline(2)
		di "----> YEAR = `y'"
		
		* define variable list
		if `y' >= 1994 | (${year_min} >= 1994 & `y' == 0) local var_hours = "hours"
		else local var_hours = ""
		if `y' >= 2003 | (${year_min} >= 2003 & `y' == 0) local var_race = "race"
		else local var_race = ""
		local vars_list = "id_unique `var_race' nation age_est months_emp"
		
		* load data
		if inrange(`y', $year_min, $year_max) prog_load_data `y' `y' "`vars_list'"
		else if `y' == 0 prog_load_data $year_min $year_max "`vars_list'"
		keep `vars_list'
		
		* save temporary file
		save "${DIR_TEMP}/temp_sum_stats.dta", replace
		
		* load data again subject to the same selection criteria as used for AKM estimation
		if inrange(`y', $year_min, $year_max) prog_load_data `y' `y' "${vars_list} month_hire month_sep id_unique"
		else if `y' == 0 prog_load_data $year_min $year_max "${vars_list} month_hire month_sep id_unique"
		
		* merge in additional variables
		merge 1:1 id_unique ///
			using "${DIR_TEMP}/temp_sum_stats.dta" ///
			, ///
			keep(match) keepusing(id_unique `var_race' nation age_est months_emp) nogen
		
		* restrict to observations in selection or connected set
		if "`sel'" == "all" {
			di "   ...doing nothing."
		}
		else if "`sel'" == "selection" {
			merge 1:1 id_unique ///
				using "${DIR_TEMP}/selection_annual.dta" ///
				, ///
				keep(match) keepusing(id_unique) nogen
		}
		else if "`sel'" == "connected" {
			merge m:1 id_unique ///
				using "${DIR_TEMP}/connected_jobs_annual.dta" ///
				, ///
				keepusing(id_unique) keep(match) nogen
		}
		
		* merge in data on CPI and minimum wage
		cap confirm file "${FILE_CPI}"
		if _rc {
			* preserve data
			preserve
		
			* create indices
			import excel using "${FILE_CPI_RAW}", clear firstrow
			gen int year = real(substr(Data, 1, 4))
			label var year "Year"
			gen byte month = real(substr(Data, 6, 2))
			drop Data
			rename I* cpi
			order year month cpi
			sort year month
			keep if year < . & month < . & cpi < .

			* reshape to wide
			${gtools}reshape wide cpi, i(year) j(month)

			* drop if any month mising
			drop if inlist(., cpi1, cpi2, cpi3, cpi4, cpi5, cpi6, cpi7, cpi8, cpi9, cpi10, cpi11, cpi12)

			* drop early years
			drop if year < 1985

			* make 13^2 = 169 observations out of every year
			expand 169

			* create extra months for "stayed from last year" and "staying until next year"
			bys year: gen byte month_hire = floor((_n - 1)/13)
			bys year: gen byte month_sep = mod(_n - 1, 13)

			* create mean CPI by month of accession and separation
			sort year month_hire month_sep
			order year month_hire month_sep
			qui sum year
			local year_min = r(min)
			local year_max = r(max)
			local counter = 1
			forval yy = `year_min'/`year_max' {
				forval m1 = 0/12 {
					forval m2 = 0/12 {
						forval m = 1/12 {
							local m_min = max(`m1', 1)
							local m_max = mod(`m2' - 1, 12) + 1
							replace cpi`m' = . in `counter' if !inrange(`m', `m_min', `m_max')
						}
						local counter = `counter' + 1
					}
				}
			}
			drop if ((month_hire > month_sep) & !(month_sep == 0))
			egen double cpi = rowmean(cpi*)
			qui sum cpi if year == 2012 & month_hire == 12 & month_sep == 12
			replace cpi = cpi/r(mean)
			label var cpi "Consumer price index (December 2012 = 1.0)"
			drop cpi1-cpi12

			* save
			compress
			save "${FILE_CPI}", replace
			
			* restore data
			restore
		}
		qui merge m:1 year month_hire month_sep ///
			using "${FILE_CPI}" ///
			, ///
			keep(match master) keepusing(cpi) nogen
		cap confirm file "${FILE_MW}"
		if _rc {
			* preserve data
			preserve
			
			* read raw minimum-wage data
			import excel using "${FILE_MW_RAW}", clear firstrow
			gen int year = real(substr(Data, 1, 4))
			label var year "Year"
			gen byte month = real(substr(Data,- 2, 2))
			drop Data
			rename Sal* mw
			order year month mw
			sort year month
			keep if year < . & month < . & mw < .

			* reshape to wide
			${gtools}reshape wide mw, i(year) j(month)

			* drop if any month mising
			drop if inlist(., mw1, mw2, mw3, mw4, mw5, mw6, mw7, mw8, mw9, mw10, mw11, mw12)

			* make 13^2 = 169 observations out of every year
			expand 169

			* create extra months for "stayed from last year" and "staying until next year"
			bys year: gen byte month_hire = floor((_n - 1)/13)
			label var month_hire "Month job started"
			bys year: gen byte month_sep = mod(_n - 1, 13)
			label var month_sep "Month of separation"

			* create mean MW by month of accession and separation
			sort year month_hire month_sep
			order year month_hire month_sep
			qui sum year
			local year_min = r(min)
			local year_max = r(max)
			local counter = 1
			forval yy = `year_min'/`year_max' {
				forval m1 = 0/12 {
					forval m2 = 0/12 {
						forval m = 1/12 {
							local m_min = max(`m1', 1)
							local m_max = mod(`m2' - 1, 12) + 1
							replace mw`m' = . in `counter' if !inrange(`m', `m_min', `m_max')
						}
						local counter = `counter' + 1
					}
				}
			}
			drop if ((month_hire > month_sep) & !(month_sep == 0))
			egen double mw = rowmean(mw*)
			label var mw "Nominal minimum wage (current BRL)"
			drop mw1-mw12

			* save
			compress
			save "${FILE_MW}", replace
			
			* restore data
			restore
		}
		qui merge m:1 year month_hire month_sep ///
			using "${FILE_MW}" ///
			, ///
			keep(match master) keepusing(mw) nogen
		recast float mw cpi, force
		compress mw cpi
		drop month_hire month_sep
		
		* convert income variable from multiples of current minimum wage to real BRL
		rename earn_mean_mw earn
		replace earn = ln(earn*mw/cpi)
		label var earn "Log real monthly earnings"
		drop mw cpi
		
		* recode gender
		rename gender female
		label var female "Ind: female"
		recode female (1=0) (2=1) (nonmissing=.)
		label define fem_l 0 "0: Male" 1 "1: Female", replace
		label val female fem_l
		
		* compute share of nonwhites
		if `y' >= 2003 | (${year_min} >= 2003 & `y' == 0) {
			gen byte nonwhite = (race != 2) if race < .
			label var nonwhite "Ind: nonwhite"
			drop race
			local var_nonwhite = "nonwhite"
		}
		else local var_nonwhite = ""
		
		* compute share of nonnatives
		gen byte nonnative = (nation != 1) if nation < .
		label var nonnative "Ind: nonnative"
		drop nation
		
		* compute share of various education degrees
		recode edu (1 2 3=1) (4 5=2) (6 7=3) (8 9=4) (nonmissing=.), generate(edu_cat) // codes: 1 "Illiterate (0 years)" 2 "Some primary school (1-5 years)" 3 "Primary school degree (5 years)" 4 "Some middle school (6-9 years)" 5 "Middle school degree (9 years)" 6 "Some high school (10-12 years)" 7 "High school degree (12 years)" 8 "Some college (13-15 years)" 9 "Bachelor's or higher degree (16+ years)"
		label define edu_l 1 "Primary school" 2 "Middle school" 3 "High school" 4 "College", replace
		label val edu_cat edu_l
		tab edu_cat, gen(edu_)
		label var edu_1 "Ind: primary school"
		label var edu_2 "Ind: middle school"
		label var edu_3 "Ind: high school"
		label var edu_4 "Ind: college"
		drop edu_cat
		recode edu (1=0) (2=3) (3=5) (4=7) (5=9) (6=11) (7=12) (8=14) (9=16) (nonmissing=.), generate(edu_y)
		label var edu_y "Years of education"
		drop edu
		
		* age
		label var age "Age"
		
		* transform employer size
		bys id_est year: ${gtools}egen float size_emp = total(hours_year/(44*365/7))
		replace size_emp = max(1/12, size_emp)
		label var size_emp "Establishment size"
		
		* compute gender-specific employer size
		bys id_est female year: ${gtools}egen float size_emp_g = total(hours_year/(44*365/7))
		replace size_emp_g = max(1/12, size_emp_g)
		label var size_emp_g "Gender-establishment size"
		drop hours_year
		
		* employer age
		label var age_est "Establishment age"
		
		* months employed during year
		label var months_emp "Months employed during year"
		
		* contractual hours per week
		if `y' >= 1994 | (${year_min} >= 1994 & `y' == 0) label var hours "Contractual work hours"
		
		* tenure
		replace tenure = tenure/12
		label var tenure "Tenure (years)"
		
		* compute hourly wage
		if `y' >= 1994 | (${year_min} >= 1994 & `y' == 0) {
			gen float wage = earn - ln(hours)
			label var wage "Log real hourly wage"
			local var_wage = "wage"
			local var_wage_gap = "wage_gap"
		}
		else {
			local var_wage = ""
			local var_wage_gap = ""
		}
		
		* compute gender pay gap
		foreach pay of varlist ///
			earn ///
			`var_wage' ///
			{
			gen float `pay'_m = `pay' if female == 0
			gen float `pay'_f = `pay' if female == 1
			${gtools}egen float `pay'_m_mean = mean(`pay'_m)
			drop `pay'_m
			${gtools}egen float `pay'_f_mean = mean(`pay'_f)
			drop `pay'_f
			gen float `pay'_gap = `pay'_m_mean - `pay'_f_mean
			if "`pay'" == "earn" label var earn_gap "Log gender earnings gap"
			else if "`pay'" == "wage" label var wage_gap "Log gender wage gap"
			drop `pay'_m_mean `pay'_f_mean
		}
		
		* order
		order year id_est id_pers female `var_nonwhite' nonnative edu_1 edu_2 edu_3 edu_4 edu_y age size_emp size_emp_g age_est months_emp `var_hours' tenure earn `var_wage' earn_gap `var_wage_gap'
		
		* sort
		sort year id_est id_pers
		
		* describe and summarize
		desc
		sum, sep(0)
		
		* save data before collapsing
		save "${DIR_TEMP}/temp_sum_stats.dta", replace
		
		local first_subgroup = 1
		foreach subgroup in ///
			"overall" ///
			"by_gender" ///
			{
			di _newline(1)
			di "------> SUBGROUP = `subgroup'"
			
			* load data
			if !`first_subgroup' use "${DIR_TEMP}/temp_sum_stats.dta", replace
			
			* store variable labels
			foreach var of varlist * {
				local `var'_lab: variable label `var'
				local `var'_lab_lower = lower(substr("``var'_lab'", 1, 1)) + substr("``var'_lab'", 2, .)
			}
			
			* collapse
			if "`subgroup'" == "overall" gen byte subgroup = -1
			else if "`subgroup'" == "by_gender" clonevar subgroup = female
			label var subgroup "Subgroup"
			label define sgg_l -1 "Overall" 0 "Men" 1 "Women", replace
			label val subgroup sgg_l
			bys id_est: gen byte ind_emp_unique = 1 if _n == 1
			bys id_pers: gen byte ind_pers_unique = 1 if _n == 1
			drop id_pers id_est
			if `y' >= 1994 | (${year_min} >= 1994 & `y' == 0) {
				local var_hours_sd_collapse = "hours_sd=hours"
				local var_hours_sd = "hours_sd"
				local var_wage_sd_collapse = "wage_sd=wage"
				local var_wage_sd = "wage_sd"
			}
			else {
				local var_hours_sd_collapse = ""
				local var_hours_sd = ""
				local var_wage_sd_collapse = ""
				local var_wage_sd = ""
			}
			${gtools}collapse ///
				(firstnm) earn_gap `var_wage_gap' year ///
				(mean) female `var_nonwhite' nonnative edu_1 edu_2 edu_3 edu_4 edu_y age size_emp size_emp_g age_est months_emp `var_hours' tenure earn `var_wage' ///
				(sd) edu_y_sd=edu_y age_sd=age size_emp_sd=size_emp size_emp_g_sd=size_emp_g age_est_sd=age_est months_emp_sd=months_emp `var_hours_sd_collapse' tenure_sd=tenure earn_sd=earn `var_wage_sd_collapse' ///
				(count) N_worker_years=earn_gap N_workers_unique=ind_pers_unique N_employers_unique=ind_emp_unique ///
				, ///
				by(subgroup) fast
			
			* label year = 0 as "Pooled (${year_min}-${year_max})"
			if `y' == 0 replace year = 0 // if summary statistics are for all years pooled
			label define year_l 0 "Pooled (${year_min}-${year_max})", replace
			label val year year_l
			
			* apply variable labels
			foreach var of varlist * {
				if substr("``var'_lab'", 1, 4) == "Ind:" {
					local `var'_lab = substr("``var'_lab'", 6, .)
					label var `var' "Share ``var'_lab'"
				}
				else if substr("`var'", -3, 3) == "_sd" {
					local var_short = substr("`var'", 1, strlen("`var'") - 3)
					label var `var' "   (std. dev.)" // label var `var' "Std. dev. of ``var_short'_lab_lower'"
				}
				else if inlist("`var'", "year", "subgroup") label var `var' `"`=proper("`var'")'"'
				else if "`var'" == "N_worker_years" label var `var' "Number of worker-years"
				else if "`var'" == "N_workers_unique" label var `var' "Number of unique workers"
				else if "`var'" == "N_employers_unique" label var N_employers_unique "Number of unique establishments"
				else label var `var' "Mean ``var'_lab_lower'"
			}
			
			* order
			order year subgroup `var_nonwhite' nonnative edu_1 edu_2 edu_3 edu_4 edu_y edu_y_sd age age_sd size_emp size_emp_sd size_emp_g size_emp_g_sd age_est age_est_sd months_emp months_emp_sd `var_hours' `var_hours_sd' tenure tenure_sd earn earn_sd `var_wage' `var_wage_sd' N_worker_years N_workers_unique N_employers_unique female earn_gap `var_wage_gap'
			
			* sort
			sort year subgroup
			
			* append year-subgroup files
			if `first_loop' save "${DIR_TEMP}/temp_gender_append.dta", replace
			else {
				append using "${DIR_TEMP}/temp_gender_append.dta"
				save "${DIR_TEMP}/temp_gender_append.dta", replace
			}
			
			* update counters
			local first_loop = 0
			local first_subgroup = 0
		}
		
		* delete temporary file
		rm "${DIR_TEMP}/temp_sum_stats.dta"
		
		* keep subgroup files within a given year --> REMOVE?!
		keep if year == `y'
		
		* describe and summarize
		desc
		sum, sep(0)
		
		* save yearly summary stats
		save "${DIR_TEMP}/temp_gender_append_`y'.dta", replace

		* update counter
		local ++y_n
	}


	*** assemble and format (yearly and pooled) summary statistics
// 	foreach y of numlist $year_min $year_max 0 { // `y' = $year_min, ..., $year_max: summary statistics for single year; `y' = 0: summary statistics for all years pooled
	foreach y of numlist 0 { // `y' = $year_min, ..., $year_max: summary statistics for single year; `y' = 0: summary statistics for all years pooled
		* load data
		if `y' == 0 {
			use "${DIR_TEMP}/temp_gender_append.dta", clear
			rm "${DIR_TEMP}/temp_gender_append.dta"
		}
		else {
			use "${DIR_TEMP}/temp_gender_append_`y'.dta", clear
			rm "${DIR_TEMP}/temp_gender_append_`y'.dta"
		}

		* describe and summarize
		desc
		sum, sep(0)

		* format
		format year %4.0f
		format female `var_nonwhite' nonnative edu_1 edu_2 edu_3 edu_4 earn earn_sd `var_wage' `var_wage_sd' earn_gap `var_wage_gap' %4.3f
		format edu_y edu_y_sd age age_sd age_est age_est_sd months_emp months_emp_sd `var_hours' `var_hours_sd' tenure tenure_sd %3.1f
		format size_emp size_emp_sd size_emp_g size_emp_g_sd %5.0f
		format N_worker_years N_workers_unique N_employers_unique %9.0f

		* store variable labels
		foreach var of varlist * {
			local `var'_lab: variable label `var'
		}

		* transpose
		xpose, varname clear
		rename _varname var_name

		* generate variable containing label text
		gen str1 var_label = ""
		qui count
		local N = r(N)
		forval n = 1/`N' {
			local var_name_n = var_name[`n']
			replace var_label = "``var_name_n'_lab'" in `n'
		}

		* convert to string
		tostring *, format(%18.3f) replace force

		* format individual variables (rows)
		if `y' == 0 local var_n = 3*`y_n' // Note: `y_n' already contains code 0 (overall), so no need to set local var_n = 3*(`y_n' + 1).
		else local var_n = 3
		foreach var of varlist v1 - v`var_n' {
			replace `var' = substr(`var', 1, 4) if _n == 1 & real(substr(`var', 1, 4)) > 0
			replace `var' = substr(`var', 1, 1) if _n == 1 & real(substr(`var', 1, 4)) == 0
			replace `var' = "Overall" if substr(`var', 1, 3) == "-1." & _n == 2
			replace `var' = "Men" if substr(`var', 1, 3) == "0.0" & _n == 2
			replace `var' = "Women" if substr(`var', 1, 3) == "1.0" & _n == 2
			local var_year = `var'[1]
			local var_subgroup = `var'[2]
			forval n = 1/`N' {
				replace `var' = "" if _n == `n' & `var' == "."
				local var_name_n = var_name[`n']
				if inlist("`var_name_n'", "nonwhite", "nonnative", "edu_1", "edu_2", "edu_3", "edu_4", "earn", "earn_sd") | inlist("`var_name_n'", "wage", "wage_sd", "earn_gap", "wage_gap") di "no format change"
				else if inlist("`var_name_n'", "female", "earn_gap", "`var_wage_gap'") replace `var' = "" if _n == `n' & inlist(`var', "0.000", "1.000")
				else if inlist("`var_name_n'", "edu_y", "edu_y_sd", "age", "age_sd", "age_est", "age_est_sd", "months_emp", "months_emp_sd", "hours") | inlist("`var_name_n'", "hours_sd", "tenure", "tenure_sd") replace `var' = substr(`var', 1, strlen(`var') - 2) if _n == `n'
				else if inlist("`var_name_n'", "size_emp", "size_emp_sd", "size_emp_g", "size_emp_g_sd", "N_worker_years", "N_workers_unique", "N_employers_unique") replace `var' = substr(`var', 1, strlen(`var') - 4) if _n == `n'
				if `n' > 1 prog_comma_thousands `var' `n'
				if substr("`var_name_n'", -3, 3) == "_sd" & !(inlist("`var_name_n'", "hours_sd", "wage_sd") & ((`var_year' > 0 & `var_year' < 1994) | (`var_year' == 0 & ${year_max} < 1994))) {
					replace `var' = "(" + `var' + ")" if _n == `n'
				}
			}
			rename `var' `var_subgroup'`var_year'
		}
		drop var_name
		
		* rename variable names and year entry of pooled variables
		if `y' == 0 {
			foreach var of varlist *0 { // for the summary stats pertaining to the pooled sample
				if !inlist(substr("`var'", -2, 2), "90", "00", "10") { // make sure that this is actually the pooled sample (i.e., ending in "0") and not one of the yearly samples for a year ending in "0"
					replace `var' = "Pooled" if _n == 1
					local var_str = substr("`var'", 1, strlen("`var'") - 1) + "Pooled"
					rename `var' `var_str'
				}
			}
		}

		* order
		local var_order = ""
		foreach yy of numlist $year_min $year_max {
			cap confirm variable Overall`yy'
			if !_rc local var_order = "`var_order' Overall`yy' Men`yy' Women`yy'"
		}
		order var_label `var_order' OverallPooled MenPooled WomenPooled
		
		* save final dataset
		compress
		lab data "Summary statistics: `sel'."
		if `y' == 0 prog_comp_desc_sum_save "${DIR_TEMP}/sum_stats_`sel'.dta"
		else prog_comp_desc_sum_save "${DIR_TEMP}/sum_stats_`sel'_`y'.dta"
	}
}


*** combine summary statistics for all data and only connected set
* prepare datasets with summary statistics on all data and on connected set for merge
foreach file in ///
	"sum_stats_all" ///
	"sum_stats_selection" ///
	"sum_stats_connected" ///
	{
	use var_label OverallPooled MenPooled WomenPooled using "${DIR_TEMP}/`file'.dta", clear
	gen n = _n
	save "${DIR_TEMP}/temp_`file'.dta", replace
}

* load summary statistics for all data
use var_label n OverallPooled MenPooled WomenPooled using "${DIR_TEMP}/temp_sum_stats_all.dta", clear
foreach var of varlist OverallPooled MenPooled WomenPooled {
	rename `var' `var'_all
}

* merge in summary statistics for selection
merge 1:1 n ///
	using "${DIR_TEMP}/temp_sum_stats_selection.dta" ///
	, ///
	keepusing(OverallPooled MenPooled WomenPooled) keep(match) nogen
foreach var of varlist OverallPooled MenPooled WomenPooled {
	rename `var' `var'_selection
}

* merge in summary statistics for connected set
merge 1:1 n ///
	using "${DIR_TEMP}/temp_sum_stats_connected.dta" ///
	, ///
	keepusing(OverallPooled MenPooled WomenPooled) keep(match) nogen
foreach var of varlist OverallPooled MenPooled WomenPooled {
	rename `var' `var'_connected
}

* generate percentages for selection and connected set relative to all data
drop n
foreach var in OverallPooled MenPooled WomenPooled {
	gen `var'_selection_perc = ""
	gen `var'_connected_perc = ""
	local N = _N
	forval i = 1/`N' {
		local val_all = `var'_all[`i']
		local val_selection = `var'_selection[`i']
		local val_connected = `var'_connected[`i']
		foreach local in val_all val_selection val_connected {
			local `local' = subinstr("``local''", "(", "", .)
			local `local' = subinstr("``local''", ")", "", .)
			local `local' = subinstr("``local''", ",", "", .)
			local `local' = real("``local''")
		}
		local val_perc_selection: di %4.1f 100*`val_selection'/`val_all'
		local val_perc_connected: di %4.1f 100*`val_connected'/`val_selection'
		if `val_perc_selection' == . local val_perc_selection = ""
		else local val_perc_selection = string(`val_perc_selection') + "%"
		if !strpos("`val_perc_selection'", ".") local val_perc_selection = subinstr("`val_perc_selection'", "%", ".0%", .)
		if `val_perc_connected' == . local val_perc_connected = ""
		else local val_perc_connected = string(`val_perc_connected') + "%"
		if !strpos("`val_perc_connected'", ".") local val_perc_connected = subinstr("`val_perc_connected'", "%", ".0%", .)
		replace `var'_selection_perc = "`val_perc_selection'" if _n == `i'
		replace `var'_connected_perc = "`val_perc_connected'" if _n == `i'
	}
}

* fill year and subgroup for percentage variables
replace OverallPooled_selection_perc = "Pooled" if _n == 1
replace MenPooled_selection_perc = "Pooled" if _n == 1
replace WomenPooled_selection_perc = "Pooled" if _n == 1
replace OverallPooled_selection_perc = "Overall" if _n == 2
replace MenPooled_selection_perc = "Men" if _n == 2
replace WomenPooled_selection_perc = "Women" if _n == 2
replace OverallPooled_connected_perc = "Pooled" if _n == 1
replace MenPooled_connected_perc = "Pooled" if _n == 1
replace WomenPooled_connected_perc = "Pooled" if _n == 1
replace OverallPooled_connected_perc = "Overall" if _n == 2
replace MenPooled_connected_perc = "Men" if _n == 2
replace WomenPooled_connected_perc = "Women" if _n == 2

* insert indicator for sample selection
gen n1 = min(_n, 3)
gen n2 = _n
qui count
set obs `=r(N) + 1'
replace var_label = "Sample" if _n == _N
replace OverallPooled_all = "All" if _n == _N
replace MenPooled_all = "All" if _n == _N
replace WomenPooled_all = "All" if _n == _N
replace OverallPooled_selection = "Selection" if _n == _N
replace MenPooled_selection = "Selection" if _n == _N
replace WomenPooled_selection = "Selection" if _n == _N
replace OverallPooled_selection_perc = "% in Selection rel. to All" if _n == _N
replace MenPooled_selection_perc = "% in Selection rel. to All" if _n == _N
replace WomenPooled_selection_perc = "% in Selection rel. to All" if _n == _N
replace OverallPooled_connected = "Connected set" if _n == _N
replace MenPooled_connected = "Connected set" if _n == _N
replace WomenPooled_connected = "Connected set" if _n == _N
replace OverallPooled_connected_perc = "% in Connected set rel. to Selection" if _n == _N
replace MenPooled_connected_perc = "% in Connected set rel. to Selection" if _n == _N
replace WomenPooled_connected_perc = "% in Connected set rel. to Selection" if _n == _N
replace n1 = 2.5 if _n == _N
sort n1 n2
drop n1 n2

* save
preserve
foreach var of varlist * {
	if "`var'" != "var_label" & substr("`var'", -4, 4) != "_all" & substr("`var'", -10, 10) != "_selection" & substr("`var'", -15, 15) != "_selection_perc" {
		drop `var'
	}
}
lab data "Comparison of summary stats: selection vs. all."
prog_comp_desc_sum_save "${DIR_TEMP}/sum_stats_comparison_selection.dta"
restore
preserve
foreach var of varlist * {
	if "`var'" != "var_label" & substr("`var'", -10, 10) != "_selection" & substr("`var'", -10, 10) != "_connected" & substr("`var'", -15, 15) != "_connected_perc" {
		drop `var'
	}
}
lab data "Comparison of summary stats: connected set vs. selection."
prog_comp_desc_sum_save "${DIR_TEMP}/sum_stats_comparison_connected.dta"
restore


*** final housekeeping
* clean up
if $clean_up {
	rm "${DIR_TEMP}/temp_sum_stats_all.dta"
	rm "${DIR_TEMP}/temp_sum_stats_selection.dta"
	rm "${DIR_TEMP}/temp_sum_stats_connected.dta"
}

* turn timer off
timer off 12

* print final banner
di _newline(5)
timer list 12
local t = r(t12)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_11_SUM_STATS.do
********************************************************************************

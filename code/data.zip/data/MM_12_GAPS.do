********************************************************************************
* FILE NAME:   MM_12_GAPS.do
*
* DESCRIPTION: Estimates gender pay gaps within and between employers
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_12_GAPS"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 13

* set random-number stream
clear rngstream
set rngstream 12

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** within- and between-employer gender pay gaps
* load data
use ///
	id_emp w_* log_w_* g_* size* ///
	using "${DIR_TEMP}/post_est.dta", clear
	
* rename variables
rename size g

* create pay gap variable
gen double log_w_gap = log_w_m - log_w_f
lab var log_w_gap "Within-employer gender pay gap (M - F)"

* save data
order id_emp log_w_m log_w_f log_w_gap size_m size_f g_m g_f g
sort id_emp
lab data "Post-est results incl. within-employer gender pay gap."
prog_comp_desc_sum_save "${DIR_TEMP}/gaps.dta"


*** employer size-pay premium across employer sizes by gender
* load data
use "${DIR_TEMP}/gaps.dta", clear

* rename variables
rename g size

* generate log employer size
foreach g in m f {
	gen log_size_`g' = ln(size_`g')
	lab var log_size_`g' "Log employer size, `g'"
}
gen log_size = ln(size)
lab var log_size "Log employer size, m + f"

* generate gender-specific quantiles of log employer size
foreach g in m f {
	gquantiles log_size_`g'_q = log_size_`g' [aw=g_`g'], xtile n(${n_q_plot})
	lab var log_size_`g'_q "Quantiles of log employer size, `g'"
}

* compute gender-specific mean pay and mean log employer size by log employer size quantile
foreach g in m f {
	${gtools}egen log_w_`g'_mean = mean(log_w_`g') [aw=g_`g'], by(log_size_`g'_q)
	lab var log_w_`g'_mean "Mean log pay, `g'"
	${gtools}egen log_size_`g'_mean = mean(log_size_`g') [aw=g_`g'], by(log_size_`g'_q)
	lab var log_size_`g'_mean "Mean log employer size, `g'"
}

* convert to long
save "${DIR_TEMP}/temp_gaps.dta", replace
local first = 1
foreach g in m f {
	use "${DIR_TEMP}/temp_gaps.dta", clear
	if "`g'" == "m" gen byte gender = 1
	else if "`g'" == "f" gen byte gender = 2
	lab var gender "Gender"
	lab def gen_l 1 "1: Male" 2 "2: Female", replace
	lab val gender gen_l
	keep gender log_w_`g'_mean log_size_`g'_mean log_size_`g'_q
	rename log_w_`g'_mean log_w_mean
	rename log_size_`g'_mean log_size_mean
	rename log_size_`g'_q log_size_q
	bys log_size_q: keep if _n == 1
	drop log_size_q
	if !`first' append using "${DIR_TEMP}/temp_gaps_append.dta"
	order gender log_w_mean log_size_mean
	save "${DIR_TEMP}/temp_gaps_append.dta", replace
	local first = 0
}
use "${DIR_TEMP}/temp_gaps_append.dta", clear

* save data
save "${DIR_TEMP}/employer_size_pay_premium.dta", replace


*** plot gender-specific employment distributions
* load data
use ///
	size_* g ///
	using "${DIR_TEMP}/gaps.dta", clear

* rename variables
rename g size

* generate log employer size
foreach g in m f {
	gen log_size_`g' = ln(size_`g')
	lab var log_size_`g' "Log employer size, `g'"
}
gen log_size = ln(size)
lab var log_size "Log employer size, m + f"

* save data
save "${DIR_TEMP}/employment_distributions.dta", replace


*** plot female employment share against employer size
* load data
use ///
	size_* g ///
	using "${DIR_TEMP}/gaps.dta", clear

* rename variables
rename g size

* generate log employer size
foreach g in m f {
	gen log_size_`g' = ln(size_`g')
	lab var log_size_`g' "Log employer size, `g'"
}
gen log_size = ln(size)
lab var log_size "Log employer size, m + f"

* compute gender employment share
gen float share_f = size_f/size
lab var share_f "Share of female employees"

* generate gender-specific quantiles of log employer size
gquantiles log_size_q = log_size [aw=size], xtile n(${n_q_plot})
lab var log_size_q "Quantiles of log employer size"

* collapse
${gtools}collapse ///
	(mean) share_f_mean=share_f log_size_mean=log_size ///
	[aw=size] ///
	, ///
	by(log_size_q) fast
lab var share_f_mean "Mean female employment share"
lab var log_size_mean "Mean log employer size"

* keep only relevant variables
keep share_f_mean log_size_mean log_size_q

* save data
save "${DIR_TEMP}/female_employment.dta", replace


*** employer pay premia and employer amenities across employer sizes
* load data
use ///
	id_emp log_w_* size_* log_size_* size log_size ///
	using "${DIR_TEMP}/post_est.dta", clear

* generate gender-specific quantiles of log employer size
foreach g in m f {
	gquantiles log_size_`g'_q = log_size_`g' [aw=size_`g'], xtile n(${n_q_plot})
	lab var log_size_`g'_q "Quantiles of log employer size, `g'"
}

* saving in postfile
cap postclose postfile_reg_pay_size_r2
postfile postfile_reg_pay_size_r2 str1 gender str32 absorb r2 using "${DIR_TEMP}/postfile_reg_pay_size_r2.dta", replace

* regressions to get R^2
foreach g in m f {
	di _newline(5) "*** gender `g'"
	reghdfe log_w_`g', a(log_size_`g'_q)
	post postfile_reg_pay_size_r2 ("`g'") ("absorb") (e(r2))
}
postclose postfile_reg_pay_size_r2


* merge in employer covariates
local vars_merge = "part_time hours_change parental_dur inc_change acc_work sep_fired sep_death" // part_time hours_change parental_gen inc_change acc_work sep_fired sep_death
forval g = 1/2 {
	if `g' == 1 {
		local g_str = "m"
		local g_other_str = "f"
	}
	else if `g' == 2 {
		local g_str = "f"
		local g_other_str = "m"
	}
	preserve
	drop size_`g_other_str' log_size_`g_other_str' log_w_`g_other_str' log_size_`g_other_str'_q
	rename size_`g_str' size_g
	rename log_size_`g_str' log_size_g
	rename log_w_`g_str' log_w
	rename log_size_`g_str'_q log_size_g_q
	merge 1:1 id_emp using "${DIR_TEMP}/covariates_g`g'.dta", keep(match) keepusing(`vars_merge' ind07_5 muni) nogen
	compress
	desc
	save "${DIR_TEMP}/temp_workplace_chars_g`g'.dta", replace
	restore
}

* merge gender-specific files
clear
gen gender = .
forval g = 1/2 {
	append using "${DIR_TEMP}/temp_workplace_chars_g`g'.dta"
	replace gender = `g' if gender == .
}
desc

* generate parental leave generosity variables
cap replace parental_dur = ln(exp(parental_dur) + 1) if parental_dur < .
cap replace parental_dur = 0 if parental_dur == .
qui sum parental_dur [aw=size], d
gen byte parental_gen = (parental_dur > r(p50)) if parental_dur < .
lab var parental_gen "Ind: Parental leave more generous than the median?"
drop parental_dur

* update list of variables
local vars_merge = subinstr("`vars_merge'", "parental_dur", "parental_gen", .)

* saving in postfile (variables counter and var used in table creation, respectively id for the y-variable and x-variables of the corresponding regressions)
cap postclose postfile_reg_workplace
postfile postfile_reg_workplace counter str32 y var beta se N r2 mean_m mean_f using "${DIR_TEMP}/postfile_reg_workplace_chars.dta", replace
local counter = 1

* regress amenity proxies on female dummy, log employer size, and their interaction
di _newline(10)
local absorb_vars = "ind07_5 muni"
foreach var of varlist `vars_merge' {

	* saving means by gender
	sum `var' [aw=size_g] if gender == 1 
	local mean_m = `r(mean)'
	sum `var' [aw=size_g] if gender == 2
	local mean_f = `r(mean)'

	* regressions
	local reg_str = "reghdfe `var' ib1.gender##c.log_size [aw=size_g], a(`absorb_vars') keepsingletons noconstant ${cluster_option}"
	di _newline(3) "--> `reg_str':"
	`reg_str'
	
	* saving
	post postfile_reg_workplace (`counter') ("`var'") (1) (_b["2.gender"]) (_se["2.gender"]) (e(N)/2) (e(r2)) (`mean_m') (`mean_f')
 	post postfile_reg_workplace (`counter') ("`var'") (2) (_b["log_size"]) (_se["log_size"]) (e(N)/2) (e(r2)) (`mean_m') (`mean_f')
	post postfile_reg_workplace (`counter') ("`var'") (3) (_b["2.gender#c.log_size"]) (_se["2.gender#c.log_size"]) (e(N)/2) (e(r2)) (`mean_m') (`mean_f')
	
	local ++counter
}

postclose postfile_reg_workplace

* summarize means of amenity proxies
di _newline(10)
bys gender: sum `vars_merge' [aw=size_g]


*** parent shares
* open postfile
cap postclose post_parent_share
postfile post_parent_share ///
	N_parent ///
	N_nonparent ///
	using "${DIR_TEMP}/parent_share.dta", replace

* load data
prog_load_data $year_min $year_min "id_pers abs_reason_1 abs_reason_2 abs_reason_3"

* generate indicator for parental leave
gen byte parent = (abs_reason_1 == 5 | abs_reason_2 == 5 | abs_reason_3 == 5) if abs_reason_1 < . | abs_reason_2 < . | abs_reason_3 < .

* keep only observations for which parental status could be determined
keep if parent < .

* keep only one observation per person
bys id_pers (parent): keep if _n == _N

* tabulate parent and ever-parent status
count if parent == 1
local N_parent = r(N)
count if parent == 0
local N_nonparent = r(N)

* write to postfile
post post_parent_share ///
	(`N_parent') ///
	(`N_nonparent')

* close postfile
postclose post_parent_share

* format postfile
use "${DIR_TEMP}/parent_share.dta", clear
lab var N_parent "Number of parents"
lab var N_nonparent "Number of nonparents"
recast long N_parent N_nonparent, force
order N_parent N_nonparent
compress
save "${DIR_TEMP}/parent_share.dta", replace


*** compare actual vs. potential experience separately by gender
* load data
use ///
	gender age edu exp_act ///
	using "${DIR_TEMP}/akm.dta", clear

* generate years of education
recode edu ///
	(1 = 0) ///
	(2 = 3) ///
	(3 = 5) ///
	(4 = 8) ///
	(5 = 9) ///
	(6 = 11) ///
	(7 = 12) ///
	(8 = 14) ///
	(9 = 16) ///
	(nonmissing = .) ///
	, ///
	generate(edu_y) // codes: 1 "Illiterate (0 years)" 2 "Some primary school (1-5 years)" 3 "Primary school degree (5 years)" 4 "Some middle school (6-9 years)" 5 "Middle school degree (9 years)" 6 "Some high school (10-12 years)" 7 "High school degree (12 years)" 8 "Some college (13-15 years)" 9 "Bachelor's or higher degree (16+ years)"
lab var edu_y "Years of education"
drop edu

* create potential experience
gen byte exp_pot = max(age - edu_y - 6, 0)
lab var exp_pot "Potential experience (age - years of education - 6)"
drop edu_y

* replace actual experience
replace exp_act = min(exp_act, exp_pot)

* keep only plausible observations
keep if inrange(exp_pot, 0, 55)

* collapse years of actual experience into years of potential experience
${gtools}collapse ///
	(p5) exp_act_p5=exp_act ///
	(p10) exp_act_p10=exp_act ///
	(p25) exp_act_p25=exp_act ///
	(p50) exp_act_p50=exp_act ///
	(p75) exp_act_p75=exp_act ///
	(p90) exp_act_p90=exp_act ///
	(p95) exp_act_p95=exp_act ///
	, ///
	by(gender exp_pot) fast
foreach p in 5 10 25 50 75 90 95 {
	lab var exp_act_p`p' "P`p' of actual experience"
}

* save data
prog_comp_desc_sum_save "${DIR_TEMP}/exp_act_vs_exp_pot.dta"


*** final housekeeping
* clean up
if $clean_up {
	rm "${DIR_TEMP}/temp_gaps_append.dta"
	forval g = 1/2 {
		rm "${DIR_TEMP}/temp_workplace_chars_g`g'.dta"
	}
}

* turn timer off
timer off 13

* print final banner
di _newline(5)
timer list 13
local t = r(t13)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_12_GAPS.do
********************************************************************************

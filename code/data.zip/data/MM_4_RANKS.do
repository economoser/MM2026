********************************************************************************
* FILE NAME:   MM_4_RANKS.do
*
* DESCRIPTION: Computes firm-level revealed-preference indices and ranks
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_4_RANKS"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 5

* set random-number stream
clear rngstream
set rngstream 4

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** compute employer sizes in annual data, if requested
if $size_measure == 2 {
	
	* load data
	use ///
		year id_emp gender ///
		using "${DIR_TEMP}/selection_annual.dta", clear
	
	* generate one indicator per unique gender-employer year
	bys id_emp gender year: gen byte emp_year_unique = 1 if _n == 1
	lab var emp_year_unique "Ind: Unique employer-gender-year?"
	drop year
	
	* collapse to gender-employer level
	gen byte ones = 1
	lab var ones "Indicator = 1"
	${gtools}collapse ///
		(sum) n_emp_years=emp_year_unique ///
		(count) size=ones ///
		, ///
		by(id_emp gender) fast

	* compute average employment
	recast float size, force
	replace size = size/n_emp_years
	lab var size "Avg employer size, based on annual data"
	drop n_emp_years
	
	* save
	order id_emp gender size
	sort id_emp gender
	prog_comp_desc_sum_save "${DIR_TEMP}/size_annual.dta"
}


*** prepare data
* load monthly data
use "${DIR_TEMP}/selection_monthly.dta", clear

* keep only employers in the intersection of the annual and monthly connected sets
merge m:1 id_emp gender ///
	using "${DIR_TEMP}/connected_employers.dta" ///
	, ///
	keep(match) keepusing(id_emp gender) nogen

* identify start and end dates
sum date, meanonly
local date_min = r(min)
local date_max = r(max)

* set panel
xtset id_pers date

* mark hires from nonemployment (N) -- note: this count includes a small number of workers who cross the minimum age threshold while employed during the period.
gen byte NE = (L.id_emp == .) if date > `date_min'
lab var NE "Ind: Hire from N?"

* mark hires from employment (E) -- note: this count does not include a small number of workers who cross the minimum age threshold while employed during the period.
gen byte EE_in = (L.id_emp < . & L.id_emp != id_emp) if date > `date_min'
lab var EE_in "Ind: Hire from E?"

* mark separations into nonemployment (N) -- note: this count includes a small number of workers who cross the maximum age threshold while employed during the period.
gen byte EN = (F.id_emp == .) if date < `date_max'
lab var EN "Ind: Separation into N?"

* mark separations into employment (E) -- note: this count does not include a small number of workers who cross the maximum age threshold while employed during the period.
gen byte EE_out = (id_emp != F.id_emp & F.id_emp < .) if date < `date_max'
lab var EE_out "Ind: Separation into E?"

* mark months that each employer exists
bys id_emp gender date: gen byte emp_exists = 1 if _n == 1
lab var emp_exists "Ind: Employer exists in this month?"

* compute job flow counts and sizes at the employer-gender level
if _N < 2147483647 local gtools = "${gtools}"
else local gtools = ""
`gtools'collapse ///
	(sum) hires_NE=NE hires_EE=EE_in sep_EN=EN sep_EE=EE_out n_months=emp_exists ///
	(count) size=id_pers ///
	, ///
	by(id_emp gender) fast
lab var hires_NE "Number of hires from N"
lab var hires_EE "Number of hires from E"
lab var sep_EN "Number of separations into N"
lab var sep_EE "Number of separations into E"
lab var n_months "Number of months that an employer exists"
lab var size "Employer size (number of worker-dates)"

* make sure that all employers have a positive and nonmissing count of hires from nonemployment (N)
assert hires_NE > 0 & hires_NE < .

* normalize worker flows and employer size by the number of months that an employer exists
foreach var of varlist ///
	hires_NE ///
	hires_EE ///
	sep_EN ///
	sep_EE ///
	size ///
	{
	replace `var' = `var'/n_months
}
lab var hires_NE "Average number of hires from N"
lab var hires_EE "Average number of hires from E"
lab var sep_EN "Average number of separations into N"
lab var sep_EE "Average number of separations into E"
lab var size "Avg employer size, based on monthly data"
drop n_months

* compute total number of hires at the employer-gender level
${gtools}egen float hires = rowtotal(hires_NE hires_EE)
lab var hires "Total number of hires (from N or E)"

* compute total number of separations at the employer-gender level
${gtools}egen float sep = rowtotal(sep_EN sep_EE)
lab var sep "Total number of separations (into N or E)"


*** compute revealed-preference indices
* poaching index (Bagger & Lentz, 2019, REStud)
gen double poaching = hires_EE/hires
lab var poaching "Poaching index"
drop hires

* retention index
gen double retention = sep_EN/sep
lab var retention "Retention index"
drop sep_EN sep

* net poaching index (Haltiwanger & Hyatt & Kahn & McEntarfer, 2018, AEJ: Macro)
gen double net = (hires_EE - sep_EE)/size
lab var net "Net poaching index"
drop hires_EE sep_EE

* annual employer size
if $size_measure == 2 {
	drop size
	merge 1:1 id_emp gender ///
		using "${DIR_TEMP}/size_annual.dta" ///
		, ///
		keep(match) keepusing(size) nogen
}

* AKM gender-firm pay FE
merge 1:1 id_emp gender ///
	using "${DIR_TEMP}/akm_fe_emp.dta" ///
	, ///
	keep(match) keepusing(fe_emp) nogen

* save temporary file
save "${DIR_TEMP}/temp_ranks.dta", replace

	
*** compute PageRanks
* loop through genders
forval g = 1/2 {
	di "--> gender = `g'"
	
	* load data
	use ///
		id_pers date id_emp gender /// gender id_unique
		if gender == `g' ///
		using "${DIR_TEMP}/selection_monthly.dta", clear
	drop gender

	* set panel
	xtset id_pers date
	
	* fill panel
	if $pagerank_unemployed {
		tsfill, full
		replace id_emp = 0 if id_emp == . // note: id_emp = 0 represents nonemployment
	}
	
	* format variables
	rename id_emp id_emp_old
	lab var id_emp_old "Old employer ID"
	
	* find next month's employer ID
	gen long id_emp_new = F.id_emp_old
	lab var id_emp_new "New employer ID"
	drop date id_pers

	* keep only observations with both a current and next month's employer ID
	keep if id_emp_old < . & id_emp_new < .

	* count number of identical combinations of old employer ID x new employer ID
	gen byte one = 1
	collapse ///
		(count) freq=one ///
		, ///
		by(id_emp_old id_emp_new) fast
	lab var freq "Number of transitions"
	
	* export inputs for PageRank estimation
	order id_emp_old id_emp_new freq
	sort id_emp_old id_emp_new freq
	compress
	desc
	sum
	export delim ///
		id_emp_old id_emp_new freq ///
		using "${DIR_TEMP}/input_pagerank.csv" ///
		, ///
		delim(tab) novarnames nolab replace
	
	* export current gender (i.e., loop iteration number)
	clear
	set obs 1
	gen byte gender = `g'
	export delim ///
		gender ///
		using "${DIR_TEMP}/input_pagerank_gender.csv" ///
		, ///
		delim(tab) novarnames nolab replace
	
	* call MATLAB routine to compute PageRanks
	clear
	cap rm "${DIR_TEMP}/output_pagerank_`g'.csv"
	qui cd "${DIR_TEMP}" // set current directory so that MATLAB finds the right folder structure
	!${arch}"${APP_MATLAB}" -nodesktop -nojvm -nodisplay <"${DIR_DO_DATA}/MM_PAGERANKS.m"
	cap confirm file "${DIR_TEMP}/output_pagerank_`g'.csv"
	while _rc { // if file does not exist yet
		sleep 60000
		cap confirm file "${DIR_TEMP}/output_pagerank_`g'.csv"
	}
	qui cd // reset current directory
	rm "${DIR_TEMP}/input_pagerank.csv"
	
	* load estimated PageRanks
	import delim ///
		using "${DIR_TEMP}/output_pagerank_`g'.csv" ///
		, asdouble varnames(nonames) delim(tab) clear
	rm "${DIR_TEMP}/output_pagerank_`g'.csv"
	rename v1 id_emp
	lab var id_emp "Employer ID"
	rename v2 pagerank
	order id_emp pagerank
	lab var pagerank "PageRank"
	sort id_emp pagerank
	prog_comp_desc_sum_save "${DIR_TEMP}/output_pagerank_`g'.dta"
}

* append PageRanks for both genders
clear
gen byte gender = .
lab var gender "Gender"
forval g = 1/2 {
	append using "${DIR_TEMP}/output_pagerank_`g'.dta"
	rm "${DIR_TEMP}/output_pagerank_`g'.dta"
	replace gender = `g' if gender == .
}
lab def gen_l 1 "1: Male" 2 "2: Female", replace
lab val gender gen_l

* save results
order id_emp gender pagerank
sort id_emp gender pagerank
prog_comp_desc_sum_save "${DIR_TEMP}/pageranks.dta"


*** compute other employer-gender ranks
* load temporary data
use "${DIR_TEMP}/temp_ranks.dta", clear
rm "${DIR_TEMP}/temp_ranks.dta"

* merge in PageRanks
merge 1:1 id_emp gender ///
	using "${DIR_TEMP}/pageranks.dta" ///
	, ///
	keep(master match) keepusing(pagerank) nogen
	
* compute ranks based on indices
foreach var of varlist ///
	hires_NE ///
	poaching ///
	retention ///
	net ///
	size ///
	fe_emp ///
	pagerank ///
	{
	recast double `var', force
	local unique_ranks = 0
	local n_iter = 0
	while !`unique_ranks' & `n_iter' <= $n_iter_max {
		local ++n_iter
		bys `var': gen long N_values = _N
		if inlist("`var'", "hires_NE", "size") {
			gen double `var'_noisy = `var' + (runiform() - .5)/10^6
			replace `var' = -`var'_noisy if `var'_noisy < 0 & N_values > 1
			replace `var' = `var'_noisy if `var'_noisy >= 0 & N_values > 1
		}
		else if inlist("`var'", "poaching", "retention") {
			gen double `var'_noisy = `var' + (runiform() - .5)/10^6
			replace `var' = -`var'_noisy if `var'_noisy < 0 & N_values > 1
			replace `var' = `var'_noisy if `var'_noisy >= 0 & `var'_noisy <= 1 & N_values > 1
			replace `var' = 1 - (`var'_noisy - 1) if `var'_noisy > 1 & N_values > 1
		}
		else if inlist("`var'", "net", "fe_emp") {
			gen double `var'_noisy = `var' + (runiform() - .5)/10^6
			replace `var' = `var'_noisy if N_values > 1
		}
		else if inlist("`var'", "pagerank") {
			gen double `var'_noisy = `var' + (runiform() - .5)/10^12
			replace `var' = `var'_noisy if N_values > 1
		}
		else {
			di as error "USER ERROR: Could not find variable in list!"
			error 1
		}
		lab var `var'_noisy "Variable `var' with noise"
		drop `var'_noisy N_values
		bys `var': gen long N_values = _N
		sum N_values, meanonly
		local N_values_max = r(max)
		if `N_values_max' == 1 {
			local unique_ranks = 1
			di "--> in iteration `n_iter', all values of the variable `var' are unique"
		}
		else di "--> in iteration `n_iter', the variable `var' has at least `N_values_max' identical values"
		drop N_values
	}
	bys gender (`var'): gen rank_`var' = _n if `var' < .
	forval g = 1/2 {
		sum rank_`var' if gender == `g', meanonly
		replace rank_`var' = rank_`var'/r(max) if gender == `g'
	}
	local l: var lab `var'
	local l = subinstr("`l'", " index", "", .)
	local l = "`l' rank (1 = best)"
	lab var rank_`var' "`l'"
}

* save data
order id_emp gender hires_NE rank_hires_NE poaching rank_poaching retention rank_retention net rank_net size rank_size fe_emp rank_fe_emp pagerank rank_pagerank
sort id_emp gender
prog_comp_desc_sum_save "${DIR_TEMP}/ranks.dta"


*** final housekeeping
* clean up
if $clean_up {
	rm "${DIR_TEMP}/connected_employers.dta"
}

* turn timer off
timer off 5

* print final banner
di _newline(5)
timer list 5
local t = r(t5)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_4_RANKS.do
********************************************************************************

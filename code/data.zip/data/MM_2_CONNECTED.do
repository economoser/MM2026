********************************************************************************
* FILE NAME:   MM_2_CONNECTED.do
*
* DESCRIPTION: Finds employer IDs and job IDs in a connected set
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_2_CONNECTED"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 3

* set random-number stream
clear rngstream
set rngstream 2

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** create list of job IDs in annual connected set of employer IDs
* load data for annual connected set of employer IDs
use ///
	year id_pers id_emp gender ///
	using "${DIR_TEMP}/selection_annual.dta", clear // i.e., do not load id_unique

* call user-defined function to compute leave-one-out connected set
do "${DIR_DO_DATA}/MM_FUN_CONNECTED.do" 1 0 "year" "id_pers" "id_emp" "gender"

* keep only one observation per gender-employer ID combination
bys id_emp gender: keep if _n == 1

* save annual connected set of employer IDs
order id_emp gender
sort id_emp gender
prog_comp_desc_sum_save "${DIR_TEMP}/connected_employers_annual.dta"

* load data for list of job IDs incl. employer IDs -- Note: The variables id_emp gender id_unique are sufficient to uniquely identify employers and jobs in a yearly panel, since id_unique automatically identifies the year.
use ///
	id_emp gender id_unique ///
	using "${DIR_TEMP}/selection_annual.dta", clear

* trim down list of annual job IDs by removing employer IDs outside of gender-specific largest connected sets
merge m:1 id_emp gender ///
	using "${DIR_TEMP}/connected_employers_annual.dta" ///
	, ///
	keep(match) keepusing(id_emp gender) nogen

* keep only variables relevant for annual connected set of job IDs
drop id_emp gender // i.e., keep id_unique
sort id_unique

* save connected set of job IDs
prog_comp_desc_sum_save "${DIR_TEMP}/connected_jobs_annual.dta"


*** create list of job IDs in monthly connected set of employer IDs
* load data for monthly connected set of employer IDs
use ///
	date id_pers id_emp gender ///
	using "${DIR_TEMP}/selection_monthly.dta", clear // i.e., do not load id_unique

* call user-defined function to compute strongly connected set
do "${DIR_DO_DATA}/MM_FUN_CONNECTED.do" 0 1 "date" "id_pers" "id_emp" "gender"

* save monthly connected set of employer IDs
order id_emp gender
sort id_emp gender
prog_comp_desc_sum_save "${DIR_TEMP}/connected_employers_monthly.dta"


*** form intersection of annual and monthly connected sets
* employer IDs
use "${DIR_TEMP}/connected_employers_annual.dta", clear
merge m:1 id_emp gender ///
	using "${DIR_TEMP}/connected_employers_monthly.dta" ///
	, ///
	keep(match) keepusing(id_emp gender) nogen
order id_emp gender
sort id_emp gender
prog_comp_desc_sum_save "${DIR_TEMP}/connected_employers.dta"


*** final housekeeping
* turn timer off
timer off 3

* print final banner
di _newline(5)
timer list 3
local t = r(t3)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_2_CONNECTED.do
********************************************************************************

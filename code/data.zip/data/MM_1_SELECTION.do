********************************************************************************
* FILE NAME:   MM_1_SELECTION.do
*
* DESCRIPTION: Starts with raw data and imposes selection criteria
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_1_SELECTION"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 2

* set random-number stream
clear rngstream
set rngstream 1

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** load and clean data
* call user-defined function to load data
prog_load_data $year_min $year_max "${vars_list} month_hire month_sep id_unique" // i.e., "year id_pers gender edu age id_est ind07_5 muni hours hours_year occ02_6 tenure exp_act earn_mean_mw month_hire month_sep id_unique"

* rename variables
rename id_est id_emp
rename earn_mean_mw inc
cap rename ind07_5 ind
cap rename occ02_6 occ

* make sure all variables have nonmissing values
foreach var of varlist * {
	assert `var' < .
}

* save data
prog_comp_desc_sum_save "${DIR_TEMP}/load_${year_min}_${year_max}.dta"

* keep only relevant variables
foreach var in edu ind muni hours occ tenure exp_act {
	cap drop `var' // i.e., keep year id_pers id_emp gender age hours_year inc month_hire month_sep id_unique
}


*** impose selection criteria
* start while-loop
local N_changed = 1
local n_iter = 0
while `N_changed' {
	
	* update iteration number
	local ++n_iter
	
	* record initial number of observations
	local N_old = _N
	local N_old_disp: di %12.0fc `N_old'

	* keep only observations that are not singletons. AKM selection criterion -- for singletons, AKM worker and/or employer fixed effects are not well defined.
	if $drop_singletons {
		prog_count_before
		local singletons = 1
		while `singletons' {
			local N_before_singletons = _N
			bys id_emp gender: keep if _N > 1 // keep if (gender-specific) employer has more than one employee across years.
			bys id_pers: keep if _N > 1 // keep if worker appears more than once across years.
			local N_after_singletons = _N
			if `N_before_singletons' == `N_after_singletons' local singletons = 0
		}
		prog_count_after "dropping singletons"
	}

	* keep only employers with more than a minimum number of workers. AKM selection criterion -- assumption made by Sorkin (2018, QJE) is >= 15 employees/year on average.
	if $min_size_emp > 1 {
		prog_count_before
		if ($min_size_emp_nonsingletons & $min_size_emp_years == 3) di as error "USER WARNING: Nonsingleton and minimum employer size selections are such that all observations in year ${year_max} are dropped."
		if $min_size_emp_nonsingletons { // 
			bys id_pers (year): gen byte nonsingle = (id_pers[_n + 1] < .)
			lab var nonsingle "Ind: Not a singleton worker?"
			if inlist($min_size_emp_years, 0, 1, 2) {
				if "${gtools}" == "g" gegen double N_nonsingle = total(nonsingle), by(id_emp gender) // if minimum employer size should hold in data pooled across years ($min_size_emp_years = 0) OR if minimum employer size should hold on average in each year across pooled years ($min_size_emp_years = 1)
				else bys id_emp gender: egen double N_nonsingle = total(nonsingle) // if minimum employer size should hold in data pooled across years ($min_size_emp_years = 0) OR if minimum employer size should hold on average in each year across pooled years ($min_size_emp_years = 1)
			}
			else if $min_size_emp_years == 3 {
				if "${gtools}" == "g" gegen double N_nonsingle = total(nonsingle), by(id_emp gender year) // if minimum employer size should hold in each year
				else bys id_emp gender year: egen double N_nonsingle = total(nonsingle) // if minimum employer size should hold in each year
			}
			drop nonsingle
		}
		else {
			if inlist($min_size_emp_years, 0, 1, 2) bys id_emp gender: gen double N_nonsingle = _N
			else if $min_size_emp_years == 3 bys id_emp gender year: gen double N_nonsingle = _N
		}
		lab var N_nonsingle "Number of nonsingletons by employer-gender"
		if $min_size_emp_years == 0 keep if N_nonsingle >= ${min_size_emp}
		else if $min_size_emp_years == 1 keep if N_nonsingle >= ${min_size_emp}*(${year_max} - ${year_min} + 1)
		else if $min_size_emp_years == 2 {
			bys id_emp gender year: gen byte emp_year_unique = 1 if _n == 1
			lab var emp_year_unique "Ind: Unique employer-gender-year?"
			if "${gtools}" == "g" gegen byte n_emp_years = total(emp_year_unique), by(id_emp gender)
			else bys id_emp gender: egen byte n_emp_years = total(emp_year_unique)
			lab var n_emp_years "Total number of years that an employer exists"
			drop emp_year_unique
			keep if N_nonsingle >= ${min_size_emp}*n_emp_years
			drop n_emp_years
		}
		else if $min_size_emp_years == 3 keep if N_nonsingle >= ${min_size_emp}
		drop N_nonsingle
		prog_count_after "minimum number of workers"
	}

	* keep only employers that are in the data for more than a minimum number of years
	if $min_emp_years > 1 {
		prog_count_before
		if $min_emp_years > $year_max - $year_min + 1 {
			di as error "USER WARNING: Cannot impose minimum number of years that an employer exists because \$min_emp_years = $min_emp_years > `= $year_max - $year_min + 1' = \$year_max - \$year_min + 1. Impose \$min_emp_years = `= $year_max - $year_min + 1' = \$year_max - \$year_min + 1 instead."
			local min_emp_years = $year_max - $year_min + 1
		}
		else local min_emp_years = $min_emp_years
		bys id_emp gender year: gen byte emp_year_unique = 1 if _n == 1
		if "${gtools}" == "g" gegen byte n_emp_years = total(emp_year_unique), by(id_emp gender)
		else bys id_emp gender: egen byte n_emp_years = total(emp_year_unique)
		lab var n_emp_years "Total number of years that an employer exists"
		drop emp_year_unique
		keep if n_emp_years >= `min_emp_years'
		drop n_emp_years
		prog_count_after "minimum number of years that an employer exists"
	}
	
	* keep only dual-gender employers
	if $dual_gender {
		prog_count_before
		bys id_emp (gender): keep if gender[1] < gender[_N]
		prog_count_after "restriction to dual-gender employers"
	}

	* save temporary file
	order year id_pers id_emp gender age hours_year inc month_hire month_sep id_unique
	sort id_pers year
	if $n_batches > 1 prog_comp_desc_sum_save "${DIR_TEMP}/temp_selection.dta"

	* recast data from wide format to long format in batches
	forval b = 1/$n_batches {
		
		* load data
		if $n_batches > 1 {
			di as text "...data batch `b' out of ${n_batches}"
			use ///
				if mod(id_pers, $n_batches) == `b' - 1 ///
				using "${DIR_TEMP}/temp_selection.dta", clear
		}
		
		* check if data was loaded (e.g., this may not be the case when working with a set of worker IDs that do not match the modulo requirement above)
		if _N == 0 {
			di as error "USER WARNING: Data batch `b' out of ${n_batches} is empty."
			continue
		}
		
		* construct earnings in each month the job is active
		recode month_sep (0 = 13)
		local months_list = "January February March April May June July August September October November December"
		forval m = 1/12 {
			gen float inc`m' = inc if inrange(`m', month_hire, month_sep)
			local m_str: word `m' of `months_list'
			lab var inc`m' "Earnings in `m_str' (multiples of MW)"
		}
		compress inc*
		drop inc
		
		* reshape data from wide to long format
		if _N < 2147483647/12 local gtools = "${gtools}"
		else local gtools = ""
		`gtools'reshape long inc, i(id_unique) j(month) // Note: The gtools package is subject to a maximum dataset size since "A Stata bug prevents gtools from working with more than 2,147,483,647 observations."
		lab var inc "Earnings (multiples of MW)"
		lab var month "Month"
		compress
		
		* drop observations when individual was not employed
		prog_count_before
		keep if hours_year < . & inc < .
		prog_count_after "dropping months without earnings"
		
		* create date variable as year-month
		gen int date = ym(year, month)
		lab var date "Date (year-month)"
		drop year month
		format date %tm
		compress date

		* keep only a random tiebreaker among all highest-paid jobs among all longest jobs per worker-date
		prog_count_before
		gen double rand = runiform()
		bys id_pers date (hours_year inc rand): keep if _n == _N // Note: use random noise with fixed initial seed in order for this to yield a deterministic outcome.
		drop rand // i.e., keep date id_pers id_emp gender age hours_year inc id_unique
		prog_count_after "selecting only one job per worker-date"
		
		* save data batch
		order date id_pers id_emp gender age hours_year inc id_unique
		if $n_batches > 1 prog_comp_desc_sum_save "${DIR_TEMP}/temp_selection_batch_`b'.dta"
	}
	
	* append data batches and remove temporary files
	if $n_batches > 1 {
		clear
		forval b = 1/$n_batches {
			cap confirm file "${DIR_TEMP}/temp_selection_batch_`b'.dta"
			if !_rc {
				append using "${DIR_TEMP}/temp_selection_batch_`b'.dta"
				rm "${DIR_TEMP}/temp_selection_batch_`b'.dta"
			}
		}
		rm "${DIR_TEMP}/temp_selection.dta"
	}
	if _N == 0 {
		di as error "USER ERROR: No observations in memory after loading all data batches."
		error 1
	}
		
	* make additional selections based on hiring and separation requirements
	if ($min_hire_NE | $min_hire_tot | $min_sep_EN | $min_sep_tot) {
		
		* find earliest date that each worker appears in data
		if _N < 2147483647 local gtools = "${gtools}"
		else local gtools = ""
		
		* identify start and end dates
		sum date, meanonly
		local date_min = r(min)
		local date_max = r(max)
		
		* set panel
		xtset id_pers date
		
		* create indicator for new hires from nonemployment
		if $min_hire_NE {
			gen byte NE = (L.id_emp == .) if date > `date_min'
			lab var NE "Ind: Hire from nonemployment?"
		}

		* create indicator for new hires
		if $min_hire_tot {
			gen byte hire = (L.id_emp != id_emp) if date > `date_min'
			lab var hire "Ind: Hire?"
		}
		
		* create indicator for separations into nonemployment
		if $min_sep_EN {
			gen byte EN = (F.id_emp == .) if date < `date_max'
			lab var EN "Ind: Separation into nonemployment?"
		}
		
		* create indicator for separation
		if $min_sep_tot {
			gen byte sep = (id_emp != F.id_emp) if date < `date_max'
			lab var sep "Ind: Separation?"
		}
		
		* keep only employers with a minimum number of worker hires from nonemployment. Labor market parameter estimation selection criterion -- guarantees that employer has strictly positive sampling rate when estimating job offer cdf F(.) and pdf f(.). Note: Sorkin (2018, QJE) assumes >= 1.
		if $min_hire_NE {
			prog_count_before
			if _N < 2147483647 local gtools = "${gtools}"
			else local gtools = ""
			if "`gtools'" == "g" gegen double NE_tot = total(NE), by(id_emp gender) // Note: The gtools package is subject to a maximum dataset size since "A Stata bug prevents gtools from working with more than 2,147,483,647 observations."
			else bys id_emp gender: egen double NE_tot = total(NE)
			local min_hire_NE = ${min_hire_NE}
			keep if NE_tot >= `min_hire_NE'
			drop NE NE_tot
			prog_count_after "minimum number of hires from nonemployment"
		}

		* keep only employers with a minimum total number of worker hires. Poaching Rank estimation selection criterion -- contributes to poaching rank being measured without too much noise. Note: Bagger and Lentz (2019, REStud) assume >= 15.
		if $min_hire_tot & ($min_hire_tot > $min_hire_NE) {
			prog_count_before
			if _N < 2147483647 local gtools = "${gtools}"
			else local gtools = ""
			if "`gtools'" == "g" gegen double hire_tot = total(hire), by(id_emp gender) // Note: The gtools package is subject to a maximum dataset size since "A Stata bug prevents gtools from working with more than 2,147,483,647 observations."
			else bys id_emp gender: egen double hire_tot = total(hire)
			local min_hire_tot = ${min_hire_tot}
			keep if hire_tot >= `min_hire_tot'
			drop hire hire_tot
			prog_count_after "minimum number of total hires (from nonemployment or employment)"
		}
		
		* keep only employers with a minimum number of worker separations into nonemployment
		if $min_sep_EN {
			prog_count_before
			if _N < 2147483647 local gtools = "${gtools}"
			else local gtools = ""
			if "`gtools'" == "g" gegen double EN_tot = total(EN), by(id_emp gender) // Note: The gtools package is subject to a maximum dataset size since "A Stata bug prevents gtools from working with more than 2,147,483,647 observations."
			else bys id_emp gender: egen double EN_tot = total(EN)
			local min_sep_EN = ${min_sep_EN}
			keep if EN_tot >= `min_sep_EN'
			drop EN EN_tot
			prog_count_after "minimum number of separations into nonemployment"
		}
		
		* keep only employers with a minimum total number of worker separations
		if $min_sep_tot & ($min_sep_tot > $min_sep_EN) {
			prog_count_before
			if _N < 2147483647 local gtools = "${gtools}"
			else local gtools = ""
			if "`gtools'" == "g" gegen double sep_tot = total(sep), by(id_emp gender) // Note: The gtools package is subject to a maximum dataset size since "A Stata bug prevents gtools from working with more than 2,147,483,647 observations."
			else bys id_emp gender: egen double sep_tot = total(sep)
			local min_sep_tot = ${min_sep_tot}
			keep if sep_tot >= `min_sep_tot'
			drop sep sep_tot
			prog_count_after "minimum number of total separations (into nonemployment or employment)"
		}
	}

	* save temporary file
	order date id_pers id_emp gender hours_year inc id_unique age month_hire month_sep
	sort id_pers date
	prog_comp_desc_sum_save "${DIR_TEMP}/temp_selection.dta"
	
	* save monthly data
	keep date id_pers id_emp gender id_unique
	order date id_pers id_emp gender id_unique
	sort id_pers date
	prog_comp_desc_sum_save "${DIR_TEMP}/selection_monthly.dta" // estimate employer ranks (e.g., PageRanks) based on this dataset

	* keep only a random tiebreaker among all highest-paid jobs among all longest jobs per worker-year
	use ///
		date id_pers id_emp gender hours_year inc id_unique age month_hire month_sep ///
		using "${DIR_TEMP}/temp_selection.dta", clear
	prog_count_before
	gen int year = year(dofm(date))
	lab var year "Year"
	drop date
	gen double rand = runiform()
	bys id_pers year (hours_year inc rand): keep if _n == _N
	drop rand
	prog_count_after "selecting only one job per worker-year"
	
	* save annual data
	preserve
	drop age hours_year inc month_hire month_sep
	order year id_pers id_emp gender id_unique
	sort id_pers year
	prog_comp_desc_sum_save "${DIR_TEMP}/selection_annual.dta" // estimate AKM model based on this dataset
	restore
	
	* decide whether to continue the while-loop
	local N_new = _N
	local N_new_disp: di %12.0fc `N_new'
	local N_diff = `N_new' - `N_old'
	local N_diff_disp: di %12.0fc `N_diff'
	if $selection_iter local N_changed = (`N_diff' != 0)
	else local N_changed = 0
	di _newline(3) "  --> in iteration `n_iter', number of observations changed by `N_diff_disp' from `N_old_disp' to `N_new_disp'"
	
	* clean up
	rm "${DIR_TEMP}/temp_selection.dta"
}


*** final housekeeping
* turn timer off
timer off 2

* print final banner
di _newline(5)
timer list 2
local t = r(t2)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_1_SELECTION.do
********************************************************************************

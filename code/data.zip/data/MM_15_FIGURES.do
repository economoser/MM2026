********************************************************************************
* FILE NAME:   MM_15_FIGURES.do
*
* DESCRIPTION: Produces figures to be included in the paper
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_15_FIGURES"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 16

* set random-number stream
clear rngstream
set rngstream 15

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** switches for which figures to produce
global fig_gaps 					= 1 	// employer-gender pay gaps
global fig_akm 						= 1 	// AKM estimation results
global fig_kdens_ranks 				= 1 	// employment distribution over employer ranks
global fig_recruiting_dens 			= 1 	// density estimates of recruiting intensity by gender
global fig_prod 					= 1 	// density estimates of productivity by gender
global fig_gender_wedge 			= 1 	// density estimates of gender wedge by gender
global fig_amenity_cost_shifters 	= 1 	// density estimates of amenity cost shifters by gender
global fig_dist_pay_amenities 		= 1		// distributions of pay and amenities
global fig_ind_ranks 				= 1 	// ranks by industry
global fig_amenity_shares 			= 1 	// distribution of amenity shares
global fig_amenity_shares_ranks 	= 1		// gender-specific amenity shares across employer ranks
global fig_prod_ranks 				= 1		// productivity across employer ranks
global fig_prod_net_of_wedge 		= 1		// productivity vs. productivity net of wedge
global fig_pay_size 				= 1 	// employer size-pay premium across employer sizes by gender
global fig_emp_distributions 		= 1 	// gender-specific employment distributions
global fig_female_emp 				= 1		// female employment share against employer size
global fig_compensation_components 	= 1  	// gender-specific compensation components across employer ranks
global fig_exp_act_vs_exp_pot 		= 1 	// actual vs. potential experience
global fig_women_to_men 			= 1 	// moving women into men's employers
global fig_men_to_women 			= 1 	// moving men into women's employers
global fig_amenities_wedges 		= 1 	// amenities and gender wedges


*** graph settings
* line colors
global lc1 = "blue"
global lc2 = "red"
global lc3 = "green"
global lc4 = "orange"
global lc5 = "gs10"
global lc6 = "cyan"
global lc7 = "pink"
global lc8 = "lime"
global lc9 = "gold"
global lc_comb = "purple"
global lc_d = "black"
global lc_v = "gs6"
global lc_h = "gs6"

* line patterns
global lp1 = "solid"
global lp2 = "longdash"
global lp3 = "dash"
global lp4 = "shortdash"
global lp5 = "dot"
global lp6 = "longdash_dot"
global lp7 = "dash_dot"
global lp8 = "shortdash_dot"
global lp9 = "_--"
global lp_comb = "${lp3}"
global lp_d = "${lp1}"

* line width
global lw = "thick"

* marker colors
global mc1 = "${lc1}"
global mc2 = "${lc2}"
global mc3 = "${lc3}"
global mc4 = "${lc4}"
global mc5 = "${lc5}"
global mc6 = "${lc6}"
global mc7 = "${lc7}"
global mc8 = "${lc8}"
global mc9 = "${lc9}"

* marker symbols
global ms1 = "O"
global ms2 = "D"
global ms3 = "T"
global ms4 = "S"
global ms5 = "X"
global ms6 = "Oh"
global ms7 = "Dh"
global ms8 = "Th"
global ms9 = "Sh"

* grid pattern
global gs = "dot"

* length of legend lines
global symxsize = "*0.66"
global symxsize_short = "*0.50"

* number of legend columns
global n_cols = 1

* whether to export figures?
global graph_export = 1 // 0 = do not export figures; 1 = export figures


*** employer-gender pay gaps
if $fig_gaps {
	
	* load data
	use "${DIR_TEMP}/gaps.dta", clear
	
	* gender-specific employer FE densities, baseline
	sum log_w_m [aw=g_m], meanonly
	local mean_m_m = r(mean)
	sum log_w_f [aw=g_f], meanonly
	local mean_f_f = r(mean)
	tw ///
		(kdensity log_w_m [aw=g_m] if inrange(log_w_m, -1, 1), lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_m_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_w_f [aw=g_f] if inrange(log_w_f, -1, 1), lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_f_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.5)3, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific AKM employer FE") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women" 3 "") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(fig_densities_baseline, replace)
	graph export "${DIR_RES_FIG}/fig_densities_baseline.eps", replace

	* gender-specific employer FE densities, alternative 1: fixing pay for men at each firm
	sum log_w_m [aw=g_f], meanonly
	local mean_m_f = r(mean)
	tw ///
		(kdensity log_w_m [aw=g_m] if inrange(log_w_m, -1, 1), lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_m_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_w_m [aw=g_f] if inrange(log_w_m, -1, 1), lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_m_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.5)3, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific AKM employer FE") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women" 3 "") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(fig_densities_alt_1, replace)
	graph export "${DIR_RES_FIG}/fig_appendix_densities_alt_1.eps", replace

	* gender-specific employer FE densities, alternative 2: fixing pay for women at each firm
	sum log_w_f [aw=g_m], meanonly
	local mean_f_m = r(mean)
	tw ///
		(kdensity log_w_f [aw=g_m] if inrange(log_w_f, -1, 1), lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_f_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_w_f [aw=g_f] if inrange(log_w_f, -1, 1), lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_f_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.5)3, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific AKM employer FE") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women" 3 "") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(fig_densities_alt_2, replace)
	graph export "${DIR_RES_FIG}/fig_appendix_densities_alt_2.eps", replace

	* distribution of within-firm pay gaps, baseline
	sum log_w_gap [aw=g], meanonly
	local mean_all = r(mean)
	tw ///
		(kdensity log_w_gap [aw=g], lcolor(${lc_comb}) lpattern(${lp_comb}) lwidth(${lw}) xline(`mean_all', lcolor(${lc_v}) lpattern(${lp3}) lwidth(${lw}))) ///
		if inrange(log_w_gap, -.5, .5), ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(1)5, format(%1.0f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Within-employer gap in AKM employer FEs (men - women)") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(off) ///
		name(fig_within_baseline, replace)
	graph export "${DIR_RES_FIG}/fig_within_baseline.eps", replace

	* distribution of within-firm pay gaps, alternative 1: using only men's distribution
	sum log_w_gap [aw=g_m], meanonly
	local mean_m = r(mean)
	tw ///
		(kdensity log_w_gap [aw=g_m], lcolor(${lc_comb}) lpattern(${lp_comb}) lwidth(${lw}) xline(`mean_m', lcolor(${lc_v}) lpattern(${lp3}) lwidth(${lw}))) ///
		if inrange(log_w_gap, -.5, .5), ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(1)5, format(%1.0f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Within-employer gap in AKM employer FEs (men - women)") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(off) ///
		name(fig_within_alt_1, replace)
	graph export "${DIR_RES_FIG}/fig_appendix_within_alt_1.eps", replace

	* distribution of within-firm pay gaps, alternative 2: using only women's distribution
	sum log_w_gap [aw=g_f], meanonly
	local mean_f = r(mean)
	tw ///
		(kdensity log_w_gap [aw=g_m], lcolor(${lc_comb}) lpattern(${lp_comb}) lwidth(${lw}) xline(`mean_f', lcolor(${lc_v}) lpattern(${lp3}) lwidth(${lw}))) ///
		if inrange(log_w_gap, -.5, .5), ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(1)5, format(%1.0f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Within-employer gap in AKM employer FEs (men - women)") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(off) ///
		name(fig_within_alt_2, replace)
	graph export "${DIR_RES_FIG}/fig_appendix_within_alt_2.eps", replace
	
}


*** AKM estimation results
if $fig_akm {

	* AKM hour FEs by gender
	if $akm_hours {
		use "${DIR_TEMP}/akm_xb_hours.dta", clear
		tw ///
			(connected xb_hours hours if gender == 1, mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
			(connected xb_hours hours if gender == 2, mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp2})) ///
			if inrange(hours, 1, 44) ///
			, ///
			xlabel(0(4)44, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(-.4(.1).2, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
			name(fig_akm_hours, replace)
		graph export "${DIR_RES_FIG}/fig_appendix_akm_hours.eps", replace
	}

	* AKM occupation FEs by gender
	if $akm_occ {
		use "${DIR_TEMP}/akm_xb_occ.dta", clear
		bys occ: drop if _N < 2 // Note: a small number of occupations are held only by men or only by women.
		${gtools}egen occ_rank_m = rank(xb_occ) if gender == 1
		if "${gtools}" == "g" gquantiles occ_rank_m_bin = occ_rank_m, xtile n(100)
		else xtile occ_rank_m_bin = occ_rank_m, n(100)
		sum occ_rank_m_bin, meanonly
		replace occ_rank_m_bin = (occ_rank_m_bin - `=r(min)')/(`=r(max)' - `=r(min)')
		bys occ (occ_rank_m_bin): replace occ_rank_m_bin = occ_rank_m_bin[1]
		${gtools}collapse ///
			(mean) xb_occ ///
			, ///
			by(gender occ_rank_m_bin) fast
		tw ///
			(connected xb_occ occ_rank_m_bin if gender == 1, sort mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
			(connected xb_occ occ_rank_m_bin if gender == 2, sort mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp2})) ///
			if occ_rank_m_bin >= 0 & occ_rank_m_bin <= 1, ///
			xlabel(0(.1)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(-.3(.1).7, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
			xtitle("Percentiles of AKM occupation FE for men") ytitle("Mean AKM occupation FE") ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
			name(fig_akm_occ, replace)
		graph export "${DIR_RES_FIG}/fig_appendix_akm_occ.eps", replace
	}

	* AKM actual-experience FEs by gender
	if $akm_exp_act {
		use "${DIR_TEMP}/akm_xb_exp_act.dta", clear
		tw ///
			(connected xb_exp_act exp_act if gender == 1, sort mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
			(connected xb_exp_act exp_act if gender == 2, sort mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp1})) ///
			if inrange(exp_act, 1, 39) ///
			, ///
			xlabel(0(4)40, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.1).7, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
			name(fig_akm_exp_act, replace)
		graph export "${DIR_RES_FIG}/fig_appendix_akm_exp_act.eps", replace
	}

	* AKM tenure FEs by gender
	if $akm_tenure {
		use "${DIR_TEMP}/akm_xb_tenure.dta", clear
		tw ///
			(connected xb_tenure tenure if gender == 1, mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
			(connected xb_tenure tenure if gender == 2, mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp2})) ///
			if inrange(tenure, 1, 39) ///
			, ///
			xlabel(0(4)40, format(%4.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.1).5, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
			name(fig_akm_xb_tenure, replace)
		graph export "${DIR_RES_FIG}/fig_appendix_akm_xb_tenure.eps", replace
	}

	* AKM year FEs by gender
	if $akm_years {
		use "${DIR_TEMP}/akm_xb_year.dta", clear
		tw ///
			(connected xb_year year if gender == 1 & edu == 1, mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 1 & edu == 2, mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 1 & edu == 3, mcolor(${mc3}) lcolor(${lc3}) msymbol(${ms3}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 1 & edu == 4, mcolor(${mc4}) lcolor(${lc4}) msymbol(${ms4}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 1 & edu == 5, mcolor(${mc5}) lcolor(${lc5}) msymbol(${ms5}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 1 & edu == 6, mcolor(${mc6}) lcolor(${lc6}) msymbol(${ms6}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 1 & edu == 7, mcolor(${mc7}) lcolor(${lc7}) msymbol(${ms7}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 1 & edu == 8, mcolor(${mc8}) lcolor(${lc8}) msymbol(${ms8}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 1 & edu == 9, mcolor(${mc9}) lcolor(${lc9}) msymbol(${ms9}) lpattern(${lp1})) ///
			if inrange(year, ${year_min}, ${year_max}) ///
			, ///
			xlabel(2007(1)2014, format(%4.0f) gmin gmax grid gstyle(${gs})) ylabel(-.15(.03)0, format(%3.2f) gmin gmax grid gstyle(${gs})) ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "0 years" 2 "<5 years" 3 "5 years" 4 "<9 years" 5 "9 years" 6 "<12 years" 7 "12 years" 8 "13-15 years" 9 ">=16 years") symxsize(${symxsize}) region(color(none)) cols(3) ring(0) pos(7)) ///
			name(fig_akm_xb_year_m, replace)
		graph export "${DIR_RES_FIG}/fig_appendix_akm_xb_year_m.eps", replace
		tw ///
			(connected xb_year year if gender == 2 & edu == 1, mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 2 & edu == 2, mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 2 & edu == 3, mcolor(${mc3}) lcolor(green) msymbol(${ms3}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 2 & edu == 4, mcolor(${mc4}) lcolor(orange) msymbol(${ms4}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 2 & edu == 5, mcolor(${mc5}) lcolor(gs13) msymbol(${ms5}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 2 & edu == 6, mcolor(${mc6}) lcolor(cyan) msymbol(${ms6}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 2 & edu == 7, mcolor(${mc7}) lcolor(pink) msymbol(${ms7}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 2 & edu == 8, mcolor(${mc8}) lcolor(lime) msymbol(${ms8}) lpattern(${lp1})) ///
			(connected xb_year year if gender == 2 & edu == 9, mcolor(${mc9}) lcolor(gold) msymbol(${ms9}) lpattern(${lp1})) ///
			if inrange(year, ${year_min}, ${year_max}) ///
			, ///
			xlabel(2007(1)2014, format(%4.0f) gmin gmax grid gstyle(${gs})) ylabel(-.15(.03)0, format(%3.2f) gmin gmax grid gstyle(${gs})) ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "0 years" 2 "<5 years" 3 "5 years" 4 "<9 years" 5 "9 years" 6 "<12 years" 7 "12 years" 8 "13-15 years" 9 ">=16 years") symxsize(${symxsize}) region(color(none)) cols(3) ring(0) pos(7)) ///
			name(fig_akm_xb_year_f, replace)
		graph export "${DIR_RES_FIG}/fig_appendix_akm_xb_year_f.eps", replace
	}

	* AKM age FEs by gender
	if $akm_age_poly_order == 1 {
		use "${DIR_TEMP}/akm_xb_age.dta", clear
		tw ///
			(connected xb_age age if gender == 1 & edu == 1, mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 1 & edu == 2, mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 1 & edu == 3, mcolor(${mc3}) lcolor(${lc3}) msymbol(${ms3}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 1 & edu == 4, mcolor(${mc4}) lcolor(${lc4}) msymbol(${ms4}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 1 & edu == 5, mcolor(${mc5}) lcolor(${lc5}) msymbol(${ms5}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 1 & edu == 6, mcolor(${mc6}) lcolor(${lc6}) msymbol(${ms6}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 1 & edu == 7, mcolor(${mc7}) lcolor(${lc7}) msymbol(${ms7}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 1 & edu == 8, mcolor(${mc8}) lcolor(${lc8}) msymbol(${ms8}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 1 & edu == 9, mcolor(${mc9}) lcolor(${lc9}) msymbol(${ms9}) lpattern(${lp1})) ///
			if inrange(age, ${age_min}, ${age_max}) ///
			, ///
			xlabel(18(4)54, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.2)1.4, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "0 years" 2 "<5 years" 3 "5 years" 4 "<9 years" 5 "9 years" 6 "<12 years" 7 "12 years" 8 "13-15 years" 9 ">=16 years") symxsize(${symxsize}) region(color(none)) cols(3) ring(0) pos(11)) ///
			name(fig_akm_xb_age_m, replace)
		graph export "${DIR_RES_FIG}/fig_appendix_akm_xb_age_m.eps", replace
		
		tw ///
			(connected xb_age age if gender == 2 & edu == 1, mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 2 & edu == 2, mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 2 & edu == 3, mcolor(${mc3}) lcolor(${lc3}) msymbol(${ms3}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 2 & edu == 4, mcolor(${mc4}) lcolor(${lc4}) msymbol(${ms4}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 2 & edu == 5, mcolor(${mc5}) lcolor(${lc5}) msymbol(${ms5}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 2 & edu == 6, mcolor(${mc6}) lcolor(${lc6}) msymbol(${ms6}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 2 & edu == 7, mcolor(${mc7}) lcolor(${lc7}) msymbol(${ms7}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 2 & edu == 8, mcolor(${mc8}) lcolor(${lc8}) msymbol(${ms8}) lpattern(${lp1})) ///
			(connected xb_age age if gender == 2 & edu == 9, mcolor(${mc9}) lcolor(${lc9}) msymbol(${ms9}) lpattern(${lp1})) ///
			if inrange(age, ${age_min}, ${age_max}) ///
			, ///
			xlabel(18(4)54, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.2)1.4, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "0 years" 2 "<5 years" 3 "5 years" 4 "<9 years" 5 "9 years" 6 "<12 years" 7 "12 years" 8 "13-15 years" 9 ">=16 years") symxsize(${symxsize}) region(color(none)) cols(3) ring(0) pos(11)) ///
			name(fig_akm_xb_age_f, replace)
		graph export "${DIR_RES_FIG}/fig_appendix_akm_xb_age_f.eps", replace
	}
	
}


*** employment distribution over employer ranks
if $fig_kdens_ranks {

	* load data
	use ///
		rank* ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear
	
	* compute gender-specific means
	foreach g in m f {
		sum rank_`g' [aw=size_`g'], meanonly
		local mean_rank_`g' = r(mean)
	}
	
	* distribution of employment across own gender's employer ranks
	tw ///
		(kdensity rank_m [aw=size_m], lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_rank_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity rank_f [aw=size_f], lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_rank_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(2)12, format(%2.0f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific employer ranks (r{subscript:g})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(kdens_ranks, replace)
	graph export "${DIR_RES_FIG}/fig_kdens_ranks.eps", replace
	
}


*** density estimates of recruiting intensity by gender
if $fig_recruiting_dens {
	
	* load data
	use ///
		f_m f_f ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear

	* generate log recruiting intensities
	foreach g in m f {
		gen float log_f_`g' = ln(f_`g')
		lab var log_f_`g' "Log recruiting intensity for gender `g'"
	}
	drop f_m f_f

	* rename variables
	rename size_m weight_m
	rename size_f weight_f
	
	* compute gender-specific means
	foreach g in m f {
		sum log_f_`g', meanonly
		local mean_log_f_`g' = r(mean)
	}
	
	* plot firm-weighted density of log recruiting intensities
	tw ///
		(kdensity log_f_m, lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_log_f_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_f_f, lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_log_f_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-16(2)-4, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.1).6, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific log recruiting intensity (ln f{subscript:g})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(1)) ///
		name(recruiting_density_log_unw, replace)
	graph export "${DIR_RES_FIG}/fig_recruiting_unw.eps", replace
	
	* compute gender-specific means
	foreach g in m f {
		sum log_f_`g' [aw=weight_`g'], meanonly
		local mean_log_f_`g' = r(mean)
	}
	
	* plot employment-weighted density of log recruiting intensities
	tw ///
		(kdensity log_f_m [aw=weight_m], lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_log_f_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_f_f [aw=weight_f], lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_log_f_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-16(2)-4, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.1).6, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific log recruiting intensity (ln f{subscript:g})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(1)) ///
		name(recruiting_density_log_w, replace)
	graph export "${DIR_RES_FIG}/fig_recruiting_w.eps", replace
	
}


*** productivity
if $fig_prod {
	
	* load data
	use ///
		id_emp ///
		p_m ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear

	* generate log productivity
	gen float log_p = ln(p_m)
	lab var log_p "Log productivity"
	drop p_m

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* save data
	order id_emp log_p weight_m weight_f
	sort id_emp
	
	* compute gender-specific means
	foreach g in m f {
		sum log_p, meanonly
		local mean_log_p_`g' = r(mean)
	}

	* plot firm-weighted productivity distribution by gender
	tw ///
		(kdensity log_p, lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_log_p_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_p, lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_log_p_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-1(.5)3, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.5)2.5, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Log productivity (ln p)") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(1)) ///
		name(log_p_unw, replace)
	graph export "${DIR_RES_FIG}/fig_productivity_unw.eps", replace
	
	* compute gender-specific means
	foreach g in m f {
		sum log_p [aw=weight_`g'], meanonly
		local mean_log_p_`g' = r(mean)
	}

	* plot employment-weighted productivity distribution by gender
	tw ///
		(kdensity log_p [aw=weight_m], lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_log_p_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_p [aw=weight_f], lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_log_p_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-1(.5)3, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.5)2.5, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Log productivity (ln p)") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(1)) ///
		name(log_p_w, replace)
	graph export "${DIR_RES_FIG}/fig_productivity_w.eps", replace
	
}


*** gender wedge
if $fig_gender_wedge {
	
	* load data
	use ///
		id_emp ///
		tau ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* save data
	order id_emp tau weight_m weight_f
	sort id_emp
	
	* compute gender-specific means
	foreach g in m f {
		sum tau, meanonly
		local mean_tau_`g' = r(mean)
	}
	
	* plot firm-weighted gender wedge distribution by gender
	tw ///
		(kdensity tau if inrange(tau, -1, 1), lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_tau_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity tau if inrange(tau, -1, 1), lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_tau_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(1)4, format(%1.0f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender wedge ({&tau})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(1)) ///
		name(gender_wedge_unw, replace)
	graph export "${DIR_RES_FIG}/fig_gender_wedge_unw.eps", replace
	
	* compute gender-specific means
	foreach g in m f {
		sum tau [aw=weight_`g'], meanonly
		local mean_tau_`g' = r(mean)
	}
	
	* plot employment-weighted gender wedge distribution by gender
	tw ///
		(kdensity tau [aw=weight_m] if inrange(tau, -1, 1), lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_tau_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity tau [aw=weight_f] if inrange(tau, -1, 1), lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_tau_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(1)4, format(%1.0f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender wedge ({&tau})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(1)) ///
		name(gender_wedge_w, replace)
	graph export "${DIR_RES_FIG}/fig_gender_wedge_w.eps", replace
	
}


*** amenity cost shifters
if $fig_amenity_cost_shifters {
	
	* load data
	use ///
		id_emp ///
		c_pi_m c_pi_f ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear

	* generate log amenity cost shifters
	foreach g in m f {
		gen double log_c_pi_`g' = ln(c_pi_`g')
		lab var log_c_pi_`g' "Log amenity cost shifter, `g'"
		drop c_pi_`g'
	}

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* save data
	order id_emp log_c_pi_m log_c_pi_f weight_m weight_f
	sort id_emp
	
	* compute gender-specific means, unweighted
	foreach g in m f {
		sum log_c_pi_`g', meanonly
		local mean_log_c_pi_`g' = r(mean)
	}
	
	* plot firm-weighted gender wedge distribution by gender
	tw ///
		(kdensity log_c_pi_m if inrange(log_c_pi_m, -3, 5), lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_log_c_pi_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_c_pi_f if inrange(log_c_pi_f, -3, 5), lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_log_c_pi_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-3(1)5, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.2).8, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific log amenity cost shifter (ln c{subscript:g}{superscript:a,0})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(1)) ///
		name(amenity_cost_shifters_unw, replace)
	graph export "${DIR_RES_FIG}/fig_amenity_cost_shifters_unw.eps", replace
	
	* compute gender-specific means, weighted
	foreach g in m f {
		sum log_c_pi_`g' [aw=weight_`g'], meanonly
		local mean_log_c_pi_`g' = r(mean)
	}
	
	* plot employment-weighted gender wedge distribution by gender
	tw ///
		(kdensity log_c_pi_m [aw=weight_m] if inrange(log_c_pi_m, -3, 5), lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_log_c_pi_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_c_pi_f [aw=weight_f] if inrange(log_c_pi_f, -3, 5), lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_log_c_pi_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-3(1)5, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.2).8, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific log amenity cost shifter (ln c{subscript:g}{superscript:a,0})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(1)) ///
		name(amenity_cost_shifters_w, replace)
	graph export "${DIR_RES_FIG}/fig_amenity_cost_shifters_w.eps", replace
	
}


*** distribution of pay and amenities
if $fig_dist_pay_amenities {
	
	* load data
	use ///
		id_emp ///
		log_pi_m log_pi_f ///
		log_w_m log_w_f ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename size_m weight_m
	rename size_f weight_f
	
	* compute gender-specific means
	foreach g in m f {
		foreach var in log_w log_pi {
			sum `var'_`g' [aw=weight_`g'], meanonly
			local mean_`var'_`g' = r(mean)
		}
	}

	* pay, weighted
	tw ///
		(kdensity log_w_m [aw=weight_m] if inrange(log_w_m, -1, 1), lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_log_w_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_w_f [aw=weight_f] if inrange(log_w_f, -1, 1), lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_log_w_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.5)3, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific log pay (ln w{subscript:g})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(wage_dist, replace)
	graph export "${DIR_RES_FIG}/fig_wage_dist.eps", replace

	* amenities, weighted
	tw ///
		(kdensity log_pi_m [aw=weight_m] if inrange(log_pi_m, -1, 1), lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_log_pi_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity log_pi_f [aw=weight_f] if inrange(log_pi_f, -1, 1), lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_log_pi_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(-1(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.5)3, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific log amenity value (ln a{subscript:g})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(amenity_dist, replace)
	graph export "${DIR_RES_FIG}/fig_amenity_dist.eps", replace
	
}


*** employer ranks by industry
if $fig_ind_ranks {
	
	* load data
	use ///
		id_emp ///
		log_w_m log_w_f ///
		log_pi_m log_pi_f ///
		log_x_m log_x_f ///
		size_m size_f ///
		using "${DIR_TEMP}/post_est.dta", clear
		
	* merge in industry codes
	merge 1:1 id_emp ///
		using "${DIR_TEMP}/id_emp_ind.dta" ///
		, ///
		keepusing(ind_2) keep(match) nogen
	rename ind_2 ind

	* generate ranks
	gen double r = runiform()
	foreach var in ///
		log_w_m log_w_f ///
		log_pi_m log_pi_f ///
		log_x_m log_x_f ///
		{
		local var_str = subinstr("`var'", "log_", "", .)
		sort `var' r
		gen float rank_`var_str' = _n/_N
		lab var rank_`var_str' "Employer rank in terms of `var_str'"
	}
	drop r

	* collapse to industry level using gender-specific employment weights, separately by gender
	foreach g in m f {
		preserve
		${gtools}collapse ///
			(mean) rank_*_`g' ///
			(rawsum) size_`g' ///
			[aw=size_`g'] ///
			, ///
			by(ind) fast
		save "${DIR_TEMP}/temp_ind_collapse_`g'.dta", replace
		restore
	}

	* merge files for both genders
	use "${DIR_TEMP}/temp_ind_collapse_m.dta", clear
	merge 1:1 ind ///
		using "${DIR_TEMP}/temp_ind_collapse_f.dta" ///
		, ///
		keepusing(rank_*f size_f) keep(match) nogen

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* save data
	order ind rank_x_m rank_x_f rank_w_m rank_w_f rank_pi_m rank_pi_f weight_m weight_f
	sort ind
	
	* produce labels
	foreach g in m f {
		egen clock_`g' = mlabvpos(rank_x_`g' rank_w_`g')
	}
	
	* produce graphs
	foreach g in m f {
		if "`g'" == "m" {
			local color = "${lc1}"
			local pattern = "${lp1}"
			local msymbol = "${ms1}"
			local legend_str = "Men"
		}
		else if "`g'" == "f" {
			local color = "${lc2}"
			local pattern = "${lp2}"
			local msymbol = "${ms2}"
			local legend_str = "Women"
		}
		
		* employer rank vs. pay rank
		tw ///
			(scatter rank_x_`g' rank_w_`g' [aw=weight_`g'], msymbol(`msymbol'h) mcolor(`color')) ///
			(lfit rank_x_`g' rank_w_`g' [aw=weight_`g'], lcolor(`color') lpattern(`pattern') lwidth(${lw})) ///
			(scatter rank_x_`g' rank_w_`g' [aw=weight_`g'], mlabel(ind) mlabvpos(clock_`g') msymbol(none) mlabcolor(black)) ///
			, ///
			xtitle("`legend_str''s mean pay rank") ytitle("`legend_str''s mean employer rank") ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0.5(0.1)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
			legend(off) ///
			name(rank_x_w_`g', replace)
		graph export "${DIR_RES_FIG}/fig_ind_ranks_x_w_`g'.eps", replace
		
		* employer rank vs. amenity rank
		tw ///
			(scatter rank_x_`g' rank_pi_`g' [aw=weight_`g'], msymbol(`msymbol'h) mcolor(`color')) ///
			(lfit rank_x_`g' rank_pi_`g' [aw=weight_`g'], lcolor(`color') lpattern(`pattern') lwidth(${lw})) ///
			(scatter rank_x_`g' rank_pi_`g' [aw=weight_`g'], mlabel(ind) mlabvpos(clock_`g') msymbol(none) mlabcolor(black)) ///
			, ///
			xtitle("`legend_str''s mean amenity rank") ytitle("`legend_str''s mean employer rank") ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(.5(0.1)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
			legend(off) ///
			name(rank_x_a_`g', replace)
		graph export "${DIR_RES_FIG}/fig_ind_ranks_x_a_`g'.eps", replace
	}

}


*** distribution of amenity shares
if $fig_amenity_shares {
	
	* load data
	use ///
		id_emp ///
		pi_* x_* ///
		size_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* shares of utility due to wages vs. amenities
	foreach g in m f {
		gen float pi_share_`g' = pi_`g'/x_`g'
		lab var pi_share_`g' "Share of flow utility due to amenities, `g'"
		sum pi_share_`g' [aw=weight_`g']
		drop pi_`g' x_`g'
	}

	* save data
	order id_emp pi_share_m pi_share_f weight_m weight_f
	sort id_emp
	
	* compute gender-specific means
	foreach g in m f {
		sum pi_share_`g' [aw=weight_`g'], meanonly
		local mean_pi_share_`g' = r(mean)
	}
	
	* plot employment-weighted gender wedge distribution by gender
	tw ///
		(kdensity pi_share_m [aw=weight_m], lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw}) xline(`mean_pi_share_m', lcolor(${lc_v}) lpattern(${lp1}) lwidth(${lw}))) ///
		(kdensity pi_share_f [aw=weight_f], lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw}) xline(`mean_pi_share_f', lcolor(${lc_v}) lpattern(${lp2}) lwidth(${lw}))) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(1)6, format(%2.0f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific amenity share in total compensation (a{subscript:g}/(a{subscript:g} + w{subscript:g}))") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(fig_amenity_shares, replace)
	graph export "${DIR_RES_FIG}/fig_dist_amenity_shares.eps", replace
	
}


*** gender-specific amenity shares across employer ranks
if $fig_amenity_shares_ranks {
	
	* load data
	use ///
		id_emp ///
		pi_* x_* ///
		rank_* ///
		size_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* shares of utility due to wages vs. amenities
	foreach g in m f {
		gen float pi_share_`g' = pi_`g'/x_`g'
		lab var pi_share_`g' "Share of flow utility due to amenities, `g'"
		sum pi_share_`g' [aw=weight_`g']
		drop pi_`g' x_`g'
	}

	* collapse to rank quantiles using gender-specific employment weights, separately by gender
	foreach g in m f {
		preserve
		gquantiles rank_q = rank_`g' [aw=weight_`g'], xtile n(50)
		lab var rank_q "Gender-specific employer rank quantile"
		${gtools}collapse ///
			(mean) pi_share_*`g' ///
			[aw=weight_`g'] ///
			, ///
			by(rank_q) fast
		sum
		save "${DIR_TEMP}/temp_rank_collapse_`g'.dta", replace
		restore
	}

	* merge files for both genders
	use "${DIR_TEMP}/temp_rank_collapse_m.dta", clear
	merge 1:1 rank_q ///
		using "${DIR_TEMP}/temp_rank_collapse_f.dta" ///
		, ///
		keepusing(pi_share_f) keep(match) nogen

	* normalize ranks
	sum rank_q, meanonly
	replace rank_q = rank_q/r(max)

	* save data
	order rank_q pi_share_m pi_share_f
	sort rank_q
	
	* plot amenity shares across employer ranks
	tw ///
		(line pi_share_m rank_q, lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw})) ///
		(line pi_share_f rank_q, lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw})) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(.45(.05).65, format(%3.2f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific employer rank (r{subscript:g})") ytitle("Amenity share in total compensation (a{subscript:g}/(a{subscript:g} + w{subscript:g}))") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(amenity_shares_ranks, replace)
	graph export "${DIR_RES_FIG}/fig_amenity_shares_ranks.eps", replace
	
}


*** productivity across employer ranks
if $fig_prod_ranks {
	
	* load data
	use ///
		log_x* rank* log_p_m size_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* collapse to rank quantiles using gender-specific employment weights, separately by gender
	foreach g in m f {
		preserve
		gquantiles rank_q = rank_`g' [aw=weight_`g'], xtile n(50)
		lab var rank_q "Gender-specific employer rank quantile"
		${gtools}collapse ///
			(mean) log_p_m ///
			[aw=weight_`g'] ///
			, ///
			by(rank_q) fast
		if "`g'" == "m" {
			rename log_p_m log_p_m_for_men
		}
		else if "`g'" == "f" {
			rename log_p_m log_p_m_for_women
		}
		save "${DIR_TEMP}/temp_rank_collapse_`g'.dta", replace
		restore
	}

	* merge files for both genders
	use "${DIR_TEMP}/temp_rank_collapse_m.dta", clear
	merge 1:1 rank_q ///
		using "${DIR_TEMP}/temp_rank_collapse_f.dta" ///
		, ///
		keepusing(log_p_*) keep(match) nogen

	* normalize productivity
	foreach var of varlist ///
		log_p_m_for_men ///
		log_p_m_for_women ///
		{
		sum rank_q, meanonly
		local rank_q_min = r(min)
		sum `var' if rank_q == `rank_q_min'
		local `var'_min = r(mean)
		replace `var' = `var' - ``var'_min'
	}

	* normalize ranks
	sum rank_q, meanonly
	replace rank_q = rank_q/r(max)

	* save data
	order rank_q log_p_m_for_men log_p_m_for_women
	sort rank_q
	
	* plot amenity shares across employer ranks
	tw ///
		(line log_p_m_for_men rank_q, lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw})) ///
		(line log_p_m_for_women rank_q, lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw})) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.5)2, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Gender-specific employer rank (r{subscript:g})") ytitle("Normalized log productivity (ln p)") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(prod_ranks, replace)
	graph export "${DIR_RES_FIG}/fig_prod_ranks.eps", replace
	
}


*** productivity net of gender wedge vs. productivity
if $fig_prod_net_of_wedge {
	
	* load data
	use ///
		log_p_m log_p_f tau size ///
		using "${DIR_TEMP}/post_est.dta", clear

	* generate bins of productivity
	gquantiles log_p_m_q = log_p_m [aw=size], xtile n(50)
	lab var log_p_m_q "Productivity quantile"
	${gtools}collapse ///
		(mean) log_p_m log_p_f tau ///
		[aw=size] ///
		, ///
		by(log_p_m_q) fast

	* save
	order log_p_m_q log_p_m log_p_f tau
	sort log_p_m_q
	
	* plot
	local label_max = 2.5
	local label = "0(.5)`label_max', format(%2.1f)"
	tw ///
		(scatter log_p_f log_p_m, mcolor(${lc_comb})) ///
		(lfit log_p_f log_p_m, lcolor(${lc_comb}) lpattern(${lp_comb}) lwidth(${lw})) ///
		(fun y = x, range(0 `label_max') lcolor(${lc_d}) lpattern(${lp_d}) lwidth(${lw})) ///
		, ///
		xlabel(`label' gmin gmax grid gstyle(${gs})) ylabel(`label' gmin gmax grid gstyle(${gs})) ///
		xtitle("Log productivity (ln p)") ytitle("Log productivity net of ${wedge_name} (ln[(1 - {&tau})p])") /// (ln(l{subscript:M} + l{subscript:F}))
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(off) ///
		name(log_p_f_log_p_m, replace)
	graph export "${DIR_RES_FIG}/fig_log_p_f_log_p_m.eps", replace
	
}


*** employer size-pay premium across employer sizes by gender
if $fig_pay_size {
	
	* load data
	use "${DIR_TEMP}/employer_size_pay_premium.dta", clear
	
	* plot gender-specific employer-size pay premia
	tw ///
		(scatter log_w_mean log_size_mean if gender == 1, mcolor(${mc1}) msymbol(${ms1})) ///
		(lfit log_w_mean log_size_mean if gender == 1, lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw})) ///
		(scatter log_w_mean log_size_mean if gender == 2, mcolor(${mc2}) msymbol(${ms2})) ///
		(lfit log_w_mean log_size_mean if gender == 2, lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw})) ///
		, ///
		xlabel(2(2)14, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(-.1(.1).4, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Log total employment") ytitle("Mean AKM employer FE") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 3 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(pay_size, replace)
	graph export "${DIR_RES_FIG}/fig_pay_size.eps", replace
	
}


*** employer size distribution by gender
if $fig_emp_distributions {
	
	* load data
	use "${DIR_TEMP}/employment_distributions.dta", clear
	
	* gender-specific densities over gender-specific employer sizes
	tw ///
		(kdensity log_size_m [aw=size_m], lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw})) ///
		(kdensity log_size_f [aw=size_f], lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw})) ///
		, ///
		xlabel(2(2)14, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.05).25, format(%3.2f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Log gender-specific employment (ln l{subscript:g})") ytitle("Density") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(kdens_size, replace)
	graph export "${DIR_RES_FIG}/fig_kdens_size.eps", replace

	* gender-specific densities over total employer size
	tw ///
		(kdensity log_size [aw=size_m], lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw})) ///
		(kdensity log_size [aw=size_f], lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw})) ///
		, ///
		xlabel(2(2)14, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(0(.05).25, format(%3.2f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Log total employment") ytitle("Density") /// (ln(l{subscript:M} + l{subscript:F}))
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men" 2 "Women") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(kdens_size_total, replace)
	graph export "${DIR_RES_FIG}/fig_kdens_size_total.eps", replace
	
}


*** female employment share against employer size
if $fig_female_emp {
	
	* load data
	use "${DIR_TEMP}/employment_distributions.dta", clear
	
	* compute average female share in the economy
	foreach g in m f {
		sum size_`g', meanonly
		local s_`g' = r(sum)
	}
	local share_f = `s_f'/(`s_m' + `s_f')
	
	* load data
	use "${DIR_TEMP}/female_employment.dta", clear
	
	* plot
	tw ///
		(scatter share_f_mean log_size_mean, mcolor(${lc_comb}) yline(`share_f', lcolor(${lc_h}) lpattern(${lp1}) lwidth(${lw}))) ///
		(qfit share_f_mean log_size_mean, lcolor(${lc_comb}) lpattern(${lp_comb}) lwidth(${lw})) ///
		, ///
		xlabel(2(2)14, format(%2.0f) gmin gmax grid gstyle(${gs})) ylabel(.3(.1).7, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Log total employment") ytitle("Female employment share") /// (ln(l{subscript:M} + l{subscript:F}))
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(off) ///
		name(share_f_emp, replace)
	graph export "${DIR_RES_FIG}/fig_share_f_emp.eps", replace
	
}


*** gender-specific compensation components across employer ranks
if $fig_compensation_components {
	
	* load data
	use ///
		id_emp ///
		log_pi* log_w_* log_x_* ///
		rank_* ///
		size_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	* rename variables
	rename size_m weight_m
	rename size_f weight_f

	* merge in industry codes
	merge m:1 id_emp using "${DIR_TEMP}/id_emp_public.dta", keepusing(public) keep(master match) nogen

	* collapse to rank quantiles using gender-specific employment weights, separately by gender
	foreach g in m f {
		preserve
		gquantiles rank_q = rank_`g' [aw=weight_`g'], xtile n(50)
		lab var rank_q "Gender-specific employer rank quantile"
		rename public public_`g'
		${gtools}collapse ///
			(mean) log_w_*`g' log_pi_*`g' log_x_*`g' public_`g' ///
			[aw=weight_`g'] ///
			, ///
			by(rank_q) fast
		save "${DIR_TEMP}/temp_rank_collapse_`g'.dta", replace
		restore
	}

	* merge files for both genders
	use "${DIR_TEMP}/temp_rank_collapse_m.dta", clear
	merge 1:1 rank_q ///
		using "${DIR_TEMP}/temp_rank_collapse_f.dta" ///
		, ///
		keepusing(*w_* *pi_* *x_* *public_*) keep(match) nogen

	* normalize variables in logs
	foreach var of varlist log* {
		sum rank_q, meanonly
		local rank_q_min = r(min)
		sum `var' if rank_q == `rank_q_min'
		local `var'_min = r(mean)
		replace `var' = `var' - ``var'_min'
	}

	* normalize ranks
	sum rank_q, meanonly
	replace rank_q = rank_q/r(max)

	* save data
	order rank_q log_w_m log_w_f log_pi_m log_pi_f log_x_m log_x_f public_m public_f
	sort rank_q

	* loop through genders
	foreach g in m f {
		if "`g'" == "m" {
			local lc = "blue"
			local xtitle = "Men's"
			local subscript = "M"
		}
		else if "`g'" == "f" {
			local lc = "red"
			local xtitle = "Women's"
			local subscript = "F"
		}
		tw ///
			(line log_w_`g' log_pi_`g' log_x_`g' rank_q, lcolor(`lc' `lc' black) lpattern(longdash shortdash solid) lwidth(thick thick thick)) ///
			, ///
			xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(-.2(.1).4, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
			xtitle("`xtitle' employer rank (r{subscript:`subscript'})") ytitle("Normalized log value") ///
			graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
			legend(order(1 "Pay" 2 "Amenities" 3 "Total compensation") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
			name(fig_comp_ladder_`g', replace)
		graph export "${DIR_RES_FIG}/fig_comp_ladder_`g'.eps", replace
	}
	
}


*** actual vs. potential experience
if $fig_exp_act_vs_exp_pot {
	
	* load data
	use "${DIR_TEMP}/exp_act_vs_exp_pot.dta", clear
	
	* set maximum experience level
	local max_actual_exp = 50
	
	* plots
	tw ///
		(fun y = x, range(0 `max_actual_exp') lcolor(${lc_d}) lwidth(${lw}) lpattern(${lp_comb})) ///
		(connected exp_act_p5 exp_pot if gender == 1, mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
		(connected exp_act_p10 exp_pot if gender == 1, mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp2})) ///
		(connected exp_act_p25 exp_pot if gender == 1, mcolor(${mc3}) lcolor(${lc3}) msymbol(${ms3}) lpattern(${lp3})) ///
		(connected exp_act_p50 exp_pot if gender == 1, mcolor(${mc4}) lcolor(${lc4}) msymbol(${ms4}) lpattern(${lp4})) ///
		(connected exp_act_p75 exp_pot if gender == 1, mcolor(${mc5}) lcolor(${lc5}) msymbol(${ms5}) lpattern(${lp5})) ///
		(connected exp_act_p90 exp_pot if gender == 1, mcolor(${mc6}) lcolor(${lc6}) msymbol(${ms6}) lpattern(${lp6})) ///
		(connected exp_act_p95 exp_pot if gender == 1, mcolor(${mc7}) lcolor(${lc7}) msymbol(${ms7}) lpattern(${lp7})) ///
		, ///
		xlabel(0(5)`max_actual_exp', gmin gmax grid gstyle(${gs})) ///
		ylabel(0(5)`max_actual_exp', gmin gmax grid gstyle(${gs})) ///
		xtitle("Potential experience (years)") ytitle("Actual experience (years)") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(2 "P5" 3 "P10" 4 "P25" 5 "P50" 6 "P75" 7 "P90" 8 "P95") symxsize(${symxsize}) region(color(none)) cols(2) ring(0) pos(11)) ///
		name(fig_exp_act_vs_exp_pot_m, replace)
	graph export "${DIR_RES_FIG}/fig_appendix_exp_act_vs_exp_pot_m.eps", replace
		
	tw ///
		(fun y = x, range(0 `max_actual_exp') lcolor(${lc_d}) lwidth(${lw}) lpattern(${lp_comb})) ///
		(connected exp_act_p5 exp_pot if gender == 2, mcolor(${mc1}) lcolor(${lc1}) msymbol(${ms1}) lpattern(${lp1})) ///
		(connected exp_act_p10 exp_pot if gender == 2, mcolor(${mc2}) lcolor(${lc2}) msymbol(${ms2}) lpattern(${lp2})) ///
		(connected exp_act_p25 exp_pot if gender == 2, mcolor(${mc3}) lcolor(${lc3}) msymbol(${ms3}) lpattern(${lp3})) ///
		(connected exp_act_p50 exp_pot if gender == 2, mcolor(${mc4}) lcolor(${lc4}) msymbol(${ms4}) lpattern(${lp4})) ///
		(connected exp_act_p75 exp_pot if gender == 2, mcolor(${mc5}) lcolor(${lc5}) msymbol(${ms5}) lpattern(${lp5})) ///
		(connected exp_act_p90 exp_pot if gender == 2, mcolor(${mc6}) lcolor(${lc6}) msymbol(${ms6}) lpattern(${lp6})) ///
		(connected exp_act_p95 exp_pot if gender == 2, mcolor(${mc7}) lcolor(${lc7}) msymbol(${ms7}) lpattern(${lp7})) ///
		, ///
		xlabel(0(5)`max_actual_exp', gmin gmax grid gstyle(${gs})) ///
		ylabel(0(5)`max_actual_exp', gmin gmax grid gstyle(${gs})) ///
		xtitle("Potential experience (years)") ytitle("Actual experience (years)") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(2 "P5" 3 "P10" 4 "P25" 5 "P50" 6 "P75" 7 "P90" 8 "P95") symxsize(${symxsize}) region(color(none)) cols(2) ring(0) pos(11)) ///
		name(fig_exp_act_vs_exp_pot_f, replace)
	graph export "${DIR_RES_FIG}/fig_appendix_exp_act_vs_exp_pot_f.eps", replace
	
}


*** moving women into men's employers
if $fig_women_to_men {
	
	*Load data
	use ///
		log_x_* log_w_* log_pi* g_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	*Sort data and generate the counterfactual distribution G_f_m: female employment CDF if they worked at the same firms as men
	sort log_x_f
	gen float G_f_x = sum(g_f)
	gen float G_f_m_x = sum(g_m)
	sort log_pi_f
	gen float G_f_pi = sum(g_f)
	gen float G_f_m_pi = sum(g_m)
	sort log_w_f
	gen float G_f_w = sum(g_f)
	gen float G_f_m_w = sum(g_m)

	*Impact on flow utility: negative!
	preserve
	gquantiles log_x_f_quantiles = log_x_f [aw=g_f], xtile n(100)
	${gtools}collapse ///
		(mean) log_x_f G_f_x G_f_m_x ///
		, ///
		by(log_x_f_quantiles) fast
	sum log_x_f_quantiles, meanonly
	replace log_x_f_quantiles = log_x_f_quantiles/r(max)
	sort log_x_f
	tw (fun y = x, range(0 1) lcolor(${lc_d}) lpattern(${lp_d}) lwidth(${lw}) ) (line G_f_m_x log_x_f_quantiles, lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw})) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Rank of women's total compensation (x{sub:F})") ytitle("Employment CDF") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Women's current distribution (45-degree line)" 2 "Moving women into men's employers") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(women_to_men_x, replace)
	if $graph_export graph export "${DIR_RES_FIG}/fig_women_to_men_x.eps", replace
	restore

	*Impact on amenities: strongly negative
	preserve
	gquantiles log_pi_f_quantiles = log_pi_f [aw=g_f], xtile n(100)
	${gtools}collapse ///
		(mean) log_pi_f G_f_pi G_f_m_pi ///
		, ///
		by(log_pi_f_quantiles) fast
	sum log_pi_f_quantiles, meanonly
	replace log_pi_f_quantiles = log_pi_f_quantiles/r(max)
	sort log_pi_f
	tw (fun y = x, range(0 1) lcolor(${lc_d}) lpattern(${lp_d}) lwidth(${lw})) (line G_f_m_pi log_pi_f_quantiles, lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw})) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Rank of women's amenities (a{sub:F})") ytitle("Employment CDF") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Women's current distribution (45-degree line)" 2 "Moving women into men's employers") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(women_to_men_pi, replace) 
	if $graph_export graph export "${DIR_RES_FIG}/fig_women_to_men_pi.eps", replace
	restore

	*Impact on wages: [positive]
	preserve
	gquantiles log_w_f_quantiles = log_w_f [aw=g_f], xtile n(100) 
	${gtools}collapse ///
		(mean) log_w_f G_f_w G_f_m_w ///
		, ///
		by(log_w_f_quantiles) fast
	sum log_w_f_quantiles, meanonly
	replace log_w_f_quantiles = log_w_f_quantiles/r(max)
	sort log_w_f
	tw (fun y = x, range(0 1) lcolor(${lc_d}) lpattern(${lp_d}) lwidth(${lw})) (line G_f_m_w log_w_f_quantiles, lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw})) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Rank of women's pay (w{sub:F})") ytitle("Employment CDF") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Women's current distribution (45-degree line)" 2 "Moving women into men's employers") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(women_to_men_w, replace) 
	if $graph_export graph export "${DIR_RES_FIG}/fig_women_to_men_w.eps", replace
	restore
	
}


*** moving women into men's employers
if $fig_men_to_women {
	
	*Load data
	use ///
		log_x_* log_w_* log_pi* g_* ///
		using "${DIR_TEMP}/post_est.dta", clear

	*Sort data and generate the counterfactual distribution G_m_f: male employment CDF if they worked at the same firms as women
	sort log_x_m
	gen float G_m_x = sum(g_m)
	gen float G_m_f_x = sum(g_f)
	sort log_pi_m
	gen float G_m_pi = sum(g_m)
	gen float G_m_f_pi = sum(g_f)
	sort log_w_m
	gen float G_m_w = sum(g_m)
	gen float G_m_f_w = sum(g_f)

	*Impact on flow utility
	preserve
	gquantiles log_x_m_quantiles = log_x_m [aw=g_m], xtile n(100)
	${gtools}collapse ///
		(mean) log_x_m G_m_x G_m_f_x ///
		, ///
		by(log_x_m_quantiles) fast
	sum log_x_m_quantiles, meanonly
	replace log_x_m_quantiles = log_x_m_quantiles/r(max)
	sort log_x_m
	tw (fun y = x, range(0 1) lcolor(${lc_d}) lpattern(${lp_d}) lwidth(${lw})) (line G_m_f_x log_x_m_quantiles, lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw})) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Rank of men's total compensation (x{sub:M})") ytitle("Employment CDF") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men's current distribution (45-degree line)" 2 "Moving men into women's employers") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(men_to_women_x, replace)
	if $graph_export graph export "${DIR_RES_FIG}/fig_men_to_women_x.eps", replace
	restore

	*Impact on amenities
	preserve
	gquantiles log_pi_m_quantiles = log_pi_m [aw=g_m], xtile n(100)
	${gtools}collapse ///
		(mean) log_pi_m G_m_pi G_m_f_pi ///
		, ///
		by(log_pi_m_quantiles) fast
	sum log_pi_m_quantiles, meanonly
	replace log_pi_m_quantiles = log_pi_m_quantiles/r(max)
	sort log_pi_m
	tw (fun y = x, range(0 1) lcolor(${lc_d}) lpattern(${lp_d}) lwidth(${lw})) (line G_m_f_pi log_pi_m_quantiles, lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw})) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Rank of men's amenities (a{sub:M})") ytitle("Employment CDF") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men's current distribution (45-degree line)" 2 "Moving men into women's employers") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(men_to_women_pi, replace)
	if $graph_export graph export "${DIR_RES_FIG}/fig_men_to_women_pi.eps", replace
	restore

	*Impact on wages
	preserve
	gquantiles log_w_m_quantiles = log_w_m [aw=g_m], xtile n(100) 
	${gtools}collapse ///
		(mean) log_w_m G_m_w G_m_f_w ///
		, ///
		by(log_w_m_quantiles) fast
	sum log_w_m_quantiles, meanonly
	replace log_w_m_quantiles = log_w_m_quantiles/r(max)
	sort log_w_m
	tw (fun y = x, range(0 1) lcolor(${lc_d}) lpattern(${lp_d}) lwidth(${lw})) (line G_m_f_w log_w_m_quantiles, lcolor(${lc1}) lpattern(${lp1}) lwidth(${lw})) ///
		, ///
		xlabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(0(.2)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		xtitle("Rank of men's pay (w{sub:M})") ytitle("Employment CDF") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		legend(order(1 "Men's current distribution (45-degree line)" 2 "Moving men into women's employers") symxsize(${symxsize}) region(color(none)) cols(${n_cols}) ring(0) pos(11)) ///
		name(men_to_women_w, replace)
	if $graph_export graph export "${DIR_RES_FIG}/fig_men_to_women_w.eps", replace
	restore
}


*** amenities and gender wedges
if $fig_amenities_wedges {
	
	* load data
	use ///
		log_pi_f tau g_f ///
		using "${DIR_TEMP}/post_est.dta", clear

	* generate bins of gender wedges
	gquantiles tau_q = tau [aw=g_f], xtile n(50)
	lab var tau_q "Gender wedge quantile"
	${gtools}collapse ///
		(mean) log_pi_f tau ///
		[aw=g_f] ///
		, ///
		by(tau_q) fast

	* normalize ranks
	sum tau_q, meanonly
	replace tau_q = tau_q/r(max)

	* save
	order log_pi_f tau tau_q
	sort tau_q
	compress
	desc
	save "${DIR_TEMP}/amenities_wedges.dta", replace
	
	* load data
	use "${DIR_TEMP}/amenities_wedges.dta", clear
	
	* employer rank vs. pay rank
	tw ///
		(scatter log_pi_f tau, msymbol(${ms2}) mcolor(${mc2})) ///
		(lfit log_pi_f tau, lcolor(${lc2}) lpattern(${lp2}) lwidth(${lw})) ///
		, ///
		xtitle("Gender wedge ({&tau})") ytitle("Women's log amenity (ln a{sub:F})") ///
		graphregion(color(white)) plotregion(lcolor(black) margin(l=0 r=0 b=0 t=0)) ///
		xlabel(-1(.5)1, format(%2.1f) gmin gmax grid gstyle(${gs})) ylabel(-.2(.2).6, format(%2.1f) gmin gmax grid gstyle(${gs})) ///
		legend(off) ///
		name(amenities_wedges, replace)
	graph export "${DIR_RES_FIG}/fig_amenities_wedges.eps", replace
	
}


*** final housekeeping
* clean up
if $clean_up {
	rm "${DIR_TEMP}/id_emp_ind.dta"
	rm "${DIR_TEMP}/temp_ind_collapse_m.dta"
	rm "${DIR_TEMP}/temp_ind_collapse_f.dta"
	rm "${DIR_TEMP}/temp_rank_collapse_m.dta"
	rm "${DIR_TEMP}/temp_rank_collapse_f.dta"
}

* turn timer off
timer off 16

* print final banner
di _newline(5)
timer list 16
local t = r(t16)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_15_FIGURES.do
********************************************************************************

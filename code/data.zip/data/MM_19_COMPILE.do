********************************************************************************
* FILE NAME:   MM_19_COMPILE.do
*
* DESCRIPTION: Compiles the paper with all exhibits, including figures, tables, and text snippets
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_19_COMPILE"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 20

* set random-number stream
clear rngstream
set rngstream 19

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** clean up
* keep only exhibits used in the paper
foreach file in ///
	/// 0_abstract.tex:
	/// none
	///
	/// 1_introduction.tex:
	"${DIR_RES_TXT}/txt_sum_stats_earn_gap.tex" ///
	"${DIR_RES_TXT}/txt_gap_log_w.tex" ///
	"${DIR_RES_TXT}/txt_sum_stats_gap_share_fe_earn.tex" ///
	"${DIR_RES_TXT}/txt_pi_share_m_mean.tex" ///
	"${DIR_RES_TXT}/txt_pi_share_f_mean.tex" ///
	"${DIR_RES_TXT}/txt_var_x_share_m.tex" ///
	"${DIR_RES_TXT}/txt_var_x_share_f.tex" ///
	"${DIR_RES_TXT}/txt_gap_log_x.tex" ///
	"${DIR_RES_TXT}/txt_gap_log_x_share.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_amenities_gap_decline_pp.tex" ///
	///
	/// 2_data.tex:
	"${DIR_RES_TXT}/txt_N_ind07_5.tex" ///
	"${DIR_RES_TXT}/txt_N_muni.tex" ///
	"${DIR_RES_TXT}/txt_N_occ02_6.tex" ///
	"${DIR_RES_TXT}/txt_sum_stats_n_worker_years.tex" ///
	"${DIR_RES_TXT}/txt_sum_stats_n_workers.tex" ///
	"${DIR_RES_TXT}/txt_sum_stats_n_estab.tex" ///
	"${DIR_RES_TXT}/txt_sum_stats_sh_f.tex" ///
	"${DIR_RES_TXT}/txt_sum_stats_earn_gap.tex" /// (duplicate)
	"${DIR_RES_TAB}/tab_sum_stats.tex" ///
	///
	/// 3_gaps.tex:
	"${DIR_RES_FIG}/fig_densities_baseline.eps" ///
	"${DIR_RES_FIG}/fig_within_baseline.eps" ///
	"${DIR_RES_TXT}/txt_akm_var_m.tex" ///
	"${DIR_RES_TXT}/txt_akm_kss_var_y_1.tex" ///
	"${DIR_RES_TXT}/txt_akm_var_f.tex" ///
	"${DIR_RES_TXT}/txt_akm_kss_var_y_2.tex" ///
	"${DIR_RES_TXT}/txt_akm_var_pers_fe_sh_m.tex" ///
	"${DIR_RES_TXT}/txt_akm_kss_share_var_pe_leaveout_1.tex" ///
	"${DIR_RES_TXT}/txt_akm_var_pers_fe_sh_f.tex" ///
	"${DIR_RES_TXT}/txt_akm_kss_share_var_pe_leaveout_2.tex" ///
	"${DIR_RES_TXT}/txt_akm_var_emp_fe_sh_m.tex" ///
	"${DIR_RES_TXT}/txt_akm_kss_share_var_fe_leaveout_1.tex" ///
	"${DIR_RES_TXT}/txt_akm_var_emp_fe_sh_f.tex" ///
	"${DIR_RES_TXT}/txt_akm_kss_share_var_fe_leaveout_2.tex" ///
	"${DIR_RES_TXT}/txt_akm_corr_pers_emp_m.tex" ///
	"${DIR_RES_TXT}/txt_akm_kss_corr_fe_pe_leaveout_1.tex" ///
	"${DIR_RES_TXT}/txt_akm_corr_pers_emp_f.tex" ///
	"${DIR_RES_TXT}/txt_akm_kss_corr_fe_pe_leaveout_2.tex" ///
	"${DIR_RES_TXT}/txt_akm_r2.tex" ///
	"${DIR_RES_TXT}/txt_akm_kss_r_2_leaveout_1.tex" ///
	"${DIR_RES_TAB}/tab_akm_combined_decomp.tex" ///
	"${DIR_RES_TXT}/txt_kob_gender_gap_log_w.tex" ///
	"${DIR_RES_TXT}/txt_sum_stats_gap_share_fe_earn.tex" ///
	"${DIR_RES_TXT}/txt_sum_stats_earn_gap.tex" ///
	"${DIR_RES_TXT}/txt_kob_gender_gap_log_w.tex" ///
	"${DIR_RES_TXT}/txt_kob_share_between_1_log_w.tex" ///
	"${DIR_RES_TXT}/txt_kob_level_within_1_log_w.tex" ///
	"${DIR_RES_TXT}/txt_akm_mean_fe_m.tex" ///
	"${DIR_RES_TXT}/txt_kob_level_within_1_log_w.tex" /// (duplicate)
	"${DIR_RES_TXT}/txt_akm_mean_fe_m.tex" /// (duplicate)
	"${DIR_RES_TXT}/txt_kob_bargaining_disadvantage.tex" ///
	"${DIR_RES_TAB}/tab_kob_log_w_short.tex" ///
	///
	/// 4_model.tex:
	/// none
	///
	/// 5_identification.tex:
	"${DIR_RES_TXT}/txt_model_rho.tex" ///
	"${DIR_RES_TXT}/txt_model_discount_rate.tex" ///
	"${DIR_RES_TXT}/txt_model_chi.tex" ///
	"${DIR_RES_TXT}/txt_model_alpha.tex" ///
	///
	/// 6_estimation.tex:
	"${DIR_RES_TXT}/txt_mean_rank_m.tex" ///
	"${DIR_RES_TXT}/txt_mean_rank_f.tex" ///
	"${DIR_RES_TXT}/txt_pop_share_m.tex" ///
	"${DIR_RES_TXT}/txt_pop_share_f.tex" ///
	"${DIR_RES_TXT}/txt_lambda_u_f.tex" ///
	"${DIR_RES_TXT}/txt_lambda_u_m.tex" ///
	"${DIR_RES_TXT}/txt_delta_f.tex" ///
	"${DIR_RES_TXT}/txt_delta_m.tex" ///
	"${DIR_RES_TXT}/txt_lambda_g_m.tex" ///
	"${DIR_RES_TXT}/txt_lambda_g_f.tex" ///
	"${DIR_RES_TXT}/txt_lambda_e_m.tex" ///
	"${DIR_RES_TXT}/txt_lambda_e_f.tex" ///
	"${DIR_RES_TXT}/txt_u_m.tex" ///
	"${DIR_RES_TXT}/txt_u_f.tex" ///
	"${DIR_RES_TXT}/txt_b_m.tex" ///
	"${DIR_RES_TXT}/txt_b_f.tex" ///
	"${DIR_RES_TXT}/txt_phi_m.tex" ///
	"${DIR_RES_TXT}/txt_phi_f.tex" ///
	"${DIR_RES_TAB}/tab_lab_params.tex" ///
	"${DIR_RES_TXT}/txt_mean_log_prod_m.tex" ///
	"${DIR_RES_TXT}/txt_mean_log_prod_f.tex" ///
	"${DIR_RES_TXT}/txt_mean_log_prod_gap.tex" ///
	"${DIR_RES_TXT}/txt_financials_b_log_revenue_pw_data.tex" ///
	"${DIR_RES_TAB}/tab_reg_productivity.tex" ///
	"${DIR_RES_TXT}/txt_tau_f_mean.tex" ///
	"${DIR_RES_TXT}/txt_tau_m_mean.tex" ///
	"${DIR_RES_TXT}/txt_reg_wedges_r2.tex" ///
	"${DIR_RES_TAB}/tab_reg_wedges.tex" ///
	"${DIR_RES_TXT}/txt_reg_amenities_r2_men.tex" ///
	"${DIR_RES_TXT}/txt_reg_amenities_r2_women.tex" ///
	"${DIR_RES_TAB}/tab_reg_amenities.tex" ///
	"${DIR_RES_TXT}/txt_corr_log_w.tex" ///
	"${DIR_RES_TXT}/txt_corr_log_pi.tex" ///
	"${DIR_RES_TXT}/txt_corr_rank.tex" ///
	"${DIR_RES_TXT}/txt_model_baseline_eta_v.tex" ///
	"${DIR_RES_TXT}/txt_model_baseline_eta_a.tex" ///
	"${DIR_RES_TAB}/tab_economy_wide_parameters_rank5.tex" ///
	"${DIR_RES_TXT}/txt_model_fit_gap_difference.tex" ///
	"${DIR_RES_TAB}/tab_model_fit.tex" ///
	"${DIR_RES_FIG}/fig_fit_pay.eps" ///
	"${DIR_RES_FIG}/fig_fit_size.eps" ///
	///
	/// 7_structure.tex:
	"${DIR_RES_TXT}/txt_N_ind85_2.tex" ///
	"${DIR_RES_FIG}/fig_ind_ranks_x_w_m.eps" ///
	"${DIR_RES_FIG}/fig_ind_ranks_x_w_f.eps" ///
	"${DIR_RES_TXT}/txt_N_ind85_2.tex" /// (duplicate)
	"${DIR_RES_FIG}/fig_ind_ranks_x_a_m.eps" ///
	"${DIR_RES_FIG}/fig_ind_ranks_x_a_f.eps" ///
	"${DIR_RES_TXT}/txt_N_ind85_2.tex" /// (duplicate)
	"${DIR_RES_TXT}/txt_mean_log_pi_f.tex" ///
	"${DIR_RES_TXT}/txt_mean_log_pi_m.tex" ///
	"${DIR_RES_TXT}/txt_gap_log_pi.tex" ///
	"${DIR_RES_FIG}/fig_wage_dist.eps" ///
	"${DIR_RES_FIG}/fig_amenity_dist.eps" ///
	"${DIR_RES_TXT}/txt_log_x_m_range.tex" ///
	"${DIR_RES_TXT}/txt_log_x_f_range.tex" ///
	"${DIR_RES_FIG}/fig_comp_ladder_m.eps" ///
	"${DIR_RES_FIG}/fig_comp_ladder_f.eps" ///
	"${DIR_RES_TXT}/txt_pi_share_m_mean.tex" /// (duplicate)
	"${DIR_RES_TXT}/txt_pi_share_f_mean.tex" /// (duplicate)
	"${DIR_RES_FIG}/fig_dist_amenity_shares.eps" ///
	"${DIR_RES_FIG}/fig_amenity_shares_ranks.eps" ///
	"${DIR_RES_TXT}/txt_var_log_w_m.tex" ///
	"${DIR_RES_TXT}/txt_var_log_w_f.tex" ///
	"${DIR_RES_TXT}/txt_var_log_x_m.tex" ///
	"${DIR_RES_TXT}/txt_var_x_share_m.tex" /// (duplicate)
	"${DIR_RES_TXT}/txt_var_log_x_f.tex" ///
	"${DIR_RES_TXT}/txt_var_x_share_f.tex" /// (duplicate)
	"${DIR_RES_TAB}/tab_var_pay_decomp.tex" ///
	"${DIR_RES_TXT}/txt_gap_log_w.tex" /// (duplicate)
	"${DIR_RES_TXT}/txt_gap_log_pi_tilde.tex" ///
	"${DIR_RES_TXT}/txt_gap_log_x.tex" /// (duplicate)
	"${DIR_RES_TXT}/txt_gap_log_x_share.tex" ///
	"${DIR_RES_TXT}/txt_gap_log_pi_tilde.tex" ///
	"${DIR_RES_TXT}/txt_kob_level_between_1_log_pi_tilde.tex" ///
	"${DIR_RES_TXT}/txt_kob_level_within_1_log_pi_tilde.tex" ///
	"${DIR_RES_TXT}/txt_gap_log_x.tex" ///
	"${DIR_RES_TAB}/tab_kob_log_w_pi_x.tex" ///
	///
	/// 8_counterfactuals.tex:
	"${DIR_RES_TAB}/tab_counterfactuals_equilibrium_main_text.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_amenities_gap_decline.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_amenities_gap_decline_pp.tex" /// (duplicate)
	"${DIR_RES_TXT}/txt_model_cf_amenities_gap_decline_between.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_amenities_gap_increase_within.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_amenities_employment_increase.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_amenities_output_increase.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_amenities_workerwelfare_increase.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_equalpay_output_decrease.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_equalpay_gendergap_closing.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_equalhiring_gendergap_decline.tex" ///
	"${DIR_RES_TAB}/tab_counterfactuals_policies.tex" ///
	///
	/// 9_conclusion.tex:
	/// none
	///
	/// A_appendix_data.tex:
	"${DIR_RES_FIG}/fig_appendix_exp_act_vs_exp_pot_m.eps" ///
	"${DIR_RES_FIG}/fig_appendix_exp_act_vs_exp_pot_f.eps" ///
	"${DIR_RES_TAB}/tab_appendix_a1.tex" ///
	"${DIR_RES_TAB}/tab_appendix_a2.tex" ///
	"${DIR_RES_TAB}/tab_appendix_a3.tex" ///
	"${DIR_RES_TAB}/tab_appendix_a4.tex" ///
	"${DIR_RES_TAB}/tab_appendix_a5.tex" ///
	///
	/// B_appendix_gaps.tex:
	"${DIR_RES_FIG}/fig_appendix_akm_hours.eps" ///
	"${DIR_RES_FIG}/fig_appendix_akm_occ.eps" ///
	"${DIR_RES_FIG}/fig_appendix_akm_exp_act.eps" ///
	"${DIR_RES_FIG}/fig_appendix_akm_xb_tenure.eps" ///
	"${DIR_RES_FIG}/fig_appendix_akm_xb_year_m.eps" ///
	"${DIR_RES_FIG}/fig_appendix_akm_xb_year_f.eps" ///
	"${DIR_RES_FIG}/fig_appendix_akm_xb_age_m.eps" ///
	"${DIR_RES_FIG}/fig_appendix_akm_xb_age_f.eps" ///
	"${DIR_RES_TAB}/tab_kob_log_w.tex" ///
	"${DIR_RES_FIG}/fig_appendix_densities_alt_2.eps" ///
	"${DIR_RES_FIG}/fig_appendix_within_alt_1.eps" ///
	"${DIR_RES_FIG}/fig_appendix_densities_alt_1.eps" ///
	"${DIR_RES_FIG}/fig_appendix_within_alt_2.eps" ///
	///
	/// C_appendix_model.tex:
	/// none
	///
	/// D_appendix_identification.tex:
	"${DIR_RES_TAB}/tab_montecarlo_100000.tex" ///
	"${DIR_RES_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_1.eps" ///
	"${DIR_RES_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_2.eps" ///
	"${DIR_RES_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_3.eps" ///
	"${DIR_RES_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_4.eps" ///
	"${DIR_RES_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_5.eps" ///
	"${DIR_RES_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_1.eps" ///
	"${DIR_RES_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_2.eps" ///
	"${DIR_RES_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_3.eps" ///
	"${DIR_RES_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_4.eps" ///
	"${DIR_RES_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_5.eps" ///
	"${DIR_RES_TAB}/tab_montecarlo_misspecification_100000_etav2_rho0.tex" ///
	"${DIR_RES_TAB}/tab_montecarlo_misspecification_100000_etav2_rho-1.tex" ///
	"${DIR_RES_TAB}/tab_montecarlo_misspecification_100000_etav2_rho1.tex" ///
	"${DIR_RES_TXT}/txt_model_baseline_eta_v.tex" /// (duplicate)
	"${DIR_RES_FIG}/fig_corr_dem_rank_gender_edu_m.eps" ///
	"${DIR_RES_FIG}/fig_corr_dem_rank_gender_edu_f.eps" ///
	"${DIR_RES_FIG}/fig_corr_dem_rank_gender_parent_m.eps" ///
	"${DIR_RES_FIG}/fig_corr_dem_rank_gender_parent_f.eps" ///
	"${DIR_RES_FIG}/fig_corr_dem_rank_gender_yob_m.eps" ///
	"${DIR_RES_FIG}/fig_corr_dem_rank_gender_yob_f.eps" ///
	///
	/// E_appendix_estimation.tex:
	"${DIR_RES_FIG}/fig_kdens_ranks.eps" ///
	"${DIR_RES_FIG}/fig_recruiting_unw.eps" ///
	"${DIR_RES_FIG}/fig_recruiting_w.eps" ///
	"${DIR_RES_FIG}/fig_productivity_unw.eps" ///
	"${DIR_RES_FIG}/fig_productivity_w.eps" ///
	"${DIR_RES_FIG}/fig_gender_wedge_unw.eps" ///
	"${DIR_RES_FIG}/fig_gender_wedge_w.eps" ///
	"${DIR_RES_FIG}/fig_amenity_cost_shifters_unw.eps" ///
	"${DIR_RES_FIG}/fig_amenity_cost_shifters_w.eps" ///
	"${DIR_RES_TAB}/tab_corr_m.tex" ///
	"${DIR_RES_TAB}/tab_corr_f.tex" ///
	"${DIR_RES_TAB}/tab_corr_cross.tex" ///
	"${DIR_RES_FIG}/fig_model_fit_w_size_m.eps" ///
	"${DIR_RES_FIG}/fig_model_fit_w_size_f.eps" ///
	"${DIR_RES_TAB}/tab_ranks.tex" ///
	"${DIR_RES_FIG}/compare_pagerank_size_1.eps" ///
	"${DIR_RES_FIG}/compare_pagerank_size_2.eps" ///
	"${DIR_RES_FIG}/compare_poaching_size_1.eps" ///
	"${DIR_RES_FIG}/compare_poaching_size_2.eps" ///
	"${DIR_RES_TAB}/tab_R1_pagerank.tex" ///
	"${DIR_RES_TAB}/tab_kob_log_w_pi_x_pageranks.tex" ///
	"${DIR_RES_TAB}/tab_R2_hetdelta.tex" ///
	"${DIR_RES_TAB}/tab_kob_log_w_pi_x_delta.tex" ///
	"${DIR_RES_TAB}/tab_R2_eta_a_robustness.tex" ///
	"${DIR_RES_TAB}/tab_kob_log_w_pi_x_eta_a_h.tex" ///
	"${DIR_RES_TAB}/tab_kob_log_w_pi_x_eta_a_d.tex" ///
	///
	/// F_appendix_structure.tex:
	"${DIR_RES_TAB}/tab_kob_log_pi_tilde.tex" ///
	"${DIR_RES_TAB}/tab_kob_log_x.tex" ///
	"${DIR_RES_FIG}/fig_amenities_wedges.eps" ///
	"${DIR_RES_FIG}/fig_public_share_ladder_m.eps" ///
	"${DIR_RES_FIG}/fig_public_share_ladder_f.eps" ///
	"${DIR_RES_TAB}/tab_kob_log_w_pi_x_pri.tex" ///
	"${DIR_RES_TAB}/tab_kob_log_w_pi_x_pub.tex" ///
	"${DIR_RES_FIG}/fig_prod_ranks.eps" ///
	"${DIR_RES_FIG}/fig_log_p_f_log_p_m.eps" ///
	"${DIR_RES_TXT}/txt_elast_f.tex" ///
	"${DIR_RES_TXT}/txt_elast_m.tex" ///
	"${DIR_RES_TXT}/txt_cf1_change_log_x_m_minus_f.tex" ///
	"${DIR_RES_TXT}/txt_cf1_change_log_w_m_minus_f.tex" ///
	"${DIR_RES_TXT}/txt_cf1_change_log_pi_m.tex" ///
	"${DIR_RES_TXT}/txt_cf2b_change_log_x_m_minus_f.tex" ///
	"${DIR_RES_TXT}/txt_cf2b_change_log_pi_m_minus_f.tex" ///
	"${DIR_RES_TXT}/txt_cf2b_change_log_w_m_minus_f.tex" ///
	"${DIR_RES_TXT}/txt_cf1_change_log_x_f_minus_m.tex" ///
	"${DIR_RES_TXT}/txt_cf1_change_log_w_f.tex" ///
	"${DIR_RES_TXT}/txt_cf1_change_log_pi_f_minus_m.tex" ///
	"${DIR_RES_TXT}/txt_cf2_change_log_pi_f.tex" ///
	"${DIR_RES_TXT}/txt_cf2_change_log_w_f.tex" ///
	"${DIR_RES_TXT}/txt_cf2_change_log_x_f.tex" ///
	"${DIR_RES_FIG}/fig_men_to_women_w.eps" ///
	"${DIR_RES_FIG}/fig_men_to_women_pi.eps" ///
	"${DIR_RES_FIG}/fig_men_to_women_x.eps" ///
	"${DIR_RES_FIG}/fig_women_to_men_w.eps" ///
	"${DIR_RES_FIG}/fig_women_to_men_pi.eps" ///
	"${DIR_RES_FIG}/fig_women_to_men_x.eps" ///
	///
	/// G_appendix_counterfactuals.tex:
	"${DIR_RES_TAB}/tab_counterfactuals_equilibrium_appendix.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_nowedges_output_increase.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_nowedges_amenitiesgap_increase.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_nowedges_utilitygap_decrease.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_utilitygap_baseline.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_nowedges_womenwelfare_increase.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_frictions_wagegap_decrease.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_frictions_utilitygap_decrease.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_genderneutral_output_increase.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_genderneutral_welfare_increase.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_utilitygap_baseline.tex" /// (duplicate)
	"${DIR_RES_TAB}/tab_cf_policy_equalamenities.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_equalamenities_output_decline.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_equalamenities_welfare_decline.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_equalhiring_public_gendergap_decline.tex" ///
	"${DIR_RES_TXT}/txt_model_cf_equalhiring_public_amenitiesgap_increase.tex" ///
	"${DIR_RES_TAB}/tab_cf_policy_equalhiring_public.tex" ///
	{
	foreach dir in ///
		"DIR_RES_FIG" ///
		"DIR_RES_TAB" ///
		"DIR_RES_TXT" ///
		{
		local dir_paper = subinstr("`dir'", "_RES_", "_PAPER_", .)
		local file_paper = subinstr("`file'", "${`dir'}", "${`dir_paper'}", .)
		copy "`file'" "`file_paper'", replace
	}
}

* rename exhibits
// Main exhibit or panel A:
!mv "${DIR_PAPER_FIG}/fig_densities_baseline.eps" "${DIR_PAPER_FIG}/figure1a.eps"
!mv "${DIR_PAPER_FIG}/fig_fit_pay.eps" "${DIR_PAPER_FIG}/figure2a.eps"
!mv "${DIR_PAPER_FIG}/fig_ind_ranks_x_w_m.eps" "${DIR_PAPER_FIG}/figure3a.eps"
!mv "${DIR_PAPER_FIG}/fig_ind_ranks_x_a_m.eps" "${DIR_PAPER_FIG}/figure4a.eps"
!mv "${DIR_PAPER_FIG}/fig_wage_dist.eps" "${DIR_PAPER_FIG}/figure5a.eps"
!mv "${DIR_PAPER_FIG}/fig_comp_ladder_m.eps" "${DIR_PAPER_FIG}/figure6a.eps"
!mv "${DIR_PAPER_FIG}/fig_dist_amenity_shares.eps" "${DIR_PAPER_FIG}/figure7a.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_exp_act_vs_exp_pot_m.eps" "${DIR_PAPER_FIG}/figureA1a.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_akm_hours.eps" "${DIR_PAPER_FIG}/figureB1.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_akm_occ.eps" "${DIR_PAPER_FIG}/figureB2.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_akm_exp_act.eps" "${DIR_PAPER_FIG}/figureB3.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_akm_xb_tenure.eps" "${DIR_PAPER_FIG}/figureB4.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_akm_xb_year_m.eps" "${DIR_PAPER_FIG}/figureB5a.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_akm_xb_age_m.eps" "${DIR_PAPER_FIG}/figureB6a.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_densities_alt_1.eps" "${DIR_PAPER_FIG}/figureB7a.eps"
!mv "${DIR_PAPER_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_1.eps" "${DIR_PAPER_FIG}/figureD1a.eps"
!mv "${DIR_PAPER_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_1.eps" "${DIR_PAPER_FIG}/figureD2a.eps"
!mv "${DIR_PAPER_FIG}/fig_corr_dem_rank_gender_edu_m.eps" "${DIR_PAPER_FIG}/figureD3a.eps"
!mv "${DIR_PAPER_FIG}/fig_kdens_ranks.eps" "${DIR_PAPER_FIG}/figureE1.eps"
!mv "${DIR_PAPER_FIG}/fig_recruiting_unw.eps" "${DIR_PAPER_FIG}/figureE2a.eps"
!mv "${DIR_PAPER_FIG}/fig_productivity_unw.eps" "${DIR_PAPER_FIG}/figureE3a.eps"
!mv "${DIR_PAPER_FIG}/fig_gender_wedge_unw.eps" "${DIR_PAPER_FIG}/figureE4a.eps"
!mv "${DIR_PAPER_FIG}/fig_amenity_cost_shifters_unw.eps" "${DIR_PAPER_FIG}/figureE5a.eps"
!mv "${DIR_PAPER_FIG}/fig_model_fit_w_size_m.eps" "${DIR_PAPER_FIG}/figureE6a.eps"
!mv "${DIR_PAPER_FIG}/compare_pagerank_size_1.eps" "${DIR_PAPER_FIG}/figureE7a.eps"
!mv "${DIR_PAPER_FIG}/fig_amenities_wedges.eps" "${DIR_PAPER_FIG}/figureF1.eps"
!mv "${DIR_PAPER_FIG}/fig_public_share_ladder_m.eps" "${DIR_PAPER_FIG}/figureF2a.eps"
!mv "${DIR_PAPER_FIG}/fig_prod_ranks.eps" "${DIR_PAPER_FIG}/figureF3a.eps"
!mv "${DIR_PAPER_FIG}/fig_men_to_women_w.eps" "${DIR_PAPER_FIG}/figureF4a.eps"
!mv "${DIR_PAPER_TAB}/tab_sum_stats.tex" "${DIR_PAPER_TAB}/table1.tex"
!mv "${DIR_PAPER_TAB}/tab_akm_combined_decomp.tex" "${DIR_PAPER_TAB}/table2.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_w_short.tex" "${DIR_PAPER_TAB}/table3.tex"
!mv "${DIR_PAPER_TAB}/tab_lab_params.tex" "${DIR_PAPER_TAB}/table4.tex"
!mv "${DIR_PAPER_TAB}/tab_reg_productivity.tex" "${DIR_PAPER_TAB}/table5.tex"
!mv "${DIR_PAPER_TAB}/tab_reg_wedges.tex" "${DIR_PAPER_TAB}/table6.tex"
!mv "${DIR_PAPER_TAB}/tab_reg_amenities.tex" "${DIR_PAPER_TAB}/table7.tex"
!mv "${DIR_PAPER_TAB}/tab_economy_wide_parameters_rank5.tex" "${DIR_PAPER_TAB}/table8.tex"
!mv "${DIR_PAPER_TAB}/tab_model_fit.tex" "${DIR_PAPER_TAB}/table9.tex"
!mv "${DIR_PAPER_TAB}/tab_var_pay_decomp.tex" "${DIR_PAPER_TAB}/table10.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_w_pi_x.tex" "${DIR_PAPER_TAB}/table11.tex"
!mv "${DIR_PAPER_TAB}/tab_counterfactuals_equilibrium_main_text.tex" "${DIR_PAPER_TAB}/table12.tex"
!mv "${DIR_PAPER_TAB}/tab_counterfactuals_policies.tex" "${DIR_PAPER_TAB}/table13.tex"
!mv "${DIR_PAPER_TAB}/tab_appendix_a1.tex" "${DIR_PAPER_TAB}/tableA1.tex"
!mv "${DIR_PAPER_TAB}/tab_appendix_a2.tex" "${DIR_PAPER_TAB}/tableA2.tex"
!mv "${DIR_PAPER_TAB}/tab_appendix_a3.tex" "${DIR_PAPER_TAB}/tableA3.tex"
!mv "${DIR_PAPER_TAB}/tab_appendix_a4.tex" "${DIR_PAPER_TAB}/tableA4.tex"
!mv "${DIR_PAPER_TAB}/tab_appendix_a5.tex" "${DIR_PAPER_TAB}/tableA5.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_w.tex" "${DIR_PAPER_TAB}/tableB1.tex"
!mv "${DIR_PAPER_TAB}/tab_montecarlo_100000.tex" "${DIR_PAPER_TAB}/tableD1.tex"
!mv "${DIR_PAPER_TAB}/tab_montecarlo_misspecification_100000_etav2_rho0.tex" "${DIR_PAPER_TAB}/tableD2.tex"
!mv "${DIR_PAPER_TAB}/tab_montecarlo_misspecification_100000_etav2_rho-1.tex" "${DIR_PAPER_TAB}/tableD3.tex"
!mv "${DIR_PAPER_TAB}/tab_montecarlo_misspecification_100000_etav2_rho1.tex" "${DIR_PAPER_TAB}/tableD4.tex"
!mv "${DIR_PAPER_TAB}/tab_corr_m.tex" "${DIR_PAPER_TAB}/tableE1a.tex"
!mv "${DIR_PAPER_TAB}/tab_ranks.tex" "${DIR_PAPER_TAB}/tableE2.tex"
!mv "${DIR_PAPER_TAB}/tab_R1_pagerank.tex" "${DIR_PAPER_TAB}/tableE3.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_w_pi_x_pageranks.tex" "${DIR_PAPER_TAB}/tableE4.tex"
!mv "${DIR_PAPER_TAB}/tab_R2_hetdelta.tex" "${DIR_PAPER_TAB}/tableE5.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_w_pi_x_delta.tex" "${DIR_PAPER_TAB}/tableE6.tex"
!mv "${DIR_PAPER_TAB}/tab_R2_eta_a_robustness.tex" "${DIR_PAPER_TAB}/tableE7.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_w_pi_x_eta_a_h.tex" "${DIR_PAPER_TAB}/tableE8.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_w_pi_x_eta_a_d.tex" "${DIR_PAPER_TAB}/tableE9.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_pi_tilde.tex" "${DIR_PAPER_TAB}/tableF1.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_x.tex" "${DIR_PAPER_TAB}/tableF2.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_w_pi_x_pri.tex" "${DIR_PAPER_TAB}/tableF3.tex"
!mv "${DIR_PAPER_TAB}/tab_kob_log_w_pi_x_pub.tex" "${DIR_PAPER_TAB}/tableF4.tex"
!mv "${DIR_PAPER_TAB}/tab_counterfactuals_equilibrium_appendix.tex" "${DIR_PAPER_TAB}/tableG1.tex"
!mv "${DIR_PAPER_TAB}/tab_cf_policy_equalamenities.tex" "${DIR_PAPER_TAB}/tableG2.tex"
!mv "${DIR_PAPER_TAB}/tab_cf_policy_equalhiring_public.tex" "${DIR_PAPER_TAB}/tableG3.tex"

// Panel B:
!mv "${DIR_PAPER_FIG}/fig_within_baseline.eps" "${DIR_PAPER_FIG}/figure1b.eps"
!mv "${DIR_PAPER_FIG}/fig_fit_size.eps" "${DIR_PAPER_FIG}/figure2b.eps"
!mv "${DIR_PAPER_FIG}/fig_ind_ranks_x_w_f.eps" "${DIR_PAPER_FIG}/figure3b.eps"
!mv "${DIR_PAPER_FIG}/fig_ind_ranks_x_a_f.eps" "${DIR_PAPER_FIG}/figure4b.eps"
!mv "${DIR_PAPER_FIG}/fig_amenity_dist.eps" "${DIR_PAPER_FIG}/figure5b.eps"
!mv "${DIR_PAPER_FIG}/fig_comp_ladder_f.eps" "${DIR_PAPER_FIG}/figure6b.eps"
!mv "${DIR_PAPER_FIG}/fig_amenity_shares_ranks.eps" "${DIR_PAPER_FIG}/figure7b.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_exp_act_vs_exp_pot_f.eps" "${DIR_PAPER_FIG}/figureA1b.eps"




!mv "${DIR_PAPER_FIG}/fig_appendix_akm_xb_year_f.eps" "${DIR_PAPER_FIG}/figureB5b.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_akm_xb_age_f.eps" "${DIR_PAPER_FIG}/figureB6b.eps"
!mv "${DIR_PAPER_FIG}/fig_appendix_within_alt_2.eps" "${DIR_PAPER_FIG}/figureB7b.eps"
!mv "${DIR_PAPER_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_2.eps" "${DIR_PAPER_FIG}/figureD1b.eps"
!mv "${DIR_PAPER_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_2.eps" "${DIR_PAPER_FIG}/figureD2b.eps"
!mv "${DIR_PAPER_FIG}/fig_corr_dem_rank_gender_edu_f.eps" "${DIR_PAPER_FIG}/figureD3b.eps"

!mv "${DIR_PAPER_FIG}/fig_recruiting_w.eps" "${DIR_PAPER_FIG}/figureE2b.eps"
!mv "${DIR_PAPER_FIG}/fig_productivity_w.eps" "${DIR_PAPER_FIG}/figureE3b.eps"
!mv "${DIR_PAPER_FIG}/fig_gender_wedge_w.eps" "${DIR_PAPER_FIG}/figureE4b.eps"
!mv "${DIR_PAPER_FIG}/fig_amenity_cost_shifters_w.eps" "${DIR_PAPER_FIG}/figureE5b.eps"
!mv "${DIR_PAPER_FIG}/fig_model_fit_w_size_f.eps" "${DIR_PAPER_FIG}/figureE6b.eps"
!mv "${DIR_PAPER_FIG}/compare_pagerank_size_2.eps" "${DIR_PAPER_FIG}/figureE7b.eps"

!mv "${DIR_PAPER_FIG}/fig_public_share_ladder_f.eps" "${DIR_PAPER_FIG}/figureF2b.eps"
!mv "${DIR_PAPER_FIG}/fig_log_p_f_log_p_m.eps" "${DIR_PAPER_FIG}/figureF3b.eps"
!mv "${DIR_PAPER_FIG}/fig_men_to_women_pi.eps" "${DIR_PAPER_FIG}/figureF4b.eps"























!mv "${DIR_PAPER_TAB}/tab_corr_f.tex" "${DIR_PAPER_TAB}/tableE1b.tex"
















// Panel C:














!mv "${DIR_PAPER_FIG}/fig_appendix_densities_alt_2.eps" "${DIR_PAPER_FIG}/figureB7c.eps"
!mv "${DIR_PAPER_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_3.eps" "${DIR_PAPER_FIG}/figureD1c.eps"
!mv "${DIR_PAPER_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_3.eps" "${DIR_PAPER_FIG}/figureD2c.eps"
!mv "${DIR_PAPER_FIG}/fig_corr_dem_rank_gender_parent_m.eps" "${DIR_PAPER_FIG}/figureD3c.eps"






!mv "${DIR_PAPER_FIG}/compare_poaching_size_1.eps" "${DIR_PAPER_FIG}/figureE7c.eps"



!mv "${DIR_PAPER_FIG}/fig_men_to_women_x.eps" "${DIR_PAPER_FIG}/figureF4c.eps"























!mv "${DIR_PAPER_TAB}/tab_corr_cross.tex" "${DIR_PAPER_TAB}/tableE1c.tex"
















// Panel D:














!mv "${DIR_PAPER_FIG}/fig_appendix_within_alt_1.eps" "${DIR_PAPER_FIG}/figureB7d.eps"
!mv "${DIR_PAPER_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_4.eps" "${DIR_PAPER_FIG}/figureD1d.eps"
!mv "${DIR_PAPER_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_4.eps" "${DIR_PAPER_FIG}/figureD2d.eps"
!mv "${DIR_PAPER_FIG}/fig_corr_dem_rank_gender_parent_f.eps" "${DIR_PAPER_FIG}/figureD3d.eps"






!mv "${DIR_PAPER_FIG}/compare_poaching_size_2.eps" "${DIR_PAPER_FIG}/figureE7d.eps"



!mv "${DIR_PAPER_FIG}/fig_women_to_men_w.eps" "${DIR_PAPER_FIG}/figureF4d.eps"








































// Panel E:















!mv "${DIR_PAPER_FIG}/fig_MC_scatter_ahat_vs_a_FOCs_100000_5.eps" "${DIR_PAPER_FIG}/figureD1e.eps"
!mv "${DIR_PAPER_FIG}/fig_MC_scatter_phat_vs_p_FOCs_100000_5.eps" "${DIR_PAPER_FIG}/figureD2e.eps"
!mv "${DIR_PAPER_FIG}/fig_corr_dem_rank_gender_yob_m.eps" "${DIR_PAPER_FIG}/figureD3e.eps"










!mv "${DIR_PAPER_FIG}/fig_women_to_men_pi.eps" "${DIR_PAPER_FIG}/figureF4e.eps"








































// Panel F:

















!mv "${DIR_PAPER_FIG}/fig_corr_dem_rank_gender_yob_f.eps" "${DIR_PAPER_FIG}/figureD3f.eps"










!mv "${DIR_PAPER_FIG}/fig_women_to_men_x.eps" "${DIR_PAPER_FIG}/figureF4f.eps"








































* delete unused exhibits
foreach dir in ///
	"${DIR_RES_FIG}" ///
	"${DIR_RES_TAB}" ///
	"${DIR_RES_TXT}" ///
	"${DIR_RES}" ///
	{
	if inlist("`=c(os)'", "MacOSX", "Unix") {
		!rm -rf "`dir'"
	}
	else if "`=c(os)'" == "Windows" {
		shell rmdir /s /q "`dir'"
	}
}


*** compile paper from LaTeX source files to PDF file
* prepare
local texfile = "MM2025.tex" // define source file name and location
local texfile_noext = subinstr("`texfile'", ".tex", "", .)
local texfile_appendix = "`texfile_noext'_appendix"
cd "${DIR_PAPER}" // change working directory to the .tex location

* compile
if inlist("`=c(os)'", "MacOSX") {
	!${APP_PDFLATEX} -interaction=nonstopmode -halt-on-error "`texfile'" // compile LaTeX file
	!${APP_BIBTEX} "`texfile_noext'" // compile main paper's BibTex file
	if $app_refs {
		!${APP_BIBTEX} "`texfile_appendix'" // compile supplemental appendix's BibTex file
	}
	!${APP_PDFLATEX} -interaction=nonstopmode -halt-on-error "`texfile'" // compile LaTeX file
	!${APP_PDFLATEX} -interaction=nonstopmode -halt-on-error "`texfile'" // compile LaTeX file

}
else if inlist("`=c(os)'", "Unix") {
	if $app_refs {
		!${APP_LATEX} "`texfile_noext'" && ${APP_BIBTEX} "`texfile_noext'" && ${APP_BIBTEX} "`texfile_appendix'" && ${APP_LATEX} "`texfile_noext'" && ${APP_LATEX} "`texfile_noext'"
	}
	else {
		!${APP_LATEX} "`texfile_noext'" && ${APP_BIBTEX} "`texfile_noext'" && ${APP_LATEX} "`texfile_noext'" && ${APP_LATEX} "`texfile_noext'"
	}
	!${APP_DVIPS} -Ppdf -o "`texfile_noext'.ps" "`texfile_noext'.dvi"
	!${APP_PS2PDF} "`texfile_noext'.ps" "`texfile_noext'.pdf"
}
else if "`=c(os)'" == "Windows" {
	di "USER WARNING: Must manually compile paper source file: ${DIR_PAPER}/`texfile'"
}

* clean up
foreach ext in "aux" "bbl" "blg" "dep" "dvi" "log" "out" "ps" {
	cap n rm "MM2025.`ext'"
}
foreach fig in ///
	"1a" ///
	"1b" ///
	"2a" ///
	"2b" ///
	"3a" ///
	"3b" ///
	"4a" ///
	"4b" ///
	"5a" ///
	"5b" ///
	"6a" ///
	"6b" ///
	"7a" ///
	"7b" ///
	"A1a" ///
	"A1b" ///
	"B1" ///
	"B2" ///
	"B3" ///
	"B4" ///
	"B5a" ///
	"B5b" ///
	"B6a" ///
	"B6b" ///
	"B7a" ///
	"B7b" ///
	"B7c" ///
	"B7d" ///
	"D1a" ///
	"D1b" ///
	"D1c" ///
	"D1d" ///
	"D1e" ///
	"D2a" ///
	"D2b" ///
	"D2c" ///
	"D2d" ///
	"D2e" ///
	"D3a" ///
	"D3b" ///
	"D3c" ///
	"D3d" ///
	"D3e" ///
	"D3f" ///
	"E1" ///
	"E2a" ///
	"E2b" ///
	"E3a" ///
	"E3b" ///
	"E4a" ///
	"E4b" ///
	"E5a" ///
	"E5b" ///
	"E6a" ///
	"E6b" ///
	"E7a" ///
	"E7b" ///
	"E7c" ///
	"E7d" ///
	"F1" ///
	"F2a" ///
	"F2b" ///
	"F3a" ///
	"F3b" ///
	"F4a" ///
	"F4b" ///
	"F4c" ///
	"F4d" ///
	"F4e" ///
	"F4f" ///
	{
		cap n rm "${DIR_PAPER_FIG}/figure`fig'-eps-converted-to.pdf"
	}
cd // reset working directory


*** final housekeeping
* turn timer off
timer off 20

* print final banner
di _newline(5)
timer list 20
local t = r(t20)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_19_COMPILE.do
********************************************************************************

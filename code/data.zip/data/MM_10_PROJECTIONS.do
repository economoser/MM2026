********************************************************************************
* FILE NAME:   MM_10_PROJECTIONS.do
*
* DESCRIPTION: Projects estimates of gender-specific amenities ($a$) and transformed gender wedges ($1 - \tau$) onto observables
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_10_PROJECTIONS"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 11

* set random-number stream
clear rngstream
set rngstream 10

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** macros
* choose which sections to run
global section_merge = 1
global section_amenities = 1
global section_wedges = 1

* covariates
global projections_vars_amenities = "part_time hours_change parental_gen inc_change acc_work sep_fired sep_death size_est"
global projections_vars_wedges = "woman_highest nonrout_manual nonrout_cog_pers hours simples size_est"


*** construct merged data containing estimates and covariates, by gender
if $section_merge {

	* loop through genders
	forval g = 1/2 {
		if `g' == 1 di _newline(15) "*** Gender = Men"
		else if `g' == 2 di _newline(15) "*** Gender = Women"
		
		* load data
		if `g' == 1 local gender_str_short = "m"
		else if `g' == 2 local gender_str_short = "f"
		local var_list = "id_emp size_`gender_str_short' size log_pi_`gender_str_short' p_`gender_str_short' tau"
		use ///
			`var_list' ///
			using "${DIR_TEMP}/post_est.dta", clear
		
		* merge with employer characteristics data
		if $projections_scale == 1 merge 1:1 id_emp using "${DIR_TEMP}/covariates_g`g'.dta", keep(match) nogen
		else if $projections_scale == 2 {
			merge 1:1 id_emp using "${DIR_TEMP}/covariates_standardized_g`g'.dta", keep(match) nogen
			rm "${DIR_TEMP}/covariates_standardized_g`g'.dta"
		}
		
		* rename variables
		rename log_pi_`gender_str_short' log_pi
		rename ind07_5 ind
		foreach var of varlist parental_* {
			local var_name = subinstr("`var'", "_leave", "", .)
			cap rename `var' `var_name'
		}
		
		* generate parental leave generosity variable
		gen byte parental_gen = (parental_dur > 0) if parental_dur < .
		lab var parental_gen "Ind: Parental leave more generous than the average?"
		
		* save data
		order ///
			id_emp ///
			p_`gender_str_short' tau log_pi ///
			muni ind ///
			nonrout_cog_pers nonrout_manual ///
			hours part_time hours_change ///
			inc_change ///
			sep_fired sep_death ///
			parental_dur parental_gen acc_work ///
			gender_own_highest ///
			size_est ///
			simples ///
			weight //
		sort id_emp
		prog_comp_desc_sum_save "${DIR_TEMP}/projections_g`g'.dta"
	}
}


*** explaining gender-specific amenities
if $section_amenities {

	* specify covariates in the regression
	local covariates "${projections_vars_amenities}"
	
	* define number of covariates
	local n_covariates: word count `covariates'
	
	* loop through genders
	forval g = 1/2 {
		
		* load data
		use "${DIR_TEMP}/projections_g`g'.dta", clear
		
		* keep only observations with nonmissing key variables
		foreach var of varlist log_pi ind muni id_emp weight {
			qui keep if `var' < .
		}
		
		* define industry-municipality interaction
		if $projections_absorb == 1 {
			local absorb_vars "ind"
		}
		else if $projections_absorb == 2 {
			local absorb_vars "muni"
		}
		else if $projections_absorb == 3 {
			local absorb_vars "ind muni"
		}
		else if $projections_absorb == 4 {
			${gtools}egen long ind_muni = group(ind muni)
			lab var ind_muni "Industry x municipality interaction"
			drop ind muni
			local absorb_vars "ind_muni"
		}
		
		* compute sum of weights
		sum weight, meanonly
		local n_workers = r(sum)
		
		* open postfile
		if $projections_postfile {
			cap postclose postfile_projections_amenities_`g'
			postfile postfile_projections_amenities_`g' str32 absorb_vars str128 covariates str32 var coefficient std_err obs_employers obs_workers r2 r2_within using "${DIR_TEMP}/postfile_projections_amenities_`g'.dta", replace
		}
		
		* run regression with controls
		di as result _newline(1) "...amenities projection with controls for gender `g':"
		reghdfe log_pi c.(`covariates') [aw=weight], a(`absorb_vars') keepsingletons noconstant ${projections_cluster}
		
		* store coefficient estimates
		forval i = 1/`n_covariates' {
			local var: word `i' of `covariates'
			local b_`var'_abs_`g' = _b[`var']
			local se_`var'_abs_`g' = _se[`var']
			local t_`var'_abs_`g' = `b_`var'_abs_`g''/`se_`var'_abs_`g''
			if $projections_postfile post postfile_projections_amenities_`g' ("`absorb_vars'") ("`covariates'") ("`var'") (`b_`var'_abs_`g'') (`se_`var'_abs_`g'') (e(N)) (`n_workers') (e(r2)) (e(r2_within))
		}
		
		* run regression without controls
		di as result _newline(1) "...amenities projection without controls for gender `g':"
		reghdfe log_pi c.(`covariates') [aw=weight], noabsorb keepsingletons noconstant ${projections_cluster}
		
		* store coefficient estimates
		forval i = 1/`n_covariates' {
			local var: word `i' of `covariates'
			local b_`var'_noabs_`g' = _b[`var']
			local se_`var'_noabs_`g' = _se[`var']
			local t_`var'_noabs_`g' = `b_`var'_noabs_`g''/`se_`var'_noabs_`g''
			if $projections_postfile post postfile_projections_amenities_`g' ("") ("`covariates'") ("`var'") (`b_`var'_noabs_`g'') (`se_`var'_noabs_`g'') (e(N)) (`n_workers') (e(r2)) (e(r2_within))
		}
		
		* close postfile
		if $projections_postfile postclose postfile_projections_amenities_`g'
	}
}


*** explaining gender wedges
if $section_wedges {
	
	* define lists of covariates
	local covariates "${projections_vars_wedges}"

	* define number of covariates
	local n_covariates: word count `covariates'

	* append data across genders
	clear
	gen byte gender = .
	forval g = 1/2 {
		append using "${DIR_TEMP}/projections_g`g'.dta"
		replace gender = `g' if gender == .
	}

	* define industry-municipality interaction
	if $projections_absorb == 1 {
		local absorb_vars "ind"
	}
	else if $projections_absorb == 2 {
		local absorb_vars "muni"
	}
	else if $projections_absorb == 3 {
		local absorb_vars "ind muni"
	}
	else if $projections_absorb == 4 {
		${gtools}egen long ind_muni = group(ind muni)
		lab var ind_muni "Industry x municipality interaction"
		drop ind muni
		local absorb_vars "ind_muni"
	}
	
	* compute sum of weights
	sum weight, meanonly
	local n_workers = r(sum)

	* keep only observations with nonmissing variables
	desc
	foreach var in tau `covariates' {
		if "`var'" == "woman_highest" qui keep if gender_own_highest < .
		else qui keep if `var' < .
	}
	
	* transform wedge
	gen float log_one_minus_tau = ln(1 - tau)
	lab var log_one_minus_tau "log(1 - \tau)"

	* generate variable for woman being in highest-paid position
	cap confirm var gender_own_highest, exact
	if !_rc {
		gen float woman_highest = .
		replace woman_highest = 1 - gender_own_highest if gender == 1
		replace woman_highest = gender_own_highest if gender == 2
		lab var woman_highest "Ind: Woman in highest-paid position?"
		drop gender_own_highest
	}
	
	* open postfile
	if $projections_postfile {
		cap postclose postfile_projections_wedges
		postfile postfile_projections_wedges str32 absorb_vars str128 covariates str32 var coefficient std_err obs_employers obs_workers r2 r2_within using "${DIR_TEMP}/postfile_projections_wedges.dta", replace
	}
	
	* run regressions in logarithms with controls
	di as result _newline(1) "...with controls:"
	reghdfe log_one_minus_tau `covariates' [aw=weight], a(`absorb_vars') keepsingletons noconstant ${projections_cluster}
	local N_emp = e(N)/2

	* check results
	forval i = 1/`n_covariates' {
		local var: word `i' of `covariates'
		local b_abs_`var' = _b[`var']
		local se_abs_`var' = _se[`var']
		if $projections_postfile post postfile_projections_wedges ("`absorb_vars'") ("`covariates'") ("`var'") (`b_abs_`var'') (`se_abs_`var'') (`N_emp') (`n_workers') (e(r2)) (e(r2_within))
	}
	
	* run regressions in logarithms without controls
	di as result _newline(1) "...without controls:"
	reghdfe log_one_minus_tau `covariates' [aw=weight], noabsorb keepsingletons noconstant ${projections_cluster}
	
	* check results
	forval i = 1/`n_covariates' {
		local var: word `i' of `covariates'
		local b_noabs_`var' = _b[`var']
		local se_noabs_`var' = _se[`var']
		if $projections_postfile post postfile_projections_wedges ("") ("`covariates'") ("`var'") (`b_noabs_`var'') (`se_noabs_`var'') (`N_emp') (`n_workers') (e(r2)) (e(r2_within))
	}
	
	* close postfile
	if $projections_postfile postclose postfile_projections_wedges
}


*** final housekeeping
* close postfiles
postutil clear

* turn timer off
timer off 11

* print final banner
di _newline(5)
timer list 11
local t = r(t11)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_10_PROJECTIONS.do
********************************************************************************

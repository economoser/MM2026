********************************************************************************
* FILE NAME:   MM_FUN_PROGRAMS.do
*
* DESCRIPTION: Defines user-written programs
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** prepare
* clear all programs from memory
program drop _all


*** define programs
* detect system architecture
program define detect_arch, rclass
    tempfile archtmp
    shell uname -m > "`archtmp'"
    file open f using "`archtmp'", read text
    file read f line
    file close f
    local arch = trim("`line'")
    return local arch "`arch'"
end

* describe, summarize, compress, and save data
program prog_load_data // arguments: `1' = minimum year, `2' = maximum year, `3' = variable list; output: data loaded in memory
	
	// make sure that passed arguments are defined
	forval i = 1/3 {
		if "``i''" == "" {
			di as error "USER ERROR: Argument number `i' passed to -prog_load_data- is not defined."
			error 1
		}
	}
	
	// store passed arguments in local macros
	local y_min = `1' // minimum year
	local y_max = `2' // maximum year
	local vars_list = "`3'" // variable list---e.g., "year id_pers id_emp gender race edu age ind07_5 occ02_6 hours muni hours_year earn_mean_mw"

	// loop through years
	forval y = `y_min'/`y_max' {

		// load data
		use `vars_list' using "${DIR_DATA_RAIS}/rais`y'.dta", clear
		
		// keep only nonmissing observations satisfying selection criteria
		foreach var of varlist * {
			keep if `var' < .
			if "${`var'_min}" != "" { // if a minimum value is set
				if ${`var'_min} < . keep if `var' >= ${`var'_min}
			}
			if "${`var'_max}" != "" { // if a maximum value is set
				if ${`var'_max} < . keep if `var' <= ${`var'_max}
			}
		}

		// save yearly data
		compress
		order `vars_list'
		save "${DIR_TEMP}/temp_load_y`y'_`y_min'_`y_max'.dta", replace
	}

	// append data across years
	clear
	forval y = `y_min'/`y_max' {
		append using "${DIR_TEMP}/temp_load_y`y'_`y_min'_`y_max'.dta", force
		rm "${DIR_TEMP}/temp_load_y`y'_`y_min'_`y_max'.dta"
	}
	compress
end

* describe, summarize, compress, and save data
program prog_comp_desc_sum_save // arguments: `1' = file name; output = saved file
	compress
	desc
	sum, sep(0)
	save "`1'", replace
end

* produce count of how many observations there are before
program prog_count_before
	global N_before_prog = _N
end

* produce count of how many observations there are after
program prog_count_after // optional argument: `1' = string describing the selection criterion
	if "${N_before_prog}" == "" {
		di as error "USER WARNING: Must run -prog_count_before- before running -prog_count_after-."
		error 1
	}
	local sel_crit_str = "`1'"
	local N_before_prog_disp: di %12.0fc ${N_before_prog}
	local N_after_prog = _N
	local N_after_prog_disp: di %12.0fc `N_after_prog'
	local N_change_abs_prog = abs(${N_before_prog} - `N_after_prog')
	local N_change_abs_prog_disp: di %12.0fc `N_change_abs_prog'
	local N_change_abs_perc_prog_disp: di %5.1f 100*`N_change_abs_prog'/${N_before_prog}
	if `N_after_prog' <= $N_before_prog di "--> `sel_crit_str' dropped `N_change_abs_prog_disp' observations (`N_change_abs_perc_prog_disp'%), N_before = `N_before_prog_disp', N_after = `N_after_prog_disp'."
	else di "--> `sel_crit_str' added `N_change_abs_prog_disp' observations (`N_change_abs_perc_prog_disp'%), N_before = `N_before_prog_disp', N_after = `N_after_prog_disp'."
	global N_before_prog = ""
end

* insert comma separator for thousands in strings
program prog_comma_thousands // arguments: `1' = name of string variable, `2' = observation number; output = comma separated thousands in string values
	destring `1', force generate(`1'_num)
	sum `1'_num if _n == `2', meanonly
	local N = r(mean)
	if `N' < . {
		if `N' >= 10^12 replace `1' = substr("`N'", 1, mod(strlen("`N'"), 3)) + "," + substr("`N'", -12, 3) + "," + substr("`N'", -9, 3) + "," + substr("`N'", -6, 3) + "," + substr("`N'", -3, 3) if _n == `2'
		else if `N' >= 10^11 replace `1' = substr("`N'", -12, 3) + "," + substr("`N'", -9, 3) + "," + substr("`N'", -6, 3) + "," + substr("`N'", -3, 3) if _n == `2'
		else if `N' >= 10^9 replace `1' = substr("`N'", 1, mod(strlen("`N'"), 3)) + "," + substr("`N'", -9, 3) + "," + substr("`N'", -6, 3) + "," + substr("`N'", -3, 3) if _n == `2'
		else if `N' >= 10^8 replace `1' = substr("`N'", -9, 3) + "," + substr("`N'", -6, 3) + "," + substr("`N'", -3, 3) if _n == `2'
		else if `N' >= 10^6 replace `1' = substr("`N'", 1, mod(strlen("`N'"), 3)) + "," + substr("`N'", -6, 3) + "," + substr("`N'", -3, 3) if _n == `2'
		else if `N' >= 10^5 replace `1' = substr("`N'", -6, 3) + "," + substr("`N'", -3, 3) if _n == `2'
		else if `N' >= 10^3 replace `1' = substr("`N'", 1, mod(strlen("`N'"), 3)) + "," + substr("`N'", -3, 3) if _n == `2'
		else if `N' >= 10^2 replace `1' = substr("`N'", -3, 3) if _n == `2'
	}
	drop `1'_num
end

* coarsen variables to be included as indicators in AKM regression
program prog_coarsen // arguments: `1' = name of variable to be coarsened; `2' = minimum number of observations in each (coarsened) category
	local var_name = "`1'"
	local N_threshold = `2'
	di "--> coarsening variable `1' up to minimum cell size `N_threshold':"
	sum `var_name', meanonly
	local coarsen_val = 10^ceil(log10(r(max))) - 1 // use as missing code the largest number within the same order of magnitude as the variable's maximum
	if r(min) <= 0 replace `var_name' = `var_name' - r(min) + 1 // ensure categorical variable starts from 1, 2, ...
	cap confirm var gender
	if !_rc {
		if _N < 2147483647 local gtools = "${gtools}"
		else local gtools = ""
		`gtools'levelsof gender, local(gender_list) // Note: The gtools package is subject to a maximum dataset size since "A Stata bug prevents gtools from working with more than 2,147,483,647 observations."
	}
	else local gender_list = "0"
	foreach g of local gender_list {
		di "    ...gender = `g' (0 = not by gender; 1 = male; 2 = female)" // Note: Could add more categories here -- e.g., parents vs. nonparents of each gender.
		if !_rc {
			if _N < 2147483647 local gtools = "${gtools}"
			local gender_var = "gender"
			local gender_cond = "if gender == `g'"
			local gender_cond_add = "& gender == `g'"
		}
		else {
			local gender_var = ""
			local gender_cond = ""
			local gender_cond_add = ""
		}
		local needs_coarsening = 1
		while `needs_coarsening' {
			bys `var_name' `gender_var': gen N = _N `gender_cond'
			sum N `gender_cond', meanonly
			local N_min = r(min)
			local needs_coarsening = (`N_min' < `N_threshold')
			if `needs_coarsening' { // if there exists some category that needs coarsening
				sum N if `var_name' == `coarsen_val' `gender_cond_add', meanonly
				local N_coarsened = r(mean)
				if `N_coarsened' < `N_threshold' { // if the coarsened category itself has too few observations, then merge with the (next) smallest noncoarsened category.
					sum N if `var_name' != `coarsen_val' `gender_cond_add', meanonly
					local N_min = r(min)
					replace `var_name' = `coarsen_val' if N == `N_min' `gender_cond_add'
				}
				else replace `var_name' = `coarsen_val' if N == `N_min' `gender_cond_add' // coarsened category = 999999 // else, if the coarsened category has enough observations, then recode the category with insufficient observations to coarsened value.
			}
			drop N
		}
	}
end

* Kitagawa-Oaxaca-Blinder decomposition
program prog_kob // arguments: `1' = variable to be decomposed (e.g., "log_w")
	// catch arguments
	local var_kob = "`1'"

	// preserve
	preserve
	
	// generate within-firm gender gap
	qui gen float gap = `var_kob'_m - `var_kob'_f
	lab var gap "Within-employer gender gap (m - f)"
	
	// summarize within-firm gender gap
	sum `var_kob'_m [aw=g_m], meanonly
	local mean_m = r(mean)
	sum `var_kob'_f [aw=g_f], meanonly
	local mean_f = r(mean)
	local gap_total = `mean_m' - `mean_f'
	local gap_total_disp: di %4.3f `gap_total'
	qui gen byte dual = (g_m < . & g_f < .)
	lab var dual "Ind: Employs both men and women?"
	qui keep if dual == 1
	drop dual
	sum `var_kob'_m [aw=g_m], meanonly
	local mean_m_dual = r(mean)
	sum `var_kob'_f [aw=g_f], meanonly
	local mean_f_dual = r(mean)
	local gap_total_dual = `mean_m_dual' - `mean_f_dual'
	local gap_total_dual_disp: di %4.3f `gap_total_dual'

	// decomposition 1: using distribution of women to construct within-gap and outcome of men to construct between-gap
	sum gap [aw=g_f], meanonly
	local gap_within_1 = r(mean)
	local gap_within_1_disp: di %4.3f `gap_within_1'
	local gap_within_1_share = 100*`gap_within_1'/`gap_total_dual'
	local gap_within_1_share_disp: di %4.1f `gap_within_1_share'
	sum `var_kob'_m [aw=g_m], meanonly
	local gap_between_1A = r(mean)
	sum `var_kob'_m [aw=g_f], meanonly
	local gap_between_1B = r(mean)
	local gap_between_1 = `gap_between_1A' - `gap_between_1B'
	local gap_between_1_disp: di %4.3f `gap_between_1'
	local gap_between_1_share = 100*`gap_between_1'/`gap_total_dual'
	local gap_between_1_share_disp: di %4.1f `gap_between_1_share'
	assert abs(`gap_total_dual' - `gap_within_1' - `gap_between_1') < 10^-6
	assert abs(100 - `gap_within_1_share' - `gap_between_1_share') < 10^-4
	
	// decomposition 2: using distribution of men to construct within-gap and outcome of women to construct between-gap
	sum gap [aw=g_m], meanonly
	local gap_within_2 = r(mean)
	local gap_within_2_disp: di %4.3f `gap_within_2'
	local gap_within_2_share = 100*`gap_within_2'/`gap_total_dual'
	local gap_within_2_share_disp: di %4.1f `gap_within_2_share'
	sum `var_kob'_f [aw=g_m], meanonly
	local gap_between_2A = r(mean)
	sum `var_kob'_f [aw=g_f], meanonly
	local gap_between_2B = r(mean)	
	local gap_between_2 = `gap_between_2A' - `gap_between_2B'
	local gap_between_2_disp: di %4.3f `gap_between_2'
	local gap_between_2_share = 100*`gap_between_2'/`gap_total_dual'
	local gap_between_2_share_disp: di %4.1f `gap_between_2_share'
	assert abs(`gap_total_dual' - `gap_within_2' - `gap_between_2') < 10^-6
	assert abs(100 - `gap_within_2_share' - `gap_between_2_share') < 10^-4
	
	// show results
	di as text ///
		"   `gap_total_dual_disp' (100.0%) total gender gap in `var_kob'" _newline ///
		" = `gap_within_1_disp' (`gap_within_1_share_disp'%) within + `gap_between_1_disp' (`gap_between_1_share_disp'%) between  [decomposition 2]" _newline ///
		" = `gap_within_2_disp' (`gap_within_2_share_disp'%) within + `gap_between_2_disp' (`gap_between_2_share_disp'%) between  [decomposition 1]"
	
	// saving values in a temp .dta to produce Table 3 (the .dta is removed in MM_16_TABLES.do)
	cap postclose postfile_kob
	qui postfile postfile_kob str32 gender_pay_gap str32 level_pay str32 share_pay str32 level_sorting str32 share_sorting using "${DIR_TEMP}/postfile_kob_`var_kob'.dta", replace
	post postfile_kob ("`gap_total_dual_disp'") ("`gap_within_1_disp'") ("`gap_within_1_share_disp'") ("`gap_between_1_disp'") ("`gap_between_1_share_disp'")
	post postfile_kob ("`gap_total_dual_disp'") ("`gap_within_2_disp'") ("`gap_within_2_share_disp'") ("`gap_between_2_disp'") ("`gap_between_2_share_disp'")
	postclose postfile_kob
		
	// restore
	restore
end


********************************************************************************
* END OF MM_FUN_PROGRAMS.do
********************************************************************************

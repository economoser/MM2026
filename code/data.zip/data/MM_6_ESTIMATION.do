********************************************************************************
* FILE NAME:   MM_6_ESTIMATION.do
*
* DESCRIPTION: Prepares data for the estimation of the structural model.
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_6_ESTIMATION"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 7

* set random-number stream
clear rngstream
set rngstream 6

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** get industry codes for later normalization of gender-specific employer FEs
* load data containing employer IDs and industry codes
prog_load_data $year_min $year_max "id_est ind07_5 ind85_2"

* rename variables
rename id_est id_emp
rename ind07_5 ind
rename ind85_2 ind_2

* keep a single observation per employer ID (i.e., for both genders)
${gtools}collapse ///
	(firstnm) ind ind_2 ///
	, ///
	by(id_emp) fast
lab var ind "Industry code (5 digits, CNAE 2.0 2007)"
lab var ind_2 "Industry code (2 digits, IBGE 1985)"

* save data
order id_emp ind ind_2
sort id_emp
prog_comp_desc_sum_save "${DIR_TEMP}/id_emp_ind.dta"


*** get municipality codes for later analysis
* load data containing employer IDs and industry codes
prog_load_data $year_min $year_max "id_est muni state"

* rename variables
rename id_est id_emp

* keep a single observation per employer ID (i.e., for both genders)
${gtools}collapse ///
	(firstnm) muni state ///
	, ///
	by(id_emp) fast
lab var muni "Municipality"
lab var state "State"

* save data
order id_emp muni state
sort id_emp
prog_comp_desc_sum_save "${DIR_TEMP}/id_emp_muni_state.dta"


*** save data file with firm ID and indicator for public sector
* load data
use ///
	id_emp ind_2 ///
	using "${DIR_TEMP}/id_emp_ind.dta", clear

* create indicator for public sector
gen byte public = .
replace public = 0 if ind_2 != 24 & ind_2 < .
replace public = 1 if ind_2 == 24
lab var public "Ind: Public sector?"
drop ind_2

* save data
order id_emp public
sort id_emp
prog_comp_desc_sum_save "${DIR_TEMP}/id_emp_public.dta"


*** assemble labor market "parameters" and employer-gender estimates
* open postfile
cap postclose postfile_estimation
postfile postfile_estimation ///
	rank_concept ///
	N_norm_firms_m N_norm_firms_f ///
	N_norm_workers_m N_norm_workers_f ///
	fe_mean_m fe_mean_f ///
	fe_mean_diff ///
	using "${DIR_TEMP}/postfile_estimation.dta", replace

* loop through rank concepts
foreach r in 5 7 { // i.e., size (5) and PageRanks (7)
	
	* choose rank concept
	if `r' == 5 local var_rank = "rank_size"
	else if `r' == 7 local var_rank = "rank_pagerank"
	
	
	*** labor market "parameters"
	* load labor market "parameters"
	use ///
		if rank_concept == `r' ///
		using "${DIR_TEMP}/lab_params.dta", clear
	
	* check that this rank concept exists
	if _N > 0 {
		
		* generate variable containing the rank concept as a string
		drop rank_concept
		gen str16 rank_concept = "`var_rank'"
		lab var rank_concept "Rank concept"
		
		* use desired estimate of lambda^E
		if $var_lambda_e == 1 { // use estimate of lambda^E obtained from composite of lambda^G in EE transitions
			drop lambda_e_alt
		}
		else if $var_lambda_e == 2 { // use estimate of lambda^E obtained from combining kappa, lambda^G, and delta
			drop lambda_e
			rename lambda_e_alt lambda_e
		}
		
		* save labor market "parameters" for each gender
		order ///
			rank_concept ///
			gender ///
			delta ///
			lambda_u ///
			lambda_g ///
			lambda_e ///
			s_g s_e s_e_alt ///
			kappa kappa_alt ///
			u_rate
		sort rank_concept gender
		compress
		prog_comp_desc_sum_save "${DIR_TEMP}/lab_params_rank_concept_`r'.dta"
		
		
		*** employer-gender pay estimates
		* load employer-gender estimates
		if `r' == 7 {
			use ///
				id_emp gender fe_emp hires_NE size pagerank `var_rank' ///
				using "${DIR_TEMP}/ranks.dta", clear
			rename pagerank cardinality
		}
		else {
			use ///
				id_emp gender fe_emp hires_NE size `var_rank' ///
				using "${DIR_TEMP}/ranks.dta", clear
			gen double cardinality = size
		}
		lab var cardinality "Cardinality of a firm in the employment distribution"
		
		* generate variable containing the rank concept as a string
		gen str16 rank_concept = "`var_rank'"
		lab var rank_concept "Rank concept"
		
		* rename rank concept
		rename `var_rank' rank
		
		* get industry codes
		merge m:1 id_emp ///
			using "${DIR_TEMP}/id_emp_ind.dta" ///
			, ///
			keepusing(id_emp ind) keep(match) nogen
		
		* define bottom 10% of employer ranks
		gen byte rank_bottom = (rank < 0.10)
		lab var rank_bottom "Ind: Bottom 10% of employer ranks?"
		
		* normalize pay to be = 0 in selected industries for both genders
		forval g = 1/2 {
			sum fe_emp if inlist(ind, ${akm_norm_ind_list}) & rank_bottom == 1 & gender == `g' [aw=cardinality] // CNAE 2.0 (2007) code 56112 = restaurants ("Restaurantes e outros estabelecimentos de serviços de alimentação e bebidas"). Source: https://cnae.ibge.gov.br/?view=classe&tipo=cnae&versao=5&classe=56112
			local N_norm_firms_g`g' = r(N)
			local N_norm_firms_g`g'_disp: di %9.0fc `N_norm_firms_g`g''
			local N_norm_workers_g`g' = r(sum_w)
			local N_norm_workers_g`g'_disp: di %9.0fc `N_norm_workers_g`g''
			local norm_g`g' = r(mean)
			local norm_g`g'_disp: di %4.3f `norm_g`g''
			replace fe_emp = fe_emp - `norm_g`g'' if gender == `g'
			sum fe_emp if gender == `g' [aw=cardinality], meanonly
			local fe_mean_g`g' = r(mean)
			local fe_mean_g`g'_disp: di %4.3f `fe_mean_g`g''
			di _newline (1) "*** rank concept `r', gender `g':"
			di "  --> there are `N_norm_firms_g`g'_disp' near-bottom-ranked employers in selected industries."
			di "  --> mean employer FE among these employers = `norm_g`g'_disp'."
			di "  --> demeaning employer FEs for these employers results in mean normalized employer FE = `fe_mean_g`g'_disp'."
		}
		local fe_mean_diff = `fe_mean_g1' - `fe_mean_g2'
		local fe_mean_diff_disp: di %4.3f `fe_mean_diff'
		di _newline (1) "*** rank concept `r', difference:"
		di "  --> difference (i.e., men - women) in means of normalized employer FEs = `fe_mean_diff_disp'."
		drop ind rank_bottom
		
		* write to postfile
		post postfile_estimation ///
			(`r') ///
			(`N_norm_firms_g1') (`N_norm_firms_g2') ///
			(`N_norm_workers_g1') (`N_norm_workers_g2') ///
			(`fe_mean_g1') (`fe_mean_g2') ///
			(`fe_mean_diff')
		
		* get F and G
		merge 1:1 id_emp gender ///
			using "${DIR_TEMP}/F_G_rank_concept_`r'.dta" ///
			, ///
			keep(match) keepusing(F G) nogen
		
		* save employer-gender estimates
		order ///
			rank_concept ///
			id_emp ///
			gender ///
			fe_emp ///
			hires_NE ///
			size ///
			cardinality ///
			rank ///
			F ///
			G
		sort rank_concept id_emp gender
		prog_comp_desc_sum_save "${DIR_TEMP}/employers_rank_concept_`r'.dta"
		
		
		*** combine files
		* start with file containing employer-gender estimates
		use "${DIR_TEMP}/employers_rank_concept_`r'.dta", clear
		rm "${DIR_TEMP}/employers_rank_concept_`r'.dta"
		
		* merge in file containing labor market "parameters"
		merge m:1 gender ///
			using "${DIR_TEMP}/lab_params_rank_concept_`r'.dta" ///
			, ///
			keepusing(delta lambda_u lambda_g lambda_e) keep(match) nogen
		
		* merge in industry codes
		merge m:1 id_emp using "${DIR_TEMP}/id_emp_public.dta", keepusing(public) keep(master match) nogen
		
		* save combined data
		order ///
			rank_concept ///
			id_emp ///
			public ///
			gender ///
			fe_emp ///
			hires_NE ///
			size ///
			cardinality ///
			rank ///
			F ///
			G ///
			delta ///
			lambda_u ///
			lambda_g ///
			lambda_e
		sort rank_concept id_emp gender
		compress
		prog_comp_desc_sum_save "${DIR_TEMP}/estimation_rank_concept_`r'.dta"
	}
}

* close postfile
postclose postfile_estimation

* format postfile
use "${DIR_TEMP}/postfile_estimation.dta", clear
lab var rank_concept "Rank concept"
lab def rnk_l ///
	1 "rank_hires_NE" ///
	2 "rank_poaching" ///
	3 "rank_retention" ///
	4 "rank_net" ///
	5 "rank_size" ///
	6 "rank_fe_emp" ///
	7 "rank_pagerank" ///
	, replace
lab val rank_concept rnk_l
lab var N_norm_firms_m "Number of firms in normalization set for men"
lab var N_norm_firms_f "Number of firms in normalization set for women"
lab var N_norm_workers_m "Number of workers in normalization set for men"
lab var N_norm_workers_f "Number of workers in normalization set for women"
lab var fe_mean_m "Mean employer FE in normalization set for men"
lab var fe_mean_f "Mean employer FE in normalization set for women"
lab var fe_mean_diff "Difference (i.e., men - women) in means of normalized employer FEs"

* save formatted postfile
order rank_concept N_norm_firms_m N_norm_firms_f N_norm_workers_m N_norm_workers_f fe_mean_m fe_mean_f fe_mean_diff
sort rank_concept
compress
desc
save "${DIR_TEMP}/postfile_estimation.dta", replace


*** export exogenous model parameters
* create mini-dataset
clear
set obs 1
gen float rho = ${model_rho}
lab var rho "Discount rate"
gen float alpha = ${model_alpha}
lab var alpha "Elasticity of the matching function with respect to vacancies"
if $model_chi != 1 {
	di as error "USER ERROR: Must normize efficiency of the matching function to = 1, or else adjust model codes!"
	error 1
}

* export
order rho alpha
export delim using "${DIR_TEMP}/exogenous_parameters.txt", delim(tab) novarnames replace


*** final housekeeping
* turn timer off
timer off 7

* print final banner
di _newline(5)
timer list 7
local t = r(t7)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_6_ESTIMATION.do
********************************************************************************

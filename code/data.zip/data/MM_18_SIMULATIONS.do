*******************************************************************************
* FILE NAME:   MM_18_SIMULATIONS.do
*
* DESCRIPTION: Runs Monte Carlo and counterfactual model simulations
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** initial housekeeping
* open log file
local log_name = "MM_18_SIMULATIONS"
cap log close `log_name'
log using "${DIR_LOG}/log_${STR_TIME_STAMP}_`log_name'.log", text name(`log_name') replace

* turn timer on
timer on 19

* set random-number stream
clear rngstream
set rngstream 18

* set sort seed
// set sortseed ${sortseed}

* print initial banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di "********************************************************************************"
di "* STARTING `log_name'.do ON `STR_DATE', AT `STR_TIME'."
di "********************************************************************************"
di _newline(5)


*** export counterfactuals to run
* create mini-dataset
clear
set obs 1
gen float cfs_to_run = ${model_cfs_to_run}
lab var cfs_to_run "Counterfactuals to run"

* export
export delim using "${DIR_TEMP}/cfs_to_run.txt", delim(tab) novarnames replace


*** Monte Carlo simulations
* delete results from past runs
cap erase "${DIR_TEMP}/ihavefinished.txt"

* run Monte Carlo simulations
qui cd "${DIR_TEMP}" // set current directory so that MATLAB finds the right folder structure
if inlist("`=c(os)'", "MacOSX", "Unix") {
	!${arch}"${APP_MATLAB}" -nodesktop -nodisplay <"${DIR_DO_MODEL_SOLUTION}/do_simulations.m"
}
else if "`=c(os)'" == "Windows" {
	shell ${arch}"${APP_MATLAB}" -nosplash -r "run('${DIR_DO_MODEL_SOLUTION}/do_simulations.m')"
}
qui cd // reset current directory

* check that the MATLAB job completed successfully
global file_is_missing = 1
while $file_is_missing {
	cap confirm file "${DIR_TEMP}/ihavefinished.txt"
	if _rc {
		sleep 2000
	}
	else {
		erase "${DIR_TEMP}/ihavefinished.txt"
		global file_is_missing = 0
	}
}

* prepare data for importing in MATLAB for the model
use "${DIR_TEMP}/firm_parameters_merged_match${match_F_or_G}_${baseline_rank}_p_pi_z.dta", clear
gen byte only_m = (f_m > 0 & f_m < . & f_f == .)
gen byte only_f = (f_f > 0 & f_f < . & f_m == .)
rename p_${baseline_rank}_* p_*
rename ${empid_var} empid
keep empid p pi_m pi_f p_* c_m c_f c_pi_m c_pi_f fe_m fe_f f_m f_f F_m F_f g_m g_f only_m only_f eta_v eta_pi public
export delim "${DIR_TEMP}/distribution_data.txt", replace

* prepare labor market parameters
use "${DIR_TEMP}/lab_params_rank_concept_${baseline_rank}.dta", clear
keep gender lambda_e lambda_u delta lambda_g
${gtools}collapse delta lambda_u lambda_e lambda_g, by(gender) fast
foreach g in 1 2 { // 0 = both genders, 1 = men only, 2 = women only
	if `g' == 1 {
		local gender_str = "m"
	}
	else if `g' == 2 {
		local gender_str = "f"
	}
	gen delta_`gender_str' = delta if gender == `g'
	gen lambda_u_`gender_str' = lambda_u if gender == `g' 
	gen lambda_e_`gender_str' = lambda_e if gender == `g' 
	gen lambda_g_`gender_str' = lambda_g if gender == `g' 
}
gen byte indexbase = 1
keep delta_* lambda_u_* lambda_e_* lambda_g_* indexbase
${gtools}collapse delta_* lambda_u_* lambda_e_* lambda_g_*, by(indexbase) fast
drop indexbase
export delim "${DIR_TEMP}/lab_params_data.txt", replace


*** model counterfactuals
* delete results from past runs
cap erase "${DIR_TEMP}/ihavefinished.txt"

* run model counterfactuals
qui cd "${DIR_TEMP}" // set current directory so that MATLAB finds the right folder structure
if inlist("`=c(os)'", "MacOSX", "Unix") {
	!${arch}"${APP_MATLAB}" -nodesktop -nojvm -nodisplay <"${DIR_DO_MODEL_SOLUTION}/do_counterfactuals.m"
}
else if "`=c(os)'" == "Windows" {
	shell ${arch}"${APP_MATLAB}" -nosplash -nojvm -r "run('${DIR_DO_MODEL_SOLUTION}/do_counterfactuals.m')"
}
qui cd // reset current directory

* check that the MATLAB job completed successfully
global file_is_missing = 1
while $file_is_missing {
	cap confirm file "${DIR_TEMP}/ihavefinished.txt"
	if _rc sleep 2000
	else {
		erase "${DIR_TEMP}/ihavefinished.txt"
		global file_is_missing = 0
	}
}


*** final housekeeping
* clean up
if $clean_up {
	rm "${DIR_TEMP}/distribution_data.txt"
}

* turn timer off
timer off 19

* print final banner
di _newline(5)
timer list 19
local t = r(t19)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"

* close log file
cap log close `log_name'


********************************************************************************
* END OF MM_18_SIMULATIONS.do
********************************************************************************

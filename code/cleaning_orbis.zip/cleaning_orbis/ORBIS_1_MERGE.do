********************************************************************************
* FILE NAME:   ORBIS_1_MERGE.do
*
* DESCRIPTION: Merges RAIS with Orbis Historical data based on establishment IDs and firm IDs using both unconsolidated and consolidated accounts
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** 0a. read exchange-rate data
import excel using "${DIR_DATA_FX}/fx_data.xls", firstrow clear
save "${DIR_TEMP}/fx_data.dta", replace


*** 0b. produce employer IDs from RAIS
forval y = $year_min/$year_max {
	use year id_firm id_est using "${DIR_DATA_RAIS}/rais`y'.dta", clear
	${gtools}collapse (firstnm) year id_firm, by(id_est) fast
	save "${DIR_TEMP}/employer_ids`y'.dta", replace
}

*** 1. merge RAIS with Orbis Historical data
clear
forval y = $year_min/$year_max {
	append using "${DIR_TEMP}/employer_ids`y'.dta"
}

* add nonanonimized IDs
nonanonimized_ids
tempfile rais
save `rais' 


*** prepare financials data
* extract archives
!"${APP_UNRAR}" e "${DIR_DATA_ORBIS}/Key_financials.part01.rar" "${DIR_TEMP}/"

* cut data into chunks
chunky using "${DIR_TEMP}/Key_financials.txt", chunksize("1gb") header(include) stub("${DIR_TEMP}/temp_Key_financials_") replace
local chunk_list = s(filelist)

* determine number of chunks
foreach chunk of local chunk_list {
	local N_chunks = real(substr("`chunk'", -8, 4))
}

* read data in chunks
local n_chunk = 1
foreach chunk of local chunk_list {
	disp "...reading data chunk `n_chunk' out of `N_chunks'."
	
	* read data chunks
	import delim using "`chunk'", varnames(1) encoding("utf-8") clear
	rm "`chunk'"
	
	* keep only Brazilian firms
	keep if substr(bvdidnumber, 1, 2) == "BR"
	
	* save data chunk
	compress
	local chunk_dta = substr("`chunk'", 1, strlen("`chunk'") - 3) + "dta"
	save "`chunk_dta'", replace
	local ++n_chunk
}

* append data chunks
clear
foreach chunk of local chunk_list {
	local chunk_dta = substr("`chunk'", 1, strlen("`chunk'") - 3) + "dta"
	append using "`chunk_dta'"
	rm "`chunk_dta'"
}

* clean up
rm "${DIR_TEMP}/Key_financials.txt"

* save data
compress
save "${DIR_TEMP}/temp_bvd_orbis_historical_bra.dta", replace


*** process financials data
* load financials data
use "${DIR_TEMP}/temp_bvd_orbis_historical_bra.dta", clear

* shorten variable names
shortenfinvarnames

* extract numerical part of establishment ID
gen id_est = substr(bvdidnumber, 3, .)
gen id_firm2 = substr(id_est, 1, 8)

* generate year
gen int year = real(substr(string(closingdate, "%8.0f"), 1, 4))
label var year "Year"

* save consolidated statements
preserve
keep if (consolidationcode=="C1" | consolidationcode=="C2" | consolidationcode=="CA2")
tempfile financials_cons
save `financials_cons'

* save unconsolidated statements
restore
keep if (consolidationcode=="U1" | consolidationcode=="U2" | consolidationcode=="UA2")
tempfile financial_uncons
save `financial_uncons'

* merge financials into admin data
use `rais', clear
merge 1:m id_est year using `financial_uncons'

* save results from first merge
rename _merge merge1
tempfile firstmerge
save `firstmerge'

* get list of unmerged observations
keep if merge1==1
keep id_firm year 
rename id_firm id_firm2
bys id_firm2 year: keep if _n==1

* second merge based on firm ID
merge 1:m id_firm2 year using `financials_cons'
keep if _merge==3

* rename financials
ds id_firm2 year, not
foreach var of varlist `r(varlist)' {
	rename `var' `var'_
}
rename id_firm2 id_firm
tempfile secondmerge
save `secondmerge'

* add results from second merge to results from first merge
use `firstmerge', clear
preserve
keep if merge1==1
tempfile unmatchedfirms
save `unmatchedfirms'
keep id_firm year 
duplicates drop id_firm year, force
merge 1:m id_firm year using `secondmerge'
rename _merge merge2
tempfile unmatchedfin
save `unmatchedfin'
use `unmatchedfirms'
joinby id_firm year using `unmatchedfin'
tempfile unmatched
save `unmatched'
restore
drop if merge1==1
append using `unmatched'
gen merge_hyb=merge1
replace merge_hyb=3 if merge2==3

* add financials from merge 2
keep if merge_hyb==3
drop id_est_
ds 
foreach var of varlist `r(varlist)' {
	local x=substr("`var'",1,length("`var'")-1)
	cap replace `x'=`x'_ if merge2==3 & merge1==1
}
* save merged observations 
gen level=""
replace level="merged at establishment level" if merge1==3
replace level="merged at firm level" if merge1==1 & merge_hyb==3
drop id_firm* size* *_ merge* country_code bvdidnumber

* ensure unique financial statement for each establishment-year
// set id_emp var
gen id_emp=id_est
unique_id_emp
drop id_emp
// gen numerical level variable
gen str8 id_firm=substr(id_est,1,8)
encode level, g(leveln) 
drop level 
rename leveln level
// replace id_est="" if level==2
// replace id_firm="" if level==1
// duplicates drop id_firm year if level==2, force old: keeping only one est per firm

* normalize financials to year-level
local tonormalize operatingrevenueturnover plbeforetax plforperiodnetincome cashflow shareholdersfunds
foreach var of varlist `tonormalize' {
	replace `var' = `var'*(numberofmonths/12)*12
}
drop numberofmonths

* normalize units to millions
local tonormalize operatingrevenueturnover plbeforetax plforperiodnetincome cashflow totalassets shareholdersfunds
foreach var of varlist `tonormalize' {
	replace `var'=`var'/(10^6)
	recast float `var'
}

* label employer IDs
cap lab var id_est "Employer ID (establishment, CNPJ/CEI)"
cap lab var id_firm "Employer ID (firm, CNPJ/CEI)"

* add fx data from IMF international financial statistics
merge m:1 year using "${DIR_TEMP}/fx_data.dta"
drop if _merge == 2
drop _merge
rm "${DIR_TEMP}/fx_data.dta"
local tonormalize operatingrevenueturnover plbeforetax plforperiodnetincome cashflow totalassets shareholdersfunds marketcapitalisationmil
foreach var of varlist `tonormalize' {
	replace `var'=`var'*fx_usdBrazil if originalcurrency=="USD"
	replace `var'=`var'*(fx_usdBrazil/fx_usdArgentina) if originalcurrency=="ARS"
	local currentlab: variable label `var'
	lab var `var' "`currentlab' (millions BRL)"
}
lab var operatingrevenueturnover "Operating revenue or turnover (millions BRL)"
lab var plforperiodnetincome "P/L for period or net income (millions BRL)"
lab var marketcapitalisationmil "Market capitalisation (millions BRL)"

drop originalcurrency exchangeratefromoriginalcurren fx*

* drop unneeded variables
drop closingdate originalunits consolidationcode filingtype

* adjust consolidated statements by subtracting unconsolidated statements -- get sum of unconsolidated statements for each firm in Orbis Historical
preserve 
use "${DIR_TEMP}/temp_bvd_orbis_historical_bra.dta", clear
rm "${DIR_TEMP}/temp_bvd_orbis_historical_bra.dta"
drop if consolidationcode=="LF"
gen id_firm=substr(bvdidnumber,3,8)
keep if strpos(consolidationcode,"U")>0
// ensure only have one row per establishment-year observation
gen level=""
rename bvdidnumber id_est
shortenfinvarnames
gen id_emp=id_est
unique_id_emp
drop id_emp
// sum over all establishments within firm
collapse (sum) operatingrevenueturnover plbeforetax plforperiodnetincome cashflow totalassets shareholdersfunds, by(id_firm year)
// rename for merge with matched data
ds id_firm year, not
foreach var of varlist `r(varlist)' {
	rename `var' `var'_adjust
}
tempfile adjustedfin
save `adjustedfin'
restore

* merge into matched data
preserve 
keep if level==2
merge m:1 id_firm year using `adjustedfin'
drop if _merge==2
gen adjusted=cond(_merge==3,1,0)
drop _merge
ds *_adjust
foreach var of varlist `r(varlist)' {
	local _pos = strpos("`var'","_")
	local originalvar = substr("`var'",1,`_pos'-1)
	replace `var' = 0 if missing(`var')
	replace `originalvar' = `originalvar' - `var'
}
drop *_adjust
tempfile adjustedlevel2
save `adjustedlevel2'
restore 
drop if level==2
append using `adjustedlevel2'

* variable for whether statements are adjusted or not 
gen level_new="unconsolidated / establishment"
replace level_new="consolidated / firm" if adjusted==0 & level==2
replace level_new="adjusted / group of establishments" if adjusted==1 & level==2
drop level 
rename level_new level
gen byte level_num=.
replace level_num=1 if level=="unconsolidated / establishment"
replace level_num=2 if level=="consolidated / firm"
replace level_num=3 if level=="adjusted / group of establishments"
label define level 1 "unconsolidated / establishment" 2 "consolidated / firm" 3 "adjusted / group of establishments"
label values level_num level
drop level
rename level_num level
gen byte id_statement_temp=0 if level==3
replace id_statement_temp=1 if level==2
egen id_statement_temp_group=group(id_est) if level==1 // if missing(id_statement_temp)
replace id_statement_temp_group = id_statement_temp_group + 1
replace id_statement_temp=id_statement_temp_group if missing(id_statement_temp)
egen long id_statement = group(id_firm year id_statement_temp)
drop id_statement_temp id_statement_temp_group adjusted

* save all data together
lab var level "Level at which establishment matched"
lab var id_statement "ID for establishment-years with independent financial information"
sort level id_firm id_est year
order id_firm id_est year level id_statement

* add anonimized establishment IDs
preserve
use "${DIR_TEMP}/id_est.dta", clear
gen id_est_padded=string(id_est_original,"%014.0f")
drop id_est_original
rename id_est id_est_deidentified
rename id_est_padded id_est
tempfile id_est
save `id_est'
restore
merge m:1 id_est using `id_est'
drop if _merge==2

drop _merge
compress
drop id_est id_firm
rename id_est_deidentified id_est
sort id_est year
order id_est year level 

* save processed Orbis Historical data
save "${DIR_DATA_ORBIS}/bvd_orbis_historical_bra.dta", replace

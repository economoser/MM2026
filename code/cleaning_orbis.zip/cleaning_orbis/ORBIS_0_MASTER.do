********************************************************************************
* FILE NAME:   ORBIS_0_MASTER.do
*
* DESCRIPTION: Master file for merging the Orbis Historical firm financials data with the Brazilian linked employer-employee data (RAIS)
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        February 12, 2026
********************************************************************************


*** housekeeping
set more off
clear all
macro drop _all 
timer clear 1
timer on 1
set matsize 11000
set seed 20250828
set sortseed 1001XZA112210f4b16c1cb10507a1f38cb440c40003c9a83566fa1201b69ab0aff2f2401e18
set graphics off


*** user-defined directories
global DIR_MAIN = "/root/MM2025_replication" // main directory of the replication package
global DIR_TEMP = "/root/temp_MM2025_replication" // temporary directory
global APP_UNRAR = "/usr/local/bin/unrar" // system handle for UnRAR utility to decompress .rar files


*** automatically set directories
global DIR_DATA = "${DIR_MAIN}/inputs" // inputs directory
	global DIR_DATA_FX = "${DIR_DATA}/fx" // data directory for exchange rates
	global DIR_DATA_ORBIS = "${DIR_DATA}/orbis" // data directory for Orbis Historical
	global DIR_DATA_RAIS = "${DIR_DATA}/rais" // data directory for RAIS
global DIR_DO = "${DIR_MAIN}/code/cleaning_orbis" // code directory
sysdir set PLUS "${DIR_DO}/_stata_packages" // Stata PLUS directory


*** macros
global packages_install = 0 // 0 = do not install Stata packages; 1 = install Stata packages
global gtools = "g" // "" = use Stata-native commands, "g" = use gtools package
global year_min = 2009 // first year of Orbis Historical data
global year_max = 2018 // last year of Orbis Historical data


*** packages
if $packages_install {
	cap n ssc install chunky
	cap n ssc install egenmore
	cap ssc uninstall ftools
	cap ado uninstall ftools
	cap n ssc install ftools // alternatively: cap n net install ftools, from("https://github.com/sergiocorreia/ftools/raw/master/src/")
	cap n ssc install gtools // alternatively: cap n net install gtools, from("https://raw.githubusercontent.com/mcaceresb/stata-gtools/master/build/")
	cap n gtools, upgrade
}


*** programs
* drop old programs
program drop _all

* add non-anonimized firm and establishment IDs
program define nonanonimized_ids 
	
	merge m:1 id_firm using "${DIR_TEMP}/id_firm.dta"
	drop if _merge==2
	drop _merge
	drop id_firm
	rename id_firm_original id_firm
	
	merge m:1 id_est using "${DIR_TEMP}/id_est.dta"
	drop if _merge==2
	drop _merge
	drop id_est
	rename id_est_original id_est

	*pad firm id with 0s to match Orbis ID
	gen id_est_padded=string(id_est,"%014.0f")
	drop id_est id_firm
	rename id_est_padded id_est
	gen id_firm=substr(id_est,1,8)
	
	*generate firm size
	rename N size_est
	bys id_firm year: egen size_firm=sum(size_est)

end

* keep U2/C2 over UA2/CA2
program define unique_id_emp
	
	* loop through consolidation types
	foreach code in "U" "C" {
		local lccode = lower("`code'")
		gen has`lccode'2 = consolidationcode=="`code'2"
		gen has`lccode'a2 = consolidationcode=="`code'A2"
		bys empid year: egen tot`lccode'2 = sum(has`lccode'2)
		bys empid year: egen tot`lccode'a2 = sum(has`lccode'a2)
		gen total`lccode'a2or`lccode'2 = tot`lccode'2 + tot`lccode'a2
		bys empid year (has`lccode'a2): gen n`code'2 = _n
		bys empid year (has`lccode'a2): drop if ((consolidationcode == "`code'A2") & (total`lccode'a2or`lccode'2 > 1) & (n`code'2 > 1))
	}
	
	* keep C1 if both C1 and CA1 available 
	foreach code in "U" "C" {
		local lccode = lower("`code'")
		gen has`lccode'1 = consolidationcode == "`code'1"
		gen has`lccode'a1 = consolidationcode == "`code'A1"
		bys empid year: egen tot`lccode'1 = sum(has`lccode'1)
		bys empid year: egen tot`lccode'a1 = sum(has`lccode'a1)
		gen total`lccode'a1or`lccode'1 = tot`lccode'1 + tot`lccode'a1
		bys empid year (has`lccode'a1): gen n`code'1 = _n
		bys empid year: drop if ((consolidationcode == "`code'A1") & (total`lccode'a1or`lccode'1 > 1) & (n`code'1 > 1))
	}
	
	* keep C1/U1 if both C1/U1 and C2/U2 available (should be the same)
	foreach code in "U" "C" {
		local lccode=lower("`code'")
		gen has`lccode'a2or`lccode'2 = (consolidationcode == "`code'A2" | consolidationcode == "`code'2")
		gen has`lccode'a1or`lccode'1 = (consolidationcode == "`code'A1" | consolidationcode == "`code'1")
		bys empid year: egen tot`lccode'a2`lccode'2 = sum(has`lccode'a2or`lccode'2)
		bys empid year: egen tot`lccode'a1`lccode'1 = sum(has`lccode'a1or`lccode'1)
		bys empid year (has`lccode'a2or`lccode'2): gen n`lccode'_2 = _n
		bys empid year (has`lccode'a2or`lccode'2): drop if ((consolidationcode == "`code'A2" | consolidationcode == "`code'2") & (tot`lccode'a2`lccode'2 > 0) & (tot`lccode'a1`lccode'1 > 0) & (n`lccode'_2 > 1))
	}
	
	* keep annual report if local registry filing also available
	cap bys empid year: egen nfilings = nvals(filingtype)
	cap bys empid year: gen islocalregfil=(filingtype == "Local registry filing")
	bys empid year (islocalregfil): gen nfiling = _n
	bys empid year (islocalregfil): drop if ((nfilings == 2) & (filingtype == "Local registry filing") & (nfiling > 1)) 

	* keep row with least missing fincials data 
	ds empid year, not
	local missing
	foreach var of varlist `r(varlist)' {
		gen m_`var' = cond(missing(`var'),1,0)
		local missing `missing' m_`var'
	}
	egen missing_total = rowtotal(`missing')
	bys empid year: egen min_missing = min(missing_total)
	bys empid year: drop if missing_total != min_missing 
	sort empid year missing_total
	drop hasc* hasu* totalc* totc* totalu* totu* m_* missing_total min_missing nfilings nU* nC* nu_* nc_* islocalregfil nfiling

	* if have multiple closing dates in one year keep the latest one 
	bys empid year (closingdate): drop if _n < _N
end

* shorten financial variable names
program define shortenfinvarnames
	ds
	foreach var of varlist `r(varlist)' {
		local name = substr("`var'", 1, 30)
		rename `var' `name'
	}
end


*** merge Orbis Historical and RAIS datasets
do "${DIR_DO}/ORBIS_1_MERGE.do"


*** final housekeeping
* print final banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di _newline(15)
timer off 1
timer list 1
local t = r(t1)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"
log close _all
clear all

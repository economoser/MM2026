********************************************************************************
* FILE NAME:   RAIS_0_MASTER.do
*
* DESCRIPTION: Master file for cleaning the Brazilian linked employer-employee data (RAIS)
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        February 12, 2026
********************************************************************************


*** initial housekeeping
set more off
clear all
timer clear 1
timer on 1
set seed 20250828
set sortseed 1001XZA112210f4b16c1cb10507a1f38cb440c40003c9a83566fa1201b69ab0aff2f2401e18
set type double
set excelxlsxlargefile on
set graphics off
set varabbrev off
set rmsg on
set matsize 11000
set linesize 100
cap log close _all


*** macros
* user-defined directories
global DIR_MAIN = "/root/MM2025_replication" // main directory of the replication package
global DIR_TEMP = "/root/temp_MM2025_replication" // temporary directory

* set switches
global reread = 1 // 0 = do not re-run READ.do for raw state files that already exist; 1 = re-read everything
global saveold_v = 15 // version of Stata to save data files in
global packages_install = 0 // 0 = do not install Stata packages; 1 = install Stata packages

* define options
global n_cpus = 8 // number of cores to use (4 on Chris' MacBook or MacBook Pro with 2 dual cores; up to 8 on Princeton/Columbia servers)
global server = 1 // 0 = run on local machine; 1 = run on server
global year_min = 1985 // first data year
global year_max = 2018 // last data year
global header = 0 // 0 = read entire dataset; 1 = read header that consists of only variable names and first observation; 2 = use header
global gtools = "g" // "" = use Stata-native commands, "g" = use gtools package

* select parts to run
global DO_READ = 1 // read RAIS data
global DO_CLEAN = 1 // clean RAIS data


*** automated steps
* set processors
global n_cpus = 1 // number of cores to use
set processors `=min(${n_cpus}, `c(processors_max)')'

* automatically set directories
global DIR_DO = "${DIR_MAIN}/code/cleaning_rais" // code directory
global DIR_DATA = "${DIR_MAIN}/inputs" // data directory
	global DIR_DATA_CPI = "${DIR_DATA}/cpi" // price-index data directory
		global FILE_CPI_RAW = "${DIR_DATA_CPI}/IPCA_IPEA_13February2019.xls"
		global FILE_CPI = "${DIR_DATA_CPI}/cpi_bra.dta"
		global FILE_CPI_YEARLY = "${DIR_DATA_CPI}/cpi_bra_yearly.dta"
	global DIR_DATA_IND = "${DIR_DATA}/ind" // industry data directory
		global FILE_IND07_5_TO_IND95_5 = "${DIR_DATA_IND}/ind07_5_to_ind95_5_official.dta"
		global FILE_IND95_5_TO_IND07_5 = "${DIR_DATA_IND}/ind95_5_to_ind07_5_official.dta"
		global FILE_IND85_2_TO_IND95_5 = "${DIR_DATA_IND}/ind85_2_to_ind95_5_official.dta"
		global FILE_IND95_5_TO_IND85_2 = "${DIR_DATA_IND}/ind95_5_to_ind85_2_official.dta"
	global DIR_DATA_MW = "${DIR_DATA}/mw" // minimum-wage data directory
		global FILE_MW_RAW = "${DIR_DATA_MW}/minwage_nominal_IPEA_13February2019.xls"
		global FILE_MW = "${DIR_DATA_MW}/mw_bra.dta"
		global FILE_MW_YEARLY = "${DIR_DATA_MW}/mw_bra_yearly.dta"
	global DIR_DATA_OCC = "${DIR_DATA}/occ" // ocupation data directory
		global FILE_OCC94_5_TO_OCC02_6 = "${DIR_DATA_OCC}/occ94_5_to_occ02_6_official.dta"
		global FILE_OCC02_6_TO_OCC94_5 = "${DIR_DATA_OCC}/occ02_6_to_occ94_5_official.dta"
	global DIR_DATA_RAIS = "${DIR_DATA}/rais" // data directory for cleaned RAIS data
global DIR_LOG = "${DIR_MAIN}/logs" // log directory
sysdir set PLUS "${DIR_DO}/_stata_packages" // Stata packages
global ZIPPER = "${DIR_DO}/_7z/7zz" // 7-Zip software directory

* programs
program drop _all

* packages
if $packages_install {
	cap n ssc install egenmore
	cap ssc uninstall ftools
	cap ado uninstall ftools
	cap n ssc install ftools // alternatively: cap n net install ftools, from("https://github.com/sergiocorreia/ftools/raw/master/src/")
	cap n ssc install gtools // alternatively: cap n net install gtools, from("https://raw.githubusercontent.com/mcaceresb/stata-gtools/master/build/")
	cap n gtools, upgrade
}


*** execute code
log using "${DIR_LOG}/log_RAIS_0_MASTER.log", text replace
disp "********************************************************************************"
disp "********************************************************************************"
disp "* MASTER.do"
disp "********************************************************************************"
disp "********************************************************************************"
disp "STARTING ON $S_DATE AT $S_TIME."
display _newline(5)
if ${DO_READ} do "${DIR_DO}/RAIS_1_READ.do"
if ${DO_CLEAN} do "${DIR_DO}/RAIS_2_CLEAN.do"


*** final housekeeping
* print final banner
local STR_DATE: di upper(string(date("${S_DATE}","DMY"), "%tdMonth_dd,_CCYY"))
local STR_TIME = "${S_TIME}"
di _newline(15)
timer off 1
timer list 1
local t = r(t1)
local STR_DAYS = floor(`t'/86400)
local STR_HOURS = floor((`t' - `STR_DAYS'*86400)/3600)
local STR_MINUTES = floor((`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600)/60)
local STR_SECONDS = round(`t' - `STR_DAYS'*86400 - `STR_HOURS'*3600 - `STR_MINUTES'*60)
di "********************************************************************************"
di "* FINISHED `log_name'.do ON `STR_DATE', AT `STR_TIME' IN A TOTAL OF `STR_DAYS' DAYS, `STR_HOURS' HOURS, `STR_MINUTES' MINUTES, AND `STR_SECONDS' SECONDS."
di "********************************************************************************"
log close _all
clear all

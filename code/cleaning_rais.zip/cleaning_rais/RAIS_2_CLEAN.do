********************************************************************************
* FILE NAME:   RAIS_2_CLEAN.do
*
* DESCRIPTION: Cleans variables and makes them consistent across years
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** create consistent person and employer IDs
* construct mapping from id_pers_cpf (CPF) and id_pers_ctps (CTPS) into id_pers_pis (PIS) for years >= 2002
if $year_min < 2002 global year_min_loop = 2002
else global year_min_loop = ${year_min}
foreach id in "id_pers_cpf" "id_pers_ctps" {
	clear
	forval y = $year_min_loop/$year_max {
		qui append using "${DIR_TEMP}/`y'/read`y'.dta", keep(id_pers_pis `id')
	}
	keep if `id' < . & id_pers_pis < .
	if "${gtools}" == "g" gegen double id_pers_pis_mode = mode(id_pers_pis), maxmode by(`id') // keep only highest-frequency id_pers_pis for every value of `id' (tie breaker: keep highest id_pers_pis)
	else bys `id': egen double id_pers_pis_mode = mode(id_pers_pis), maxmode // keep only highest-frequency id_pers_pis for every value of `id' (tie breaker: keep highest id_pers_pis)
	replace id_pers_pis = id_pers_pis_mode
	drop id_pers_pis_mode
	bys `id': keep if _n == 1
	sort `id' id_pers_pis
	order `id' id_pers_pis
	compress
	saveold "${DIR_TEMP}/`id'_to_id_pers_pis.dta", version(${saveold_v}) replace
}

* replace missing id_pers_pis (PIS) with id_pers_cpf (CPF) or id_pers_ctps (CTPS) from above mapping
forval y = $year_min/$year_max {
	use "${DIR_TEMP}/`y'/read`y'.dta", clear
// 	rm "${DIR_TEMP}/`y'/read`y'.dta"
	if `y' >= 2002 {
		qui merge m:1 id_pers_cpf using "${DIR_TEMP}/id_pers_cpf_to_id_pers_pis.dta", keepusing(id_pers_pis) update keep(master match match_update match_conflict) nogen // replace id_pers_pis (PIS) = . with id_pers_cpf (CPF)
		qui merge m:1 id_pers_ctps using "${DIR_TEMP}/id_pers_ctps_to_id_pers_pis.dta", keepusing(id_pers_pis) update keep(master match match_update match_conflict) nogen // replace id_pers_pis (PIS) = . with id_pers_ctps (CTPS)
		replace id_pers_pis = id_pers_cpf if id_pers_pis == .
		replace id_pers_pis = id_pers_ctps if id_pers_pis == .
		drop id_pers_cpf id_pers_ctps
	}
	rename id_pers_pis id_pers
	label var id_pers "Worker ID (PIS/PASEP/CPF/CTPS)"
	compress
	saveold "${DIR_TEMP}/`y'/clean`y'.dta", version(${saveold_v}) replace
}

* list of numeric person IDs, firm IDs, and establishment IDs
foreach id in "id_pers" "id_firm" "id_est" {
	clear
	forval y = $year_min/$year_max {
		qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(`id')
	}
	rename `id' `id'_original
	keep if `id'_original < .
	bys `id'_original: keep if _n == 1
	gen double `id' = _n
	if "`id'" == "id_pers" label var id_pers "Worker ID (deidentified)"
	else if "`id'" == "id_firm" label var id_firm "Employer ID (firm, deidentified)"
	else if "`id'" == "id_est" label var id_est "Employer ID (establishment, deidentified)"
	compress
	saveold "${DIR_TEMP}/`id'.dta", version(${saveold_v}) replace
	save "${DIR_TEMP}/`id'.dta", replace // save a copy in the replication folder
}

* update IDs and save updated clean files
forval y = $year_min/$year_max {
	use "${DIR_TEMP}/`y'/clean`y'.dta", clear
	foreach id in "id_pers" "id_firm" "id_est" {
		rename `id' `id'_original
		qui merge m:1 `id'_original using "${DIR_TEMP}/`id'.dta", keepusing(`id') keep(master match) nogen // replace original IDs with standardized numerical IDs
		drop `id'_original
		if "`id'" == "id_pers" label var id_pers "Worker ID (deidentified)"
		else if "`id'" == "id_firm" label var id_firm "Employer ID (firm, deidentified)"
		else if "`id'" == "id_est" label var id_est "Employer ID (establishment, deidentified)"
		format `id' %12.0g
	}
	compress
	saveold "${DIR_TEMP}/`y'/clean`y'.dta", version(${saveold_v}) replace
}


*** create and apply industry crosswalks
* use establishment classification and worker-level data to construct industry classification crosswalks from and to ind85_4, ind85_2, ind95_5, ind07_5
foreach ind_source in "85_4" "85_2" "95_5" "07_5" {
	local first = 1
	foreach ind_target in "85_4" "85_2" "95_5" "07_5" {
		if "`ind_source'" != "`ind_target'" {
			foreach t in "target" "source" {
				if "`ind_`t''" == "85_4" {
					local miny_`t' = 1985
					local maxy_`t' = 1994
				}
				else if "`ind_`t''" == "85_2" {
					local miny_`t' = 1985
					local maxy_`t' = 2001
				}
				else if "`ind_`t''" == "95_5" {
					local miny_`t' = 1995 // missing: 2010!
					local maxy_`t' = $year_max
				}
				else if "`ind_`t''" == "07_5" {
					local miny_`t' = 2006
					local maxy_`t' = $year_max
				}
			}
			if inrange(`maxy_source', `miny_target', `maxy_target') | inrange(`maxy_target', `miny_source', `maxy_source') { // if there is overlap between target and source classifications
				local miny_overlap = max(`miny_source', `miny_target')
				local maxy_overlap = min(`maxy_source', `maxy_target')
				clear
				forval y = `miny_overlap'/`maxy_overlap' {
					if !(("`ind_source'" == "95_5" | "`ind_target'" == "95_5") & `y' == 2010) qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(ind`ind_source' ind`ind_target')
				}
				keep if ind`ind_source' < . & ind`ind_target' < .
			}
			else { // else if there is no overlap between target and source classifications
				if `first' { // if first time, load source data containing information on ind_`ind_source'
					clear
					forval y = `miny_source'/`maxy_source' {
						if !("`ind_source'" == "95_5" & `y' == 2010) qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_est ind`ind_source')
					}
					keep if id_est < . & ind`ind_source' < .
					if "${gtools}" == "g" gegen long ind`ind_source'_mode = mode(ind`ind_source'), minmode by(id_est) // determine modal industry for each establishment
					else bys id_est: egen long ind`ind_source'_mode = mode(ind`ind_source'), minmode // determine modal industry for each establishment
					replace ind`ind_source' = ind`ind_source'_mode
					drop ind`ind_source'_mode
					${gtools}collapse (firstnm) ind`ind_source', by(id_est) fast
					compress
					saveold "${DIR_TEMP}/temp_ind`ind_source'.dta", version(${saveold_v}) replace
					local first = 0
				}
				// in any case, merge with target data containing information on `ind_target'
				clear
				forval y = `miny_target'/`maxy_target' {
					if !("`ind_target'" == "95_5" & `y' == 2010) qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_est ind`ind_target')
				}
				keep if id_est < . & ind`ind_target' < .
				qui merge m:1 id_est using "${DIR_TEMP}/temp_ind`ind_source'.dta", keepusing(ind`ind_source') keep(match) nogen
			}
			// compute modal industry correspondence
			if "${gtools}" == "g" gegen long ind`ind_target'_mode = mode(ind`ind_target'), minmode by(ind`ind_source')
			else bys ind`ind_source': egen long ind`ind_target'_mode = mode(ind`ind_target'), minmode
			replace ind`ind_target' = ind`ind_target'_mode
			drop ind`ind_target'_mode
			${gtools}collapse (firstnm) ind`ind_target', by(ind`ind_source') fast
			cap label var ind85_4 "Industry code (4 digits, IBGE 1985)"
			cap label var ind85_2 "Industry code (2 digits, IBGE 1985)"
			cap label var ind95_5 "Industry code (5 digits, CNAE 1995 / CNAE 1.0 2003)"
			cap label var ind07_5 "Industry code (5 digits, CNAE 2.0 2007)"
			sort ind`ind_source' ind`ind_target'
			order ind`ind_source' ind`ind_target'
			sum ind*, sep(0)
			compress
			saveold "${DIR_TEMP}/ind`ind_source'_to_ind`ind_target'.dta", version(${saveold_v}) replace
		}
	}
}
foreach ind_source in "85_4" "85_2" "95_5" "07_5" {
	rm "${DIR_TEMP}/temp_ind`ind_source'.dta"
}

* convert industry classifications and merge into clean files
forval y = $year_min/$year_max {
	use "${DIR_TEMP}/`y'/clean`y'.dta", clear
	if inrange(`y', 1985, 1994) { // data contain: ind85_4, ind85_2
		qui merge m:1 ind85_4 using "${DIR_TEMP}/ind85_4_to_ind85_2.dta", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind85_2 using "${DIR_TEMP}/ind85_2_to_ind85_4.dta", keepusing(ind85_4) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind85_4 using "${DIR_TEMP}/ind85_4_to_ind95_5.dta", keepusing(ind95_5) keep(master match) nogen
		qui merge m:1 ind85_2 using "${FILE_IND85_2_TO_IND95_5}", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_2 using "${DIR_TEMP}/ind85_2_to_ind95_5.dta", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind95_5 using "${FILE_IND95_5_TO_IND07_5}", keepusing(ind07_5) keep(master match) nogen
		qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_4 using "${DIR_TEMP}/ind85_4_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_2 using "${DIR_TEMP}/ind85_2_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind07_5 using "${FILE_IND07_5_TO_IND95_5}", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind07_5 using "${DIR_TEMP}/ind07_5_to_ind95_5.dta", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind95_5 using "${FILE_IND95_5_TO_IND85_2}", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind85_2.dta", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind07_5 using "${DIR_TEMP}/ind07_5_to_ind85_2.dta", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind85_4.dta", keepusing(ind85_4) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind07_5 using "${DIR_TEMP}/ind07_5_to_ind85_4.dta", keepusing(ind85_4) update keep(master match match_update match_conflict) nogen
	}
	else if inrange(`y', 1995, 2001) { // data contain: ind85_2, ind95_5
		qui merge m:1 ind95_5 using "${FILE_IND95_5_TO_IND85_2}", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind85_2.dta", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind85_2 using "${FILE_IND85_2_TO_IND95_5}", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_2 using "${DIR_TEMP}/ind85_2_to_ind95_5.dta", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind95_5 using "${FILE_IND95_5_TO_IND07_5}", keepusing(ind07_5) keep(master match) nogen
		qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_2 using "${DIR_TEMP}/ind85_2_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind07_5 using "${DIR_TEMP}/ind07_5_to_ind85_4.dta", keepusing(ind85_4) keep(master match) nogen
		qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind85_4.dta", keepusing(ind85_4) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_2 using "${DIR_TEMP}/ind85_2_to_ind85_4.dta", keepusing(ind85_4) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind85_4 using "${DIR_TEMP}/ind85_4_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind07_5 using "${DIR_TEMP}/ind07_5_to_ind85_2.dta", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_4 using "${DIR_TEMP}/ind85_4_to_ind85_2.dta", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind07_5 using "${FILE_IND07_5_TO_IND95_5}", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind07_5 using "${DIR_TEMP}/ind07_5_to_ind95_5.dta", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_4 using "${DIR_TEMP}/ind85_4_to_ind95_5.dta", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
	}
	else if `y' >= 2002 { // data contain: ind95_5 (2002-2009, 2011-present), ind07_5 (2006-present)
		if `y' < 2006 {
			qui merge m:1 ind95_5 using "${FILE_IND95_5_TO_IND07_5}", keepusing(ind07_5) keep(master match) nogen
			qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		}
		else if `y' != 2010 {
			qui merge m:1 ind95_5 using "${FILE_IND95_5_TO_IND07_5}", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
			qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		}
		else gen long ind95_5 = .
		
		qui merge m:1 ind07_5 using "${FILE_IND07_5_TO_IND95_5}", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind07_5 using "${DIR_TEMP}/ind07_5_to_ind95_5.dta", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind85_4.dta", keepusing(ind85_4) keep(master match) nogen
		qui merge m:1 ind07_5 using "${DIR_TEMP}/ind07_5_to_ind85_4.dta", keepusing(ind85_4) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind95_5 using "${FILE_IND95_5_TO_IND85_2}", keepusing(ind85_2) keep(master match) nogen
		qui merge m:1 ind95_5 using "${DIR_TEMP}/ind95_5_to_ind85_2.dta", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind07_5 using "${DIR_TEMP}/ind07_5_to_ind85_2.dta", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_4 using "${DIR_TEMP}/ind85_4_to_ind85_2.dta", keepusing(ind85_2) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind85_2 using "${DIR_TEMP}/ind85_2_to_ind85_4.dta", keepusing(ind85_4) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind85_4 using "${DIR_TEMP}/ind85_4_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_2 using "${DIR_TEMP}/ind85_2_to_ind07_5.dta", keepusing(ind07_5) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 ind85_4 using "${DIR_TEMP}/ind85_4_to_ind95_5.dta", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_2 using "${FILE_IND85_2_TO_IND95_5}", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 ind85_2 using "${DIR_TEMP}/ind85_2_to_ind95_5.dta", keepusing(ind95_5) update keep(master match match_update match_conflict) nogen
	}
	sum ind*, sep(0)
	compress
	saveold "${DIR_TEMP}/`y'/clean`y'.dta", version(${saveold_v}) replace
}


*** create and apply occupation crosswalks
* use years with both occupation classifications to create crosswalk between occ94_5_subs and occ02_6
clear
forval y = 2003/2009 { // data contain: occ94_5_subs, occ02_6
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(occ94_5_subs occ02_6)
}
keep if occ94_5_subs < . & occ02_6 < .
bys occ94_5_subs occ02_6: gen long N = _N
preserve
bys occ94_5_subs (N occ02_6): keep if _n == _N // keep only highest-frequency occ02_6 for every value of occ94_5 (tie breaker: keep highest occ02_6 code)
drop N
compress
saveold "${DIR_TEMP}/occ94_5_subs_to_occ02_6.dta", version(${saveold_v}) replace
restore
bys occ02_6 (N occ94_5_subs): keep if _n == _N // keep only highest-frequency occ94_5 for every value of occ02_6 (tie breaker: keep highest occ94_5 code)
drop N
compress
saveold "${DIR_TEMP}/occ02_6_to_occ94_5_subs.dta", version(${saveold_v}) replace

* use workers staying at same employer between 2002 (occ94_5) and 2003 (occ02_6) to create crosswalk between occ94_5 and occ02_6
use year id_firm id_pers occ94_5 using "${DIR_TEMP}/2002/clean2002.dta", clear
qui append using "${DIR_TEMP}/2003/clean2003.dta", keep(year id_firm id_pers occ02_6 hire_year)
drop if (occ94_5 == . & year == 2002) | (occ02_6 == . & year == 2003) | (hire_year == 2003 & year == 2003)
drop hire_year
gen long occ_mix = . // create new variable containing both occupation codes, one in each year 2002 and 2003
replace occ_mix = occ94_5 if year == 2002
replace occ_mix = occ02_6 if year == 2003
drop occ02_6
if "${gtools}" == "g" gegen long occ_mix_mode = mode(occ_mix), maxmode by(id_pers year) // keep only one observation containing modal occupation mix variable per person-year
else bys id_pers year: egen long occ_mix_mode = mode(occ_mix), maxmode // keep only one observation containing modal occupation mix variable per person-year
bys id_pers year: keep if _n == 1
replace occ_mix = occ_mix_mode
drop occ_mix_mode
bys id_pers id_firm (year): gen long occ02_6 = occ_mix[_n + 1] // create new variable containing the value of occ02_6 in first year for all workers who remained at same employer
label var occ02_6 "Occupation code (6 digits, CBO 2002)"
drop if year == 2003 | occ02_6 == . // drop second year since it contains no other useful information
keep occ94_5 occ02_6
preserve
if "${gtools}" == "g" gegen long occ02_6_mode = mode(occ02_6), maxmode by(occ94_5) // keep only one observation containing modal occ02_6 per occ94_5
else bys occ94_5: egen long occ02_6_mode = mode(occ02_6), maxmode // keep only one observation containing modal occ02_6 per occ94_5
bys occ94_5: keep if _n == 1
replace occ02_6 = occ02_6_mode
drop occ02_6_mode
compress
saveold "${DIR_TEMP}/occ94_5_to_occ02_6.dta", version(${saveold_v}) replace
restore
if "${gtools}" == "g" gegen long occ94_5_mode = mode(occ94_5), maxmode by(occ02_6) // keep only one observation containing modal occ94_5 per occ02_6
else bys occ02_6: egen long occ94_5_mode = mode(occ94_5), maxmode // keep only one observation containing modal occ94_5 per occ02_6
bys occ02_6: keep if _n == 1
replace occ94_5 = occ94_5_mode
drop occ94_5_mode
compress
saveold "${DIR_TEMP}/occ02_6_to_occ94_5.dta", version(${saveold_v}) replace

* convert occupation classifications and merge into clean files
forval y = $year_min/$year_max {
	// VARIABLES: occ94_5 (1985-2002), occ94_5_subs (2003-2009), occ02_6 (2003-2018)
	// CROSSWALKS: occ94_5 <--> occ02_6 (x2: official and manually constructed), occ94_5_subs <--> occ02_6
	use "${DIR_TEMP}/`y'/clean`y'.dta", clear
	if inrange(`y', 1985, 2002) { // data contain: occ94_5
		qui merge m:1 occ94_5 using "${FILE_OCC94_5_TO_OCC02_6}", keepusing(occ02_6) keep(master match) nogen
		qui merge m:1 occ94_5 using "${DIR_TEMP}/occ94_5_to_occ02_6.dta", keepusing(occ02_6) update keep(master match match_update match_conflict) nogen
		rename occ94_5 occ94_5_subs
		qui merge m:1 occ94_5_subs using "${DIR_TEMP}/occ94_5_subs_to_occ02_6.dta", keepusing(occ02_6) update keep(master match match_update match_conflict) nogen
		rename occ94_5_subs occ94_5
	}
	else if inrange(`y', 2003, 2009) { // data contain: occ94_5_subs and occ02_6
		qui merge m:1 occ94_5_subs using "${DIR_TEMP}/occ94_5_subs_to_occ02_6.dta", keepusing(occ02_6) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 occ02_6 using "${DIR_TEMP}/occ02_6_to_occ94_5_subs.dta", keepusing(occ94_5_subs) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 occ02_6 using "${FILE_OCC02_6_TO_OCC94_5}", keepusing(occ94_5) keep(master match) nogen
		qui merge m:1 occ02_6 using "${DIR_TEMP}/occ02_6_to_occ94_5.dta", keepusing(occ94_5) update keep(master match match_update match_conflict) nogen
		
		replace occ94_5 = occ94_5_subs if occ94_5 == .
		drop occ94_5_subs
		qui merge m:1 occ94_5 using "${FILE_OCC94_5_TO_OCC02_6}", keepusing(occ02_6) update keep(master match match_update match_conflict) nogen
		qui merge m:1 occ94_5 using "${DIR_TEMP}/occ94_5_to_occ02_6.dta", keepusing(occ02_6) update keep(master match match_update match_conflict) nogen
		
		qui merge m:1 occ02_6 using "${FILE_OCC02_6_TO_OCC94_5}", keepusing(occ94_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 occ02_6 using "${DIR_TEMP}/occ02_6_to_occ94_5.dta", keepusing(occ94_5) update keep(master match match_update match_conflict) nogen
	}
	else { // data contain: occ02_6
		qui merge m:1 occ02_6 using "${FILE_OCC02_6_TO_OCC94_5}", keepusing(occ94_5) keep(master match) nogen
		qui merge m:1 occ02_6 using "${DIR_TEMP}/occ02_6_to_occ94_5.dta", keepusing(occ94_5) update keep(master match match_update match_conflict) nogen
		qui merge m:1 occ02_6 using "${DIR_TEMP}/occ02_6_to_occ94_5_subs.dta", keepusing(occ94_5_subs) keep(master match) nogen
		replace occ94_5 = occ94_5_subs if occ94_5 == .
		drop occ94_5_subs
	}
	sum occ*, sep(0)
	compress
	saveold "${DIR_TEMP}/`y'/clean`y'.dta", version(${saveold_v}) replace
}


*** create consistent variables across years
* race
if $year_min < 2003 global year_min_loop = 2003
else global year_min_loop = ${year_min}
clear
forval y = $year_min_loop/$year_max {
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_pers race)
}
keep if race < .
if "${gtools}" == "g" gegen byte race_mode = mode(race), minmode by(id_pers)
else bys id_pers: egen byte race_mode = mode(race), minmode
replace race = race_mode
drop race_mode
bys id_pers: keep if _n == 1
sort id_pers race
order id_pers race
compress
saveold "${DIR_TEMP}/race.dta", version(${saveold_v}) replace

* gender
clear
forval y = $year_min/$year_max {
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_pers gender)
}
keep if gender < .
if "${gtools}" == "g" gegen byte gender_mode = mode(gender), minmode by(id_pers)
else bys id_pers: egen byte gender_mode = mode(gender), minmode
replace gender = gender_mode
drop gender_mode
bys id_pers: keep if _n == 1
sort id_pers gender
order id_pers gender
compress
saveold "${DIR_TEMP}/gender.dta", version(${saveold_v}) replace

* nationality
clear
forval y = $year_min/$year_max {
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_pers nation)
}
keep if nation < .
if "${gtools}" == "g" gegen byte nation_mode = mode(nation), minmode by(id_pers)
else bys id_pers: egen byte nation_mode = mode(nation), minmode
replace nation = nation_mode
drop nation_mode
bys id_pers: keep if _n == 1
sort id_pers nation
order id_pers nation
compress
saveold "${DIR_TEMP}/nation.dta", version(${saveold_v}) replace

* year immigrated to Brazil
clear
foreach y of numlist 2010/2013 2015/$year_max {
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_pers year_immigr)
}
keep if year_immigr < .
if "${gtools}" == "g" gegen int year_immigr_mode = mode(year_immigr), minmode by(id_pers)
else bys id_pers: egen int year_immigr_mode = mode(year_immigr), minmode
replace year_immigr = year_immigr_mode
drop year_immigr_mode
bys id_pers: keep if _n == 1
sort id_pers year_immigr
order id_pers year_immigr
compress
saveold "${DIR_TEMP}/year_immigr.dta", version(${saveold_v}) replace

* education
clear
forval y = $year_min/$year_max {
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_pers edu)
}
keep if edu < .
if "${gtools}" == "g" gegen byte edu_mode = mode(edu), maxmode by(id_pers)
else bys id_pers: egen byte edu_mode = mode(edu), maxmode
replace edu = edu_mode
drop edu_mode
bys id_pers: keep if _n == 1
sort id_pers edu
order id_pers edu
compress
saveold "${DIR_TEMP}/edu.dta", version(${saveold_v}) replace

* age // NOTE: May have exp = edu_y - age < 0, due to forcing edu and yob to be constant (affects app. 1.7% of observations)!
// Age ranges and how to set "middle" ages:
// age_group = 1 --> "Age 14 or younger" --> middle age = 14
// age_group = 2 --> "Age 15 to 17" --> middle age = 16
// age_group = 3 --> "Age 18 to 24" --> middle age = 21
// age_group = 4 --> "Age 25 to 29" --> middle age = 27
// age_group = 5 --> "Age 30 to 39" --> middle age = 34
// age_group = 6 --> "Age 40 to 49" --> middle age = 44
// age_group = 7 --> "Age 50 to 64" --> middle age = 57
// age_group = 8 --> "Age 65 or older" --> middle age = 65
clear
forval y = $year_min/$year_max {
	if inrange(`y', 1985, 1993) qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(year id_pers age_group)
	else qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(year id_pers age)
}
replace age_group = . if year >= 1994
keep if age_group < . | age < .
bys id_pers year (age_group age): keep if _n == _N | year >= 1994 // keep one (the highest) age group per person-year up to 1994, or arbitrarily many age observations thereafter
bys id_pers (year): gen byte age_group_switch = (year == year[_n - 1] + 1 & age_group == age_group[_n - 1] + 1) if year < 1994
recode age_group (2 = 15) (3 = 18) (4 = 25) (5 = 30) (6 = 40) (7 = 50) (8 = 65) (nonmissing = .), generate(age_switcher)
replace age = age_switcher if age_group_switch == 1
drop age_switcher
recode age_group (1 = 14) (2 = 16) (3 = 21) (4 = 27) (5 = 34) (6 = 44) (7 = 57) (8 = 65) (nonmissing = .), generate(age_nonswitcher)
drop age_group
replace age = age_nonswitcher if age_group_switch == 0
drop age_nonswitcher age_group_switch
gen int yob = year - age
label var yob "Year of birth"
drop year age
keep if yob < .
if "${gtools}" == "g" gegen int yob_mode = mode(yob), minmode by(id_pers)
else bys id_pers: egen int yob_mode = mode(yob), minmode
replace yob = yob_mode
drop yob_mode
bys id_pers: keep if _n == 1
sort id_pers yob
order id_pers yob
compress
saveold "${DIR_TEMP}/yob.dta", version(${saveold_v}) replace

* indicator: ever took parental leave?
clear
forval y = 2007/$year_max {
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_pers abs_reason_1 abs_reason_2 abs_reason_3)
}
keep if abs_reason_1 < . | abs_reason_2 < . | abs_reason_3 < .
gen byte parent_ind = inlist(5, abs_reason_1, abs_reason_2, abs_reason_3) if abs_reason_1 < . | abs_reason_2 < . | abs_reason_3 < .
drop abs_reason_1 abs_reason_2 abs_reason_3
if "${gtools}" == "g" gegen byte parent = max(parent_ind), by(id_pers)
else bys id_pers: egen byte parent = max(parent_ind)
label var parent "Ind: Parental leave during 2007-${year_max}"
label define par_l 0 "Never parent" 1 "Parent", replace
label val parent par_l
drop parent_ind
bys id_pers: keep if _n == 1
sort id_pers parent
order id_pers parent
compress
saveold "${DIR_TEMP}/parent.dta", version(${saveold_v}) replace

* tenure

* establishment and firm foundation year
clear
forval y = $year_min/$year_max {
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(year id_firm id_est tenure)
}
replace tenure = 0 if tenure == .
bys id_est (year): gen int year_est1 = year[1] // earliest year in which establishment is observed
bys id_est year (tenure): gen int max_tenure_years = floor(tenure[_N]/12) // maximum tenure of any employee at this establishment (in years, converted from months)
drop tenure
gen int year_est2 = year - max_tenure_years // earliest year in which a current employee was hired
drop year max_tenure_years
gen int year_est = min(year_est1, year_est2) // take the minimum of the two earliest years (first year observed in data vs. earliest hiring year)
drop year_est1 year_est2
bys id_est (year_est): keep if _n == 1 // keep only lowest establishment foundation year
preserve
keep id_est year_est
sort id_est year_est
order id_est year_est
compress
label var year_est "Establishment foundation year (years, left-censored)"
compress
saveold "${DIR_TEMP}/year_est.dta", version(${saveold_v}) replace
restore
keep id_firm year_est
bys id_firm (year_est): keep if _n == 1 // keep only lowest firm foundation year
rename year_est year_firm
label var year_firm "Firm foundation year (years, left-censored)"
sort id_firm year_firm
order id_firm year_firm
compress
saveold "${DIR_TEMP}/year_firm.dta", version(${saveold_v}) replace

* state and municipality of employer
clear
forval y = $year_min/$year_max {
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_est muni)
}
keep if muni < .
if "${gtools}" == "g" gegen long muni_mode = mode(muni), minmode by(id_est)
else bys id_est: egen long muni_mode = mode(muni), minmode
replace muni = muni_mode
drop muni_mode
bys id_est: keep if _n == 1
gen byte state = floor(muni/10000) if muni > 109999
recode state (11 = 1) (12 = 2) (13 = 3) (14 = 4) (15 = 5) (16 = 6) (17 = 7) ///
	(21 = 8) (22 = 9) (23 = 10) (24 = 11) (25 = 12) (26 = 13) (27 = 14) (28 = 15) (29 = 16) ///
	(31 = 17) (32 = 18) (33 = 19) (35 = 20) ///
	(41 = 21) (42 = 22) (43 = 23) ///
	(50 = 24) (51 = 25) (52 = 26) (53 = 27) (nonmissing = .)
label var state "State of employer"
label define sta_l 1 "Rondonia (RO)" 2 "Acre (AC)" 3 "Amazonas (AM)" 4 "Roraima (RR)" 5 "Para (PA)" 6 "Amapa (AP)" 7 "Tocantins (TO)" ///
	8 "Maranhao (MA)" 9 "Piaui (PI)" 10 "Ceara (CE)" 11 "Rio Grande do Norte (RN)" 12 "Paraiba (PB)" 13 "Pernambuco (PE)" 14 "Alagoas (AL)" 15 "Sergipe (SE)" 16 "Bahia (BA)" ///
	17 "Minas Gerais (MG)" 18 "Espirito Santo (ES)" 19 "Rio de Janeiro (RJ)" 20 "Sao Paulo (SP)" ///
	21 "Parana (PR)" 22 "Santa Catarina (SC)" 23 "Rio Grande do Sul (RS)" ///
	24 "Mato Grosso do Sul (MS)" 25 "Mato Grosso (MT)" 26 "Goias (GO)" 27 "Distrito Federal (DF)", replace
label val state sta_l
sort id_est state muni
order id_est state muni
compress
saveold "${DIR_TEMP}/state_muni.dta", version(${saveold_v}) replace

* industry of employer
clear
forval y = $year_min/$year_max {
	qui append using "${DIR_TEMP}/`y'/clean`y'.dta", keep(id_est ind85_4 ind85_2 ind95_5 ind07_5)
}
keep if ind85_4 < . | ind85_2 < . | ind95_5 < . | ind07_5 < .
foreach var of varlist ind85_4 ind85_2 ind95_5 ind07_5 {
	if "${gtools}" == "g" gegen long `var'_mode = mode(`var'), minmode by(id_est)
	else bys id_est: egen long `var'_mode = mode(`var'), minmode
	replace `var' = `var'_mode
	drop `var'_mode
}
bys id_est: keep if _n == 1
sort id_est ind85_4 ind85_2 ind95_5 ind07_5
order id_est ind85_4 ind85_2 ind95_5 ind07_5
compress
saveold "${DIR_TEMP}/ind.dta", version(${saveold_v}) replace


*** adopt new variables (person IDs, race, gender, nationality, year immigrated to Brazil, education, age, parental leave, occupation, employer IDs, establishment and firm age, state and municipality of employer, industry of employer)
forval y = $year_min/$year_max {
	* load data
	use "${DIR_TEMP}/`y'/clean`y'.dta", clear
	
	* person ID // already done above!
	
	* race
	if `y' < 2003 qui merge m:1 id_pers using "${DIR_TEMP}/race.dta", keepusing(race) keep(master match) nogen
	else qui merge m:1 id_pers using "${DIR_TEMP}/race.dta", keepusing(race) update replace keep(master match match_update match_conflict) nogen
	
	* gender
	qui merge m:1 id_pers using "${DIR_TEMP}/gender.dta", keepusing(gender) update replace keep(master match match_update match_conflict) nogen
	
	* nationality
	qui merge m:1 id_pers using "${DIR_TEMP}/nation.dta", keepusing(nation) update replace keep(master match match_update match_conflict) nogen
	
	* year immigrated to Brazil
	if `y' < 2010 | `y' == 2014 qui merge m:1 id_pers using "${DIR_TEMP}/year_immigr.dta", keepusing(year_immigr) keep(master match) nogen
	else qui merge m:1 id_pers using "${DIR_TEMP}/year_immigr.dta", keepusing(year_immigr) update replace keep(master match match_update match_conflict) nogen
	replace year_immigr = . if year_immigr > year
	
	* education
	qui merge m:1 id_pers using "${DIR_TEMP}/edu.dta", keepusing(edu) update replace keep(master match match_update match_conflict) nogen
	
	* age
	qui merge m:1 id_pers using "${DIR_TEMP}/yob.dta", keepusing(yob) keep(match master) nogen
	replace yob = . if year < yob + 10
	if inrange(`y', 1985, 2001) drop age_group
	if `y' >= 1994 drop age
	gen int age = year - yob
	label var age "Age (years)"
// 	recode age (1/14 = 1) (15/17 = 2) (18/24 = 3) (25/29 = 4) (30/39 = 5) (40/49 = 6) (50/64 = 7) (65/125 = 8) (nonmissing = .), generate(age_group)
// 	label var age_group "Age group"
// 	label define age_l 1 "<=14" 2 "15-17" 3 "18-24" 4 "25-29" 5 "30-39" 6 "40-49" 7 "50-64" 8 ">=65", replace
// 	label val age_group age_l
	
	* parental leave
	qui merge m:1 id_pers using "${DIR_TEMP}/parent.dta", keepusing(parent) keep(match master) nogen
	
	* occupation // already done above!
	
	* employer IDs // already done above!
	
	* tenure
	
	* establishment and firm age
	qui merge m:1 id_est using "${DIR_TEMP}/year_est.dta", keepusing(year_est) keep(match master) nogen
	gen int age_est = year - year_est if year >= year_est
	label var age_est "Establishment age (years, censored)"
	drop year_est
	qui merge m:1 id_firm using "${DIR_TEMP}/year_firm.dta", keepusing(year_firm) keep(match master) nogen
	gen int age_firm = year - year_firm if year >= year_firm
	label var age_firm "Firm age (years, censored)"
	drop year_firm
	
	* state and municipality of employer
	qui merge m:1 id_est using "${DIR_TEMP}/state_muni.dta", keepusing(state muni) update replace keep(master match match_update match_conflict) nogen
	
	* industry of employer
	qui merge m:1 id_est using "${DIR_TEMP}/ind.dta", keepusing(ind85_4 ind85_2 ind95_5 ind07_5) update replace keep(master match match_update match_conflict) nogen
	replace ind07_5 = 99008 if ind07_5 == 0
	
	* month job started
	replace month_hire = 0 if hire_year < year
	
	* month job ended
	replace month_sep = 0 if month_sep < 0 | month_sep >= 13
	
	* months employed in any job during current year
	gen byte months_emp = 0
	sort id_pers
	forval m = 1/12 {
		gen byte month_`m'_emp = .
		replace month_`m'_emp = (hire_year < year & (`m' <= month_sep | month_sep == 0)) if hire_year < . & month_sep < . // person was hired before current year and separated after month `m' of current year
		replace month_`m'_emp = (month_hire <= `m' & (`m' <= month_sep | month_sep == 0)) if month_hire < . & month_sep < . & inlist(month_`m'_emp, 0, .) // person was hired before month `m' of current year and separated after month `m' of current year
		if "${gtools}" == "g" gegen byte month_`m'_emp_max = max(month_`m'_emp), by(id_pers)
		else by id_pers: egen byte month_`m'_emp_max = max(month_`m'_emp)
		drop month_`m'_emp
		replace months_emp = months_emp + month_`m'_emp_max
		drop month_`m'_emp_max
	}
	label var months_emp "Months employed in any job during current year"
	
	* actual work experience (= years recorded in RAIS) // done below!
	
	* hours worked during year in current job
	gen byte months_year = (month_sep == 0)*12 + (month_sep > 0)*month_sep - (hire_year == year)*max(month_hire, 1) - (hire_year < year)*1 + 1 // months worked during current year
	replace months_year = min(months_year, 12) if months_year < .
	gen int hours_year = .
	cap confirm var hours, exact
	if !_rc {
		replace hours = min(hours, 168) if hours < .
		replace hours_year = round(hours*365/7*months_year/12)
		replace hours_year = round(hours*365/7*12/12) if hours_year == .
	}
	replace hours_year = round(44*365/7*months_year/12) if hours_year == .
	replace hours_year = round(44*365/7*12/12) if hours_year == .
	replace hours_year = min(hours_year, 2294) if hours_year < .
	drop months_year
	label var hours_year "Hours worked during year in current job"
	
	* firm size and establishment size
	foreach emp in firm est {
		if "${gtools}" == "g" gegen float size_`emp' = total(hours_year/(44*365/7)), by(id_`emp') // size_`emp' = number of full-time full-year employees, winsorized from below at 1 FTE month
		else bys id_`emp': egen float size_`emp' = total(hours_year/(44*365/7)) // size_`emp' = number of full-time full-year employees, winsorized from below at 1 FTE month
		replace size_`emp' = max(1/12, size_`emp')
	}
	label var size_firm "Firm size (full-time equivalent workers)"
	label var size_est "Establishment size (full-time equivalent workers)"
	
	* Simples tax program
	if `y' >= 2001 {
		if "${gtools}" == "g" gegen byte simples_mode = mode(simples), maxmode missing by(id_est)
		else bys id_est: egen byte simples_mode = mode(simples), maxmode missing
		replace simples = simples_mode
		drop simples_mode
	}
	
	* PAT food program
	if `y' >= 2001 {
		if "${gtools}" == "g" gegen byte pat_mode = mode(pat), maxmode missing by(id_est)
		else bys id_est: egen byte pat_mode = mode(pat), maxmode missing
		replace pat = pat_mode
		drop pat_mode
	}
	
	* conversion factors (minimum wage and CPI)
	foreach file in ///
		"${FILE_MW}" ///
		"${FILE_CPI}" ///
		{
		cap confirm file "`file'"
		if _rc {
			preserve
			do "${DIR_DO}/RAIS_2A_CONVERSION.do"
			restore
		}
	}
	qui merge m:1 year month_hire month_sep using "${FILE_MW}", keep(match master) keepusing(mw) nogen
	recast float mw, force
	compress mw
	qui merge m:1 year month_hire month_sep using "${FILE_CPI}", keep(match master) keepusing(cpi) nogen
	recast float cpi, force
	compress cpi
	
	* population (labor force participation rate, unemployment rate, informality rate) // do not do this here yet!
	
	* unique observation ID
	sort id_firm id_est id_pers earn_mean_mw earn_dec_mw
	gen double id_unique = real("`y'" + string(_n, "%13.0g"))
	label var id_unique "Unique observation ID"
	
	* save
	compress
// 	VARIABLE LIST: year id_pers gender race nation year_immigr edu age yob union muni_worker parent id_firm id_est id_type state muni zip_code ind85_4 ind85_2 ind95_5 ind07_5 size_firm size_est size_est_cat age_firm age_est simples pat legal_form hire_year month_hire month_sep sep_reason months_emp occ94_5 occ02_6 earn_jan earn_feb earn_mar earn_apr earn_may earn_jun earn_jul earn_aug earn_sep earn_oct earn_nov earn_dec earn_dec_mw earn_contr earn_mean earn_mean_mw hours hours_year tenure permit disabil disabil_type contract_type part_time temp_contr pay_freq abs_reason_1 abs_reason_2 abs_reason_3 abs_dur_1 abs_dur_2 abs_dur_3 mw cpi id_unique // age_group
	local varlist_ordered = ""
	foreach var in year id_pers gender race nation year_immigr edu age yob union muni_worker parent id_firm id_est id_type state muni zip_code ind85_4 ind85_2 ind95_5 ind07_5 size_firm size_est size_est_cat age_firm age_est simples pat legal_form hire_year month_hire month_sep sep_reason months_emp occ94_5 occ02_6 earn_jan earn_feb earn_mar earn_apr earn_may earn_jun earn_jul earn_aug earn_sep earn_oct earn_nov earn_dec earn_dec_mw earn_contr earn_mean earn_mean_mw hours hours_year tenure permit disabil disabil_type contract_type part_time temp_contr pay_freq abs_reason_1 abs_reason_2 abs_reason_3 abs_dur_1 abs_dur_2 abs_dur_3 mw cpi id_unique { // age_group
		cap confirm var `var', exact
		if !_rc local varlist_ordered = "`varlist_ordered' `var'"
	}
	order `varlist_ordered'
	desc
	saveold "${DIR_TEMP}/`y'/clean`y'.dta", version(${saveold_v}) replace
}


*** create actual experience from panel
forval y = $year_min/$year_max {
	* create actual experience from previous years' + current year' months of employment
	local y_minus_1 = `y' - 1
	use id_pers tenure months_emp using "${DIR_TEMP}/`y'/clean`y'.dta", clear
	bys id_pers: keep if _n == 1
	if `y' == 1985 gen float exp_act = max(tenure, months_emp) // note: months_emp already contains information on all jobs (i.e., not just one job) held in RAIS during current calendar year
	else {
		local file_exists = 0
		while !`file_exists' {
			cap confirm file "${DIR_TEMP}/exp_act_`y_minus_1'.dta"
			local file_exists = !_rc
			sleep 10000
		}
		merge m:1 id_pers using "${DIR_TEMP}/exp_act_`y_minus_1'.dta", keep(match master using) keepusing(exp_act) nogen // NOTE: exp_act < . <==> was in data in previous years; (months_emp < . | tenure < .) <==> is in data in current year
		replace exp_act = exp_act + months_emp if exp_act < . & months_emp < . // was in data in previous years and in current year
		replace exp_act = max(tenure, months_emp) if exp_act == . & (tenure < . | months_emp < .) // was not in data in previous years but is in data in current year
		// was in data in previous years but is not in data in current year --> leave unchanged
		// was not in data in previous years and is not in data in current year --> not observed
	}
	label var exp_act "Actual experience in formal sector (months)"
	drop tenure months_emp
	desc
	compress
	saveold "${DIR_TEMP}/exp_act_`y'.dta", version(${saveold_v}) replace

	* update clean files
	use "${DIR_TEMP}/`y'/clean`y'.dta", clear
	rm "${DIR_TEMP}/`y'/clean`y'.dta"
	merge m:1 id_pers using "${DIR_TEMP}/exp_act_`y'.dta", keep(match master) keepusing(exp_act) nogen
	local varlist_ordered = ""
	foreach var in year id_pers gender race nation year_immigr edu age yob union muni_worker parent id_firm id_est id_type state muni zip_code ind85_4 ind85_2 ind95_5 ind07_5 size_firm size_est size_est_cat age_firm age_est simples pat legal_form hire_year month_hire month_sep sep_reason months_emp occ94_5 occ02_6 earn_jan earn_feb earn_mar earn_apr earn_may earn_jun earn_jul earn_aug earn_sep earn_oct earn_nov earn_dec earn_dec_mw earn_contr earn_mean earn_mean_mw hours hours_year tenure exp_act permit disabil disabil_type contract_type part_time temp_contr pay_freq abs_reason_1 abs_reason_2 abs_reason_3 abs_dur_1 abs_dur_2 abs_dur_3 mw cpi id_unique { // age_group
		cap confirm var `var', exact
		if !_rc local varlist_ordered = "`varlist_ordered' `var'"
	}
	order `varlist_ordered'
	desc
	compress
	// 	COMPLETE VARIABLE LIST: year id_pers gender race nation year_immigr edu age yob union muni_worker parent id_firm id_est id_type state muni zip_code ind85_4 ind85_2 ind95_5 ind07_5 size_firm size_est size_est_cat age_firm age_est simples pat legal_form hire_year month_hire month_sep sep_reason months_emp occ94_5 occ02_6 earn_jan earn_feb earn_mar earn_apr earn_may earn_jun earn_jul earn_aug earn_sep earn_oct earn_nov earn_dec earn_dec_mw earn_contr earn_mean earn_mean_mw hours hours_year tenure exp_act permit disabil disabil_type contract_type part_time temp_contr pay_freq abs_reason_1 abs_reason_2 abs_reason_3 abs_dur_1 abs_dur_2 abs_dur_3 mw cpi id_unique // age_group
	********************************************************************************
	* Note:
	* 1992-2000: incomes capped at 120*current minimum wage
	* 2001-2014: incomes capped at 150*current minimum wage
	********************************************************************************
	keep year id_pers gender edu race nation parent age id_est ind85_2 ind07_5 state muni simples age_est hours hours_year occ94_5 occ02_6 contract_type tenure exp_act earn_mean_mw earn_mean earn_dec earn_contr month_hire month_sep months_emp abs_reason_1 abs_reason_2 abs_reason_3 abs_dur_1 abs_dur_2 abs_dur_3 sep_reason id_unique
	save "${DIR_DATA_RAIS}/rais`y'.dta", replace
}


disp "DONE!"

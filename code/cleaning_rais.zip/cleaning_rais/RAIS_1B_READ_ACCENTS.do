********************************************************************************
* FILE NAME:   RAIS_1B_READ_ACCENTS.do
*
* DESCRIPTION: Converts letters with accents to regular letters
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** convert accents to letters
* define accents and corresponding letters
local accents "À Á Â Ã Ç É Ê Í Ô Ó Õ Ú à á â ã ç é ê í ô ó õ ú"
local letters "A A A A C E E I O O O U a a a a c e e i o o o u"
local n1: word count `accents'
local n2: word count `letters'
assert `n1' == `n2'

* replace accents with letters in variable names and labels
forval i = 1/`n1' {
	local accent_`i': word `i' of `accents'
	local letter_`i': word `i' of `letters'
	foreach var of varlist * {
		local var_subst = subinstr("`var'", "`accent_`i''", "`letter_`i''", .)
		qui rename `var' `var_subst'
		local var_lab: var label `var_subst'
		local var_lab_subst = subinstr("`var_lab'", "`accent_`i''", "`letter_`i''", .)			
		label var `var_subst' "`var_lab_subst'"
	}
}

********************************************************************************
* FILE NAME:   RAIS_2A_CONVERSION.do
*
* DESCRIPTION: Creates time series of minimum wage and CPI to use as conversion factors
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** nominal minimum wage data downloaded from IPEA data repository (http://www.ipeadata.gov.br/Default.aspx)
* read raw minimum-wage data
import excel using "${FILE_MW_RAW}", clear firstrow
gen int year = real(substr(Data, 1, 4))
label var year "Year"
gen byte month = real(substr(Data,- 2, 2))
drop Data
rename Sal* mw
order year month mw
sort year month
keep if year < . & month < . & mw < .

* reshape to wide
reshape wide mw, i(year) j(month)

* drop if any month mising
drop if inlist(., mw1, mw2, mw3, mw4, mw5, mw6, mw7, mw8, mw9, mw10, mw11, mw12)

* make 13^2 = 169 observations out of every year
expand 169

* create extra months for "stayed from last year" and "staying until next year"
bys year: gen byte month_hire = floor((_n - 1)/13)
label var month_hire "Month job started"
bys year: gen byte month_sep = mod(_n - 1, 13)
label var month_sep "Month of separation"

* create mean MW by month of accession and separation
sort year month_hire month_sep
order year month_hire month_sep
qui sum year
local year_min = r(min)
local year_max = r(max)
local counter = 1
forval y_n = `year_min'/`year_max' {
	forval m1 = 0/12 {
		forval m2 = 0/12 {
			forval m = 1/12 {
				local m_min = max(`m1', 1)
				local m_max = mod(`m2' - 1, 12) + 1
				replace mw`m' = . in `counter' if !inrange(`m', `m_min', `m_max')
			}
			local counter = `counter' + 1
		}
	}
}
drop if ((month_hire > month_sep) & !(month_sep == 0))
egen double mw = rowmean(mw*)
label var mw "Nominal minimum wage (current BRL)"
drop mw1-mw12

* save
compress
saveold "${FILE_MW}", version(${saveold_v}) replace
keep if month_hire == 0 & month_sep == 0
drop month_hire month_sep
label var mw "Nominal minimum wage (current BRL), yearly mean)"
compress
saveold "${FILE_MW_YEARLY}", version(${saveold_v}) replace


*** consumer price index data downloaded from IPEA data repository (http://www.ipeadata.gov.br/Default.aspx)
// for description of IPCA (families earning 1-40 MWs) vs. INPC (families earning 1-5 MWs) see: http://www.ibge.gov.br/home/estatistica/indicadores/precos/inpc_ipca/defaultinpc.shtm
* read raw CPI data
import excel using "${FILE_CPI_RAW}", clear firstrow
gen int year = real(substr(Data, 1, 4))
label var year "Year"
gen byte month = real(substr(Data, 6, 2))
drop Data
rename I* cpi
order year month cpi
sort year month
keep if year < . & month < . & cpi < .

* reshape to wide
reshape wide cpi, i(year) j(month)

* drop if any month mising
drop if inlist(., cpi1, cpi2, cpi3, cpi4, cpi5, cpi6, cpi7, cpi8, cpi9, cpi10, cpi11, cpi12)

* drop early years
drop if year < 1985

* make 13^2 = 169 observations out of every year
expand 169

* create extra months for "stayed from last year" and "staying until next year"
bys year: gen byte month_hire = floor((_n - 1)/13)
bys year: gen byte month_sep = mod(_n - 1, 13)

* create mean CPI by month of accession and separation
sort year month_hire month_sep
order year month_hire month_sep
qui sum year
local year_min = r(min)
local year_max = r(max)
local counter = 1
forval y_n = `year_min'/`year_max' {
	forval m1 = 0/12 {
		forval m2 = 0/12 {
			forval m = 1/12 {
				local m_min = max(`m1', 1)
				local m_max = mod(`m2' - 1, 12) + 1
				replace cpi`m' = . in `counter' if !inrange(`m', `m_min', `m_max')
			}
			local counter = `counter' + 1
		}
	}
}
drop if ((month_hire > month_sep) & !(month_sep == 0))
egen double cpi = rowmean(cpi*)
qui sum cpi if year == 2012 & month_hire == 12 & month_sep == 12
replace cpi = cpi/r(mean)
label var cpi "Consumer price index (December 2012 = 1.0)"
drop cpi1-cpi12

* save
compress
saveold "${FILE_CPI}", version(${saveold_v}) replace
keep if month_hire == 0 & month_sep == 0
drop month_hire month_sep
label var cpi "Consumer price index (December 2012 = 1.0, yearly mean)"
compress
saveold "${FILE_CPI_YEARLY}", version(${saveold_v}) replace

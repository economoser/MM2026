********************************************************************************
* FILE NAME:   RAIS_1A_READ_UNZIP.do
*
* DESCRIPTION: Extracts compressed (.7z or .zip) data files and saves text (.txt) files
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************

*** macros
if "`1'" != "" &  "`2'" != "" {
	local y_min = `1'
	local y_max = `2'
}
else {
	local y_min = $year_min
	local y_max = $year_max
}


*** unzip files
forval y = `y_min'/`y_max' {
	global year = `y'
	local filename_list_1 : dir "${DIR_DATA_RAIS}/${year}/" files "*.7z"
	local filename_list_2 : dir "${DIR_DATA_RAIS}/${year}/" files "*.7Z"
	local filename_list_3 : dir "${DIR_DATA_RAIS}/${year}/" files "*.zip"
	local filename_list_4 : dir "${DIR_DATA_RAIS}/${year}/" files "*.ZIP"
	local filename_list = ""
	foreach filename in `filename_list_1' `filename_list_2' `filename_list_3' `filename_list_4' {
		local filename_list = "`filename_list' `filename'"
	}
	local filename_list: list sort filename_list
	disp "FILELIST = `filename_list'"
	foreach filename in `filename_list' {
		disp  "`filename'"
		if lower(substr("`filename'", 1, 4)) != "estb" {
			!${ZIPPER} e "${DIR_DATA_RAIS}/${year}/`filename'" -o"${DIR_TEMP}/${year}" -y
		}
	}
}

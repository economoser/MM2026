********************************************************************************
* FILE NAME:   RAIS_1C_READ_RENAME.do
*
* DESCRIPTION: Renames and labels variables
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** variables to drop
cap drop bairrossp // neighborhood of Sao Paulo --> not needed
cap drop diadedesligamento // day of separation --> not available in all years
cap drop diadesl // day of separation --> not available in all years
cap drop distritossp // district of Sao Paulo --> not needed
cap drop nome // worker name --> not needed
cap drop nometrabalhador // worker name --> not needed
cap drop razaosocial // employer name --> not needed
cap drop situacaovinculo // status of employment relationship --> not available in all years
cap drop tipoestbid // duplicate variable of tipoestbl --> not needed
cap drop v61 // faulty variable only occurs in sudeste07.TXT --> not needed
cap drop v77 // duplicate variable of chegadabrasil (in 2017 data) --> not needed


*** worker characteristics
* worked ID
cap rename pis id_pers_pis
cap label var id_pers_pis "Worker ID (PIS/PASEP)" // 1985-2018
cap rename cpf id_pers_cpf
cap label var id_pers_cpf "Worker ID (CPF)" // 2002-2018
cap rename numctps id_pers_ctps
cap rename numectps id_pers_ctps
cap rename numeroctps id_pers_ctps
cap label var id_pers_ctps "Worker ID (CTPS)" // 2002-2018

* gender
cap rename genero gender
cap rename sexo gender
cap rename sexotrabalhador gender
cap label var gender "Gender" // 1985-2018

* race
cap rename raca_cor race
cap rename racacor race
cap label var race "Race" // 2003-2018

* nationality
cap rename nacionalidad nation
cap rename nacionalidade nation
cap label var nation "Nationality" // 1985-2018

* education
cap rename escolaridadeapos2005 edu
cap rename grauinstr edu
cap rename grauinstrucao20051985 edu
cap rename grinstrucao edu
cap label var edu "Educational attainment" // 1985-2018

* age
cap rename faixaetaria age_group
cap label var age_group "Age group" // 1985-2001
cap rename idade age
cap label var age "Age (years)" // 1994-2001 and 2011-2018
cap rename datadenascimento dob
cap rename dtnasciment dob
cap label var dob "Date of birth" // 2002-2010 and 2014-2018

* union membership
cap rename indsindical union
cap label var union "Union membership" // 2017

* residence
cap rename muntrab muni_worker
cap label var muni_worker "Municipality of worker's residence" // 2015-2018

* immigration year
cap rename anochegada2 year_immigr
cap rename anochegadabrasil year_immigr
cap label var year_immigr "Year immigrated to Brazil" // 2010-2013 and 2015-2018


*** employer characteristics
* employer ID
cap rename cnpjraiz id_firm
cap rename radiccnpj id_firm
cap label var id_firm "Employer ID (firm, CNPJ/CEI)" // 1985-2018
cap rename cnpjcei id_est
cap rename identificad id_est
cap label var id_est "Employer ID (establishment, CNPJ/CEI)" // 1985-2018
cap rename ceivinc id_cei
cap rename ceivinculado id_cei
cap label var id_cei "Employer ID (firm, CEI)" // 1999-2018
cap rename tipoestab id_type
cap rename tipoestbl id_type
cap label var id_type "Employer ID type" // 1985-2018
cap rename indceivinc cei_link
cap rename indceivinculado cei_link
cap label var cei_link "Ind: Employer ID linked to CEI number" // 1999-2018

* location
cap rename uf state
cap label var state "State of employer" // 1985-2001
cap rename cepestab zip_code
cap label var zip_code "ZIP code of employer" // 2015-2018
cap rename municipio muni
cap label var muni "Municipality of employer" // 1985-2018

* industry
cap rename ibgesubatividade ind85_4
cap label var ind85_4 "Industry code (4 digits, IBGE 1985)" // 1985-1994 (IBGE subatividade, 285 categories)
cap rename ibgesubsetor ind85_2
cap label var ind85_2 "Industry code (2 digits, IBGE 1985)" // 1985-2001 and 2015-2018 (IBGE subsetor, 25 categories)
cap rename clascnae95 ind95_5
cap rename cnae95classe ind95_5
cap label var ind95_5 "Industry code (5 digits, CNAE 1995 / CNAE 1.0 2003)" // 1995-2009 and 2011-2018
cap rename clascnae20 ind07_5
cap rename cnae20classe ind07_5
// cap label var ind07_5 "Industry code (5 digits, CNAE 2.0 2007)" // 2006-2009 and 2011-2018
cap drop ind07_5 // drop because missing in 2010 and can be recovered from ind07_7 in all years 2006-2018
cap rename sbclas20 ind07_7
cap rename cnae20subclasse ind07_7
cap label var ind07_7 "Industry code (7 digits, CNAE 2.0 2007)" // 2006-2018

* size
cap rename tamanhoestabelecimento size_est_cat
cap rename tamestab size_est_cat
cap label var size_est_cat "Establishment size category" // 1985-2018

* Simples tax program
cap rename indsimples simples
cap label var simples "Ind: Employer in Simples tax program?" // 2001-2018

* PAT food program
cap rename indestabparticipapat pat
cap rename indpat pat
cap label var pat "Ind: Employer in PAT food program?" // 2001-2018

* legal form
cap rename natjuridica legal_form
cap rename naturezajuridica legal_form
cap rename naturjur legal_form
cap label var legal_form "Legal form" // 1994-2018


*** job characteristics
* formation
cap rename dataadmissaodeclarada hire_date
cap rename dtadmissao hire_date
cap label var hire_date "Date job started" // 2002-2018
cap rename anoadmissao hire_year
cap label var hire_year "Year job started" // 1985-2001
cap rename mesadmissao month_hire
cap label var month_hire "Month job started" // 1985-2001
cap rename tipoadmissao hire_type
cap rename tipoadm hire_type
// cap label var hire_type "Hire type" // 1994-2018
cap drop hire_type // drop because of breaks in 2000, 2002, 2006, 2010, 2011, missing in most of 2002

* occupation code
cap rename cboocupacao occ94_5 // CBO 1982, data for 1985-1993
cap rename cbo94ocupacao occ94_5 // CBO 1994 (an update to CBO 1982), data for 1994-2001
cap rename ocupacao occ94_5 // CBO 1994 (an update to CBO 1982), data for 2002
cap label var occ94_5 "Occupation code (5 digits, CBO 1982/1994)" // 1985-2002
if ${year} >= 2011 cap drop occ94_5 // drop, since only missing observations from 2011-2018
cap rename ocupacao94 occ94_5_subs // CBO 1994 subset, data for 2003-2009
cap label var occ94_5_subs "Occupation code (5 digits, CBO 1982/1994 subset)" // 2003-2009
cap rename cboocupacao2002 occ02_6
cap rename ocup2002 occ02_6
cap label var occ02_6 "Occupation code (6 digits, CBO 2002)" // 2003-2018

* pay
cap rename ultrem earn_last
cap rename vlultimaremuneracaoano earn_last
// cap label var earn_last "Earnings in last month of employment (current BRL)" // 2002-2018
cap drop earn_last // Note: values of this variable frequently seem to be in wrong units (e.g., /100)
cap rename vlremjaneirocc earn_jan
cap label var earn_jan "Earnings in January (current BRL)" // 2015-2018
cap rename vlremfevereirocc earn_feb
cap label var earn_feb "Earnings in February (current BRL)" // 2015-2018
cap rename vlremmarcocc earn_mar
cap label var earn_mar "Earnings in March (current BRL)" // 2015-2018
cap rename vlremabrilcc earn_apr
cap label var earn_apr "Earnings in April (current BRL)" // 2015-2018
cap rename vlremmaiocc earn_may
cap label var earn_may "Earnings in May (current BRL)" // 2015-2018
cap rename vlremjunhocc earn_jun
cap label var earn_jun "Earnings in June (current BRL)" // 2015-2018
cap rename vlremjulhocc earn_jul
cap label var earn_jul "Earnings in July (current BRL)" // 2015-2018
cap rename vlremagostocc earn_aug
cap label var earn_aug "Earnings in August (current BRL)" // 2015-2018
cap rename vlremsetembrocc earn_sep
cap label var earn_sep "Earnings in September (current BRL)" // 2015-2018
cap rename vlremoutubrocc earn_oct
cap label var earn_oct "Earnings in October (current BRL)" // 2015-2018
cap rename vlremnovembrocc earn_nov
cap label var earn_nov "Earnings in November (current BRL)" // 2015-2018
cap rename vlremundezembronom earn_dec
cap rename remdezr earn_dec
cap label var earn_dec "Earnings in December (current BRL)" // 1999-2018
cap rename vlremundezembrosm earn_dec_mw
cap rename remdezembro earn_dec_mw
cap label var earn_dec_mw "Earnings in December (multiples of MW)" // 1985-2018
cap rename vlsalariocontratual earn_contr
cap rename salcontr earn_contr
cap label var earn_contr "Contractual monthly base salary (current BRL)" // 2002-2018
cap rename vlremunmedianom earn_mean
cap rename remmedr earn_mean
cap label var earn_mean "Mean monthly earnings (current BRL)" // 1999-2018
cap rename vlremunmediasm earn_mean_mw
cap rename remmedia earn_mean_mw
cap label var earn_mean_mw "Mean monthly earnings (multiples of MW)" // 1985-2018

* hours
cap rename qtdhoracontr hours
cap rename horascontr hours
cap label var hours "Contractual work hours" // 1994-2018

* tenure
cap rename tempempr tenure
cap rename tempoemprego tenure
cap label var tenure "Tenure in current job (months)" // 1985-2018

* work permit
cap rename indalvara permit
cap rename indvinculoalvara permit
cap label var permit "Ind: Judicial work permit?" // 2001-2018

* disability
cap rename indportadordefic disabil
cap rename portdefic disabil
cap label var disabil "Ind: Disability?" // 2003-2018
cap rename tpdefic disabil_type
cap rename tipodefic disabil_type
cap label var disabil_type "Disability type" // 2006-2018

* contract
cap rename tipovinculo contract_type
cap rename tpvincl contract_type
cap rename tpvinculo contract_type
cap label var contract_type "Contract type" // 1985-2018
cap rename indtrabparcial part_time
cap label var part_time "Ind: Part-time contract?" // 2017-2018
cap rename indtrabintermitente temp_contr
cap label var temp_contr "Ind: Temporary contract?" // 2017-2018

* payment frequency
cap rename tiposal pay_freq
cap rename tiposalario pay_freq
cap label var pay_freq "Pay frequency" // 2002-2018

* absence
cap rename causaafastamento1 abs_reason_1
cap rename causafast1 abs_reason_1
cap label var abs_reason_1 "Reason for absence 1" // 2007-2018
cap rename causaafastamento2 abs_reason_2
cap rename causafast2 abs_reason_2
cap label var abs_reason_2 "Reason for absence 2" // 2007-2018
cap rename causaafastamento3 abs_reason_3
cap rename causafast3 abs_reason_3
cap label var abs_reason_3 "Reason for absence 3" // 2007-2018
cap rename diainiaf1 abs_start_d_1
cap label var abs_start_d_1 "Day absence 1 started" // 2007-2018
cap rename diainiaf2 abs_start_d_2
cap label var abs_start_d_2 "Day absence 2 started" // 2007-2018
cap rename diainiaf3 abs_start_d_3
cap label var abs_start_d_3 "Day absence 3 started" // 2007-2018
cap rename mesiniaf1 abs_start_m_1
cap label var abs_start_m_1 "Month absence 1 started" // 2007-2018
cap rename mesiniaf2 abs_start_m_2
cap label var abs_start_m_2 "Month absence 2 started" // 2007-2018
cap rename mesiniaf3 abs_start_m_3
cap label var abs_start_m_3 "Month absence 3 started" // 2007-2018
cap rename diafimaf1 abs_end_d_1
cap label var abs_end_d_1 "Day absence 1 ended" // 2007-2018
cap rename diafimaf2 abs_end_d_2
cap label var abs_end_d_2 "Day absence 2 ended" // 2007-2018
cap rename diafimaf3 abs_end_d_3
cap label var abs_end_d_3 "Day absence 3 ended" // 2007-2018
cap rename mesfimaf1 abs_end_m_1
cap label var abs_end_m_1 "Month absence 1 ended" // 2007-2018
cap rename mesfimaf2 abs_end_m_2
cap label var abs_end_m_2 "Month absence 2 ended" // 2007-2018
cap rename mesfimaf3 abs_end_m_3
cap label var abs_end_m_3 "Month absence 3 ended" // 2007-2018
cap rename qtddiasafastamento abs_dur
cap rename qtdiasafas abs_dur
// cap label var abs_dur "Duration of absence (days)" // 2007-2018
cap drop abs_dur // contains only information on total days absent


* separation
cap rename causadesli sep_reason
cap rename motivodesligamento sep_reason
cap label var sep_reason "Reason for separation" // 1985-2018
cap rename mesdeslig month_sep
cap rename mesdesligamento month_sep
cap label var month_sep "Month of separation" // 1985-2018

* job active at end of year
// cap rename empem3112 active_eoy
// cap rename vinculoativo3112 active_eoy
// cap label var active_eoy "Ind: Active at end of year?" // 1985-2018

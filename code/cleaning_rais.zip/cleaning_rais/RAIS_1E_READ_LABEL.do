********************************************************************************
* FILE NAME:   RAIS_1E_READ_LABEL.do
*
* DESCRIPTION: Recodes, formats, and labels variable values
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** macros
global year_minus_100 = ${year} - 100
global year_plus_1 = ${year} + 1
global current_year = real(substr(c(current_date), -4, 4))
global date_max = 3112*10000 + ${current_year}


*** worker characteristics
* worked ID
// id_pers_pis, 1985-2018
cap recode id_pers_pis (-999999999999/0 = .)
cap format id_pers_pis %16.0g
// id_pers_cpf, 2002-2018
cap recode id_pers_cpf (-999999999999/0 = .)
cap format id_pers_cpf %16.0g
// id_pers_ctps, 2002-2018
cap recode id_pers_ctps (-999999999999/0 = .)
cap format id_pers_ctps %16.0g

* immigration year
cap recode year_immigr (-9999/${year_minus_100} ${year_plus_1}/. = 0)
cap label define yim_l 0 "Never immigrated", replace
cap label val year_immigr yim_l // 2010-2013 and 2015-2018

* gender
cap recode gender (1 = 1) (2 = 2) (nonmissing = .)
cap label define gen_l 1 "Male" 2 "Female", replace
cap label val gender gen_l // 1985-2018

* race
cap recode race (1 = 1) (2 = 2) (4 = 3) (6 = 4) (8 = 5) (nonmissing = .)
cap label define rac_l 1 "Indigenous" 2 "White" 3 "Black" 4 "Asian" 5 "Brown", replace
cap label val race rac_l // 2003-2018

* nationality
cap recode nation (10 =  1) ///
	(20 =  2) (21 =  3) (22 =  4) (23 =  5) (24 =  6) (25 =  7) (26 =  8) (27 =  9) (28 = 10) (29 = 11) ///
	(30 = 12) (31 = 13) (32 = 14)           (34 = 15) (35 = 16) (36 = 17) (37 = 18) (38 = 19) (39 = 20) ///
	(40 = 21) (41 = 22) (42 = 23) (43 = 24) (44 = 25) (45 = 26) (46 = 27) (47 = 28) (48 = 29) (49 = 30) ///
	(50 = 31) (51 = 32) ///
	(60 = 33) (61 = 34) (62 = 35) (63 = 36) (64 = 37) ///
	(70 = 38) ///
	(80 = 39) (nonmissing = 39)
cap label define nat_l 1 "Brazil (native)" 2 "Brazil (naturalized)" 3 "Argentina" 4 "Bolivia" 5 "Chile" 6 "Paraguay" 7 "Uruguay" 8 "Venezuela" 9 "Colombia" 10 "Peru" ///
	11 "Ecuador" 12 "Germany" 13 "Belgium" 14 "United Kingdom" 15 "Canada" 16 "Spain" 17 "United States" 18 "France" 19 "Switzerland" 20 "Italy" ///
	21 "Haiti" 22 "Japan" 23 "China" 24 "South Korea" 25 "Russia" 26 "Portugal" 27 "Pakistan" 28 "India" 29 "Rest of Latin America" 30 "Rest of Asia" ///
	31 "Bangladesh" 32 "Rest of Europe" 33 "Angola" 34 "Congo" 35 "South Africa" 36 "Ghana" 37 "Senegal" 38 "Rest of Africa" 39 "Rest of World", replace
cap label val nation nat_l // 1985-2018

* education
cap recode edu (1 = 1) (2 = 2) (3 = 3) (4 = 4) (5 = 5) (6 = 6) (7 = 7) (8 = 8) (9 10 11 = 9) (nonmissing = .) // 10 "Master's degree (17-18 years)" 11 "Doctorate (18+ years)"
cap label define edu_l 1 "Illiterate (0 years)" 2 "Some primary school (1-5 years)" 3 "Primary school degree (5 years)" ///
	4 "Some middle school (6-9 years)" 5 "Middle school degree (9 years)" 6 "Some high school (10-12 years)" ///
	7 "High school degree (12 years)" 8 "Some college (13-15 years)" 9 "Bachelor's or higher degree (16+ years)", replace // 1985-2018
cap label val edu edu_l

* age
cap recode age_group (1 = 1) (2 = 2) (3 = 3) (4 = 4) (5 = 5) (6 = 6) (7 = 7) (8 = 8) (nonmissing = .)
cap label define age_l 1 "<=14" 2 "15-17" 3 "18-24" 4 "25-29" 5 "30-39" 6 "40-49" 7 "50-64" 8 ">=65", replace
cap label val age_group age_l // 1985-2001
// age, 1994-2001 and 2011-2018
cap recode age (-999/0 = .)
// dob, 2002-2010 and 2014-2018
cap recode dob (-99999999/0 = .)

* union membership
cap recode union (0 = 0) (1 = 1) (nonmissing = .)
cap label define uni_l 0 "No" 1 "Yes", replace
cap label val union uni_l // 2017 only

* residence
// muni_worker, 2015-2018
cap recode muni_worker (-999999/109999 540000/. = .)


*** job characteristics
* formation
// hire_date, 2002-2018
cap recode hire_date (-99999999/0 = .)
cap replace hire_date = real("101" + substr(string(hire_date, "%13.0f"), -4, 4)) if hire_date > ${date_max} & hire_date < .
cap replace hire_date = 1010000 + ${year} if hire_date < 1011900
// hire_year, 1985-2001
cap recode hire_year (-9999/${year_minus_100} ${year_plus_1}/. = ${year})
// month_hire, 1985-2001
cap recode month_hire (-99/-1 13/. = 0)
cap label define him_l 0 "Not hired", replace
cap label val month_hire him_l
// cap recode hire_type (1 = 1) (2 = 2) (3 4 = 3) (5/8 = 4) (6/13 = 5) (nonmissing = .)
// cap label define hir_l 1 "New hire" 2 "Poaching" 3 "Internal transfer" 4 "Return" 5 "Public assignment", replace
// cap label val hire_type hir_l // 1994-2018

* occupation code
// occ94_5, 1985-2002
cap recode occ94_5 (-99999/0 100000/. = .) (1 = 99999)
// occ94_5_subs, 2003-2009
cap recode occ94_5_subs (-99999/0 100000/. = .) (1 = 99999)
// occ02_6, 2003-2018
cap recode occ02_6 (-999999/0 1000000/. = .) (1 = 999999)

* pay
// earn_last, 2002-2018
// earn_jan, 2015-2018
// earn_feb, 2015-2018
// earn_mar, 2015-2018
// earn_apr, 2015-2018
// earn_may, 2015-2018
// earn_jun, 2015-2018
// earn_jul, 2015-2018
// earn_aug, 2015-2018
// earn_sep, 2015-2018
// earn_oct, 2015-2018
// earn_nov, 2015-2018
// earn_dec, 1999-2018
// earn_dec_mw, 1985-2018
// earn_contr, 2002-2018
// earn_mean, 1999-2018
// earn_mean_mw, 1985-2018

* hours
// hours, 1994-2018
cap recode hours (-999/-1 169/. = .)

* tenure
// tenure, 1985-2018
cap recode tenure (-9999/-1 = .)
if ${year} < 1994 cap replace tenure = min(ceil(tenure*10 + 0.01), 600)
else cap replace tenure = min(ceil(tenure + 0.01), 600)
cap replace tenure = (${year} - hire_year)*12 + 6 if ${year} > hire_year + 50

* work permit
if inrange($year, 2002, 2010) cap recode permit (2 = 0) (1 = 1) (nonmissing = .)
else cap recode permit (0 = 0) (1 = 1) (nonmissing = .)
cap label define per_l 0 "No" 1 "Yes", replace
cap label val permit per_l // 2001-2018

* disability
cap recode disabil (0 = 0) (1 = 1) (nonmissing = .)
cap label define dab_l 0 "No" 1 "Yes", replace
cap label val disabil dab_l // 2003-2018
cap recode disabil_type (0 = 0) (1 = 1) (2 = 2) (3 = 3) (4 = 4) (5 = 5) (6 = 6) (nonmissing = .)
cap label define dat_l 0 "None" 1 "Physical" 2 "Hearing" 3 "Visual" 4 "Mental" 5 "Multiple" 6 "Rehabilitation", replace
cap label val disabil_type dat_l // 2006-2018
cap replace disabil = 0 if disabil_type == 0
cap replace disabil_type = 0 if disabil == 0

* contract
cap recode contract_type (10 15 20 25 = 1) (30 31 35 = 2) (40 = 3) (50 = 4) (55 = 5) (60 65 70 75 90 95 96 97 = 6) (80 = 7) (nonmissing = .)
cap label define ctt_l 1 "Indefinite" 2 "Public appointment" 3 "Union appointment" 4 "Temporary" 5 "Apprentice" 6 "Fixed-term" 7 "Director", replace
cap label val contract_type ctt_l // 1985-2018
cap recode part_time (0 = 0) (1 = 1) (nonmissing = .)
cap label define ptt_l 0 "No" 1 "Yes", replace
cap label val part_time ptt_l // 2018
cap recode temp_contr (0 = 0) (1 = 1) (nonmissing = .)
cap label define tmp_l 0 "No" 1 "Yes", replace
cap label val temp_contr tmp_l // 2018

* payment frequency
cap recode pay_freq (1 = 1) (2 = 2) (3 = 3) (4 = 4) (5 = 5) (6 = 6) (7 = 7) (nonmissing = .)
cap label define frq_l 1 "Monthly" 2 "Biweekly" 3 "Weekly" 4 "Daily" 5 "Hourly" 6 "One-off" 7 "Other", replace
cap label val pay_freq frq_l // 2002-2018

* absence
cap label define abs_l 0 "Not absent" 1 "Work accident" 2 "Commuting accident" 3 "Work-related illness" 4 "Other illness" 5 "Paternity leave" 6 "Military service" 7 "Unpaid leave", replace
forval i = 1/3 {
	cap recode abs_reason_`i' (10 = 1) (20 = 2) (30 = 3) (40 = 4) (50 = 5) (60 = 6) (70 = 7) (nonmissing = 0) (missing = 0)
	cap label val abs_reason_`i' abs_l // 2007-2018
}
// abs_start_d_1, 2007-2018
cap recode abs_start_d_1 (-99/-1 99 = 0)
// abs_start_d_2, 2007-2018
cap recode abs_start_d_2 (-99/-1 99 = 0)
// abs_start_d_3, 2007-2018
cap recode abs_start_d_3 (-99/-1 99 = 0)
// abs_start_m_1, 2007-2018
cap recode abs_start_m_1 (-99/-1 99 = 0)
// abs_start_m_2, 2007-2018
cap recode abs_start_m_2 (-99/-1 99 = 0)
// abs_start_m_3, 2007-2018
cap recode abs_start_m_3 (-99/-1 99 = 0)
// abs_end_d_1, 2007-2018
cap recode abs_end_d_1 (-99/-1 99 = 0)
// abs_end_d_2, 2007-2018
cap recode abs_end_d_2 (-99/-1 99 = 0)
// abs_end_d_3, 2007-2018
cap recode abs_end_d_3 (-99/-1 99 = 0)
// abs_end_m_1, 2007-2018
cap recode abs_end_m_1 (-99/-1 99 = 0)
// abs_end_m_2, 2007-2018
cap recode abs_end_m_2 (-99/-1 99 = 0)
// abs_end_m_3, 2007-2018
cap recode abs_end_m_3 (-99/-1 99 = 0)
// cap recode abs_dur_1 (-99/-1 = .) (366/. = 365) // 2007-2018
// cap recode abs_dur_2 (-99/-1 = .) (366/. = 365) // 2007-2018
// cap recode abs_dur_3 (-99/-1 = .) (366/. = 365) // 2007-2018


* separation
// sep_reason, 1985-2018
if ${year} < 1994 cap recode sep_reason (2 = 2) (4 = 5) (nonmissing = 13) (missing = 0)
else cap recode sep_reason (0 = 0) (10 = 1) (11 = 2) (12 = 3) (20 = 4) (21 = 5) (22 32 34 = 6) (30 31 = 7) (33 = 8) ///
	(40 50 = 9) (60 62 63 = 10) (72 73 74 75 76 78 79 80 = 11) (90 = 12) (nonmissing = 13) (missing = 0)
cap label define spr_l 0 "Not separated" 1 "Just cause of employer" 2 "Unjust cause of employer" 3 "Expiration" 4 "Just cause of employee" 5 "Unjust cause of employee" 6 "Other assignment (public servant)" ///
	7 "Transfer to other establishment" 8 "Assignment" 9 "Change of labor or military law" 10 "Death" 11 "Retirement" 12 "Mutual agreement" 13 "Other", replace
cap label val sep_reason spr_l
cap replace sep_reason = 0 if (month_sep <= 0 | month_sep >= 13) & sep_reason == 0
// month_sep, 1985-2018
cap recode month_sep (-99/-1 13/. = 0)
cap replace month_sep = 0 if sep_reason == 0 & month_sep == 0
cap label define spm_l 0 "Not separated", replace
cap label val month_sep spm_l

* job active at end of year
// cap recode active_eoy (0 = 0) (1 = 1) (nonmissing = .)
// cap label define aey_l 0 "No" 1 "Yes", replace
// cap label val active_eoy aey_l // 1985-2018


*** employer characteristics
* employer ID
// id_firm, 1985-2018
cap recode id_firm (-999999999999/0 = .)
format id_firm %16.0g
// id_est, 1985-2018
cap recode id_est (-999999999999/0 = .)
format id_est %16.0g
// id_cei, 1999-2018
cap recode id_cei (-999999999999/0 = .)
cap recode id_type (1 = 1) (3 = 2) (nonmissing = .)
cap label define emp_l 1 "CNPJ" 2 "CEI", replace
cap label val id_type emp_l // 1985-2018
cap recode cei_link (0 = 0) (1 = 1) (nonmissing = .)
cap label define cei_l 0 "No" 1 "Yes", replace
cap label val cei_link cei_l // 1999-2018

* location
// muni, 1985-2018
cap recode muni (-999999/109999 540000/. = .) ///
	(119999 = 110001) (129999 = 120001) (139999 = 130002) (149999 = 140002) (159999 = 150010) ///
	(169999 = 160005) (179999 = 170025) (219999 = 210005) (229999 = 220005) (239999 = 230010) ///
	(249999 = 240010) (259999 = 250010) (269999 = 260005) (279999 = 270010) (289999 = 280010) ///
	(299999 = 290010) (319999 = 310010) (329999 = 320010) (339999 = 330010) (359999 = 350010) ///
	(419999 = 410010) (429999 = 420005) (439999 = 430003) (509999 = 500020) (519999 = 510010) (529999 = 520005) (539999 = 530010) ///
	(150475 = 150680) (421265 = 420940) (422000 = 420700) (431453 431454 = 430210) (500627 = 500295)
cap replace muni = 170000 + mod(muni, 10000) if inlist(muni, 522210, 522208, 522120, 522110, 522090, 522080, 522065, 522030, 521840, 521820, 521790, 521780, 521750, 521700, 521670, 521660, 521650, 521620, 521610, 521575, 521510, 521488, 521430, 521420, 521360, 521330, 521320, 521240, 521110, 521070, 521050, 520950, 520930, 520900, 520820, 520770, 520765, 520755, 520730, 520720, 520700, 520610, 520600, 520560, 520550, 520370, 520300, 520290, 520270, 520255, 520240, 520230, 520220, 520210, 520200, 520190, 520100, 520070, 520040)
cap gen byte state = .
cap replace state = floor(muni/10000) if muni > 109999
cap recode state (11 = 1) (12 = 2) (13 = 3) (14 = 4) (15 = 5) (16 = 6) (17 = 7) ///
	(21 = 8) (22 = 9) (23 = 10) (24 = 11) (25 = 12) (26 = 13) (27 = 14) (28 = 15) (29 = 16) ///
	(31 = 17) (32 = 18) (33 = 19) (35 = 20) ///
	(41 = 21) (42 = 22) (43 = 23) ///
	(50 = 24) (51 = 25) (52 = 26) (53 = 27) (nonmissing = .)
cap label var state "State of employer"
cap label define sta_l 1 "Rondonia (RO)" 2 "Acre (AC)" 3 "Amazonas (AM)" 4 "Roraima (RR)" 5 "Para (PA)" 6 "Amapa (AP)" 7 "Tocantins (TO)" ///
	8 "Maranhao (MA)" 9 "Piaui (PI)" 10 "Ceara (CE)" 11 "Rio Grande do Norte (RN)" 12 "Paraiba (PB)" 13 "Pernambuco (PE)" 14 "Alagoas (AL)" 15 "Sergipe (SE)" 16 "Bahia (BA)" ///
	17 "Minas Gerais (MG)" 18 "Espirito Santo (ES)" 19 "Rio de Janeiro (RJ)" 20 "Sao Paulo (SP)" ///
	21 "Parana (PR)" 22 "Santa Catarina (SC)" 23 "Rio Grande do Sul (RS)" ///
	24 "Mato Grosso do Sul (MS)" 25 "Mato Grosso (MT)" 26 "Goias (GO)" 27 "Distrito Federal (DF)", replace
cap label val state sta_l // 1985-2001
// zip_code, 2015-2018
cap recode zip_code (-99999999/0 99999999 = .)

* industry
cap recode ind85_2 (1 = 1) (2 = 2) (3 = 3) (4 = 4) (5 = 5) (6 = 6) (7 = 7) (8 = 8) (9 = 9) (10 = 10) ///
	(11 = 11) (12 = 12) (13 = 13) (14 = 14) (15 = 15) (16 = 16) (17 = 17) (18 = 18) (19 = 19) (20 = 20) ///
	(21 = 21) (22 = 22) (23 = 23) (24 = 24) (25 = 25) (nonmissing = .)
cap n label define ind_l 1 "Mining" 2 "Mineral" 3 "Metal" 4 "Manufacturing" 5 "Electronics, communication" ///
	6 "Automobile" 7 "Wood, furniture" 8 "Paper, publishing, graphic" 9 "Rubber, tobacco, leather" 10 "Chemical, pharmaceutical" ///
	11 "Textile" 12 "Footwear" 13 "Food, beverage" 14 "Utilities" 15 "Construction" ///
	16 "Retail" 17 "Wholesale" 18 "Finance, insurance" 19 "Real estate" 20 "Transport, communication" ///
	21 "Hospitality" 22 "Medical" 23 "Education" 24 "Public administration" 25 "Agriculture", replace
cap label val ind85_2 ind_l // 1985-2001 and 2015-2018
 // ind85_4, 1985-1994
cap recode ind85_4 (-99999/0 10000/. = .) (1 = 9000)
// ind95_5, 1995-2009 and 2010-2018
cap recode ind95_5 (-99999/0 100000/. = .) (1 = 99007)
// ind07_5, 2006-2009 and 2011-2018
cap recode ind07_5 (-99999/0 100000/. = .) (1 = 99008)
// ind07_7, 2006-2018
cap recode ind07_7 (-9999999/0 10000000/. = .) (1/199 = 9900800)

* size
cap confirm var size_est_cat, exact
if !_rc {
	qui sum size_est_cat, meanonly
	if r(min) == 0 & r(max) == 9 replace size_est_cat = size_est_cat + 1
}
cap recode size_est_cat (1 = 1) (2 = 2) (3 = 3) (4 = 4) (5 = 5) (6 = 6) (7 = 7) (8 = 8) (9 = 9) (10 = 10) (nonmissing = .)
cap label define sec_l 1 "0" 2 "1-4" 3 "5-9" 4 "10-19" 5 "20-49" ///
	6 "50-99" 7 "100-249" 8 "250-499" 9 "500-999" 10 ">=1000", replace
cap label val size_est_cat sec_l // 1985-2018

* Simples tax program
cap recode simples (0 = 0) (1 = 1) (nonmissing = .)
cap label define sim_l 0 "No" 1 "Yes", replace
cap label val simples sim_l // 2001-2018

* PAT food program
cap recode pat (0 = 0) (1 = 1) (nonmissing = .)
cap label define pat_l 0 "No" 1 "Yes", replace
cap label val pat pat_l // 2001-2018

* legal form
if ${year} == 1994 cap replace legal_form = . // ALTERNATIVELY: cap recode legal_form (60 70 80 = 1) (20 40 50 = 2) (30 35 90 = 3) (10 = 4) (nonmissing = .) // ( = 5)
else cap recode legal_form (1000/1999 = 1) (2000/2999 = 2) (3000/3999 = 3) (4000/4999 = 4) (5000/5999 = 5) (nonmissing = .)
cap label define leg_l 1 "Public" 2 "Private" 3 "Nonprofit" 4 "Individual" 5 "International", replace
cap label val legal_form leg_l // 1994-2018

********************************************************************************
* FILE NAME:   RAIS_1_READ.do
*
* DESCRIPTION: Reads RAIS data and saves formatted files
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** create folders, if they do not exist already
foreach f in "${DIR_TEMP}" "${DIR_TEMP}" {
	cap confirm file "`f'"
	if _rc {
		!mkdir "`f'"
	}
}


*** read data year-by-year
forval y = $year_min/$year_max {
	
	* macros
	global year = `y'
	if ${header} == 1 global rowrange = "rowrange(1:2)"
	else global rowrange = ""
	
	* create subfolders, if they do not exist already
	foreach f in "${DIR_TEMP}" "${DIR_TEMP}" {
		cap confirm file "`f'/${year}"
		if _rc {
			!mkdir "`f'/${year}"
		}
	}
	
	* delete old text files
	local filename_list_1: dir "${DIR_TEMP}/${year}/" files "*.txt"
	local filename_list_2: dir "${DIR_TEMP}/${year}/" files "*.TXT"
	foreach filename in `filename_list_1' `filename_list_2' {
		cap rm "${DIR_TEMP}/${year}/`filename'"
	}
	
	* decompress files
	if ${header} != 2 do "${DIR_DO}/RAIS_1A_READ_UNZIP.do" ${year} ${year}

	* create file list
	if inlist(${header}, 0, 1) {
		local filename_list_1: dir "${DIR_TEMP}/${year}/" files "*.txt"
		local filename_list_2: dir "${DIR_TEMP}/${year}/" files "*.TXT"
	}
	else if ${header} == 2 {
		local filename_list_1: dir "${DIR_TEMP}/${year}/" files "*_header.dta"
		local filename_list_2 = ""
	}

	* read raw files
	foreach filename in `filename_list_1' `filename_list_2' {
		if inlist(${header}, 0, 1) local filename_short = subinstr(substr("`filename'", 1, length("`filename'") - 4), " ", "", .)
		else if ${header} == 2 local filename_short = subinstr(substr("`filename'", 1, length("`filename'") - 11), " ", "", .)
		cap confirm file "${DIR_TEMP}/${year}/read`filename_short'.dta"
		if (_rc | $reread == 1) & lower(substr("`filename'", 1, 4)) != "estb" ///
			& !($year == 2002 & "`filename_short'" == "SP2002ID1") ///
			& !($year == 2004 & "`filename_short'" == "SP1") { // NOTE: leave out "SP2002ID1" in 2002 and "SP1" in 2004, as those contain more observations than 2001 or 2003!
			disp _newline(1)
			
			* read
			disp "*** Reading file `filename' ***"
			if inlist(${header}, 0, 1) {
				import delim using "${DIR_TEMP}/${year}/`filename'", delim(";") asdouble ${rowrange} clear
				rm "${DIR_TEMP}/${year}/`filename'"
				
				* ensure that dataset is nonempty
				cap assert _N > 0
				if _rc {
					disp as error "USER ERROR: Dataset ${DIR_TEMP}/${year}/`filename' is empty!"
					error 1
				}
				
				* remove accents from variable names and labels
				do "${DIR_DO}/RAIS_1B_READ_ACCENTS.do"
				
				* save
				cap drop nome*
				order *, alpha
				desc
				if ${header} == 0 {
					saveold "${DIR_TEMP}/${year}/raw`filename_short'.dta", version(${saveold_v}) replace
					keep if _n == 0
					saveold "${DIR_TEMP}/${year}/raw`filename_short'_header.dta", version(${saveold_v}) replace
					use "${DIR_TEMP}/${year}/raw`filename_short'.dta", clear
					rm "${DIR_TEMP}/${year}/raw`filename_short'.dta"
				}
				else if ${header} == 1 saveold "${DIR_TEMP}/${year}/raw`filename_short'_header.dta", version(${saveold_v}) replace
			}
			else if ${header} == 2 use "${DIR_TEMP}/${year}/`filename'", clear
			
			* year-specific corrections -- part 1
			if ($year == 2007 & "`filename_short'" == "sudeste07") { // manually correct reading error in observation number 10996761
				local var1 = "diadesl"
				local var2 = "v61"
				local first = 1
				foreach var of varlist `var1' - `var2' {
					if !`first' {
						cap confirm numeric var `var_previous', exact
						local `var_previous'_type = !_rc
						cap confirm numeric var `var', exact
						local `var'_type = !_rc
						if ``var_previous'_type' & !``var'_type' replace `var_previous' = real(`var') if _n == 10996761
						else if ``var'_type' & !``var_previous'_type' replace `var_previous' = string(`var', "%13.0f") if _n == 10996761
						else replace `var_previous' = `var' if _n == 10996761
					}
					local var_previous = "`var'"
					local first = 0
				}
				drop v61
			}
			
			* rename and label variables
			do "${DIR_DO}/RAIS_1C_READ_RENAME.do"
						
			* year-specific corrections -- part 2
			if inrange(${year}, 1985, 2001) { // replace missings with first month of current year
				cap confirm string var month_hire, exact
				local month_hire_str = !_rc
				cap confirm string var hire_year, exact
				local hire_year_str = !_rc
				if `month_hire_str' == 1 & `hire_year_str' == 1 {
					replace month_hire = "1" if strpos(hire_year, "{")
					replace hire_year = "${year}" if strpos(hire_year, "{")
					replace hire_year = string(min(real(hire_year), ${year} - 1), "%5.0f") if month_hire == "0"
				}
				else if `month_hire_str' == 1 & `hire_year_str' == 0 {
					replace month_hire = "1" if hire_year == .
					replace hire_year = ${year} if hire_year == .
					replace hire_year = min(real(hire_year), ${year} - 1) if month_hire == "0"
				}
				else if `month_hire_str' == 0 & `hire_year_str' == 1 {
					replace month_hire = 1 if strpos(hire_year, "{")
					replace hire_year = "${year}" if strpos(hire_year, "{")
					replace hire_year = string(min(real(hire_year), ${year} - 1), "%5.0f") if month_hire == 0
				}
				else if `month_hire_str' == 0 & `hire_year_str' == 0 {
					replace month_hire = 1 if hire_year == .
					replace hire_year = ${year} if hire_year == .
					replace hire_year = min(real(hire_year), ${year} - 1) if month_hire == 0
				}
			}
			if inrange($year, 1985, 1994) {
				cap confirm string var contract_type, exact
				if _rc == 0 replace contract_type = ""
				else if _rc == 7 replace contract_type = .
			}
			if $year == 2002 { // convert string responses into numeric codes
				replace contract_type = "55" if contract_type == "APREND CONTR" // taking these values from the 2002 RAIS data dictionary
				replace contract_type = "40" if contract_type == "AVULSO"
				replace contract_type = "25" if contract_type == "CLT R/PF IND"
				replace contract_type = "20" if contract_type == "CLT R/PJ IND"
				replace contract_type = "65" if contract_type == "CLT U/PF DET"
				replace contract_type = "15" if contract_type == "CLT U/PF IND"
				replace contract_type = "60" if contract_type == "CLT U/PJ DET"
				replace contract_type = "10" if contract_type == "CLT U/PJ IND"
				replace contract_type = "90" if contract_type == "CONT PRZ DET"
				replace contract_type = "95" if contract_type == "CONT TMP DET"
				replace contract_type = "80" if contract_type == "DIRETOR"
				replace contract_type = "35" if contract_type == "ESTAT N/EFET"
				replace contract_type = "30" if contract_type == "ESTATUTARIO"
				replace contract_type = "50" if contract_type == "TEMPORARIO"
			}
			if ${year} >= 2002 {
				foreach date_var in dob hire_date {
					cap confirm var `date_var', exact
					if !_rc {
						* generate date in string format
						gen str8 `date_var'_str = string(`date_var', "%8.0f")
						
						* extract substrings consisting of last 4 and first 4 digits of date string
						gen int `date_var'_y_1 = real(substr(`date_var'_str, -4, 4))
						replace `date_var'_y_1 = . if !inrange(`date_var'_y_1, ${year} - 110, ${year})
						gen int `date_var'_y_2 = real(substr(`date_var'_str, 1, 4))
						replace `date_var'_y_2 = . if !inrange(`date_var'_y_2, ${year} - 110, ${year}) | `date_var'_y_1 < .
						
						* construct year from 4-digit date substrings
						gen int `date_var'_y = `date_var'_y_1 if inrange(`date_var'_y_1, ${year} - 110, ${year})
						replace `date_var'_y = `date_var'_y_2 if inrange(`date_var'_y_2, ${year} - 110, ${year}) & `date_var'_y == .
						if "`date_var'" == "hire_date" replace `date_var'_y =  ${year} if `date_var'_y == .
						
						* construct month from date strings (only for hire_date)
						if "`date_var'" == "hire_date"  {
							gen byte `date_var'_m = real(substr(`date_var'_str, 3, 2)) if `date_var'_y_1 < . & strlen(`date_var'_str) == 8
							replace `date_var'_m = real(substr(`date_var'_str, 2, 2)) if `date_var'_y_1 < . & strlen(`date_var'_str) == 7
							replace `date_var'_m = real(substr(`date_var'_str, 5, 2)) if `date_var'_y_2 < .
							replace `date_var'_m = 1 if !inrange(`date_var'_m, 1, 12)
						}
						
						* construct day from date strings
// 						gen byte `date_var'_d = real(substr(`date_var'_str, 1, 2)) if `date_var'_y_1 < . & strlen(`date_var'_str) == 8
// 						replace `date_var'_d = real(substr(`date_var'_str, 1, 1)) if `date_var'_y_1 < . & strlen(`date_var'_str) == 7
// 						replace `date_var'_d = real(substr(`date_var'_str, -2, 2)) if `date_var'_y_2 < .
// 						replace `date_var'_d = 1 if !inrange(`date_var'_d, 1, 31)
						
						* drop date variables that are no longer needed
						drop `date_var'_str `date_var'_y_1 `date_var'_y_2
						
						* create missing variables from date strings extracted above
						if "`date_var'" == "dob" { // create age
							cap gen int age = ${year} - dob_y // already exists from 2014-2018
							label var age "Age (years)" // adding 2002-2010 and 2014-2018 to 1994-2001 and 2011-2018 (overlap from 2014-2018)
							drop dob_y
						}
						else if "`date_var'" == "hire_date" { // create hire_year and month_hire
							rename hire_date_y hire_year
							label var hire_year "Year job started" // adding 2002-2018 to 1985-2001
							rename hire_date_m month_hire
							label var month_hire "Month job started" // adding 2002-2018 to 1985-2001
						}
// 						drop `date_var'_d
					drop `date_var'
					}
				}
			}
			
			* destring variables
			do "${DIR_DO}/RAIS_1D_READ_DESTRING.do"
			
			* recode and label values
			do "${DIR_DO}/RAIS_1E_READ_LABEL.do"
			
			* drop variables not needed for now
			foreach var in cei_link disabil_type legal_form permit temp_contr zip_code id_type { // also dropped in RAIS_1C_READ_RENAME.do: ind07_5, hire_type, occ94_5 (2011-2018) earn_last, abs_dur
				cap drop `var'
			}
			
			* order variables
			global varlist_ordered = ""
			foreach var in id_pers_pis id_pers_cpf id_pers_ctps gender race nation edu age_group age union muni_worker year_immigr id_firm id_est id_cei state muni ind85_4 ind85_2 ind95_5 ind07_5 ind07_7 size_est simples pat hire_year month_hire month_sep sep_reason occ94_5 occ94_5_subs occ02_6 earn_jan earn_feb earn_mar earn_apr earn_may earn_jun earn_jul earn_aug earn_sep earn_oct earn_nov earn_dec earn_dec_mw earn_contr earn_mean earn_mean_mw hours tenure disabil contract_type part_time pay_freq abs_reason_1 abs_reason_2 abs_reason_3 abs_start_d_1 abs_start_d_2 abs_start_d_3 abs_start_m_1 abs_start_m_2 abs_start_m_3 abs_end_d_1 abs_end_d_2 abs_end_d_3 abs_end_m_1 abs_end_m_2 abs_end_m_3 {
				cap confirm var `var', exact
				if !_rc global varlist_ordered = "${varlist_ordered} `var'"
			}
			order ${varlist_ordered}
			
			* save
			compress
			saveold "${DIR_TEMP}/${year}/read`filename_short'.dta", version(${saveold_v}) replace
		}
		else if ($year == 2002 & "`filename_short'" == "SP2002ID1") ///
			| ($year == 2004 & "`filename_short'" == "SP1") {
			if inlist(${header}, 0, 1) rm "${DIR_TEMP}/${year}/`filename'"
		}
	}
	
	* append state-year files
	clear
	local filename_list: dir "${DIR_TEMP}/${year}/" files "read*.dta"	
	foreach filename of local filename_list {
		if "`filename'" != "read${year}.dta" {
			qui append using "${DIR_TEMP}/${year}/`filename'", force	
			rm "${DIR_TEMP}/${year}/`filename'"
		}
	}
	
	* clean variables
	// --> year
	gen int year = `y'
	label var year "Year"
	
	// --> person IDs
	if `y' < 2002 keep if id_pers_pis < .
	else keep if id_pers_pis < . | id_pers_cpf < . | id_pers_ctps < .
	
	// --> gender
	
	// --> race
	
	// --> nationality
	
	// --> education
	
	// --> age
	
	// --> immigration year
	
	// --> employer IDs
	if `y' >= 1999 {
		replace id_est = id_cei if id_est == .
		drop id_cei
	}
	replace id_est = id_pers_pis if id_est == .
	if `y' >= 2002 {
		replace id_est = id_pers_cpf if id_est == .
		replace id_est = id_pers_ctps if id_est == .
	}
	keep if id_est < . | id_firm < .	
	tostring id_est, format(%16.0g) generate(id_est_str) // replace id_firm with first six digits of id_est if id_est is longer than 6 digits, or else with all of id_est
	replace id_firm = real(substr(id_est_str, 1, length(id_est_str) - 6)) if id_firm == . // Note: CNPJ number consists of 14 digits: 8 firm ID digits, 4 establishment ID digits, and 2 check digits
	replace id_firm = id_est if id_firm == .
	drop id_est_str
	replace id_est = id_firm if id_est == .
	
	// --> employer ID type
	
	// --> state
	
	// --> municipality
	
	// --> industry
	if `y' >= 2006 {
		gen long ind07_5 = floor(ind07_7/100)
		label var ind07_5 "Industry code (5 digits, CNAE 2.0 2007)"
		drop ind07_7
	}
	
	// --> establishment size category
	
	// --> indicator: employer participates in Simples tax program
	
	// --> indicator: employer participates in PAT food program
	
	// --> hire year // check 2011 and pre-2002?
	replace hire_year = year if hire_year > year
	
	// --> hire month // check 2011 and pre-2002?
	replace month_hire = 0 if hire_year < year
	
	// --> separation month
	replace month_sep = month_hire if month_sep < month_hire & month_sep > 0 & hire_year == year
	
	// --> reason for separation
	
	// --> indicator: job active at end of year
	
	// --> occupation
	
	// --> earnings
	// NOTE:
	// 1992-2000: earnings capped at 120*current minimum wage
	// 2001-2014: earnings capped at 150*current minimum wage

	// --> contractual work hours
	
	// --> tenure // check values (x10?) pre-1994
	
	// --> indicator: worker has disability
	
	// --> indicator: part-time contract
	
	// --> reasons for absence
	
	// --> days when absence started
	if `y' >= 2007 {
		forval i = 1/3 {
			replace abs_start_d_`i' = abs_end_d_`i' if abs_start_d_`i' > abs_end_d_`i' & abs_start_m_`i' == abs_end_m_`i'
		}
	}
	
	// --> months when absences started
	if `y' >= 2007 {
		forval i = 1/3 {
			replace abs_start_m_`i' = abs_end_m_`i' if abs_start_m_`i' > abs_end_m_`i'
		}
	}
	
	// --> days when absence ended
	
	// --> months when absences ended
	
	// --> number of days absent
	if `y' >= 2007 {
		forval i = 1/3 {
			gen int abs_dur_`i' = min(floor((abs_end_m_`i' - abs_start_m_`i')*30.5 + (abs_end_d_`i' - abs_start_d_`i')), 365) if abs_end_m_`i' < . & abs_start_m_`i' < . & abs_end_d_`i' < . & abs_start_d_`i' < .
			replace abs_dur_`i' = 0 if abs_dur_`i' == . | abs_reason_`i' == 0
			label var abs_dur_`i' "Duration of absence `i' (days)"
			drop abs_start_m_`i' abs_end_m_`i' abs_start_d_`i' abs_end_d_`i'
		}
	}
	
	// --> occupation
	
	* save
	compress
// 	COMPLETE VARIABLE LIST: year id_pers_pis id_pers_cpf id_pers_ctps gender race nation year_immigr edu age_group age union muni_worker id_firm id_est state muni ind85_4 ind85_2 ind95_5 ind07_5 size_est_cat simples pat hire_year month_hire month_sep sep_reason occ94_5 occ94_5_subs occ02_6 earn_jan earn_feb earn_mar earn_apr earn_may earn_jun earn_jul earn_aug earn_sep earn_oct earn_nov earn_dec earn_dec_mw earn_contr earn_mean earn_mean_mw hours tenure disabil contract_type part_time pay_freq abs_reason_1 abs_reason_2 abs_reason_3 abs_dur_1 abs_dur_2 abs_dur_3
	global varlist_ordered = ""
	foreach var in year id_pers_pis id_pers_cpf id_pers_ctps gender race nation year_immigr edu age_group age union muni_worker id_firm id_est state muni ind85_4 ind85_2 ind95_5 ind07_5 size_est_cat simples pat hire_year month_hire month_sep sep_reason occ94_5 occ94_5_subs occ02_6 earn_jan earn_feb earn_mar earn_apr earn_may earn_jun earn_jul earn_aug earn_sep earn_oct earn_nov earn_dec earn_dec_mw earn_contr earn_mean earn_mean_mw hours tenure disabil contract_type part_time pay_freq abs_reason_1 abs_reason_2 abs_reason_3 abs_dur_1 abs_dur_2 abs_dur_3 {
		cap confirm var `var', exact
		if !_rc global varlist_ordered = "${varlist_ordered} `var'"
	}
	order ${varlist_ordered}
	saveold "${DIR_TEMP}/${year}/read${year}.dta", version(${saveold_v}) replace
}

disp "DONE!"

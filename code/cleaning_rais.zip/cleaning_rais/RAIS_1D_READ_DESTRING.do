********************************************************************************
* FILE NAME:   RAIS_1D_READ_DESTRING.do
*
* DESCRIPTION: Converts string variables into numeric variables
*
* AUTHORS:     Iacopo Morchio (University of Bristol)
*              Christian Moser (Columbia University)
*
* DATE:        November 4, 2025
********************************************************************************


*** destring all variables
foreach var of varlist * {
	cap confirm string var `var', exact
	if !_rc {
		* replace string 'missing' placeholders with missing string
		replace `var' = "" if inlist(`var', "-1", "-9", "-99")
		
		* preliminary string conversion
		if "`var'" == "gender" {
			replace gender = "1" if strpos(lower(gender), "mas") // if lower(substr(gender, 1, 3)) == "mas"
			replace gender = "2" if strpos(lower(gender), "fem") // if lower(substr(gender, 1, 3)) == "fem"
		}
		else if strpos("`var'", "month") {
			local month_counter = 1
			foreach month in "jan" "fev" "mar" "abr" "mai" "jun" "jul" "ago" "set" "out" "nov" "dez" {
				replace `var' = "`month_counter'" if strlower(substr(`var', 1, 3)) == "`month'"
				local ++month_counter
			}
		}
		else if "`var'" == "muni" & strlower(substr("`filename'", 1, 8)) == "ignorado" {
			cap confirm string var muni, exact
			if !_rc replace muni = ""
			else replace muni = .
		}
		
		* define destring exceptions and comma-decimal treatment
		if "`var'" == "dob" | strpos("`var'", "date") {
			global ignore_str = ",.;:-_EOXeox"
			global comma_dec = ""
		}
		else if strpos("`var'", "day") | strpos("`var'", "month") | strpos("`var'", "year") {
			global ignore_str = ",./;:-_"
			global comma_dec = ""
		}
		else if substr("`var'", 1, 3) == "occ" & substr("`var'", 6, 1) == "_" {
			global ignore_str = "CBOLXcbolx,./;:-_"
			global comma_dec = ""
		}
		else if substr("`var'", 1, 3) == "ind" & substr("`var'", 6, 1) == "_" {
			global ignore_str = "CLASNEclasne,./;:-_"
			global comma_dec = ""
		}
		else {
			global ignore_str = "./;:-_"
			global comma_dec = "dpcomma"
		}
		
		* destring
		destring `var', generate(`var'_num) ignore("${ignore_str}") ${comma_dec} force
		
		* report strings that were converted into missing during destringing
		qui count if `var'_num == . & `var' != ""
		if r(N) > 0 {
			disp "--> WARNING: DESTRINGING VARIABLE `var' RESULTED IN MISSING OBSERVATIONS! LIST OF NONSTANDARD VALUES:"
			tab `var' if `var'_num == . & !inlist(`var', "{ñ", "{ñ c", "{n", "{n c"), m
		}
		drop `var'
		rename `var'_num `var'
	}
	
	* replace numeric 'missing' placeholders with missing number
	else replace `var' = . if inlist(`var', -1, -9, -99)
}
